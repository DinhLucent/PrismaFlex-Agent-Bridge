"""
PrismaFlex Central Station API
================================
Lean routing module. All business logic lives in services/.

Architecture:
    main.py (this file) â†’ Routes only
    services/database.py â†’ SQLite operations
    services/ws_manager.py â†’ WebSocket broadcast
    services/alarm_service.py â†’ Smart alarm debouncing
    services/event_service.py â†’ Parameter tracking & trends
"""
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Body, Request, Response
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from typing import Dict, Any
import logging
from logging.handlers import RotatingFileHandler, QueueHandler, QueueListener
import queue
import sys
import os
import random
import sqlite3
from datetime import datetime, timezone, timedelta
import asyncio
import dateutil.parser
import time

# 1. Add Project Root to Python Path (Critical for importing prismaflex_lib)
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from prismaflex_lib import ReferenceDatabase

from services import TrendDatabase, ConnectionManager, SmartAlarmService, EventService
from services.treatment import TreatmentDatabase, TreatmentRecorderService, TreatmentSnapshotService, RawDataStreamer
from services.treatment.historical_backfill_importer import HistoricalBackfillImporter
from services.treatment.telemetry_filter import TelemetryFilter

# â”€â”€â”€ Logging â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
LOGS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), 'logs'))
os.makedirs(LOGS_DIR, exist_ok=True)

# Standard Formatter
log_formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s')

# 1. Console Handler (General Info)
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(log_formatter)

# 2. Main System Log (Rotating)
main_handler = RotatingFileHandler(
    os.path.join(LOGS_DIR, 'backend.log'),
    maxBytes=5 * 1024 * 1024, backupCount=5, encoding='utf-8'
)
main_handler.setLevel(logging.INFO)
main_handler.setFormatter(log_formatter)

# 3. Error Log (Rotating)
error_handler = RotatingFileHandler(
    os.path.join(LOGS_DIR, 'errors.log'),
    maxBytes=5 * 1024 * 1024, backupCount=5, encoding='utf-8'
)
error_handler.setLevel(logging.ERROR)
error_handler.setFormatter(log_formatter)

# 4. Audit Log (Rotating - Clinical Actions)
audit_handler = RotatingFileHandler(
    os.path.join(LOGS_DIR, 'audit.log'),
    maxBytes=10 * 1024 * 1024, backupCount=10, encoding='utf-8'
)
audit_handler.setFormatter(logging.Formatter('%(asctime)s [AUDIT] %(message)s'))

# 5. Frontend Log (Rotating)
frontend_handler = RotatingFileHandler(
    os.path.join(LOGS_DIR, 'frontend.log'),
    maxBytes=5 * 1024 * 1024, backupCount=5, encoding='utf-8'
)
frontend_handler.setFormatter(log_formatter)

# 6. Replay Status Log (Rotating)
replay_handler = RotatingFileHandler(
    os.path.join(LOGS_DIR, 'replay_status.log'),
    maxBytes=2 * 1024 * 1024, backupCount=2, encoding='utf-8'
)
replay_handler.setFormatter(log_formatter)

# Root Configuration
logging.basicConfig(
    level=logging.INFO,
    handlers=[console_handler, main_handler, error_handler, replay_handler]
)

logger = logging.getLogger("PrismaFlexBackend")

# Dedicated Loggers
audit_logger = logging.getLogger("PrismaFlexAudit")
audit_logger.addHandler(audit_handler)
audit_logger.propagate = False

frontend_logger = logging.getLogger("PrismaFlexFrontend")
frontend_logger.addHandler(frontend_handler)
frontend_logger.propagate = False

# Performance logger for high-frequency metrics (Clinical Grade: Async & Non-blocking)
perf_logger = logging.getLogger("PrismaFlexPerformance")
perf_logger.setLevel(logging.INFO)
perf_log_path = os.path.join(LOGS_DIR, 'performance.log')

# 1. The actual file writer (RotatingFileHandler) 
file_perf_handler = RotatingFileHandler(
    perf_log_path, 
    maxBytes=5 * 1024 * 1024, # 5MB limit
    backupCount=3, encoding='utf-8' # Keep 3 older files
)
file_perf_handler.setFormatter(logging.Formatter('%(asctime)s,%(message)s'))

# 2. The Async Bridge (Queue and Handler)
log_queue = queue.Queue(-1)  # Infinite queue size for safety
queue_handler = QueueHandler(log_queue)
perf_logger.addHandler(queue_handler)

# 3. The Log Worker (Listener) - starts writing from queue to file in a background thread
log_listener = QueueListener(log_queue, file_perf_handler)

# â”€â”€â”€ App â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# â”€â”€â”€ Initialize Services â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

# â”€â”€â”€ Initialize Services â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

# Reference Database (read-only, for parameter enrichment)
ref_db_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'prismaflex_reference.db'))
try:
    if os.path.exists(ref_db_path):
        logger.info(f"Found Reference DB at: {ref_db_path}")
        ref_db = ReferenceDatabase(ref_db_path)
    else:
        logger.error(f"Could not find prismaflex_reference.db at: {ref_db_path}")
        ref_db = None
except Exception as e:
    logger.error(f"Error loading Reference Database: {e}")
    ref_db = None

# Core Services (singleton instances)
db = TrendDatabase()
manager = ConnectionManager()
alarm_svc = SmartAlarmService(db)
event_svc = EventService(db)

# Wire up session reset: when patient/treatment changes, also clear alarm cache
def _on_session_reset(device_id: str):
    if device_id in alarm_svc._active_alarms:
        del alarm_svc._active_alarms[device_id]
    if device_id in alarm_svc._pending_clears:
        del alarm_svc._pending_clears[device_id]

event_svc.on_session_reset = _on_session_reset

# â”€â”€â”€ In-Memory State & Constants â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
REALTIME_THRESHOLD_SECONDS = 25
device_last_timestamps: Dict[str, datetime] = {}
device_last_broadcast: Dict[str, datetime] = {}

# Step 02: Device Mode Lock — ensures one device = one mode at a time
device_mode_registry: Dict[str, str] = {}

# â”€â”€â”€ Lifecycle â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Modern Clinical-Grade Lifecycle Management.
    Ensures all queues, workers, and log listeners start/stop in order.
    """
    # 1. Initialize Split Queues (Step 02: Live/Backfill separation)
    app.state.live_queue = asyncio.Queue(maxsize=10000)
    app.state.backfill_queue = asyncio.Queue(maxsize=5000)
    # Legacy alias for backward compatibility
    app.state.telemetry_queue = app.state.live_queue

    # 2. Treatment Services
    app.state.treat_db = TreatmentDatabase()
    app.state.streamer = RawDataStreamer()

    # LIVE services (stateful)
    app.state.recorder = TreatmentRecorderService(app.state.treat_db, app.state.streamer)
    app.state.snapshot_svc = TreatmentSnapshotService(app.state.treat_db)

    # Wire lifecycle: when a treatment closes, flush snapshot cache + close raw stream
    def _on_treatment_close(device_id: str, treatment_id: str):
        try:
            app.state.snapshot_svc.flush_device(device_id)
        except Exception as e:
            logger.error(f"on_close flush_device error: {e}")
        # streamer.close_treatment is async — schedule it
        try:
            asyncio.ensure_future(
                app.state.streamer.close_treatment(device_id, treatment_id)
            )
        except Exception as e:
            logger.error(f"on_close close_treatment error: {e}")
        try:
            app.state.backfill_importer.flush_device(device_id)
        except Exception as e:
            logger.error(f"on_close backfill flush error: {e}")
    app.state.recorder.on_close = _on_treatment_close

    # BACKFILL services (stateless)
    app.state.backfill_importer = HistoricalBackfillImporter(app.state.treat_db)

    # 3. Start split workers
    app.state.live_workers = [
        asyncio.create_task(live_worker(app)) for _ in range(4)
    ]
    app.state.backfill_workers = [
        asyncio.create_task(backfill_worker(app)) for _ in range(2)
    ]

    # 4. Start Async Logger
    log_listener.start()

    # 5. Start Heartbeat
    app.state.heartbeat = asyncio.create_task(heartbeat_task())

    yield

    # --- Shutdown ---
    print("[LIFESPAN] Stopping Systems...", flush=True)

    # Task D3: Flush all backfill importer caches on shutdown
    try:
        if hasattr(app.state, 'backfill_importer'):
            logger.info("[LIFESPAN] Flushing backfill importer caches...")
            app.state.backfill_importer.flush_all()
    except Exception as e:
        logger.error(f"[LIFESPAN] Error flushing backfill caches: {e}")

    for worker in app.state.live_workers:
        worker.cancel()
    for worker in app.state.backfill_workers:
        worker.cancel()
    app.state.heartbeat.cancel()
    log_listener.stop()
    db.close()

# â”€â”€â”€ App â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
app = FastAPI(
    title="PrismaFlex Central Station API",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


async def heartbeat_task():
    """Broadcast server time and run periodic maintenance."""
    counter = 0
    while True:
        try:
            now = datetime.now(timezone(timedelta(hours=7)))
            await manager.broadcast({
                "type": "HEARTBEAT",
                "server_time": now.isoformat()
            })
            
            # Clinical Grade: Run session cleanup every 60 seconds
            counter += 1
            if counter >= 60:
                counter = 0
                if hasattr(app.state, 'recorder'):
                    app.state.recorder.enforce_auto_close()
                
                # Cleanup stale device locks (devices not seen in >1h)
                stale_keys = [k for k in _device_processing_locks
                              if k not in device_last_timestamps
                              or (now - device_last_timestamps[k]).total_seconds() > 3600]
                for k in stale_keys:
                    _device_processing_locks.pop(k, None)
                    
        except Exception as e:
            logger.error(f"Heartbeat maintenance error: {e}")
        await asyncio.sleep(1.0)


# Per-device locks: serialize processing for same device_id across workers
_device_processing_locks: dict[str, asyncio.Lock] = {}

def normalize_device_id(raw: Any) -> str:
    """Normalize PrismaFlex machine ids so every path uses PF_XXX."""
    text = str(raw or "").strip()
    if not text or text.lower() == "unknown":
        return "unknown"

    upper = text.upper()
    if upper.startswith("PF_"):
        suffix = upper[3:].strip()
        return f"PF_{int(suffix):03d}" if suffix.isdigit() else upper

    if text.isdigit():
        return f"PF_{int(text):03d}"

    return text

def _get_device_lock(device_id: str) -> asyncio.Lock:
    if device_id not in _device_processing_locks:
        _device_processing_locks[device_id] = asyncio.Lock()
    return _device_processing_locks[device_id]


async def live_worker(app: FastAPI):
    """
    Step 02: LIVE Worker — processes real-time telemetry.
    Handles: enrichment, websocket, alarm, recorder, snapshot, event tracking.
    """
    queue = app.state.live_queue
    while True:
        try:
            qsize = queue.qsize()
            if qsize > 7000:
                logger.warning(f"High Live Queue Load: {qsize} packets pending!")
            
            job = await queue.get()
            t_start = job['t_start']
            data = job['data']
            
            meta = data.setdefault("meta", {})
            header = data.get("s_header", data.get("header", {}))
            body = data.get("s_body", data.get("body", {}))
            device_id = normalize_device_id(meta.get("device_id") or header.get("machine_id") or "unknown")
            meta["device_id"] = device_id
            timestamp_str = meta.get("timestamp") or header.get("timestamp") or datetime.now(timezone.utc).isoformat()
            
            async with _get_device_lock(device_id):
                t_logic_start = time.perf_counter()
            
                # 1. Enrichment & Alarm Processing
                active_alarms = []
                if ref_db:
                    for key in ["therapy_type_id", "therapy_status_id"]:
                        val = header.get(key)
                        if val is not None:
                            if "type" in key:
                                header[f"{key}_name"] = ref_db.get_therapy_type(val)
                            elif "status" in key:
                                header[f"{key}_name"] = ref_db.get_therapy_status(val)

                    params_list = body.get("parameters") or []
                    for p in params_list:
                        pid = p.get("id")
                        pval = p.get("value")
                        rec_type = p.get("type", "Actual")

                        if rec_type == "Alarm" and pval in [1, 2]:
                            alarm_info = ref_db.get_alarm_info(pid)
                            if alarm_info:
                                state = "PRESENT" if pval == 1 else "OVERRIDDEN"
                                active_alarms.append({
                                    "id": pid, "title": alarm_info["title"],
                                    "description": alarm_info["description"],
                                    "severity": alarm_info["severity"],
                                    "category": alarm_info["category"], "state": state
                                })
                        else:
                            info = ref_db.get_parameter_info(pid)
                            if info:
                                ptype, pname, _, _, pmap, _, _ = info
                                p["label"] = pname
                                if ptype == 2 and pmap and pval in pmap:
                                    p["value_text"] = pmap[pval]

                data["active_alarms"] = active_alarms
                
                # 2. WebSocket Broadcast (LIVE ONLY)
                now_t = datetime.now()
                last_broadcast = device_last_broadcast.get(device_id)
                should_broadcast_full = (last_broadcast is None or 
                                        (now_t - last_broadcast).total_seconds() > 10)
                
                t_ws_start = time.perf_counter()
                if should_broadcast_full:
                    asyncio.create_task(manager.broadcast({
                        "type": "TELEMETRY_UPDATE",
                        "payload": data,
                        "quality_status": job.get('quality_info')
                    }))
                    device_last_broadcast[device_id] = now_t
                
                t_ws_end = time.perf_counter()

                # 3. Treatment Recording (LIVE ONLY — stateful session)
                treatment_id = await app.state.recorder.process_packet(
                    device_id, timestamp_str, header, body, meta, is_live=True
                )

                # 4. Snapshot Projection
                if treatment_id:
                    try:
                        await asyncio.to_thread(
                            app.state.snapshot_svc.process_packet,
                            device_id, timestamp_str, treatment_id, header, body
                        )
                    except Exception as snap_err:
                        logger.error(f"SNAPSHOT CRASH [{device_id}]: {snap_err}", exc_info=True)

                # 5. Trends & Alarms (LIVE ONLY)
                t_db_start = time.perf_counter()
                params_list = body.get("parameters") or []
                await asyncio.to_thread(event_svc.save_trend_point, device_id, timestamp_str, params_list)
                await asyncio.to_thread(
                    alarm_svc.process, device_id, active_alarms, timestamp_str,
                    str(header.get("patient_id", "Unknown"))
                )
                
                # 6. Event Tracking & Order-Change (LIVE ONLY)
                changes = await asyncio.to_thread(event_svc.track_parameter_changes, device_id, timestamp_str, header, body)
                if changes:
                    await manager.broadcast({
                        "type": "EVENT_UPDATE",
                        "device_id": device_id,
                        "changes": [
                            {"param_id": pid, "old_value": old_val, "new_value": new_val,
                             "timestamp": datetime.now(timezone(timedelta(hours=7))).isoformat()}
                            for pid, old_val, new_val in changes
                        ]
                    })

                    if treatment_id:
                        order_pids = {17, 21, 18, 19, 22, 25}
                        order_changes = [(pid, old, new) for pid, old, new in changes if pid in order_pids]
                        if order_changes:
                            await asyncio.to_thread(
                                app.state.snapshot_svc.save_order_change_snapshot,
                                device_id, timestamp_str, order_changes
                            )
                
                # Auto-Prune (Low frequency)
                if random.randint(1, 250) == 1:
                    await asyncio.to_thread(db.prune)
                    
                t_db_end = time.perf_counter()
                
                t_total = time.perf_counter() - t_start
                log_msg = f"{device_id},{t_total*1000:.2f},{(t_db_end-t_db_start)*1000:.2f},{(t_ws_end-t_ws_start)*1000:.2f},LIVE"
                perf_logger.info(log_msg)
                logger.info(f"[LIVE] {device_id}: {log_msg}")
            
            queue.task_done()

        except Exception as e:
            logger.error(f"Live worker error: {e}")
            await asyncio.sleep(0.1)


async def backfill_worker(app: FastAPI):
    """
    Step 02: BACKFILL Worker — processes historical replay packets.
    Handles: snapshot projection ONLY. No websocket, alarm, event, or live recorder.
    """
    queue = app.state.backfill_queue
    importer = app.state.backfill_importer
    while True:
        try:
            qsize = queue.qsize()
            if qsize > 3500:
                logger.warning(f"High Backfill Queue Load: {qsize} packets pending!")

            job = await queue.get()
            t_start = job['t_start']
            data = job['data']
            # Task C3: Use pre-resolved packet time from route
            pkt_time = job['pkt_time']

            meta = data.setdefault("meta", {})
            header = data.get("s_header", data.get("header", {}))
            body = data.get("s_body", data.get("body", {}))
            device_id = normalize_device_id(meta.get("device_id") or header.get("machine_id") or "unknown")
            meta["device_id"] = device_id

            async with _get_device_lock(device_id):
                # 1. Use recorder for backfill session management
                #    (creates/resumes treatment with is_live=False)
                #    Task C3: Pass pre-resolved pkt_time (datetime)
                treatment_id = await app.state.recorder.process_packet(
                    device_id, pkt_time, header, body, meta, is_live=False
                )

                # 2. Snapshot Projection via dedicated BackfillImporter
                if treatment_id:
                    try:
                        # Get treatment start time from recorder's backfill sessions
                        backfill_session = app.state.recorder._backfill_sessions.get(device_id)
                        if backfill_session:
                            start_time = backfill_session.start_pkt_time
                        else:
                            # Fallback: parse from DB
                            t_row = app.state.treat_db.get_treatment_by_id(treatment_id)
                            # Task C3: ensure start_time is also GMT+7 aware if fallback
                            start_time = app.state.recorder._parse_time(t_row['start_time']) if t_row else pkt_time

                        await asyncio.to_thread(
                            importer.process_packet,
                            treatment_id, device_id, pkt_time, start_time, body
                        )
                    except Exception as snap_err:
                        logger.error(f"[BACKFILL] SNAPSHOT CRASH [{device_id}]: {snap_err}", exc_info=True)

                # NO websocket, NO alarm, NO event tracking, NO trend storage

                t_total = time.perf_counter() - t_start
                logger.debug(f"[BACKFILL] {device_id}: {t_total*1000:.2f}ms")

            queue.task_done()

        except Exception as e:
            logger.error(f"Backfill worker error: {e}")
            await asyncio.sleep(0.1)


# ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
#  HELPER FUNCTIONS
# ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

def _parse_time_fallback(timestamp_str: str) -> datetime:
    """Task C1: Standalone parsing logic fallback for when recorder is not ready."""
    local_tz = timezone(timedelta(hours=7))
    try:
        ts = str(timestamp_str).strip()
        if ts.endswith(' UTC'):
            ts = ts.replace(' UTC', '')
            return dateutil.parser.parse(ts).replace(tzinfo=local_tz)
        if ts.endswith('Z'):
            ts = ts[:-1]
            return dateutil.parser.parse(ts).replace(tzinfo=local_tz)
        dt = dateutil.parser.parse(ts)
        return dt.replace(tzinfo=local_tz) if dt.tzinfo is None else dt.astimezone(local_tz)
    except Exception:
        return datetime.now(local_tz)

def resolve_packet_time(data: dict) -> tuple[datetime, str, Any]:
    """
    Task C1: Unified packet-time resolver.
    Precedence: meta.timestamp_unix > meta.timestamp > header.timestamp
    PrismaFlex timestamp_unix carries machine wall-clock time mislabeled as UTC.
    Returns (resolved_datetime, source_name, raw_value).
    """
    local_tz = timezone(timedelta(hours=7))
    meta = data.get("meta", {})
    header = data.get("s_header") or data.get("header", {})

    # helper for parsing strings
    def parse_str(s):
        try:
            if hasattr(app.state, 'recorder'):
                return app.state.recorder._parse_time(s)
        except Exception: pass
        return _parse_time_fallback(s)

    # 1. Try meta.timestamp_unix (highest precedence)
    ts_unix = meta.get("timestamp_unix")
    if ts_unix is not None:
        try:
            val = float(ts_unix)
            orig_val = val
            if val > 1e12: val /= 1000.0
            # PrismaFlex decoder stores the machine wall-clock as an epoch and
            # labels it UTC. Preserve the wall-clock, then tag it as GMT+7.
            wall_clock = datetime.fromtimestamp(val, tz=timezone.utc).replace(tzinfo=None)
            dt = wall_clock.replace(tzinfo=local_tz)
            return dt, "meta.timestamp_unix", orig_val
        except (ValueError, TypeError):
            pass

    # 2. Try meta.timestamp
    ts_meta = meta.get("timestamp")
    if ts_meta:
        return parse_str(ts_meta), "meta.timestamp", ts_meta

    # 3. Try header.timestamp
    ts_header = header.get("timestamp")
    if ts_header:
        return parse_str(ts_header), "header.timestamp", ts_header

    # Fallback to now
    return datetime.now(local_tz), "fallback.now", "N/A"


def calculate_data_quality(packet_timestamp_str: str) -> dict:
    """Compare packet time vs server time to determine LIVE or DELAYED."""
    try:
        # PrismaFlex Machine Timestamp Handling:
        # The decoder labels machine timestamps as "UTC", but the machine clock
        # is actually set to local time (GMT+7). Strip the fake UTC marker.
        local_tz = timezone(timedelta(hours=7))
        ts = packet_timestamp_str.strip()
        
        if ts.endswith(' UTC'):
            ts = ts.replace(' UTC', '')
            pkt_time = dateutil.parser.parse(ts)
            pkt_time = pkt_time.replace(tzinfo=local_tz)
        elif ts.endswith('Z'):
            ts = ts[:-1]
            pkt_time = dateutil.parser.parse(ts)
            pkt_time = pkt_time.replace(tzinfo=local_tz)
        else:
            pkt_time = dateutil.parser.parse(ts)
            if pkt_time.tzinfo is None:
                pkt_time = pkt_time.replace(tzinfo=local_tz)
            else:
                pkt_time = pkt_time.astimezone(local_tz)

        server_now = datetime.now(local_tz)
        latency = (server_now - pkt_time).total_seconds()

        quality = "LIVE" if latency <= REALTIME_THRESHOLD_SECONDS else "DELAYED"
        return {"quality": quality, "latency_sec": round(latency, 2), "server_time": server_now.isoformat()}
    except Exception as e:
        logger.warning(f"Time parsing error for '{packet_timestamp_str}': {e}")
        return {"quality": "UNKNOWN", "latency_sec": 0, "error": str(e)}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
#  ROUTES
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/")
async def health_check():
    return {"status": "online", "service": "PrismaFlex Backend", "time": datetime.now(timezone.utc).isoformat()}


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)


# â”€â”€â”€ Telemetry Ingestion â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
 
@app.post("/api/v1/telemetry")
# ─── Step 02: Split Telemetry Routes ────────────────────────────────────────

@app.post("/api/v1/devices/reset-modes")
async def reset_device_modes():
    """Clear in-memory device mode registry. Use after DB reset without restarting backend."""
    count = len(device_mode_registry)
    device_mode_registry.clear()
    logged_replay_contracts.clear()
    logger.info(f"Device mode registry cleared ({count} entries)")
    return {"status": "ok", "cleared": count}

@app.post("/api/v1/telemetry/live")
async def receive_live(request: Request, data: Dict[str, Any] = Body(...)):
    """LIVE telemetry from Mirth Live Channel."""
    t_start = time.perf_counter()
    try:
        meta = data.setdefault("meta", {})
        header = data.get("s_header") or data.get("header", {})
        device_id = normalize_device_id(meta.get("device_id") or header.get("machine_id") or "unknown")
        meta["device_id"] = device_id
        pkt_time_str = meta.get("timestamp") or header.get("timestamp") or datetime.now(timezone.utc).isoformat()

        if device_mode_registry.get(device_id) == "BACKFILL":
            return JSONResponse(status_code=409, content={
                "error": "DEVICE_MODE_CONFLICT",
                "detail": f"{device_id} is currently in BACKFILL mode"
            })
        device_mode_registry[device_id] = "LIVE"

        quality_info = calculate_data_quality(pkt_time_str)
        fast_pkt = TelemetryFilter.extract_dashboard_packet(data)
        asyncio.create_task(manager.broadcast({
            "type": "TELEMETRY_FAST_UPDATE",
            "payload": fast_pkt
        }))

        await request.app.state.live_queue.put({
            "t_start": t_start,
            "data": data,
            "quality_info": quality_info
        })
        return {"status": "queued", "mode": "live"}

    except Exception as e:
        logger.error(f"Live ingestion error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


logged_replay_contracts = set()

@app.post("/api/v1/telemetry/backfill")
async def receive_backfill(request: Request, data: Dict[str, Any] = Body(...)):
    """Historical replay from Mirth Backfill Channel."""
    t_start = time.perf_counter()
    try:
        meta = data.setdefault("meta", {})
        header = data.get("s_header") or data.get("header", {})
        device_id = normalize_device_id(meta.get("device_id") or header.get("machine_id") or "unknown")
        meta["device_id"] = device_id

        if device_mode_registry.get(device_id) == "LIVE":
            return JSONResponse(status_code=409, content={
                "error": "DEVICE_MODE_CONFLICT",
                "detail": f"{device_id} is currently in LIVE mode"
            })
        device_mode_registry[device_id] = "BACKFILL"

        # Task C2: Resolve time using contract and log once
        pkt_time, source, raw_val = resolve_packet_time(data)
        if device_id not in logged_replay_contracts:
            logger.info(f"📜 [BACKFILL] Replay Parsing Contract [{device_id}]: "
                        f"source={source}, raw={raw_val}, resolved={pkt_time.isoformat()}")
            logged_replay_contracts.add(device_id)

        await request.app.state.backfill_queue.put({
            "t_start": t_start,
            "data": data,
            "pkt_time": pkt_time # Task C3 candidate: pass resolved time to worker
        })
        return {"status": "queued", "mode": "backfill"}

    except Exception as e:
        logger.error(f"Backfill ingestion error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/telemetry")
async def receive_telemetry(request: Request, data: Dict[str, Any] = Body(...)):
    """Legacy endpoint — auto-routes to live or backfill based on meta.mode."""
    meta = data.get("meta", {})
    mode = meta.get("mode", "").upper()
    if mode == "BACKFILL":
        return await receive_backfill(request, data)
    else:
        return await receive_live(request, data)


# ─── Device Mode Management (Step 02) ───────────────────────────────────────

@app.post("/api/v1/devices/{device_id}/mode")
async def set_device_mode(device_id: str, data: Dict[str, Any] = Body(...)):
    """Admin endpoint to switch device mode."""
    device_id = normalize_device_id(device_id)
    mode = data.get("mode", "").upper()
    if mode not in ("LIVE", "BACKFILL", "RESET"):
        raise HTTPException(400, "mode must be LIVE, BACKFILL, or RESET")
    if mode == "RESET":
        device_mode_registry.pop(device_id, None)
    else:
        device_mode_registry[device_id] = mode
    return {"device_id": device_id, "mode": device_mode_registry.get(device_id, "NONE")}


@app.get("/api/v1/devices/mode")
async def get_all_device_modes():
    """View current mode lock for all devices."""
    return device_mode_registry


@app.post("/api/v1/devices/{device_id}/handoff")
async def device_handoff(device_id: str, data: Dict[str, Any] = Body(...)):
    """
    Step 04: Safe handoff from BACKFILL → LIVE.
    Flushes importer cache, closes backfill session, resets mode lock.
    """
    device_id = normalize_device_id(device_id)
    from_mode = data.get("from", "").upper()
    to_mode = data.get("to", "").upper()

    if from_mode != "BACKFILL" or to_mode != "LIVE":
        raise HTTPException(400, "Only BACKFILL → LIVE handoff is supported")

    current = device_mode_registry.get(device_id)
    if current != "BACKFILL":
        raise HTTPException(409, f"{device_id} is not in BACKFILL mode (current: {current or 'NONE'})")

    result = {"device_id": device_id, "steps": []}

    # 1. Flush importer batch cache for this device
    try:
        flushed = await asyncio.to_thread(
            app.state.backfill_importer.flush_device, device_id
        )
        result["steps"].append(f"Flushed {flushed} treatment(s) from importer cache")
    except Exception as e:
        logger.error(f"Handoff flush error [{device_id}]: {e}")
        result["steps"].append(f"Flush error: {e}")

    # 2. Close backfill session in recorder
    try:
        bf_session = app.state.recorder._backfill_sessions.get(device_id)
        if bf_session:
            app.state.recorder._close(
                device_id, bf_session,
                bf_session.last_seen.isoformat(),
                "HANDOFF: Operator switched to LIVE",
                app.state.recorder._backfill_sessions
            )
            result["steps"].append(f"Closed backfill session {bf_session.treatment_id[:8]}")
        else:
            result["steps"].append("No active backfill session to close")
    except Exception as e:
        logger.error(f"Handoff session close error [{device_id}]: {e}")
        result["steps"].append(f"Session close error: {e}")

    # 3. Switch mode lock to LIVE
    device_mode_registry[device_id] = "LIVE"
    result["steps"].append("Mode switched to LIVE")
    result["mode"] = "LIVE"

    logger.info(f"[HANDOFF] {device_id}: BACKFILL → LIVE completed. Steps: {result['steps']}")
    return result

# â”€â”€â”€ Device Data Endpoints â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@app.get("/api/v1/devices/{device_id}/trends")
async def get_device_trends(device_id: str, limit: int = 500):
    """Get last 24h of pressure trends for charts."""
    try:
        device_id = normalize_device_id(device_id)
        return await asyncio.to_thread(db.get_trends, device_id, limit)
    except Exception as e:
        logger.error(f"Fetch trend error: {e}")
        return []


@app.get("/api/v1/devices/{device_id}/events")
async def get_device_events(device_id: str):
    """Get parameter changes in the last 1 hour ("Was" logic)."""
    try:
        device_id = normalize_device_id(device_id)
        return await asyncio.to_thread(db.get_events, device_id)
    except Exception as e:
        logger.error(f"Fetch events error: {e}")
        return []


@app.get("/api/v1/devices/{device_id}/alarm_history")
async def get_device_alarm_history(device_id: str):
    """Get debounced alarm history."""
    try:
        device_id = normalize_device_id(device_id)
        return await asyncio.to_thread(db.get_alarm_history, device_id)
    except Exception as e:
        logger.error(f"Fetch alarm history error: {e}")
        return []

# â”€â”€â”€ Client Error Reporting â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@app.post("/api/v1/client-errors")
async def log_client_error(data: Dict[str, Any] = Body(...)):
    """Receives silent frontend crashes and writes them to a rotating file."""
    try:
        error_msg = data.get("error", "Unknown Error")
        stack_trace = data.get("stack", "No stack trace provided")
        url = data.get("url", "Unknown URL")
        user_agent = data.get("userAgent", "Unknown Browser")

        frontend_logger.error(
            f"[FRONTEND_CRASH] URL: {url} | Browser: {user_agent} | Error: {error_msg}\nStack: {stack_trace}"
        )
        return {"status": "recorded"}
    except Exception as e:
        logger.error(f"Failed to record client error: {e}")
        return {"status": "error", "message": "Internal log failure"}


# â”€â”€â”€ Feedback Endpoints â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@app.get("/api/v1/feedback")
async def get_feedback():
    try:
        return db.get_all_feedback()
    except Exception as e:
        logger.error(f"Fetch feedback error: {e}")
        return []


@app.post("/api/v1/feedback")
async def submit_feedback(data: Dict[str, Any] = Body(...)):
    try:
        fid = data.get("id") or str(int(datetime.now(timezone(timedelta(hours=7))).timestamp() * 1000))
        user = data.get("user", "Anonymous Medical Staff")
        content = data.get("content", "")
        timestamp = data.get("timestamp") or datetime.now(timezone(timedelta(hours=7))).strftime("%d/%m/%Y, %H:%M:%S")
        status = data.get("status", "received")

        db.insert_feedback(fid, user, content, timestamp, status)
        return {"status": "success", "id": fid}
    except Exception as e:
        logger.error(f"Submit feedback error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/v1/feedback/{feedback_id}")
async def delete_feedback(feedback_id: str, request: Request):
    require_role(request, ['admin'])
    try:
        db.delete_feedback(feedback_id)
        audit_logger.info(f"Feedback {feedback_id} DELETED by admin")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Delete feedback error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.patch("/api/v1/feedback/{feedback_id}/status")
async def update_feedback_status(feedback_id: str, request: Request, data: Dict[str, Any] = Body(...)):
    require_role(request, ['admin'])
    try:
        new_status = data.get("status")
        if not new_status:
            raise HTTPException(status_code=400, detail="Status is required")
        db.update_feedback_status(feedback_id, new_status)
        audit_logger.info(f"Feedback {feedback_id} status updated to '{new_status}' by admin")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Update feedback status error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# â”€â”€â”€ Clinical Reference Search â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@app.get("/api/v1/reference/search")
async def search_reference(query: str = "", category: str = "all"):
    """Search numerical parameters, enumerative parameters, and alarms."""
    try:
        results = []
        q = f"%{query.lower()}%"
        logger.info(f"Searching clinical reference for: '{query}' (cat: {category})")

        conn = sqlite3.connect(ref_db_path)
        try:
            c = conn.cursor()

            if category in ["all", "parameters"]:
                c.execute("""SELECT id, name, description, unit, min_value, max_value 
                             FROM numerical_parameters 
                             WHERE LOWER(name) LIKE ? OR LOWER(description) LIKE ? OR CAST(id AS TEXT) LIKE ?""", (q, q, q))
                for r in c.fetchall():
                    results.append({
                        "id": r[0], "type": "Numerical Parameter", "title": r[1],
                        "description": r[2] or "No description available.",
                        "detail": f"Range: {r[4]} - {r[5]} {r[3]}" if r[4] is not None else f"Unit: {r[3]}",
                        "category": "Parameter"
                    })

                c.execute("""SELECT id, name, description FROM enumerative_parameters 
                             WHERE LOWER(name) LIKE ? OR LOWER(description) LIKE ? OR CAST(id AS TEXT) LIKE ?""", (q, q, q))
                for r in c.fetchall():
                    results.append({
                        "id": r[0], "type": "Enumerative Parameter", "title": r[1],
                        "description": r[2] or "No description available.",
                        "detail": "Categorical selection", "category": "Parameter"
                    })

            if category in ["all", "alarms"]:
                c.execute("""SELECT id, title, description, severity FROM alarms 
                             WHERE LOWER(title) LIKE ? OR LOWER(description) LIKE ? OR CAST(id AS TEXT) LIKE ?""", (q, q, q))
                for r in c.fetchall():
                    results.append({
                        "id": r[0], "type": "Alarm / Alert", "title": r[1],
                        "description": r[2] or "No description available.",
                        "detail": f"Severity: {r[3]}", "category": "Alarm"
                    })
        finally:
            conn.close()
        logger.info(f"âœ… Search complete. Total results: {len(results)}")
        return results
    except Exception as e:
        logger.error(f"Reference search error: {e}")
        return []


# â”€â”€â”€ TREATMENT ROUTES (Modularized) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
from routers.treatment_router import router as treatment_router, require_role
from routers.treatment_command_router import router as command_router
app.include_router(treatment_router)
app.include_router(command_router)






# â”€â”€â”€ Entry Point â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

# Trigger Reload: Updated SQLAlchemy Models for Dashboard Projection
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

