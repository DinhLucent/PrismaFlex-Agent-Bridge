@echo off
setlocal
cd /d "%~dp0"
title ICU-B CONNECT - STOP SYSTEM

where pm2 >nul 2>&1
if %errorlevel% neq 0 (
    echo PM2 not found.
    exit /b 1
)

call pm2 stop icub-backend >nul 2>&1
call pm2 stop icub-frontend >nul 2>&1
call pm2 delete icub-backend >nul 2>&1
call pm2 delete icub-frontend >nul 2>&1
call pm2 status
exit /b 0
