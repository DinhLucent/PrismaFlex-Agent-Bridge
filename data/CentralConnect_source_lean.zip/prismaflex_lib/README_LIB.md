
# PrismaFlex High-Performance Decoding Library

Đây là thư viện Python chuyên dụng để giải mã gói tin từ máy lọc máu **PrismaFlex**. Được thiết kế tối ưu cho hiệu năng cao (High Performance) và độ ổn định (Robustness), thư viện này có thể xử lý hàng nghìn gói tin mỗi giây với độ chính xác tuyệt đối.

## 📦 Cài Đặt

Chỉ cần copy thư mục `prismaflex_lib` vào dự án của bạn.
Thư viện yêu cầu: `Python 3.7+` (Không cần pip install thêm gói ngoài, chỉ dùng Standard Library).

## 🚀 Tính Năng Chính

*   **⚡ Siêu Tốc Độ:** Sử dụng cấu trúc dữ liệu `tuple` và `__slots__` để đạt tốc độ giải mã **< 0.05ms** mỗi gói tin.
*   **🔍 Giải Mã Raw Hex:** Hỗ trợ cả JSON đã tiền xử lý và chuỗi **Raw Hex** trực tiếp từ thiết bị.
*   **🛡️ An Toàn & Chi Tiết:** Tự động kiểm tra tính hợp lệ (`Validation`) của dữ liệu dựa trên giới hạn Min/Max trong Database.
*   **🎯 Truy Vấn Chọn Lọc:** Hỗ trợ chỉ giải mã một vài tham số cần thiết (`decode_specific`) để tiết kiệm tài nguyên CPU.
*   **Phân Loại Dữ Liệu:** Tự động nhận diện loại dữ liệu: **Actual** (Thực tế), **Alarm** (Cảnh báo), **Set** (Cài đặt).
*   **Thông Tin Header Đầy Đủ:** Giải mã chi tiết phiên bản phần mềm (`SW8.20...`), Patient ID, Serial Number...

## 📖 Hướng Dẫn Sử Dụng (Quick Start)

### 1. Khởi Tạo

```python
import os
from prismaflex_lib import ReferenceDatabase, PrismaFlexDecoder, PrismaFlexUnpacker

# Đường dẫn đến file DB đi kèm thư viện
db_path = os.path.join("prismaflex_lib", "prismaflex_reference.db")

# Khởi tạo (Chỉ làm 1 lần duy nhất khi app bật)
ref_db = ReferenceDatabase(db_path)
decoder = PrismaFlexDecoder(ref_db)
unpacker = PrismaFlexUnpacker()
```

### 2. Giải Mã Từ Raw Hex String

```python
# Chuỗi hex nhận được từ TCP/Serial port
raw_hex = "020083f70700..." 

# Bước 1: Unpack (Hex -> Cấu trúc điển hình)
data_dict = unpacker.unpack(raw_hex)

# Bước 2: Decode (Cấu trúc -> Dữ liệu có ý nghĩa)
packet = decoder.decode(data_dict)

# Bước 3: Sử dụng
print(f"Máy đang ở trạng thái: {packet.header.therapy_status}")
print(f"Phiên bản PM: {packet.header.sw_version}")

# Duyệt qua các tham số
for param in packet.parameters:
    print(f"{param.name}: {param.value} {param.unit or ''}")
```

### 3. Giải Mã Chọn Lọc (Siêu Nhanh)

Dùng khi bạn chỉ muốn vẽ biểu đồ cho áp suất (Pressure) và bỏ qua hàng trăm thông số khác.

```python
# Danh sách ID cần lấy (Ví dụ: 1=Access, 2=Filter, 3=Effluent)
target_ids = [1, 2, 3]

# Trả về Dictionary {ID: ParameterObject}
results = decoder.decode_specific(data_dict, target_ids)

# Truy xuất cực nhanh O(1)
access_pressure = results.get(1)
if access_pressure and access_pressure.is_valid:
    print(f"Access Pressure: {access_pressure.value}")
else:
    print("Dữ liệu lỗi hoặc không tồn tại!")
```

## 📂 Cấu Trúc Thư Viện

*   `__init__.py`: Interface chính, export các class cần thiết.
*   `decoder.py`: Chứa logic giải mã (Decode), Validation và các Class chứa dữ liệu (`DecodedPacket`).
*   `reference_db.py`: Quản lý Database tham chiếu, tối ưu hóa việc tra cứu bằng RAM.
*   `unpacker.py`: Xử lý cắt chuỗi Hex thô, phân tích bit/byte, giải mã Header và Patient ID.
*   `prismaflex_reference.db`: Cơ sở dữ liệu SQLite chứa định nghĩa toàn bộ tham số máy.

## ⚠️ Lưu Ý Quan Trọng

1.  **Database:** File `prismaflex_reference.db` phải luôn đi kèm với thư viện. Nếu file này bị xóa hoặc lỗi, thư viện sẽ không hoạt động.
2.  **Thread Safety:** Các class `PrismaFlexDecoder` và `PrismaFlexUnpacker` hoàn toàn **Thread-Safe** (an toàn khi dùng đa luồng) vì chúng chỉ *đọc* dữ liệu, không ghi đè trạng thái nội tại.
