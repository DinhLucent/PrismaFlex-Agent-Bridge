
import sqlite3
import os
import logging
from typing import Dict, Any, Optional, Tuple, Union

# Parameter Types Constants
PARAM_TYPE_NUMERICAL = 1
PARAM_TYPE_ENUMERATIVE = 2
PARAM_TYPE_UNKNOWN = 0

class ReferenceDatabase:
    """
    High-performance, in-memory lookup for PrismaFlex reference data.
    """
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.logger = logging.getLogger(__name__)
        
        # Tuple format: (type, name, desc, unit, enum_map, min_val, max_val)
        self._param_lookup: Dict[int, Tuple[int, str, str, Optional[str], Optional[Dict[int, str]], Union[float, int, None], Union[float, int, None]]] = {}
        
        self._therapy_types: Dict[int, str] = {}
        self._therapy_statuses: Dict[int, str] = {}
        self._alarms: Dict[int, Dict[str, str]] = {}
        
        if not os.path.exists(db_path):
            raise FileNotFoundError(f"Database file not found: {db_path}")

        self._load_data()

    def _load_data(self) -> None:
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            # 1. Load Numerical Parameters and Limits
            cursor.execute("SELECT id, name, description, unit, min_value, max_value FROM numerical_parameters")
            for row in cursor.fetchall():
                self._param_lookup[row['id']] = (
                    PARAM_TYPE_NUMERICAL, 
                    row['name'], 
                    row['description'], 
                    row['unit'], 
                    None,
                    row['min_value'], # Limit Min
                    row['max_value']  # Limit Max
                )

            # 2. Load Enumerative Parameters
            cursor.execute("SELECT id, name, description, min_value, max_value FROM enumerative_parameters")
            enum_params = cursor.fetchall()

            cursor.execute("SELECT parameter_id, value, meaning FROM enumerative_values")
            enum_values_raw = cursor.fetchall()
            
            enum_val_map: Dict[int, Dict[int, str]] = {}
            for row in enum_values_raw:
                pid, val, meaning = row['parameter_id'], row['value'], row['meaning']
                if pid not in enum_val_map:
                    enum_val_map[pid] = {}
                enum_val_map[pid][val] = meaning

            for row in enum_params:
                pid = row['id']
                self._param_lookup[pid] = (
                    PARAM_TYPE_ENUMERATIVE,
                    row['name'],
                    row['description'],
                    None,
                    enum_val_map.get(pid, {}),
                    row['min_value'],
                    row['max_value']
                )

            # 3. Load Therapy Info
            cursor.execute("SELECT id, name FROM therapy_types")
            for row in cursor.fetchall():
                self._therapy_types[row['id']] = row['name']

            cursor.execute("SELECT id, name FROM therapy_statuses")
            for row in cursor.fetchall():
                self._therapy_statuses[row['id']] = row['name']

            # 4. Load Alerts from 'alarms' table
            try:
                cursor.execute("SELECT id, name, title, description, severity FROM alarms")
                for row in cursor.fetchall():
                    # Map the severity string (WARNING, MALFUNCTION, etc.) to category
                    # Ensure uppercase for consistent frontend matching
                    severity = (row['severity'] or "ALARM").upper()
                    self._alarms[row['id']] = {
                        "name": row['name'],
                        "title": row['title'],
                        "description": row['description'],
                        "severity": severity, 
                        "category": severity
                    }
            except sqlite3.Error as e:
                self.logger.warning(f"Could not load alerts from alarms table: {e}")

            conn.close()
            
        except sqlite3.Error as e:
            self.logger.error(f"SQLite error: {e}")
            raise

    def get_parameter_info(self, param_id: int):
        return self._param_lookup.get(param_id)

    def get_therapy_type(self, type_id: int) -> str:
        return self._therapy_types.get(type_id, "Unknown")

    def get_therapy_status(self, status_id: int) -> str:
        return self._therapy_statuses.get(status_id, "Unknown")
        
    def get_alarm_info(self, alarm_id: int) -> Optional[Dict[str, str]]:
        return self._alarms.get(alarm_id)
