
import struct
import logging
from datetime import datetime, timedelta, timezone
from typing import Dict, Any, List

class PrismaFlexUnpacker:
    """
    Parses raw hex string data from PrismaFlex devices into a structured dictionary
    compatible with PrismaFlexDecoder.
    """
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self._local_tz = timezone(timedelta(hours=7))
        self._local_epoch = datetime(1970, 1, 1, tzinfo=self._local_tz)

    def unpack(self, raw_hex: str) -> Dict[str, Any]:
        """
        Converts a hex string into the intermediate dictionary format (s_header, s_body).
        """
        try:
            raw_hex = raw_hex.strip()
            data = bytes.fromhex(raw_hex)
            
            if len(data) < 124:
                raise ValueError(f"Data too short ({len(data)}) to contain valid header (124 bytes)")

            header_struct = struct.unpack('<HHHHIIII80sIIIII', data[:124])
            
            stx = header_struct[0] 
            crc = header_struct[1] 
            machine_id = header_struct[2]
            clinical_sw = header_struct[3]
            msg_counter = header_struct[4]
            cmd_code = header_struct[5]
            total_records = header_struct[6]
            flags = header_struct[7]
            raw_pid = header_struct[8]
            
            # Enhanced Patient ID Decoding (4-byte stride)
            patient_id = self._decode_patient_id(raw_pid)
            
            # Enhanced SW Version Decoding
            sw_rev_raw = header_struct[9]
            sw_version_str = self._decode_sw_version(sw_rev_raw)
            
            therapy_type_id = header_struct[10]
            therapy_status_id = header_struct[11]
            timestamp_unix = header_struct[12]
            body_len = header_struct[13]

            s_header = {
                "stx": f"0x{stx:04X}",
                "crc": f"0x{crc:04X}",
                "clinical_sw_id": f"0x{clinical_sw:04X}",
                "message_counter": msg_counter,
                "command_code": f"0x{cmd_code:08X}",
                "flags": f"0x{flags:08X}",
                "machine_id": machine_id,
                "patient_id": patient_id,
                "sw_revision_hex": f"0x{sw_rev_raw:08X}",
                "sw_version": sw_version_str,
                "therapy_type_id": therapy_type_id,
                "therapy_status_id": therapy_status_id,
                "timestamp_unix": timestamp_unix,
                "timestamp": self._format_timestamp(timestamp_unix),
                "message_info": total_records,
                "body_length_bytes": body_len
            }

            # Body Parsing
            parameters = []
            offset = 124 
            records_count = 0
            
            while offset + 12 <= len(data):
                rec_struct = struct.unpack('<IIi', data[offset:offset+12])
                
                param_code = rec_struct[0]
                p_time = rec_struct[1]
                p_val = rec_struct[2]
                
                # Enhanced Parameter Logic: Masking
                # Check flags in High bits
                record_type = "Actual"
                true_param_id = param_code
                
                if param_code & 0x80000000:
                    record_type = "Alarm"
                    true_param_id = param_code & 0x7FFFFFFF
                elif param_code & 0x40000000:
                    record_type = "Set"
                    true_param_id = param_code & 0x3FFFFFFF
                else:
                    # Remove any other high bits if they are just noise, or keep simple?
                    # The reference code does: param_id = param_code & 0x00FFFFFF for 'else'?
                    # Actually reference does: param_id = param_code & 0x00FFFFFF AT START.
                    # Then OVERWRITES param_id if Alarm/Set bits are present.
                    # Let's follow that logic.
                    true_param_id = param_code & 0x00FFFFFF

                parameters.append({
                    "id": true_param_id, # The clean ID for DB lookup
                    "id_hex": f"0x{true_param_id:06X}",
                    "original_code_hex": f"0x{param_code:08X}",
                    "type": record_type,
                    "value": p_val,
                    "record_time": p_time
                })
                
                offset += 12
                records_count += 1
                
                if records_count >= total_records:
                    break

            s_body = {
                "total_records": total_records,
                "parameters": parameters
            }

            return {
                "s_header": s_header,
                "s_body": s_body
            }

        except Exception as e:
            self.logger.error(f"Unpack error: {e}")
            raise

    def _decode_patient_id(self, pat_id_bytes: bytes) -> str:
        pat_id = ''
        for i in range(0, len(pat_id_bytes), 4):
            char_bytes = pat_id_bytes[i:i+4]
            try:
                char = struct.unpack('<I', char_bytes)[0]
                if 0 < char <= 0x10FFFF:
                    pat_id += chr(char)
            except:
                continue
        return pat_id or 'N/A'

    def _parse_sw_decimal(self, n: int):
        s = str(n).zfill(7)
        a_str = s[:-6] or "0"
        A = int(a_str)
        B = int(s[-6:-4])
        C = int(s[-4:-2])
        D = int(s[-2:])
        return f"SW{A}.{B:02d}V{C:02d}R{D:02d}", (A, B, C, D)

    def _decode_sw_version(self, sw_revision: int) -> str:
        # Candidate 1: direct
        v1, p1 = self._parse_sw_decimal(sw_revision)
        
        # Candidate 2: swapped endian
        h = f"{sw_revision:08x}"[-8:]
        try:
            swapped = int(h[6:8] + h[4:6] + h[2:4] + h[0:2], 16)
            v2, p2 = self._parse_sw_decimal(swapped)
        except ValueError:
            return v1 # Fallback
            
        # Rank by 'A' value (major version)
        def rank(parts):
            a, b, c, d = parts
            return (0 if a <= 99 else 1, a)
            
        return v1 if rank(p1) <= rank(p2) else v2

    def _format_timestamp(self, ts):
        try:
            return (self._local_epoch + timedelta(seconds=ts)).isoformat()
        except:
            return "Invalid Timestamp"
