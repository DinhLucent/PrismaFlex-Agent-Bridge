
from typing import Dict, List, Any, Optional, Tuple, Union
from .reference_db import ReferenceDatabase, PARAM_TYPE_NUMERICAL, PARAM_TYPE_ENUMERATIVE

class DecodedParameter:
    """
    Memory-optimized structure with Validation logic.
    """
    __slots__ = ('id', 'name', 'value', 'unit', 'description', 'meaning', 'type', 'is_valid', 'validation_message', 'record_type')

    def __init__(self, pid: int, name: str, value: Any, 
                 unit: Optional[str] = None, 
                 description: str = "", 
                 meaning: Optional[str] = None, 
                 p_type: str = "Unknown",
                 is_valid: bool = True,
                 validation_message: Optional[str] = None,
                 record_type: str = "Actual"):
        self.id = pid
        self.name = name
        self.value = value
        self.unit = unit
        self.description = description
        self.meaning = meaning
        self.type = p_type # e.g. "Numerical", "Enumerative"
        self.is_valid = is_valid
        self.validation_message = validation_message
        self.record_type = record_type # e.g. "Actual", "Alarm", "Set"

    def __repr__(self):
        val_str = str(self.value)
        if self.unit: val_str += f" {self.unit}"
        if not self.is_valid: val_str += f" [INVALID: {self.validation_message}]"
        return f"<Param {self.id} '{self.name}': {val_str} ({self.record_type})>"


class DecodedHeader:
    __slots__ = ('machine_id', 'patient_id', 'timestamp', 'therapy_type', 'therapy_status')

    def __init__(self, machine_id: int, patient_id: str, timestamp: str, 
                 therapy_type: str, therapy_status: str):
        self.machine_id = machine_id
        self.patient_id = patient_id
        self.timestamp = timestamp
        self.therapy_type = therapy_type
        self.therapy_status = therapy_status


class DecodedPacket:
    __slots__ = ('header', 'parameters', 'raw_json')

    def __init__(self, header: DecodedHeader, parameters: List[DecodedParameter], raw_json: Dict[str, Any]):
        self.header = header
        self.parameters = parameters
        self.raw_json = raw_json


class PrismaFlexDecoder:
    def __init__(self, db: ReferenceDatabase):
        self.db = db

    def _validate_value(self, val: Any, min_val: Union[int, float, None], max_val: Union[int, float, None]) -> Tuple[bool, Optional[str]]:
        """Helper to validate constraints."""
        if val is None:
            return False, "Value is None"
            
        try:
            # Simple numeric checks
            if min_val is not None and val < min_val:
                return False, f"Value {val} < Min {min_val}"
            if max_val is not None and val > max_val:
                return False, f"Value {val} > Max {max_val}"
        except (TypeError, ValueError):
            return False, "Type mismatch for numeric check"
            
        return True, None

    def decode(self, json_data: Dict[str, Any]) -> DecodedPacket:
        s_header = json_data.get('s_header')
        
        if s_header:
            header = DecodedHeader(
                machine_id=s_header.get('machine_id', -1),
                patient_id=s_header.get('patient_id', "Unknown"),
                timestamp=s_header.get('timestamp', ""),
                therapy_type=self.db.get_therapy_type(s_header.get('therapy_type_id')),
                therapy_status=self.db.get_therapy_status(s_header.get('therapy_status_id'))
            )
        else:
            header = DecodedHeader(-1, "Unknown", "", "Unknown", "Unknown")

        decoded_params = []
        s_body = json_data.get('s_body')
        
        if s_body:
            params_list = s_body.get('parameters', [])
            get_param_info = self.db.get_parameter_info
            
            for p in params_list:
                pid = p.get('id')
                val = p.get('value')
                # Get record type from unpacked data, default to Actual if missing (legacy json)
                rec_type = p.get('type', 'Actual') 
                
                info = get_param_info(pid)
                
                if info:
                    p_type, name, desc, unit, enum_map, min_v, max_v = info
                    is_valid, msg = self._validate_value(val, min_v, max_v)
                    
                    if p_type == PARAM_TYPE_NUMERICAL:
                        decoded_params.append(DecodedParameter(
                            pid, name, val, unit, desc, None, "Numerical", is_valid, msg, rec_type
                        ))
                    elif p_type == PARAM_TYPE_ENUMERATIVE:
                        meaning = enum_map.get(val, "Unknown Value") if enum_map else "Unknown Value"
                        decoded_params.append(DecodedParameter(
                            pid, name, val, None, desc, meaning, "Enumerative", is_valid, msg, rec_type
                        ))
                    else:
                        decoded_params.append(DecodedParameter(pid, name, val, None, desc, None, "Unknown", True, None, rec_type))
                else:
                    decoded_params.append(DecodedParameter(
                        pid, f"Unknown_ID_{pid}", val, None, "Not found in database", None, "Unknown", False, "ID not in DB", rec_type
                    ))
                    
        return DecodedPacket(header, decoded_params, json_data)

    def decode_header(self, json_data: Dict[str, Any]) -> DecodedHeader:
        s_header = json_data.get('s_header')
        if s_header:
            return DecodedHeader(
                machine_id=s_header.get('machine_id', -1),
                patient_id=s_header.get('patient_id', "Unknown"),
                timestamp=s_header.get('timestamp', ""),
                therapy_type=self.db.get_therapy_type(s_header.get('therapy_type_id')),
                therapy_status=self.db.get_therapy_status(s_header.get('therapy_status_id'))
            )
        return DecodedHeader(-1, "Unknown", "", "Unknown", "Unknown")

    def decode_specific(self, json_data: Dict[str, Any], target_ids: List[int]) -> Dict[int, Optional[DecodedParameter]]:
        """
        Returns a DICTIONARY mapping ID -> DecodedParameter.
        If an ID is requested but missing in the packet, the value in the dict will be None.
        This allows easy checking for missing data.
        """
        # Initialize result with None for all targets to detect missing keys effectively
        results: Dict[int, Optional[DecodedParameter]] = {tid: None for tid in target_ids}
        target_set = set(target_ids)
        
        s_body = json_data.get('s_body')
        if not s_body:
            return results
            
        params_list = s_body.get('parameters', [])
        get_param_info = self.db.get_parameter_info
        
        for p in params_list:
            pid = p.get('id')
            
            if pid in target_set:
                val = p.get('value')
                rec_type = p.get('type', 'Actual')

                info = get_param_info(pid)
                
                param_obj = None
                
                if info:
                    p_type, name, desc, unit, enum_map, min_v, max_v = info
                    is_valid, msg = self._validate_value(val, min_v, max_v)
                    
                    if p_type == PARAM_TYPE_NUMERICAL:
                        param_obj = DecodedParameter(pid, name, val, unit, desc, None, "Numerical", is_valid, msg, rec_type)
                    elif p_type == PARAM_TYPE_ENUMERATIVE:
                        meaning = enum_map.get(val, "Unknown Value") if enum_map else "Unknown Value"
                        param_obj = DecodedParameter(pid, name, val, None, desc, meaning, "Enumerative", is_valid, msg, rec_type)
                    else:
                        param_obj = DecodedParameter(pid, name, val, None, desc, None, "Unknown", True, None, rec_type)
                else:
                    param_obj = DecodedParameter(pid, f"Unknown_ID_{pid}", val, None, "Not found in database", None, "Unknown", False, "ID not in DB", rec_type)
                
                results[pid] = param_obj
                    
        return results
