import dateutil.parser
from datetime import datetime, timedelta, timezone


LOCAL_TZ = timezone(timedelta(hours=7))
LOCAL_EPOCH = datetime(1970, 1, 1, tzinfo=LOCAL_TZ)


def test_time_logic(ts_str):
    dt = dateutil.parser.parse(ts_str)

    if dt.tzinfo is None:
        result = dt.replace(tzinfo=LOCAL_TZ)
    elif ts_str.endswith(" UTC"):
        # PrismaFlex strings are often local wall-clock values mislabeled as UTC.
        result = dt.replace(tzinfo=LOCAL_TZ)
    else:
        result = dt.astimezone(LOCAL_TZ)

    print(f"| Input:   {ts_str}")
    print(f"| Parsed:  {dt} (tz: {dt.tzinfo})")
    print(f"| Result:  {result} (tz: {result.tzinfo})")
    print("-" * 40)
    return result


def test_local_epoch(epoch_value: int):
    result = LOCAL_EPOCH + timedelta(seconds=epoch_value)
    print(f"| Epoch:   {epoch_value}")
    print(f"| Result:  {result} (tz: {result.tzinfo})")
    print("-" * 40)
    return result


if __name__ == "__main__":
    print("--- Timezone Logic Verification ---")

    # Case A: Decoder/Mirth string labeled as UTC but intended as local clinical time.
    res_a = test_time_logic("2026-03-12 14:22:37 UTC")

    # Case B: True ISO UTC string.
    res_b = test_time_logic("2026-03-12T14:22:37Z")

    # Case C: Naive local wall-clock.
    res_c = test_time_logic("2026-03-12 14:22:37")

    # Case D: PrismaFlex local-machine epoch from the packet header.
    res_d = test_local_epoch(1776201852)

    if (
        res_a.hour == 14 and res_a.minute == 22 and
        res_b.hour == 21 and res_b.minute == 22 and
        res_c.hour == 14 and res_c.minute == 22 and
        res_d.year == 2026 and res_d.month == 4 and res_d.day == 14 and
        res_d.hour == 21 and res_d.minute == 24
    ):
        print("SUCCESS: clinical timestamp logic matches PrismaFlex local-time semantics")
    else:
        print("FAILURE: clinical timestamp logic is inconsistent")
