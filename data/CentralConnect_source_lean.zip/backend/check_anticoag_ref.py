import sqlite3
conn = sqlite3.connect("reference/prismaflex_reference.db")
c = conn.cursor()

print("=== Tables ===")
tables = c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
for t in tables:
    print(t[0])

print("\n=== Enumerative params 400-420 ===")
rows = c.execute("SELECT id, name, description FROM enumerative_parameters WHERE id BETWEEN 400 AND 420").fetchall()
for r in rows:
    print(r)

print("\n=== All enumerative params with coag or anti ===")
rows2 = c.execute("SELECT id, name, description FROM enumerative_parameters WHERE LOWER(name) LIKE '%coag%' OR LOWER(name) LIKE '%anti%'").fetchall()
for r in rows2:
    print(r)

print("\n=== Numerical params 400-420 ===")
rows3 = c.execute("SELECT id, name, description FROM numerical_parameters WHERE id BETWEEN 400 AND 420").fetchall()
for r in rows3:
    print(r)

conn.close()
