"""Check what PID 461 actually looks like in live telemetry"""
import sqlite3, json, os

# Check the latest raw .gz file
storage_dir = os.path.join(os.path.dirname(__file__), 'services', 'treatment', 'raw')
if not os.path.exists(storage_dir):
    # Try other paths
    for candidate in ['services/treatment/raw', 'services/raw', 'raw', 'data/raw', 'data/rawdata']:
        p = os.path.join(os.path.dirname(__file__), candidate)
        if os.path.exists(p):
            storage_dir = p
            break

print(f"Looking for raw files in: {storage_dir}")
if os.path.exists(storage_dir):
    files = os.listdir(storage_dir)
    print(f"Files found: {len(files)}")
    for f in files[:5]:
        print(f"  {f}")
else:
    print("Directory not found")

# Instead, let's check the trends.db which has the latest telemetry
trends_db = os.path.join(os.path.dirname(__file__), 'trends.db')
if os.path.exists(trends_db):
    conn = sqlite3.connect(trends_db)
    conn.row_factory = sqlite3.Row
    tables = [t['name'] for t in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    print(f"\nTrends DB tables: {tables}")
    
    # Check for parameter data
    for t in tables:
        cols = [c['name'] for c in conn.execute(f"PRAGMA table_info({t})").fetchall()]
        print(f"  {t}: {cols}")
    
    conn.close()

# Check treatment_records.db for snapshot data with run_time_sec
treat_db = os.path.join(os.path.dirname(__file__), 'services', 'treatment_records.db') 
if os.path.exists(treat_db):
    conn = sqlite3.connect(treat_db)
    conn.row_factory = sqlite3.Row
    
    # Check if run_time_sec column exists in snapshots
    cols = [c['name'] for c in conn.execute("PRAGMA table_info(treatment_hourly_snapshots)").fetchall()]
    print(f"\nSnapshot columns: {cols}")
    
    # Check actual run_time_sec values
    rows = conn.execute("""
        SELECT treatment_id, hour_label, snapshot_time, run_time_sec 
        FROM treatment_hourly_snapshots 
        WHERE run_time_sec IS NOT NULL AND run_time_sec > 0
        ORDER BY snapshot_time DESC LIMIT 10
    """).fetchall()
    print(f"\nSnapshots with run_time_sec > 0: {len(rows)}")
    for r in rows:
        print(f"  {r['treatment_id'][:8]} | {r['hour_label']} | {r['snapshot_time']} | run_time={r['run_time_sec']}s")
    
    # Check if ANY snapshot has run_time_sec
    total = conn.execute("SELECT COUNT(*) as c FROM treatment_hourly_snapshots").fetchone()['c']
    with_rt = conn.execute("SELECT COUNT(*) as c FROM treatment_hourly_snapshots WHERE run_time_sec IS NOT NULL AND run_time_sec > 0").fetchone()['c']
    print(f"\nTotal snapshots: {total}, with run_time_sec > 0: {with_rt}")
    
    # Check the current active treatment
    active = conn.execute("SELECT id, device_id, patient_id, total_run_seconds, total_packets FROM treatments WHERE outcome = 'IN_PROGRESS'").fetchall()
    print(f"\nActive treatments:")
    for a in active:
        print(f"  {a['id'][:8]} | {a['device_id']} | {a['patient_id']} | run_sec={a['total_run_seconds']} | pkts={a['total_packets']}")
    
    conn.close()
