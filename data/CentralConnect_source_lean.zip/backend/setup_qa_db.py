import uuid
from datetime import datetime, timezone, timedelta
import sys

# add parent to path
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from db.postgres.session import get_session
from db.postgres.models.treatments import Treatment
from db.postgres.models.treatment_journal_rows import TreatmentJournalRow

_LOCAL_TZ = timezone(timedelta(hours=7))

def setup_db():
    tid = uuid.uuid4()
    with get_session() as session:
        now = datetime.now(_LOCAL_TZ)

        t = Treatment(
            id=tid,
            patient_id="QA-TEST",
            patient_name="QA Patient",
            device_id="DEV_QA",
            start_time=now - timedelta(hours=2),
            last_seen_time=now,
            outcome="IN_PROGRESS"
        )
        session.add(t)

        # H00 Stable
        r1 = TreatmentJournalRow(
            treatment_id=tid,
            device_id="DEV_QA",
            row_code="H00",
            row_kind="HOUR",
            snapshot_time=now - timedelta(hours=2),
            source="AUTO",
            qb=150,
            stable_at=now - timedelta(hours=1)
        )
        # H01 Stable
        r2 = TreatmentJournalRow(
            treatment_id=tid,
            device_id="DEV_QA",
            row_code="H01",
            row_kind="HOUR",
            snapshot_time=now - timedelta(hours=1),
            source="AUTO",
            qb=150,
            stable_at=now
        )
        # H02 Active Streaming
        r3 = TreatmentJournalRow(
            treatment_id=tid,
            device_id="DEV_QA",
            row_code="H02",
            row_kind="HOUR",
            snapshot_time=now,
            source="AUTO",
            qb=150
        )

        session.add_all([r1, r2, r3])
        session.commit()
        print(f"Created Treatment: {tid}")

if __name__ == "__main__":
    setup_db()
