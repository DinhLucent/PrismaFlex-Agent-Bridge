import requests
import uuid
from datetime import datetime

BASE_URL = "http://localhost:8000/api/treatments"

def setup_test_treatment():
    # 1. Create Treatment
    t_id = str(uuid.uuid4())
    t_data = {
        "id": t_id,
        "operator_name": "Test Script",
        "treatment_params": {
            "outcome": "IN_PROGRESS",
            "room_number": "ICU-TEST",
            "bed_number": "1",
            "heparin_bolus": 10.0,
            "solution_type": "Prismasol",
            "filter_type": "M150", 
            "kali": 2.0
        }
    }
    requests.post(f"{BASE_URL}/{t_id}", json=t_data)
    print(f"Created treatment: {t_id}")

    # 2. Add H00 (stable)
    requests.post(f"{BASE_URL}/{t_id}/history", json={
        "row_code": "H00",
        "row_kind": "HOURLY",
        "snapshot_time": "2026-04-05T00:00:00Z",
        "source": "AUTO",
        "qb": 150, "uf_total": 0, "pa": -50, "pv": 100, "tmp": 50,
        "stable_at": "2026-04-05T00:01:00Z"
    })

    # 3. Add H01 (stable)
    requests.post(f"{BASE_URL}/{t_id}/history", json={
        "row_code": "H01",
        "row_kind": "HOURLY",
        "snapshot_time": "2026-04-05T01:00:00Z",
        "source": "AUTO",
        "qb": 150, "uf_total": 100, "pa": -50, "pv": 100, "tmp": 50,
        "stable_at": "2026-04-05T01:01:00Z" # Task-126 makes it stable
    })

    # 4. Add H02 (active streaming, no stable_at)
    requests.post(f"{BASE_URL}/{t_id}/history", json={
        "row_code": "H02",
        "row_kind": "HOURLY",
        "snapshot_time": "2026-04-05T02:00:00Z",
        "source": "AUTO",
        "qb": 150, "uf_total": 200, "pa": -50, "pv": 100, "tmp": 50
    })
    
    print("Test rows added.")

if __name__ == "__main__":
    setup_test_treatment()
