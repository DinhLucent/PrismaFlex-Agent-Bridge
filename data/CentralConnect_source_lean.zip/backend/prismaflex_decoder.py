#!/usr/bin/env python3
"""
PrismaFlex Decoder Class
Class để decode dữ liệu PrismaFlex từ hex dump string thành JSON
"""

import json
import binascii
import struct
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional

class PrismaFlexDecoder:
    """
    Decoder class để xử lý dữ liệu PrismaFlex
    Input: hex dump string
    Output: JSON data structure
    """

    # Constants
    STX_MARKER = b'\x02\x00'
    HEADER_SIZE = 124
    S_RECORD_SIZE = 12
    MBL_OFFSET_IN_HEADER = 120
    LOCAL_TZ = timezone(timedelta(hours=7))
    LOCAL_EPOCH = datetime(1970, 1, 1, tzinfo=LOCAL_TZ)

    def __init__(self):
        """Initialize decoder"""
        pass

    def decode_patient_id(self, pat_id_bytes: bytes) -> str:
        """Decode patient ID từ bytes"""
        pat_id = ''
        for i in range(0, len(pat_id_bytes), 4):
            char_bytes = pat_id_bytes[i:i+4]
            try:
                char = struct.unpack('<I', char_bytes)[0]
                if 0 < char <= 0x10FFFF:
                    pat_id += chr(char)
            except:
                continue
        return pat_id or 'N/A'

    def _parse_sw_decimal(self, n: int):
        """Helper function to parse software version decimal"""
        s = str(n).zfill(7)               # tối thiểu A + BBCCDD
        a_str = s[:-6] or "0"
        A = int(a_str)
        B = int(s[-6:-4])
        C = int(s[-4:-2])
        D = int(s[-2:])
        return f"SW{A}.{B:02d}V{C:02d}R{D:02d}", (A, B, C, D)

    def decode_sw_version(self, sw_revision: int) -> str:
        """
        Nhận int 32-bit (có thể đã là giá trị LE-decimal hoặc là số cần đảo byte).
        Tự động nhận diện và in ra SWA.BBVCCRDD.
        """
        # Ứng viên 1: coi int đã đúng (đọc từ bytes little-endian)
        v1, p1 = self._parse_sw_decimal(sw_revision)

        # Ứng viên 2: đảo endian theo từng byte từ hex rồi parse
        h = f"{sw_revision:08x}"[-8:]
        swapped = int(h[6:8] + h[4:6] + h[2:4] + h[0:2], 16)
        v2, p2 = self._parse_sw_decimal(swapped)

        # Chọn phương án "hợp lý": ưu tiên A <= 99, sau đó A nhỏ hơn thì tốt hơn
        def rank(parts):
            a, b, c, d = parts
            return (0 if a <= 99 else 1, a)
        return v1 if rank(p1) <= rank(p2) else v2

    def decode_sw_version_bytes(self, raw4: bytes) -> str:
        """
        Nhận trực tiếp 4 byte little-endian từ máy, in SWA.BBVCCRDD.
        """
        if not isinstance(raw4, (bytes, bytearray)) or len(raw4) != 4:
            return "UNKNOWN"
        n_dec = int.from_bytes(raw4, "little", signed=False)
        v, _ = self._parse_sw_decimal(n_dec)
        return v

    def decode_header(self, header_data: bytes) -> Dict[str, Any]:
        """Decode header 124 bytes thành JSON format"""
        header_json = {
            "stx": None,
            "crc": None,
            "machine_id": None,
            "clinical_sw_id": None,
            "message_counter": None,
            "command_code": None,
            "message_info": None,
            "flags": None,
            "patient_id": None,
            "sw_revision_hex": None,
            "sw_version": None,
            "therapy_type_id": None,
            "therapy_status_id": None,
            "timestamp": None,
            "timestamp_unix": None,
            "body_length_bytes": None
        }

        try:
            if len(header_data) >= 6:
                stx, crc, mach_id = struct.unpack('<HHH', header_data[:6])
                header_json.update({
                    "stx": f"0x{stx:04X}",
                    "crc": f"0x{crc:04X}",
                    "machine_id": mach_id
                })

            if len(header_data) >= 8:
                clinical_sw_id = struct.unpack('<H', header_data[6:8])[0]
                header_json["clinical_sw_id"] = f"0x{clinical_sw_id:04X}"

            if len(header_data) >= 16:
                msg_counter, cmd_code = struct.unpack('<II', header_data[8:16])
                header_json.update({
                    "message_counter": msg_counter,
                    "command_code": f"0x{cmd_code:08X}"
                })

            if len(header_data) >= 24:
                msg_info, flags = struct.unpack('<II', header_data[16:24])
                header_json.update({
                    "message_info": msg_info,
                    "flags": f"0x{flags:08X}"
                })

            # Patient ID (bytes 24-104)
            if len(header_data) >= 104:
                pat_id_bytes = header_data[24:104]
                patient_id = self.decode_patient_id(pat_id_bytes)
                header_json["patient_id"] = patient_id

            # SW Revision, Therapy Type, Therapy Status
            if len(header_data) >= 112:
                sw_rev, therapy_type_id = struct.unpack('<II', header_data[104:112])
                therapy_status_id, time_unix = struct.unpack('<II', header_data[112:120])
                sw_version = self.decode_sw_version(sw_rev)

                header_json.update({
                    "sw_revision_hex": f"0x{sw_rev:08X}",
                    "sw_version": sw_version,
                    "therapy_type_id": therapy_type_id,
                    "therapy_status_id": therapy_status_id
                })

                try:
                    timestamp = self.LOCAL_EPOCH + timedelta(seconds=time_unix)
                    header_json["timestamp"] = timestamp.isoformat()
                    header_json["timestamp_unix"] = time_unix
                except:
                    header_json.update({
                        "timestamp": "Invalid",
                        "timestamp_unix": time_unix
                    })

            # Body length
            if len(header_data) >= 124:
                body_length = struct.unpack('<I', header_data[120:124])[0]
                header_json["body_length_bytes"] = body_length

        except Exception as e:
            header_json["error"] = str(e)

        return header_json

    def decode_body(self, body_data: bytes) -> Dict[str, Any]:
        """Decode body thành JSON format"""
        body_json = {
            "total_records": 0,
            "parameters": []
        }

        try:
            num_records = len(body_data) // self.S_RECORD_SIZE
            body_json["total_records"] = num_records

            # Parse từng record
            for i in range(num_records):
                record_start = i * self.S_RECORD_SIZE
                record_end = record_start + self.S_RECORD_SIZE

                if record_end > len(body_data):
                    break

                try:
                    record = body_data[record_start:record_end]
                    param_code, record_time, value = struct.unpack('<IIi', record)

                    # Decode parameter info
                    param_type = (param_code >> 24) & 0xFF
                    param_id = param_code & 0x00FFFFFF

                    record_type = "Actual"
                    if param_code & 0x80000000:
                        record_type = "Alarm"
                        param_id = param_code & 0x7FFFFFFF
                    elif param_code & 0x40000000:
                        record_type = "Set"
                        param_id = param_code & 0x3FFFFFFF

                    # Tạo parameter object
                    param_obj = {
                        "record_num": i + 1,
                        "type": record_type,
                        "id": param_id,
                        "id_hex": f"0x{param_id:06X}",
                        "value": value,
                        "record_time": record_time
                    }

                    body_json["parameters"].append(param_obj)

                except struct.error as e:
                    error_param = {
                        "record_num": i + 1,
                        "error": str(e),
                        "type": "Error",
                        "id": None,
                        "value": None
                    }
                    body_json["parameters"].append(error_param)

        except Exception as e:
            body_json["error"] = str(e)

        return body_json

    def decode_hex_dump(self, hex_string: str, packet_num: int = 1,
                       timestamp: str = None) -> Dict[str, Any]:
        """
        Decode hex dump string thành JSON data structure

        Args:
            hex_string: Chuỗi hex dump (ví dụ: "020068300700...")
            packet_num: Số thứ tự packet (default: 1)
            timestamp: Timestamp của packet (optional)

        Returns:
            Dict chứa dữ liệu JSON với s_header và s_body
        """
        try:
            # Convert hex string thành bytes
            packet_data = binascii.unhexlify(hex_string)

            # Tạo JSON structure
            json_data = {
                "packet_num": packet_num,
                "timestamp": timestamp or datetime.now(timezone.utc).isoformat(),
                "packet_length": len(packet_data),
                "s_header": {},
                "s_body": {}
            }

            # Process header
            if len(packet_data) >= self.HEADER_SIZE:
                header_data = packet_data[:self.HEADER_SIZE]
                json_data["s_header"] = self.decode_header(header_data)

                # Process body
                if len(packet_data) > self.HEADER_SIZE:
                    body_length = self.get_body_length(header_data)
                    if body_length > 0 and len(packet_data) >= self.HEADER_SIZE + body_length:
                        body_data = packet_data[self.HEADER_SIZE:self.HEADER_SIZE + body_length]
                        json_data["s_body"] = self.decode_body(body_data)
                    else:
                        json_data["s_body"] = {"error": "Invalid body length or incomplete packet"}
                else:
                    json_data["s_body"] = {"error": "No body data"}
            else:
                json_data["s_header"] = {"error": "Header too short"}
                json_data["s_body"] = {"error": "No header"}

            return json_data

        except Exception as e:
            return {
                "packet_num": packet_num,
                "timestamp": timestamp or datetime.now(timezone.utc).isoformat(),
                "error": str(e)
            }

    def get_body_length(self, header_data: bytes) -> int:
        """Lấy body length từ header"""
        try:
            if len(header_data) >= 124:
                return struct.unpack('<I', header_data[120:124])[0]
        except:
            pass
        return 0


# Example usage
if __name__ == "__main__":
    # Tạo instance của decoder
    decoder = PrismaFlexDecoder()

    # Example hex dump (thay bằng hex dump thật của bạn)
    example_hex = "02006830070064000000000000000000ac000000020000006700000032000000340000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d0207d000300000005000000ab7fb0681008000001000000ab7fb0686fffffff02000000ab7fb068ab00000003000000ab7fb0684100000004000000ab7fb0686700000005000000ab7fb068feffffff06000000ab7fb0683b00000007000000ab7fb068230000007c000000ab7fb0686f0100007d000000ab7fb068ad0200007e000000ab7fb0687a0200007f000000ab7fb0684602000080000000ab7fb068fb010000b0000000ab7fb068fb010000b1000000ab7fb06803020000b2000000ab7fb068810200003c000000ab7fb068460000000d000000ab7fb068d70c00000d000000ab7fb068da0c00000e000000ab7fb068700e00000e000000ab7fb0686f0e00000f000000ab7fb068820e00000f000000ab7fb068850e000010000000ab7fb068800c000010000000ab7fb068810c000078000000ab7fb06881bb000078000000ab7fb068fc84010079000000ab7fb068b2b3000079000000ab7fb068f48a01007a000000ab7fb068dcb900007a000000ab7fb0683a8e01007b000000ab7fb0682fc000007b000000ab7fb0682087010022000000ab7fb06874a8000023000000ab7fb0689c99000097000000ab7fb0688000000098000000ab7fb0688099000099000000ab7fb068a79900009a000000ab7fb068980000009b000000ab7fb06898000000b7000000ab7fb068c3010000b8000000ab7fb06819020000b9000000ab7fb06812020000ba000000ab7fb0689b010000bb000000ab7fb068be020000a8000000ab7fb068250200009c000000ab7fb068000000009d000000ab7fb06801000000aa000000ab7fb0681b000000ab000000ab7fb0684d000000bc000000ab7fb06811000000bd000000ab7fb068060000005e010000ab7fb0680000000008000000ab7fb0682202000009000000ab7fb068380700000a000000ab7fb068620700000b000000ab7fb068780f00000c000000ab7fb068ea090000c6000000ab7fb068fbffffffd1010000ab7fb06831000000d2010000ab7fb0682d020000d4010000ab7fb0688400000091000000ab7fb0686703000091000000ab7fb0683501000091000000ab7fb068454d000091000000ab7fb068444d000092000000ab7fb0684525000092000000ab7fb0685605000092000000ab7fb0687f08000092000000ab7fb0687f08000093000000ab7fb068fe0a000093000000ab7fb068aa01000093000000ab7fb068931b000093000000ab7fb068931b000094000000ab7fb068c30a000094000000ab7fb068a401000094000000ab7fb068501c000094000000ab7fb068501c000095000000ab7fb0682805000095000000ab7fb068c500000095000000ab7fb068af3b000095000000ab7fb068af3b00003b000000ab7fb0681b5b00005e000000ab7fb068000000005f000000ab7fb0689718000061000000ab7fb0689c18000063000000ab7fb068aa38000064000000ab7fb0680600000062000000ab7fb068610700005c000000ab7fb068020000005d000000ab7fb0682800000028010000ab7fb06800000000a2010000ab7fb06800000000a3010000ab7fb06805000000a0010000ab7fb06801000000a1010000ab7fb06805000000a4010000ab7fb068ff040000a5010000ab7fb0680e200000a6010000ab7fb0680e200000a7010000ab7fb06817000000a8010000ab7fb06816000000a9010000ab7fb06816000000aa010000ab7fb068fd040000ab010000ab7fb068f81f0000ac010000ab7fb068f81f0000ad010000ab7fb06817000000ae010000ab7fb06817000000af010000ab7fb06817000000b0010000ab7fb06826010000b1010000ab7fb06861070000b2010000ab7fb06861070000b3010000ab7fb06805000000b4010000ab7fb06805000000b5010000ab7fb06805000000b6010000ab7fb068d7030000b7010000ab7fb06897180000b8010000ab7fb06897180000b9010000ab7fb06812000000ba010000ab7fb06812000000bb010000ab7fb06812000000bc010000ab7fb068d7080000bd010000ab7fb068aa380000be010000ab7fb0682a000000bf010000ab7fb06829000000c0010000ab7fb06826010000c1010000ab7fb06861070000c2010000ab7fb068d8030000c3010000ab7fb0689c180000c4010000ab7fb068d7030000c5010000ab7fb06897180000c6010000ab7fb06897180000c7010000ab7fb06802000000c8010000ab7fb068100000009f010000ab7fb0688401000097010000ab7fb06810000000ca010000ab7fb068ffffffffcb010000ab7fb06804000000cd010000ab7fb0680a590000ce010000ab7fb06843c0000013000040ab7fb068e803000012000040ab7fb0680000000015000040ab7fb068e803000017000040ab7fb068ff08000016000040ab7fb0682c01000011000040ab7fb068b400000018000040ab7fb068000000002c000040ab7fb068090000001a000040ab7fb0683700000024000040ab7fb0680000000025000040ab7fb0680600000026000040ab7fb06819000000c0000040ab7fb06800000000c4000040ab7fb0689001000090010040ab7fb0680000000091010040ab7fb0680000000092010040ab7fb0680000000093010040ab7fb0680000000094010040ab7fb0680000000095010040ab7fb0680000000096010040ab7fb0680000000098010040ab7fb0680000000099010040ab7fb068010000009a010040ab7fb0682a0000009b010040ab7fb068080000009c010040ab7fb068110000009d010040ab7fb068000000009e010040ab7fb068640000002f000040ab7fb0681e000000c9010040ab7fb06801000000cc010040ab7fb06800000000cf010040ab7fb0689a860000d0010040ab7fb0687e57cf3ed3010040ab7fb06800000000"

    # Decode hex dump
    result = decoder.decode_hex_dump(example_hex, packet_num=1)

    # Print result
    print("DECODE RESULT:")
    print(json.dumps(result, indent=2, ensure_ascii=False))

    # Example: Lưu thành file JSON
    with open('sample_packet.json', 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    print("\nSaved to sample_packet.json")
