import requests
import time
import random
import json
from datetime import datetime

API_URL = "http://localhost:8000/api/v1/telemetry"

DEVICES = ["ICU-Bed-01", "ICU-Bed-02", "ICU-Bed-03", "ER-Room-01"]
STATUSES = [
    {"code": 5, "name": "RUN"},
    {"code": 5, "name": "RUN"},
    {"code": 5, "name": "RUN"},
    {"code": 5, "name": "RUN"},
    {"code": 2, "name": "PRIME"},
    {"code": 4, "name": "WAITING_START"},
    {"code": 7, "name": "STOPPED"}
]

def generate_packet(device_id, counter):
    status = random.choice(STATUSES)
    
    # Simulate pressure waves (sine-like with noise)
    base_access = -100 + random.randint(-20, 20)
    base_return = 120 + random.randint(-10, 30)
    base_flow = 150
    
    # Alarm simulation (occasional)
    alarms = []
    if random.random() < 0.05: # 5% chance of alarm
        alarms.append(102) # Some alarm ID
        status = {"code": 5, "name": "RUN_ALARM"}

    packet = {
        "meta": {
            "device_id": device_id,
            "timestamp": datetime.now().isoformat(),
            "seq": counter,
            "schema_version": "1.0"
        },
        "status": {
            "code": status["code"],
            "name": status["name"],
            "patient_id": f"Patient_{device_id.split('-')[-1]}"
        },
        "data": {
            "pressure_access": base_access,
            "pressure_return": base_return,
            "pressure_filter": base_return + 50,
            "pressure_effluent": -50,
            "flow_blood": base_flow if status["code"] == 5 else 0,
            "flow_pbp": 1000,
            "flow_dialysate": 2000,
            "temp": 37.0
        },
        "alarms": alarms
    }
    return packet

def run_simulation():
    print(f"Starting Simulator. Target: {API_URL}")
    counter = 0
    try:
        while True:
            for device in DEVICES:
                packet = generate_packet(device, counter)
                try:
                    resp = requests.post(API_URL, json=packet, timeout=1)
                    if resp.status_code == 200:
                        print(f"[{device}] Sent OK")
                    else:
                        print(f"[{device}] Failed: {resp.status_code}")
                except Exception as e:
                    print(f"[{device}] Error connecting: {e}")
                
            counter += 1
            # Send update every 1 second (realtime feel)
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("Stopping simulation")

if __name__ == "__main__":
    run_simulation()
