import json
import os
import copy
from datetime import datetime, timedelta, timezone

# Configuration
TEMPLATE_FILE = r"d:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\data\in\done\decoded_2026-01-30_105232.json"
BASE_OUTPUT_DIR = r"d:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\data\scenarios"

class SequenceGenerator:
    def __init__(self, template_path, output_dir):
        self.output_dir = output_dir
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
            
        with open(template_path, 'r') as f:
            self.base_data = json.load(f)
            
        # Initialize state from template
        self.current_packet = self.base_data.get('packet_num', 0)
        
        # Parse start time, handling potential format issues
        try:
            ts_str = self.base_data.get('timestamp', datetime.now().isoformat())
            self.current_time = datetime.fromisoformat(ts_str)
        except:
            self.current_time = datetime.now()

    def generate_step(self, modifiers=None, step_index=0):
        """
        Generates a single JSON file with updated timestamp and packet number.
        modifiers: Dict of {param_id: value} to update.
        """
        data = copy.deepcopy(self.base_data)
        
        # 1. Update Meta sequence
        self.current_packet += 1
        self.current_time += timedelta(seconds=5) # Assume 5s interval
        
        timestamp_iso = self.current_time.isoformat()
        
        data['packet_num'] = self.current_packet
        data['timestamp'] = timestamp_iso
        
        if 's_header' in data:
            data['s_header']['message_counter'] = self.current_packet
            data['s_header']['timestamp'] = self.current_time.strftime("%Y-%m-%d %H:%M:%S UTC")
            data['s_header']['timestamp_unix'] = int(self.current_time.timestamp())
            
        # 2. Apply Parameter Changes
        if modifiers:
            if 's_body' in data and 'parameters' in data['s_body']:
                for p in data['s_body']['parameters']:
                    pid = p['id']
                    if pid in modifiers:
                        p['value'] = modifiers[pid]
                        # Ensure value_text if exists is simplified
                        if 'value_text' in p:
                            del p['value_text']

        # 3. Save File
        filename = f"step_{step_index:03d}_{timestamp_iso.replace(':','-')}.json"
        filepath = os.path.join(self.output_dir, filename)
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
            
        return filepath


def scenario_varying_indicators():
    """
    Case 1: Varying Indicators (Drifting Values) - PRESSURES (For Reference)
    """
    case_name = "Case_1_Varying_Indices"
    target_dir = os.path.join(BASE_OUTPUT_DIR, case_name)
    print(f"--- Generating {case_name} into {target_dir} ---")
    
    gen = SequenceGenerator(TEMPLATE_FILE, target_dir)
    
    steps = 100
    filter_start, filter_end = 100, 300
    access_start, access_end = -50, -150
    
    for i in range(steps):
        # Calculate current values
        progress = i / (steps - 1)
        current_filter = int(filter_start + (filter_end - filter_start) * progress)
        current_access = int(access_start + (access_end - access_start) * progress)
        
        modifiers = {
            2: current_filter,
            1: current_access
        }
        
        gen.generate_step(modifiers, i)
        
    print(f"✅ Generated {steps} files for {case_name}")

def scenario_prescription_change():
    """
    Case 2: Prescription Changes (Non-Pressure)
    - 100 Steps
    - Blood Flow (ID 17): 100 -> 180 ml/min
    - Replacement Post (ID 19): 1000 -> 2000 ml/h
    - Patient Weight (ID 26): 70 -> 75 kg
    - Heparin Rate (ID 38): 500 -> 1000 IU/h
    - Citrate Dose (ID 400): 2.0 -> 3.5 mmol/L
    - HCT Port (ID 460): 30 -> 35 %
    """
    case_name = "Case_2_Prescription_Change"
    target_dir = os.path.join(BASE_OUTPUT_DIR, case_name)
    print(f"--- Generating {case_name} into {target_dir} ---")
    
    gen = SequenceGenerator(TEMPLATE_FILE, target_dir)
    
    steps = 100
    
    for i in range(steps):
        # Calculate current values
        progress = i / (steps - 1)
        
        # 1. Blood Flow: 100 -> 180
        current_blood = int(100 + (80 * progress))
        
        # 2. Replacement Post: 1000 -> 2000
        current_rep = int(1000 + (1000 * progress))
        
        # 3. Patient Weight: 70 -> 75
        current_weight = int(70 + (5 * progress))

        # 4. Heparin Rate: 500 -> 1000
        current_heparin = int(500 + (500 * progress))

        # 5. Citrate Dose: 2.0 -> 3.5 (Stored as raw scaled value usually, but let's assume direct for demo)
        current_citrate = round(2.0 + (1.5 * progress), 1)

        # 6. HCT Port: 30 -> 35
        current_hct = int(30 + (5 * progress))
        
        modifiers = {
            17: current_blood,     # Blood Flow
            19: current_rep,       # Replacement Post
            26: current_weight,    # Weight
            38: current_heparin,   # Heparin Rate
            400: current_citrate,  # Citrate Dose
            460: current_hct       # HCT Port
        }
        
        gen.generate_step(modifiers, i)
        
    print(f"✅ Generated {steps} files for {case_name}")


def scenario_clinical_drift_long():
    """
    Case 3: Clinical Prescription Sequence (High Fidelity)
    - 150 Steps total (~12.5 minutes at 5s/data)
    - Changes happen at discrete points to simulate manual adjustments.
    """
    case_name = "Case_3_Clinical_Sequence"
    target_dir = os.path.join(BASE_OUTPUT_DIR, case_name)
    print(f"--- Generating {case_name} into {target_dir} ---")
    
    gen = SequenceGenerator(TEMPLATE_FILE, target_dir)
    
    # Initial Baseline Values
    modifiers = {
        17: 100,   # Qb: 100
        22: 0,     # PBP: 0
        21: 1500,  # Qd: 1500
        19: 500,   # Rep Post: 500
        38: 500,   # Heparin: 500
        460: 32    # HCT: 32%
    }
    
    for i in range(150):
        # Trigger changes at specific steps
        if i == 5:
            print("   [Step 5] START OF TREATMENT: 5 parameters initialized/changed at once!")
            modifiers[17] = 180  # Blood Flow
            modifiers[22] = 200  # PBP
            modifiers[21] = 2000 # Qd
            modifiers[19] = 1000 # Rep Post
            modifiers[38] = 750  # Heparin
        elif i == 45:
            print("   [Step 45] Fine Tuning: Adjusting Replacement: 1000 -> 1500")
            modifiers[19] = 1500
        elif i == 75:
            print("   [Step 75] Clinician Intervention: Blood Flow 180 -> 220")
            modifiers[17] = 220
        elif i == 105:
            print("   [Step 105] Increasing Heparin: 750 -> 900")
            modifiers[38] = 900
        
        gen.generate_step(modifiers, i)
        
    print(f"✅ Generated 150 files for {case_name}")

if __name__ == "__main__":
    scenario_varying_indicators()
    scenario_prescription_change()
    scenario_clinical_drift_long()
    print("\nGeneration Complete.")
