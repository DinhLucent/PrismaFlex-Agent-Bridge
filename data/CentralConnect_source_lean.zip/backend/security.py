import uuid
import hashlib
import sys
import logging

# Configure local security logger
logger = logging.getLogger("ICU-B_Security")

# --- AUTHORIZED LICENSES ---
# For professional clinical deployments, we lock the software to the specific hospital server hardware.
# This prevents unauthorized cloning/copying of the entire system.
ALLOWED_HWIDS = [
    "36526983C8928D1B", # Primary Server (Cho Ray Hospital - ICU Zone B)
    "C85A39F1355C6DA5", # Secondary Server Deployment
    "DEVELOPER_VM_ID",   # Development Sandbox
]

def get_machine_id():
    try:
        mac = uuid.getnode()
        hwid = hashlib.sha256(str(mac).encode()).hexdigest().upper()
        return hwid[:16]
    except Exception:
        return "UNKNOWN_HARDWARE"

def verify_license():
    """
    Critical integrity check. Called at startup to verify hardware authorization.
    """
    current_hwid = get_machine_id()
    
    if current_hwid not in ALLOWED_HWIDS:
        print("\n" + "!" * 60)
        print("   CRITICAL SECURITY ERROR: LICENSE INVALID")
        print("   This software is not authorized to run on this hardware.")
        print(f"   Machine ID: {current_hwid}")
        print("   Please contact the system administrator for activation.")
        print("!" * 60 + "\n")
        
        # Log to hidden diagnostic log if needed
        logger.critical(f"Unauthorized execution attempt on HWID: {current_hwid}")
        
        # Kill the process immediately
        sys.exit(1)
    
    logger.info(f"✅ Hardware License Verified: {current_hwid}")
    return True

if __name__ == "__main__":
    # If run directly, just show status
    verify_license()
    print("License is VALID for this machine.")
