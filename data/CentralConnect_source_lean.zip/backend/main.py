"""
PrismaFlex Central Station API
================================
Lean routing module. All business logic lives in services/.

Architecture:
    main.py (this file) â†’ Routes only
    services/database.py â†’ SQLite operations
    services/ws_manager.py â†’ WebSocket broadcast
    services/alarm_service.py â†’ Smart alarm debouncing
    services/event_service.py â†’ Parameter tracking & trends
"""
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Body, Request, Response
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from typing import Dict, Any
import logging
from logging.handlers import RotatingFileHandler, QueueHandler, QueueListener
import queue
import sys
import os
import random
import sqlite3
from datetime import datetime, timezone, timedelta
import asyncio
import time

# 1. Add Project Root to Python Path (Critical for importing prismaflex_lib)
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from prismaflex_lib import ReferenceDatabase

from services import TrendDatabase, ConnectionManager, SmartAlarmService, EventService
from services.telemetry_contract import apply_ingest_contract, parse_clinical_timestamp
from services.treatment import TreatmentDatabase, TreatmentRecorderService, TreatmentSnapshotService, RawDataStreamer
from services.treatment.telemetry_filter import TelemetryFilter

# â”€â”€â”€ Logging â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
LOGS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), 'logs'))
os.makedirs(LOGS_DIR, exist_ok=True)

# Standard Formatter
log_formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s')

# 1. Console Handler (General Info)
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(log_formatter)

# 2. Main System Log (Rotating)
main_handler = RotatingFileHandler(
    os.path.join(LOGS_DIR, 'backend.log'),
    maxBytes=5 * 1024 * 1024, backupCount=5, encoding='utf-8'
)
main_handler.setLevel(logging.INFO)
main_handler.setFormatter(log_formatter)

# 3. Error Log (Rotating)
error_handler = RotatingFileHandler(
    os.path.join(LOGS_DIR, 'errors.log'),
    maxBytes=5 * 1024 * 1024, backupCount=5, encoding='utf-8'
)
error_handler.setLevel(logging.ERROR)
error_handler.setFormatter(log_formatter)

# 4. Audit Log (Rotating - Clinical Actions)
audit_handler = RotatingFileHandler(
    os.path.join(LOGS_DIR, 'audit.log'),
    maxBytes=10 * 1024 * 1024, backupCount=10, encoding='utf-8'
)
audit_handler.setFormatter(logging.Formatter('%(asctime)s [AUDIT] %(message)s'))

# 5. Frontend Log (Rotating)
frontend_handler = RotatingFileHandler(
    os.path.join(LOGS_DIR, 'frontend.log'),
    maxBytes=5 * 1024 * 1024, backupCount=5, encoding='utf-8'
)
frontend_handler.setFormatter(log_formatter)

# 6. Replay Status Log (Rotating)
replay_handler = RotatingFileHandler(
    os.path.join(LOGS_DIR, 'replay_status.log'),
    maxBytes=2 * 1024 * 1024, backupCount=2, encoding='utf-8'
)
replay_handler.setFormatter(log_formatter)

# Root Configuration
logging.basicConfig(
    level=logging.INFO,
    handlers=[console_handler, main_handler, error_handler, replay_handler]
)

logger = logging.getLogger("PrismaFlexBackend")

# Dedicated Loggers
audit_logger = logging.getLogger("PrismaFlexAudit")
audit_logger.addHandler(audit_handler)
audit_logger.propagate = False

frontend_logger = logging.getLogger("PrismaFlexFrontend")
frontend_logger.addHandler(frontend_handler)
frontend_logger.propagate = False

# Performance logger for high-frequency metrics (Clinical Grade: Async & Non-blocking)
perf_logger = logging.getLogger("PrismaFlexPerformance")
perf_logger.setLevel(logging.INFO)
perf_log_path = os.path.join(LOGS_DIR, 'performance.log')

# 1. The actual file writer (RotatingFileHandler) 
file_perf_handler = RotatingFileHandler(
    perf_log_path, 
    maxBytes=5 * 1024 * 1024, # 5MB limit
    backupCount=3, encoding='utf-8' # Keep 3 older files
)
file_perf_handler.setFormatter(logging.Formatter('%(asctime)s,%(message)s'))

# 2. The Async Bridge (Queue and Handler)
log_queue = queue.Queue(-1)  # Infinite queue size for safety
queue_handler = QueueHandler(log_queue)
perf_logger.addHandler(queue_handler)

# 3. The Log Worker (Listener) - starts writing from queue to file in a background thread
log_listener = QueueListener(log_queue, file_perf_handler)

# â”€â”€â”€ App â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# â”€â”€â”€ Initialize Services â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

# â”€â”€â”€ Initialize Services â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

# Reference Database (read-only, for parameter enrichment)
ref_db_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'prismaflex_reference.db'))
try:
    if os.path.exists(ref_db_path):
        logger.info(f"Found Reference DB at: {ref_db_path}")
        ref_db = ReferenceDatabase(ref_db_path)
    else:
        logger.error(f"Could not find prismaflex_reference.db at: {ref_db_path}")
        ref_db = None
except Exception as e:
    logger.error(f"Error loading Reference Database: {e}")
    ref_db = None

# Core Services (singleton instances)
db = TrendDatabase()
manager = ConnectionManager()
alarm_svc = SmartAlarmService(db)
event_svc = EventService(db)

# Wire up session reset: when patient/treatment changes, also clear alarm cache
def _on_session_reset(device_id: str):
    if device_id in alarm_svc._active_alarms:
        del alarm_svc._active_alarms[device_id]
    if device_id in alarm_svc._pending_clears:
        del alarm_svc._pending_clears[device_id]

event_svc.on_session_reset = _on_session_reset

# â”€â”€â”€ In-Memory State & Constants â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
REALTIME_THRESHOLD_SECONDS = 25
device_last_timestamps: Dict[str, datetime] = {}
device_last_broadcast: Dict[str, datetime] = {}

# â”€â”€â”€ Lifecycle â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Modern Clinical-Grade Lifecycle Management.
    Ensures all queues, workers, and log listeners start/stop in order.
    """
    # 1. Initialize Queue in app.state (Standard Professional Practice)
    app.state.telemetry_queue = asyncio.Queue(maxsize=10000)
    
    # 2. Treatment Services
    app.state.treat_db = TreatmentDatabase()
    app.state.streamer = RawDataStreamer()
    app.state.recorder = TreatmentRecorderService(app.state.treat_db, app.state.streamer)
    app.state.snapshot_svc = TreatmentSnapshotService(app.state.treat_db)
    
    # 3. Start workers (pass app reference to worker)
    app.state.workers = []
    for i in range(4):
        worker = asyncio.create_task(telemetry_worker(app))
        app.state.workers.append(worker)
    
    # 4. Start Async Logger
    log_listener.start()
    
    # 5. Start Heartbeat
    app.state.heartbeat = asyncio.create_task(heartbeat_task())
    
    yield
    
    # --- Shutdown ---
    print("[LIFESPAN] Stopping Systems...", flush=True)
    for worker in app.state.workers:
        worker.cancel()
    app.state.heartbeat.cancel()
    log_listener.stop()
    db.close()

# â”€â”€â”€ App â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
app = FastAPI(
    title="PrismaFlex Central Station API",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


async def heartbeat_task():
    """Broadcast server time and run periodic maintenance."""
    counter = 0
    while True:
        try:
            now = datetime.now(timezone(timedelta(hours=7)))
            await manager.broadcast({
                "type": "HEARTBEAT",
                "server_time": now.isoformat()
            })
            
            # Clinical Grade: Run session cleanup every 60 seconds
            counter += 1
            if counter >= 60:
                counter = 0
                if hasattr(app.state, 'recorder'):
                    # Call directly (NOT to_thread) — enforce_auto_close needs
                    # event loop access for compress_treatment_file() scheduling.
                    # We no longer pass current_logical_time so that backfill sessions 
                    # are NOT spuriously auto-closed by a global logical clock.
                    app.state.recorder.enforce_auto_close()
                    
        except Exception as e:
            logger.error(f"Heartbeat maintenance error: {e}")
        await asyncio.sleep(1.0)


# Per-device locks: serialize processing for same device_id across workers
_device_processing_locks: dict[str, asyncio.Lock] = {}

def _get_device_lock(device_id: str) -> asyncio.Lock:
    if device_id not in _device_processing_locks:
        _device_processing_locks[device_id] = asyncio.Lock()
    return _device_processing_locks[device_id]


async def telemetry_worker(app: FastAPI):
    """
    Dedicated background worker for high-speed clinical data processing.
    Decouples ingestion from processing to ensure 0ms API response.
    Per-device serialization: packets for the same device_id are processed in order.
    """
    queue = app.state.telemetry_queue
    while True:
        try:
            # 1. Get packet from queue
            qsize = queue.qsize()
            if qsize > 7000: # 70% of 10,000 maxsize
                logger.warning(f"High Telemetry Queue Load: {qsize} packets pending!")
            
            job = await queue.get()
            t_start = job['t_start']
            data = job['data']
            
            # --- Processing Logic Re-homed here ---
            meta = data.get("meta", {})
            header = data.get("s_header", data.get("header", {}))
            body = data.get("s_body", data.get("body", {}))
            device_id = str(meta.get("device_id", "unknown")).strip()
            timestamp_str = (
                job.get("quality_info", {}).get("packet_time")
                or meta.get("timestamp")
                or header.get("timestamp")
                or datetime.now(timezone.utc).isoformat()
            )
            clinical_timestamp = parse_clinical_timestamp(timestamp_str).isoformat()
            
            # Per-device serialization: ensure packets for the same device
            # are processed in order even across 4 workers
            async with _get_device_lock(device_id):
                t_logic_start = time.perf_counter()
            
                # 2. Enrichment & Alarm Processing
                active_alarms = []
                if ref_db:
                    # Header Enrichment
                    for key in ["therapy_type_id", "therapy_status_id"]:
                        val = header.get(key)
                        if val is not None:
                            if "type" in key:
                                header[f"{key}_name"] = ref_db.get_therapy_type(val)
                            elif "status" in key:
                                header[f"{key}_name"] = ref_db.get_therapy_status(val)

                    # Body Parameters Enrichment
                    params_list = body.get("parameters") or []
                    for p in params_list:
                        pid = p.get("id")
                        pval = p.get("value")
                        rec_type = p.get("type", "Actual")

                        if rec_type == "Alarm" and pval in [1, 2]:
                            alarm_info = ref_db.get_alarm_info(pid)
                            if alarm_info:
                                state = "PRESENT" if pval == 1 else "OVERRIDDEN"
                                active_alarms.append({
                                    "id": pid, "title": alarm_info["title"],
                                    "description": alarm_info["description"],
                                    "severity": alarm_info["severity"],
                                    "category": alarm_info["category"], "state": state
                                })
                        else:
                            info = ref_db.get_parameter_info(pid)
                            if info:
                                ptype, pname, _, _, pmap, _, _ = info
                                p["label"] = pname
                                if ptype == 2 and pmap and pval in pmap:
                                    p["value_text"] = pmap[pval]

                data["active_alarms"] = active_alarms
                
                # 3. SMART UI UPDATE (Bootstrap & Pacing)
                # Clinical Grade: Ensures NEW devices are registered, but heavy packets are paced.
                now_t = datetime.now()
                last_broadcast = device_last_broadcast.get(device_id)
                
                # Broadcast FULL update ONLY if:
                # - First time seeing this device (Bootstrap)
                # - OR last full broadcast was > 10 seconds ago (Pacing)
                should_broadcast_full = (last_broadcast is None or 
                                        (now_t - last_broadcast).total_seconds() > 10)
                
                t_ws_start = time.perf_counter()
                if should_broadcast_full:
                    asyncio.create_task(manager.broadcast({
                        "type": "TELEMETRY_UPDATE",
                        "payload": data,
                        "quality_status": job.get('quality_info')
                    }))
                    device_last_broadcast[device_id] = now_t
                    logger.debug(f"[BOOTSTRAP/PACE] Full update for {device_id}")
                
                t_ws_end = time.perf_counter()

                # 4. TREATMENT RECORDING (Bi-Phasic Storage)
                # Recorder coordinates raw ownership and snapshot ownership separately.
                resolved_mode = job.get('quality_info', {}).get('mode')
                is_live = resolved_mode == 'LIVE' or (
                    resolved_mode is None and job.get('quality_info', {}).get('quality') == 'LIVE'
                )
                routing = await app.state.recorder.process_packet(
                    device_id, clinical_timestamp, header, body, meta, is_live=is_live
                )
                snapshot_treatment_id = (routing or {}).get("treatment_id")

                # Capture snapshots on the routed treatment, then flush the cache when
                # the recorder says this packet closed the treatment boundary.
                if snapshot_treatment_id:
                    try:
                        await asyncio.to_thread(
                            app.state.snapshot_svc.process_packet,
                            device_id,
                            clinical_timestamp,
                            snapshot_treatment_id,
                            header,
                            body,
                        )
                    except Exception as snap_err:
                        logger.error(f"SNAPSHOT CRASH [{device_id}]: {snap_err}", exc_info=True)
                if (routing or {}).get("flush_snapshot_after"):
                    try:
                        await asyncio.to_thread(app.state.snapshot_svc.flush_device, device_id)
                    except Exception as snap_err:
                        logger.error(f"SNAPSHOT FLUSH CRASH [{device_id}]: {snap_err}", exc_info=True)

                # 5. SLOW STORE: Trends & Alarms (SQLite)
                t_db_start = time.perf_counter()
                params_list = body.get("parameters") or []
                await asyncio.to_thread(event_svc.save_trend_point, device_id, clinical_timestamp, params_list)
                # Debounced Alarm Processing
                await asyncio.to_thread(
                    alarm_svc.process, device_id, active_alarms, clinical_timestamp,
                    str(header.get("patient_id", "Unknown"))
                )
                
                # --- Capture & Broadcast Parameter Changes (Real-Time WAS) ---
                changes = await asyncio.to_thread(event_svc.track_parameter_changes, device_id, clinical_timestamp, header, body)
                if changes:
                    await manager.broadcast({
                        "type": "EVENT_UPDATE",
                        "device_id": device_id,
                        "changes": [
                            {
                                "param_id": pid,
                                "old_value": old_val,
                                "new_value": new_val,
                                "timestamp": clinical_timestamp
                            }
                            for pid, old_val, new_val in changes
                        ]
                    })
                    logger.debug(f"[WAS] Broadcasted {len(changes)} changes for {device_id}")

                    # --- Order-Change Snapshot: When clinical orders change ---
                    if snapshot_treatment_id:
                        order_pids = {17, 21, 18, 19, 22, 25}
                        order_changes = [(pid, old, new) for pid, old, new in changes if pid in order_pids]
                        if order_changes:
                            await asyncio.to_thread(
                                app.state.snapshot_svc.save_order_change_snapshot,
                                device_id, clinical_timestamp, order_changes
                            )
                
                # Auto-Prune (Low frequency)
                if random.randint(1, 250) == 1:
                    await asyncio.to_thread(db.prune)
                    
                t_db_end = time.perf_counter()
                
                # Performance Metric
                t_total = time.perf_counter() - t_start
                log_msg = f"{device_id},{t_total*1000:.2f},{(t_db_end-t_db_start)*1000:.2f},{(t_ws_end-t_ws_start)*1000:.2f},QUEUE_MODE"
                perf_logger.info(log_msg)
                logger.info(f"Processed {device_id}: {log_msg}")
            
            queue.task_done()

        except Exception as e:
            logger.error(f"Worker processing error: {e}")
            await asyncio.sleep(0.1)


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
#  HELPER FUNCTIONS
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

def calculate_data_quality(packet_timestamp_str: str) -> dict:
    """
    Backward-compatible wrapper.

    New ingest should prefer apply_ingest_contract(packet), but a few older
    call-sites still pass a plain timestamp string.
    """
    return apply_ingest_contract(
        {"meta": {"timestamp": packet_timestamp_str}},
        realtime_threshold_seconds=REALTIME_THRESHOLD_SECONDS,
    )


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
#  ROUTES
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/")
async def health_check():
    return {"status": "online", "service": "PrismaFlex Backend", "time": datetime.now(timezone.utc).isoformat()}


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)


# â”€â”€â”€ Telemetry Ingestion â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
 
@app.post("/api/v1/telemetry")
async def receive_telemetry(request: Request, data: Dict[str, Any] = Body(...)):
    """
    Sub-millisecond Ingestion Endpoint.
    Clinical Grade: Accepts packet instantly, offloads all work to queue.
    """
    t_start = time.perf_counter()
    try:
        quality_info = apply_ingest_contract(
            data,
            realtime_threshold_seconds=REALTIME_THRESHOLD_SECONDS,
        )
        is_live = quality_info.get("mode") == "LIVE"

        # FAST PATH: Extract & Broadcast ONLY if data is LIVE
        if is_live:
            fast_pkt = TelemetryFilter.extract_dashboard_packet(data)
            # Clinical Grade: Fire-and-forget broadcast
            asyncio.create_task(manager.broadcast({
                "type": "TELEMETRY_FAST_UPDATE",
                "payload": fast_pkt
            }))
        else:
            logger.debug(f"[BACKFILL] Silent ingestion for historical data ({quality_info.get('latency_sec')}s lag)")

        # ðŸš€ HEAVY PATH: Push to Queue for background processing (Recording/Snapshots)
        # Always record, whether live or backfill!
        await request.app.state.telemetry_queue.put({
            "t_start": t_start,
            "data": data,
            "quality_info": quality_info
        })
 
        return {"status": "queued", "mode": "live" if is_live else "backfill"}

    except Exception as e:
        logger.error(f"Ingestion error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# â”€â”€â”€ Device Data Endpoints â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@app.get("/api/v1/devices/{device_id}/trends")
async def get_device_trends(device_id: str, limit: int = 500):
    """Get last 24h of pressure trends for charts."""
    try:
        return await asyncio.to_thread(db.get_trends, device_id, limit)
    except Exception as e:
        logger.error(f"Fetch trend error: {e}")
        return []


@app.get("/api/v1/devices/{device_id}/events")
async def get_device_events(device_id: str):
    """Get parameter changes in the last 1 hour ("Was" logic)."""
    try:
        return await asyncio.to_thread(db.get_events, device_id)
    except Exception as e:
        logger.error(f"Fetch events error: {e}")
        return []


@app.get("/api/v1/devices/{device_id}/alarm_history")
async def get_device_alarm_history(device_id: str):
    """Get debounced alarm history."""
    try:
        return await asyncio.to_thread(db.get_alarm_history, device_id)
    except Exception as e:
        logger.error(f"Fetch alarm history error: {e}")
        return []

# â”€â”€â”€ Client Error Reporting â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@app.post("/api/v1/client-errors")
async def log_client_error(data: Dict[str, Any] = Body(...)):
    """Receives silent frontend crashes and writes them to a rotating file."""
    try:
        error_msg = data.get("error", "Unknown Error")
        stack_trace = data.get("stack", "No stack trace provided")
        url = data.get("url", "Unknown URL")
        user_agent = data.get("userAgent", "Unknown Browser")

        frontend_logger.error(
            f"[FRONTEND_CRASH] URL: {url} | Browser: {user_agent} | Error: {error_msg}\nStack: {stack_trace}"
        )
        return {"status": "recorded"}
    except Exception as e:
        logger.error(f"Failed to record client error: {e}")
        return {"status": "error", "message": "Internal log failure"}


# â”€â”€â”€ Feedback Endpoints â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@app.get("/api/v1/feedback")
async def get_feedback():
    try:
        return db.get_all_feedback()
    except Exception as e:
        logger.error(f"Fetch feedback error: {e}")
        return []


@app.post("/api/v1/feedback")
async def submit_feedback(data: Dict[str, Any] = Body(...)):
    try:
        fid = data.get("id") or str(int(datetime.now(timezone(timedelta(hours=7))).timestamp() * 1000))
        user = data.get("user", "Anonymous Medical Staff")
        content = data.get("content", "")
        timestamp = data.get("timestamp") or datetime.now(timezone(timedelta(hours=7))).strftime("%d/%m/%Y, %H:%M:%S")
        status = data.get("status", "received")

        db.insert_feedback(fid, user, content, timestamp, status)
        return {"status": "success", "id": fid}
    except Exception as e:
        logger.error(f"Submit feedback error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/v1/feedback/{feedback_id}")
async def delete_feedback(feedback_id: str, request: Request):
    require_role(request, ['admin'])
    try:
        db.delete_feedback(feedback_id)
        audit_logger.info(f"Feedback {feedback_id} DELETED by admin")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Delete feedback error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.patch("/api/v1/feedback/{feedback_id}/status")
async def update_feedback_status(feedback_id: str, request: Request, data: Dict[str, Any] = Body(...)):
    require_role(request, ['admin'])
    try:
        new_status = data.get("status")
        if not new_status:
            raise HTTPException(status_code=400, detail="Status is required")
        db.update_feedback_status(feedback_id, new_status)
        audit_logger.info(f"Feedback {feedback_id} status updated to '{new_status}' by admin")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Update feedback status error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# â”€â”€â”€ Clinical Reference Search â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@app.get("/api/v1/reference/search")
async def search_reference(query: str = "", category: str = "all"):
    """Search numerical parameters, enumerative parameters, and alarms."""
    try:
        results = []
        q = f"%{query.lower()}%"
        logger.info(f"Searching clinical reference for: '{query}' (cat: {category})")

        conn = sqlite3.connect(ref_db_path)
        c = conn.cursor()

        if category in ["all", "parameters"]:
            c.execute("""SELECT id, name, description, unit, min_value, max_value 
                         FROM numerical_parameters 
                         WHERE LOWER(name) LIKE ? OR LOWER(description) LIKE ? OR CAST(id AS TEXT) LIKE ?""", (q, q, q))
            for r in c.fetchall():
                results.append({
                    "id": r[0], "type": "Numerical Parameter", "title": r[1],
                    "description": r[2] or "No description available.",
                    "detail": f"Range: {r[4]} - {r[5]} {r[3]}" if r[4] is not None else f"Unit: {r[3]}",
                    "category": "Parameter"
                })

            c.execute("""SELECT id, name, description FROM enumerative_parameters 
                         WHERE LOWER(name) LIKE ? OR LOWER(description) LIKE ? OR CAST(id AS TEXT) LIKE ?""", (q, q, q))
            for r in c.fetchall():
                results.append({
                    "id": r[0], "type": "Enumerative Parameter", "title": r[1],
                    "description": r[2] or "No description available.",
                    "detail": "Categorical selection", "category": "Parameter"
                })

        if category in ["all", "alarms"]:
            c.execute("""SELECT id, title, description, severity FROM alarms 
                         WHERE LOWER(title) LIKE ? OR LOWER(description) LIKE ? OR CAST(id AS TEXT) LIKE ?""", (q, q, q))
            for r in c.fetchall():
                results.append({
                    "id": r[0], "type": "Alarm / Alert", "title": r[1],
                    "description": r[2] or "No description available.",
                    "detail": f"Severity: {r[3]}", "category": "Alarm"
                })

        conn.close()
        logger.info(f"âœ… Search complete. Total results: {len(results)}")
        return results
    except Exception as e:
        logger.error(f"Reference search error: {e}")
        return []


# â”€â”€â”€ TREATMENT ROUTES (Modularized) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
from routers.treatment_router import router as treatment_router, require_role
app.include_router(treatment_router)






# â”€â”€â”€ Entry Point â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

