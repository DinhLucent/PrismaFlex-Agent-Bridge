"""Verify treatment OPEN/RECORD/CLOSE lifecycle after PID 461 removal."""
import requests, time
from datetime import datetime, timezone, timedelta

BASE = "http://localhost:8000"
TZ = timezone(timedelta(hours=7))
DID = "TEST_V_002"
PID = "PT_V_002"

def pkt(sid, ts):
    return {
        "meta": {"device_id": DID, "timestamp": ts},
        "s_header": {
            "patient_id": PID, "therapy_type_id": 1,
            "therapy_type_id_name": "CVVHDF", "therapy_status_id": sid,
            "machine_id": 999
        },
        "s_body": {"parameters": [
            {"id": 17, "type": "Actual", "value": 150},
            {"id": 461, "type": "Actual", "value": 9999},
        ]}
    }

t0 = datetime.now(TZ)
pre = requests.get(f"{BASE}/api/v1/treatments?limit=5").json()["total"]

# OPEN (WAITINGSTART=4)
requests.post(f"{BASE}/api/v1/telemetry", json=pkt(4, t0.isoformat()))
time.sleep(0.5)

# RECORD (RUN=5) x5
for i in range(1, 6):
    ts = (t0 + timedelta(seconds=10*i)).isoformat()
    requests.post(f"{BASE}/api/v1/telemetry", json=pkt(5, ts))
time.sleep(1)

post = requests.get(f"{BASE}/api/v1/treatments?limit=5").json()
new_count = post["total"] - pre
print(f"OPEN: {new_count} new treatments created")

# CLOSE (END=8) at +10 minutes
te = t0 + timedelta(minutes=10)
requests.post(f"{BASE}/api/v1/telemetry", json=pkt(8, te.isoformat()))
time.sleep(2)

# VERIFY
final = requests.get(f"{BASE}/api/v1/treatments?limit=10").json()
found = [i for i in final.get("items", []) if i.get("patient_id") == PID]

if found:
    t = found[0]
    dur = t.get("duration_sec", 0)
    out = t.get("outcome", "?")
    pkts = t.get("total_packets", 0)
    print(f"CLOSE: outcome={out}, duration={dur}s, packets={pkts}")
    print(f"Expected: outcome=COMPLETED, duration=~600s")

    ok_outcome = out == "COMPLETED"
    ok_dur = abs(dur - 600) < 10
    
    if ok_outcome and ok_dur:
        print("RESULT: PASS")
    else:
        if not ok_outcome:
            print(f"FAIL: outcome is {out}")
        if not ok_dur:
            print(f"FAIL: duration {dur}s != expected 600s")
else:
    print("FAIL: treatment not found in index")
