"""
Shared helpers for backend tools.
"""
import os
from datetime import timezone, timedelta

# ─── Paths ───────────────────────────────────────────────────
BACKEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
RAW_DIR = os.path.join(BACKEND_DIR, 'data', 'treatments', 'raw')

# ─── Timezone ────────────────────────────────────────────────
TZ_LOCAL = timezone(timedelta(hours=7))

# ─── Colors (Windows safe) ───────────────────────────────────
class C:
    RESET = ""
    BOLD = ""
    RED = ""
    GREEN = ""
    YELLOW = ""
    BLUE = ""
    CYAN = ""

try:
    import sys
    if hasattr(sys.stdout, "isatty") and sys.stdout.isatty():
        C.RESET = "\033[0m"
        C.BOLD = "\033[1m"
        C.RED = "\033[31m"
        C.GREEN = "\033[32m"
        C.YELLOW = "\033[33m"
        C.BLUE = "\033[34m"
        C.CYAN = "\033[36m"
except Exception:
    pass


# ─── Print Helpers ───────────────────────────────────────────
def print_header(msg: str):
    print(f"\n{'=' * 60}")
    print(f"  {C.BOLD}{msg}{C.RESET}")
    print(f"{'=' * 60}")

def print_section(msg: str):
    print(f"\n--- {C.CYAN}{msg}{C.RESET} ---")

def print_info(msg: str):
    print(f"  {msg}")

def print_ok(msg: str):
    print(f"  {C.GREEN}OK{C.RESET} {msg}")

def print_warn(msg: str):
    print(f"  {C.YELLOW}WARN{C.RESET} {msg}")

def print_err(msg: str):
    print(f"  {C.RED}ERR{C.RESET} {msg}")


# ─── File Helpers ────────────────────────────────────────────
def find_raw_file(target: str):
    """Find a raw JSONL file by treatment_id fragment or filename."""
    if not os.path.isdir(RAW_DIR):
        return None
    for f in os.listdir(RAW_DIR):
        if target.lower() in f.lower():
            return os.path.join(RAW_DIR, f)
    return None


def fmt_time(value, fmt="%Y-%m-%d %H:%M:%S"):
    """Format a timestamp string or return as-is if unparseable."""
    if not value:
        return "N/A"
    if isinstance(value, str):
        return value[:19]
    return str(value)
