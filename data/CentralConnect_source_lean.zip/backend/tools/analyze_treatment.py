"""
Treatment Raw Data Analyzer
============================
Auto-check tool for analyzing raw telemetry data from JSONL files and
treatment_records.db snapshots.

Usage:
    python analyze_treatment.py                    # Interactive: pick treatment
    python analyze_treatment.py <treatment_id>     # Analyze specific treatment
    python analyze_treatment.py --all              # Summary of all treatments

Features:
    1. Parameter Change Timeline — tracks when/which PIDs change
    2. OC Trigger Validation     — validates whether OC snapshots are justified
    3. Hourly Snapshot Integrity  — checks for gaps, duplicates, timing issues
    4. Raw Packet Statistics      — packet frequency, PID coverage, timing dist

Author: Auto-generated for PrismaFlex Clinical System
"""

import os
import sys
import json
import sqlite3
from datetime import datetime, timezone, timedelta
from collections import defaultdict, Counter
from typing import Optional

# ─── Paths ────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # backend/
DB_PATH = os.path.join(BASE_DIR, 'services', 'treatment_records.db')
RAW_DIR = os.path.join(BASE_DIR, 'data', 'treatments', 'raw')

# ─── PID Reference Table ─────────────────────────────────────────
PID_NAMES = {
    17: 'QB (Blood Flow)',
    18: 'QS_PRE (Replacement Pre)',
    19: 'QS_POST (Replacement Post)',
    21: 'QD (Dialysate Flow)',
    22: 'QPBP (Pre Blood Pump)',
    23: 'Effluent Flow',
    24: 'UF Hourly Volume',
    25: 'UF Rate Target',
    26: 'Patient Weight',
    37: 'Heparin Bolus',
    38: 'Heparin Rate',
    47: 'Heparin Remaining',
    60: 'Blood Volume',
    100: 'UF Total Volume',
    400: 'Citrate Dose',
    401: 'Citrate Concentration',
    403: 'Citrate Load',
    404: 'Calcium Rate',
    406: 'Calcium Compensation',
    409: 'Anticoagulation Type',
    461: 'Run Time (sec)',
    1: 'PA (Access Pressure)',
    2: 'PBE (Filter Pressure)',
    3: 'P_DEGAS',
    4: 'PV (Return Pressure)',
    6: 'TMP',
    7: 'PFP',
}

# Order Change PIDs (the ones that should trigger OC snapshots)
ORDER_CHANGE_PIDS = {17, 21, 18, 19, 22, 25}

# Exclude volatile PIDs from "change" analysis (pressures, timers)
VOLATILE_PIDS = {1, 2, 3, 4, 6, 7, 59, 415, 461, 60, 100, 24}

TZ_LOCAL = timezone(timedelta(hours=7))

# ─── Colors for terminal ─────────────────────────────────────────
class C:
    RESET = '\033[0m'
    BOLD = '\033[1m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    DIM = '\033[2m'
    MAGENTA = '\033[95m'


def pid_name(pid: int) -> str:
    return PID_NAMES.get(pid, f'PID_{pid}')


def fmt_time(ts_str: str) -> str:
    """Parse timestamp to readable local time."""
    try:
        dt = datetime.fromisoformat(ts_str.replace('Z', '+00:00'))
        local = dt.astimezone(TZ_LOCAL)
        return local.strftime('%H:%M:%S')
    except:
        return ts_str[:19] if ts_str else '???'


# ═══════════════════════════════════════════════════════════════════
# 1. DATABASE QUERIES
# ═══════════════════════════════════════════════════════════════════

def get_db():
    if not os.path.exists(DB_PATH):
        print(f"{C.RED}❌ Database not found: {DB_PATH}{C.RESET}")
        sys.exit(1)
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db


def list_treatments():
    """List all treatments with basic info."""
    db = get_db()
    try:
        rows = db.execute("""
            SELECT t.id, t.device_id, t.patient_id, t.start_time, t.end_time,
                   t.outcome, t.fsm_state, t.total_packets, t.total_run_seconds
            FROM treatments t
            ORDER BY t.start_time DESC
        """).fetchall()
    except Exception:
        # Fallback: minimal columns
        rows = db.execute("SELECT * FROM treatments ORDER BY rowid DESC").fetchall()
    db.close()
    return rows


def get_snapshots(treatment_id: str):
    """Get all snapshots for a treatment, sorted by time."""
    db = get_db()
    rows = db.execute("""
        SELECT * FROM treatment_hourly_snapshots
        WHERE treatment_id = ?
        ORDER BY snapshot_time
    """, (treatment_id,)).fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_treatment_info(treatment_id: str):
    """Get full treatment info."""
    db = get_db()
    row = db.execute("SELECT * FROM treatments WHERE id = ?", (treatment_id,)).fetchone()
    db.close()
    return dict(row) if row else None


# ═══════════════════════════════════════════════════════════════════
# 2. RAW DATA ANALYSIS
# ═══════════════════════════════════════════════════════════════════

def find_raw_file(treatment_id: str) -> Optional[str]:
    """Find the JSONL file for a treatment."""
    if not os.path.exists(RAW_DIR):
        return None
    for fn in os.listdir(RAW_DIR):
        if treatment_id in fn and fn.endswith('.jsonl'):
            return os.path.join(RAW_DIR, fn)
    return None


def parse_raw_packets(filepath: str):
    """Parse all packets from a raw JSONL file."""
    packets = []
    with open(filepath, 'r', encoding='utf-8') as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                pkt = json.loads(line)
                packets.append(pkt)
            except json.JSONDecodeError as e:
                print(f"  {C.YELLOW}⚠ Line {line_no}: JSON parse error: {e}{C.RESET}")
    return packets


def analyze_parameter_changes(packets: list):
    """
    Track parameter changes across all packets.
    Returns:
        changes: list of (timestamp, pid, old_val, new_val)
        order_changes: list of changes for ORDER_CHANGE_PIDS only
        stats: dict with packet/PID statistics
    """
    cache = {}  # pid -> last_value
    changes = []
    order_changes = []
    pid_counter = Counter()
    total_packets = len(packets)

    for pkt in packets:
        ts = pkt.get('meta', {}).get('timestamp', '')
        body = pkt.get('s_body', {})
        params = body.get('parameters', [])

        for p in params:
            pid = p.get('id')
            val = p.get('value')
            val_text = p.get('value_text', str(val))
            pid_counter[pid] += 1

            if pid in VOLATILE_PIDS:
                continue

            if pid in cache and cache[pid] != val_text:
                change = (ts, pid, cache[pid], val_text)
                changes.append(change)
                if pid in ORDER_CHANGE_PIDS:
                    order_changes.append(change)

            cache[pid] = val_text

    stats = {
        'total_packets': total_packets,
        'unique_pids': len(pid_counter),
        'pid_frequency': pid_counter,
    }
    return changes, order_changes, stats


# ═══════════════════════════════════════════════════════════════════
# 3. SNAPSHOT VALIDATION
# ═══════════════════════════════════════════════════════════════════

def validate_snapshots(snapshots: list):
    """
    Validate snapshot integrity.
    Returns list of issues.
    """
    issues = []
    hourly = [s for s in snapshots if s['hour_label'].startswith('H')]
    oc = [s for s in snapshots if s['hour_label'].startswith('OC')]

    # Check for gaps in hourly sequence
    hour_nums = []
    for s in hourly:
        try:
            h = int(s['hour_label'].replace('H', ''))
            hour_nums.append(h)
        except:
            issues.append(f"Invalid hour label: {s['hour_label']}")

    if hour_nums:
        expected = set(range(1, max(hour_nums) + 1))
        missing = expected - set(hour_nums)
        if missing:
            issues.append(f"Missing hourly snapshots: {sorted(missing)}")

    # Check OC snapshots for "no-change" situations
    key_cols = ['qb', 'qd', 'qs', 'qpbp', 'uf_rate_target', 'heparin_rate']
    for oc_snap in oc:
        oc_time = oc_snap['snapshot_time']
        oc_label = oc_snap['hour_label']
        reason = oc_snap.get('reason', '')

        # Find the nearest hourly snapshot before this OC
        prev_hourly = None
        for h in hourly:
            if h['snapshot_time'] <= oc_time:
                prev_hourly = h
            else:
                break

        if prev_hourly:
            diffs = []
            for col in key_cols:
                oc_val = oc_snap.get(col)
                h_val = prev_hourly.get(col)
                if oc_val != h_val and oc_val is not None and h_val is not None:
                    diffs.append(f"{col}: {h_val}→{oc_val}")

            if not diffs:
                issues.append(
                    f"⚠ {oc_label} has NO visible changes vs {prev_hourly['hour_label']}. "
                    f"Reason: {reason or 'NONE'}"
                )
            else:
                # Valid OC - there are visible changes
                pass

    return issues


# ═══════════════════════════════════════════════════════════════════
# 4. DISPLAY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════

def print_header(text: str):
    print(f"\n{C.BOLD}{C.CYAN}{'═' * 70}")
    print(f"  {text}")
    print(f"{'═' * 70}{C.RESET}")


def print_section(text: str):
    print(f"\n  {C.BOLD}{C.BLUE}── {text} ──{C.RESET}")


def print_treatment_list(treatments):
    """Pretty-print treatment list."""
    print_header("📋 All Treatments")
    print(f"  {'#':>3}  {'ID':8}  {'Device':8}  {'Patient':10}  {'Start':14}  {'Duration':>10}  {'Pkts':>6}  {'State'}")
    print(f"  {'─'*3}  {'─'*8}  {'─'*8}  {'─'*10}  {'─'*14}  {'─'*10}  {'─'*6}  {'─'*10}")
    for i, t in enumerate(treatments, 1):
        tid = t['id'][:8]
        dev = t['device_id'] or '?'
        pat = (t['patient_id'] or '?')[:10]
        start = fmt_time(t['start_time']) if t['start_time'] else '?'
        dur_sec = None
        try:
            dur_sec = t['total_run_seconds']
        except (IndexError, KeyError):
            pass
        dur = f"{(dur_sec or 0) / 3600:.1f}h" if dur_sec else '?'
        pkts = '?'
        try:
            pkts = t['total_packets'] or '?'
        except (IndexError, KeyError):
            pass
        state = t['fsm_state'] or t['outcome'] or '?'
        color = C.GREEN if state == 'CLOSED' else C.YELLOW
        print(f"  {i:>3}  {tid}  {dev:8}  {pat:10}  {start:14}  {dur:>10}  {pkts:>6}  {color}{state}{C.RESET}")


def print_snapshot_table(snapshots: list):
    """Pretty-print snapshot table with change highlighting."""
    print_section("📊 Snapshot Timeline")
    cols = ['hour_label', 'snapshot_time', 'qb', 'qd', 'qs', 'qpbp', 'uf_rate_target', 'uf_hourly', 'uf_total', 'reason']
    header = f"  {'Label':8} {'Time':10} {'QB':>6} {'QD':>6} {'QS':>6} {'QPBP':>6} {'UF_R':>6} {'UF_H':>6} {'UF_T':>8}  {'Reason'}"
    print(header)
    print(f"  {'─'*8} {'─'*10} {'─'*6} {'─'*6} {'─'*6} {'─'*6} {'─'*6} {'─'*6} {'─'*8}  {'─'*20}")

    prev = {}
    for s in snapshots:
        label = s['hour_label']
        time = fmt_time(s['snapshot_time'])
        is_oc = label.startswith('OC')

        vals = {
            'qb': s.get('qb'),
            'qd': s.get('qd'),
            'qs': s.get('qs'),
            'qpbp': s.get('qpbp'),
            'uf_rate_target': s.get('uf_rate_target'),
            'uf_hourly': s.get('uf_hourly'),
            'uf_total': s.get('uf_total'),
        }

        def fmt_col(key, width=6):
            v = vals[key]
            if v is None:
                return f"{'·':>{width}}"
            v_str = f"{int(v):>{width}}" if isinstance(v, (int, float)) else f"{v:>{width}}"
            if prev and key in prev and prev[key] != v and key not in ('uf_hourly', 'uf_total'):
                return f"{C.RED}{C.BOLD}{v_str}{C.RESET}"
            return v_str

        reason = (s.get('reason') or '')[:40]
        label_color = C.YELLOW if is_oc else C.GREEN if label == snapshots[-1]['hour_label'] else ''
        label_reset = C.RESET if label_color else ''

        print(f"  {label_color}{label:8}{label_reset} {time:10} {fmt_col('qb')} {fmt_col('qd')} {fmt_col('qs')} {fmt_col('qpbp')} {fmt_col('uf_rate_target')} {fmt_col('uf_hourly')} {fmt_col('uf_total', 8)}  {C.DIM}{reason}{C.RESET}")

        # Update prev (but exclude OC so we compare OC against hourly too)
        if not is_oc:
            prev = vals.copy()


def print_change_timeline(changes: list, label: str = "All Parameter Changes"):
    """Print parameter change timeline."""
    print_section(f"🔄 {label}")
    if not changes:
        print(f"  {C.DIM}No changes detected.{C.RESET}")
        return

    # Group by timestamp (within 1 second)
    groups = []
    current_group = []
    last_ts = None

    for ts, pid, old, new in changes:
        if last_ts and ts != last_ts:
            groups.append(current_group)
            current_group = []
        current_group.append((ts, pid, old, new))
        last_ts = ts

    if current_group:
        groups.append(current_group)

    for group in groups[-50:]:  # Show last 50 change events
        ts = group[0][0]
        time_str = fmt_time(ts)
        pids_str = []
        for _, pid, old, new in group:
            is_order = pid in ORDER_CHANGE_PIDS
            color = C.RED if is_order else C.DIM
            marker = '⚡' if is_order else '  '
            pids_str.append(f"    {marker} {color}{pid_name(pid):30} {old:>10} → {new:<10}{C.RESET}")

        print(f"  {C.CYAN}{time_str}{C.RESET}")
        for line in pids_str:
            print(line)

    if len(groups) > 50:
        print(f"  {C.DIM}... and {len(groups) - 50} more change events (showing last 50){C.RESET}")


def print_oc_validation(issues: list):
    """Print OC validation results."""
    print_section("🔍 OC Snapshot Validation")
    if not issues:
        print(f"  {C.GREEN}✅ All OC snapshots have visible parameter changes.{C.RESET}")
        return
    for issue in issues:
        if issue.startswith('⚠'):
            print(f"  {C.YELLOW}{issue}{C.RESET}")
        else:
            print(f"  {C.RED}❌ {issue}{C.RESET}")


def print_raw_stats(stats: dict, order_changes: list):
    """Print raw data statistics."""
    print_section("📈 Raw Data Statistics")
    print(f"  Total packets:     {stats['total_packets']}")
    print(f"  Unique PIDs:       {stats['unique_pids']}")
    print(f"  Order changes:     {len(order_changes)}")

    print(f"\n  {C.BOLD}PID Frequency (top 20):{C.RESET}")
    for pid, count in stats['pid_frequency'].most_common(20):
        is_order = pid in ORDER_CHANGE_PIDS
        marker = '⚡' if is_order else '  '
        color = C.CYAN if is_order else ''
        reset = C.RESET if color else ''
        print(f"    {marker} {color}PID {pid:>4} ({pid_name(pid):30}) × {count:>6}{reset}")


# ═══════════════════════════════════════════════════════════════════
# 5. MAIN ANALYSIS ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════════

def analyze_treatment(treatment_id: str):
    """Full analysis of a single treatment."""
    # Treatment info
    info = get_treatment_info(treatment_id)
    if not info:
        print(f"{C.RED}❌ Treatment not found: {treatment_id}{C.RESET}")
        return

    print_header(f"🔬 Treatment Analysis: {treatment_id[:8]}")
    print(f"  Device:   {info.get('device_id')}")
    print(f"  Patient:  {info.get('patient_id')}")
    print(f"  Start:    {info.get('start_time')}")
    print(f"  End:      {info.get('end_time', 'ACTIVE')}")
    print(f"  Status:   {info.get('status')}")

    # Snapshots
    snapshots = get_snapshots(treatment_id)
    hourly = [s for s in snapshots if s['hour_label'].startswith('H')]
    oc_snaps = [s for s in snapshots if s['hour_label'].startswith('OC')]
    print(f"\n  Snapshots: {len(hourly)} hourly + {len(oc_snaps)} OC = {len(snapshots)} total")

    if snapshots:
        print_snapshot_table(snapshots)

    # Validate OC
    if oc_snaps:
        issues = validate_snapshots(snapshots)
        print_oc_validation(issues)

    # Raw data analysis
    raw_file = find_raw_file(treatment_id)
    if raw_file:
        print_section(f"📦 Raw Data: {os.path.basename(raw_file)}")
        fsize = os.path.getsize(raw_file) / 1024 / 1024
        print(f"  File size: {fsize:.1f} MB")

        packets = parse_raw_packets(raw_file)
        changes, order_changes, stats = analyze_parameter_changes(packets)

        print_raw_stats(stats, order_changes)

        if order_changes:
            print_change_timeline(order_changes, "Order-Change Events (OC Triggers)")
        
        if changes:
            print_change_timeline(changes, "All Non-Volatile Parameter Changes")
    else:
        print(f"\n  {C.DIM}No raw JSONL file found for this treatment.{C.RESET}")

    print(f"\n{C.BOLD}{'═' * 70}{C.RESET}\n")


def main():
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        if arg == '--all':
            treatments = list_treatments()
            print_treatment_list(treatments)
        elif arg == '--help':
            print(__doc__)
        else:
            # Find treatment by partial ID
            treatments = list_treatments()
            matches = [t for t in treatments if arg.lower() in t['id'].lower()]
            if matches:
                analyze_treatment(matches[0]['id'])
            else:
                print(f"{C.RED}❌ No treatment matching '{arg}'{C.RESET}")
    else:
        # Interactive mode
        treatments = list_treatments()
        if not treatments:
            print(f"{C.RED}❌ No treatments found in database.{C.RESET}")
            return

        print_treatment_list(treatments)
        print(f"\n  {C.BOLD}Enter treatment # to analyze (or 'q' to quit):{C.RESET} ", end='')
        try:
            choice = input().strip()
            if choice.lower() == 'q':
                return
            idx = int(choice) - 1
            if 0 <= idx < len(treatments):
                analyze_treatment(treatments[idx]['id'])
            else:
                print(f"{C.RED}Invalid choice.{C.RESET}")
        except (ValueError, EOFError):
            print(f"{C.RED}Invalid input.{C.RESET}")


if __name__ == '__main__':
    main()
