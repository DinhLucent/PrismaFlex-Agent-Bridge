"""
PrismaFlex Ingest Simulator
===========================
Replay legacy/raw NDJSON packets as LIVE, BACKFILL, or BACKFILL->LIVE CUTOVER.

This tool exists to answer one practical question:
"If we take an old raw file and make it behave like LIVE traffic, does the
runtime still keep treatment continuity, snapshots, and raw ownership stable?"

Supported input shapes:
1. Legacy pre-Mirth raw packets:
   {
     "packet_num": 169,
     "timestamp": "...",
     "s_header": {...},
     "s_body": {...}
   }

2. Already-normalized packets:
   {
     "meta": {...},
     "header": {...},
     "body": {...}
   }

Examples:
    python -m tools.simulate_ingest data\\done\\May4_data.ndjson --mode live --route-style split
    python -m tools.simulate_ingest data\\done\\May4_data.ndjson --mode live --route-style legacy --speed 120
    python -m tools.simulate_ingest data\\done\\May4_data.ndjson --mode cutover --cutover-at-index 1000 --backfill-speed 0 --live-speed 60
    python -m tools.simulate_ingest data\\done\\May4_data.ndjson --mode cutover --sort-by-time --dry-run
"""

from __future__ import annotations

import argparse
import gzip
import json
import os
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple

import requests

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tools.helpers import (
    BACKEND_DIR,
    C,
    RAW_DIR,
    TZ_LOCAL,
    find_raw_file,
    fmt_time,
    print_err,
    print_header,
    print_info,
    print_ok,
    print_section,
    print_warn,
)

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


DEFAULT_BASE_URL = "http://localhost:8000"
SPLIT_LIVE_PATH = "/api/v1/telemetry/live"
SPLIT_BACKFILL_PATH = "/api/v1/telemetry/backfill"
LEGACY_PATH = "/api/v1/telemetry"


@dataclass
class ReplayOrderStats:
    total_packets: int
    out_of_order_pairs: int
    max_backward_seconds: float


def find_any_ndjson(target: str) -> Optional[str]:
    """Find an NDJSON file by direct path, treatment id, or common data folders."""
    if os.path.isfile(target):
        return target

    for base in [
        BACKEND_DIR,
        os.path.join(BACKEND_DIR, "data"),
        os.path.join(BACKEND_DIR, "data", "done"),
        RAW_DIR,
        os.path.join(os.path.dirname(BACKEND_DIR), "data"),
        os.path.join(os.path.dirname(BACKEND_DIR), "data", "done"),
        os.path.join(os.path.dirname(BACKEND_DIR), "data", "treatments", "raw"),
    ]:
        full = os.path.join(base, target)
        if os.path.isfile(full):
            return full

    raw_match = find_raw_file(target)
    if raw_match:
        return raw_match

    search_dirs = [
        os.path.join(BACKEND_DIR, "data", "done"),
        RAW_DIR,
        os.path.join(os.path.dirname(BACKEND_DIR), "data", "done"),
        os.path.join(os.path.dirname(BACKEND_DIR), "data", "treatments", "raw"),
    ]
    for directory in search_dirs:
        if not os.path.isdir(directory):
            continue
        for filename in os.listdir(directory):
            if target.lower() in filename.lower():
                return os.path.join(directory, filename)
    return None


def read_packets(filepath: str) -> List[Dict[str, Any]]:
    packets: List[Dict[str, Any]] = []
    opener = gzip.open if filepath.endswith(".gz") else open
    with opener(filepath, "rt", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            line = line.strip()
            if not line:
                continue
            try:
                packets.append(json.loads(line))
            except json.JSONDecodeError as exc:
                print_warn(f"Line {line_no}: skipped invalid JSON ({exc})")
    return packets


def _parse_datetime_string(value: str) -> Optional[datetime]:
    value = (value or "").strip()
    if not value:
        return None

    if value.endswith(" UTC"):
        try:
            return datetime.strptime(value, "%Y-%m-%d %H:%M:%S UTC").replace(tzinfo=timezone.utc)
        except ValueError:
            return None

    try:
        if value.endswith("Z"):
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        parsed = datetime.fromisoformat(value)
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed
    except ValueError:
        pass

    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
        try:
            return datetime.strptime(value, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def parse_packet_time(packet: Dict[str, Any]) -> Optional[datetime]:
    """Resolve packet time for ordering/pacing, preferring unix epoch when available."""
    meta = packet.get("meta", {})
    header = packet.get("s_header") or packet.get("header") or {}

    unix_value = meta.get("timestamp_unix", header.get("timestamp_unix"))
    if unix_value is not None:
        try:
            unix_float = float(unix_value)
            if unix_float > 1_000_000_000_000:
                unix_float /= 1000.0
            return datetime.fromtimestamp(unix_float, tz=timezone.utc)
        except (TypeError, ValueError, OSError):
            pass

    for candidate in (
        meta.get("timestamp"),
        header.get("timestamp"),
        packet.get("timestamp"),
    ):
        parsed = _parse_datetime_string(str(candidate)) if candidate else None
        if parsed is not None:
            return parsed
    return None


def build_device_id(machine_id: Any) -> str:
    text = str(machine_id or "").strip()
    if not text or text.lower() == "unknown":
        return "unknown"

    upper = text.upper()
    if upper.startswith("PF_"):
        suffix = upper[3:].strip()
        return f"PF_{int(suffix):03d}" if suffix.isdigit() else upper

    if text.isdigit():
        return f"PF_{int(text):03d}"

    return text


def normalize_packet(packet: Dict[str, Any], mode: str) -> Dict[str, Any]:
    """
    Convert a raw pre-Mirth packet into the payload contract expected by backend ingest.
    If the packet is already normalized, only adjust mode/metadata.
    """
    normalized = json.loads(json.dumps(packet))

    # Already normalized packet
    if "meta" in normalized and ("header" in normalized or "s_header" in normalized):
        normalized.setdefault("meta", {})
        normalized["meta"]["device_id"] = build_device_id(
            normalized["meta"].get("device_id")
            or normalized.get("s_header", normalized.get("header", {})).get("machine_id")
            or "unknown"
        )
        normalized["meta"]["mode"] = mode.upper()
        normalized["meta"].setdefault(
            "transform_version",
            "sim_live_v1" if mode.upper() == "LIVE" else "sim_backfill_v1",
        )
        normalized["meta"].setdefault(
            "ingest_profile",
            "realtime" if mode.upper() == "LIVE" else "historical_replay",
        )
        if "header" in normalized and "s_header" not in normalized:
            normalized["s_header"] = normalized["header"]
        if "body" in normalized and "s_body" not in normalized:
            normalized["s_body"] = normalized["body"]
        return normalized

    header = normalized.get("s_header", {})
    body = normalized.get("s_body", {})
    machine_id = header.get("machine_id")
    if not machine_id:
        raise ValueError("Packet missing s_header.machine_id")

    original_time = header.get("timestamp") or normalized.get("timestamp")
    if not original_time:
        raise ValueError("Packet missing original timestamp")

    timestamp_source = "s_header.timestamp" if header.get("timestamp") else "timestamp"
    payload = {
        "meta": {
            "device_id": build_device_id(machine_id),
            "timestamp": original_time,
            "packet_num": normalized.get("packet_num"),
            "mode": mode.upper(),
            "transform_version": "sim_live_v1" if mode.upper() == "LIVE" else "sim_backfill_v1",
            "ingest_profile": "realtime" if mode.upper() == "LIVE" else "historical_replay",
            "timestamp_source": timestamp_source,
            "replay_source": "codex_simulator",
        },
        "header": json.loads(json.dumps(header)),
        "body": json.loads(json.dumps(body)),
        "s_header": json.loads(json.dumps(header)),
        "s_body": json.loads(json.dumps(body)),
    }
    if header.get("timestamp_unix") is not None:
        payload["meta"]["timestamp_unix"] = header.get("timestamp_unix")
    payload["header"]["timestamp"] = original_time
    payload["s_header"]["timestamp"] = original_time
    return payload


def analyze_order(packets: Iterable[Dict[str, Any]]) -> ReplayOrderStats:
    previous_time: Optional[datetime] = None
    backwards = 0
    max_back = 0.0
    total = 0
    for packet in packets:
        total += 1
        pkt_time = parse_packet_time(packet)
        if pkt_time is None:
            continue
        if previous_time is not None and pkt_time < previous_time:
            backwards += 1
            max_back = max(max_back, (previous_time - pkt_time).total_seconds())
        previous_time = pkt_time
    return ReplayOrderStats(total_packets=total, out_of_order_pairs=backwards, max_backward_seconds=max_back)


def endpoint_for_mode(base_url: str, mode: str, route_style: str) -> str:
    mode = mode.upper()
    if route_style == "legacy":
        return base_url.rstrip("/") + LEGACY_PATH
    if mode == "LIVE":
        return base_url.rstrip("/") + SPLIT_LIVE_PATH
    if mode == "BACKFILL":
        return base_url.rstrip("/") + SPLIT_BACKFILL_PATH
    raise ValueError(f"Unsupported mode for endpoint: {mode}")


def handoff_url(base_url: str, device_id: str) -> str:
    return f"{base_url.rstrip('/')}/api/v1/devices/{device_id}/handoff"


def sort_packets_by_time(packets: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return sorted(
        packets,
        key=lambda pkt: (parse_packet_time(pkt) or datetime.max.replace(tzinfo=timezone.utc)),
    )


def select_cutover_index(
    packets: List[Dict[str, Any]],
    cutover_at_index: Optional[int],
    cutover_at_timestamp: Optional[str],
) -> int:
    if cutover_at_index is not None:
        return max(1, min(len(packets) - 1, cutover_at_index))

    if cutover_at_timestamp:
        target = _parse_datetime_string(cutover_at_timestamp)
        if target is None:
            raise ValueError(f"Invalid cutover timestamp: {cutover_at_timestamp}")
        for index, packet in enumerate(packets):
            pkt_time = parse_packet_time(packet)
            if pkt_time is not None and pkt_time >= target:
                return max(1, min(len(packets) - 1, index))

    return max(1, len(packets) // 2)


def sleep_for_gap(previous_time: Optional[datetime], current_time: Optional[datetime], speed: float, max_delay: float) -> None:
    if speed <= 0 or previous_time is None or current_time is None:
        return
    gap = (current_time - previous_time).total_seconds()
    if gap <= 0:
        return
    delay = min(gap / speed, max_delay)
    if delay > 0:
        time.sleep(delay)


def send_packets(
    session: requests.Session,
    packets: List[Dict[str, Any]],
    mode: str,
    target_url: str,
    speed: float,
    max_delay: float,
    progress_every: int,
    dry_run: bool,
) -> Tuple[int, int]:
    print_section(f"Sending {len(packets)} packets as {mode}")
    print_info(f"Target: {target_url}")
    print_info(f"Speed: {'MAX' if speed == 0 else f'{speed}x'}")

    success = 0
    errors = 0
    previous_time: Optional[datetime] = None
    started = time.time()

    for index, raw_packet in enumerate(packets, 1):
        payload = normalize_packet(raw_packet, mode)
        current_time = parse_packet_time(payload)
        sleep_for_gap(previous_time, current_time, speed, max_delay)
        previous_time = current_time

        if dry_run:
            success += 1
        else:
            try:
                response = session.post(target_url, json=payload, timeout=15)
                if response.status_code < 400:
                    success += 1
                else:
                    errors += 1
                    if errors <= 3:
                        print_warn(
                            f"{mode} packet {index}: HTTP {response.status_code} {response.text[:120]}"
                        )
            except Exception as exc:  # pragma: no cover - network/runtime path
                errors += 1
                if errors <= 3:
                    print_err(f"{mode} packet {index}: {exc}")

        if index % progress_every == 0 or index == len(packets):
            elapsed = max(time.time() - started, 0.001)
            rate = index / elapsed
            stamp = fmt_time(payload["meta"].get("timestamp"), "%Y-%m-%d %H:%M:%S")
            print_info(f"{mode}: {index}/{len(packets)} @ {rate:.0f} pkt/s (last={stamp})")

    print_ok(f"{mode} complete: success={success}, errors={errors}")
    return success, errors


def maybe_call_handoff(
    session: requests.Session,
    base_url: str,
    route_style: str,
    device_id: str,
    dry_run: bool,
) -> None:
    if route_style == "legacy":
        print_warn("Route style is legacy; skipping handoff call and continuing on the same ingest route.")
        return

    url = handoff_url(base_url, device_id)
    print_section("Calling BACKFILL -> LIVE handoff")
    print_info(f"Handoff URL: {url}")
    if dry_run:
        print_ok("Dry-run: handoff skipped")
        return
    try:
        response = session.post(url, json={"from": "BACKFILL", "to": "LIVE"}, timeout=20)
        if response.status_code < 400:
            print_ok(f"Handoff succeeded ({response.status_code})")
        else:
            print_warn(f"Handoff returned HTTP {response.status_code}: {response.text[:200]}")
    except Exception as exc:  # pragma: no cover - network/runtime path
        print_err(f"Handoff failed: {exc}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Replay raw NDJSON as LIVE/BACKFILL/CUTOVER")
    parser.add_argument("target", help="Raw NDJSON path or treatment/raw identifier")
    parser.add_argument("--mode", choices=["live", "backfill", "cutover"], default="live")
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL, help=f"Backend base URL (default: {DEFAULT_BASE_URL})")
    parser.add_argument("--route-style", choices=["split", "legacy"], default="split")
    parser.add_argument("--speed", type=float, default=0.0, help="Unified replay speed multiplier (0 = max speed)")
    parser.add_argument("--backfill-speed", type=float, default=None, help="Override speed for backfill segment")
    parser.add_argument("--live-speed", type=float, default=None, help="Override speed for live segment")
    parser.add_argument("--max-delay", type=float, default=1.0, help="Max sleep between packets in seconds")
    parser.add_argument("--progress-every", type=int, default=1000, help="Print progress every N packets")
    parser.add_argument("--cutover-at-index", type=int, default=None, help="Switch to LIVE at this packet index")
    parser.add_argument("--cutover-at-timestamp", default=None, help="Switch to LIVE when packet_time >= this timestamp")
    parser.add_argument("--sort-by-time", action="store_true", help="Sort packets by timestamp before replay")
    parser.add_argument("--limit", type=int, default=None, help="Replay only the first N packets after optional sorting")
    parser.add_argument("--dry-run", action="store_true", help="Do not POST; only simulate plan and pacing")

    args = parser.parse_args()

    filepath = find_any_ndjson(args.target)
    if not filepath:
        print_err(f"Could not find file: {args.target}")
        raise SystemExit(1)

    packets = read_packets(filepath)
    if not packets:
        print_err("No packets loaded from file")
        raise SystemExit(1)

    if args.sort_by_time:
        packets = sort_packets_by_time(packets)
    if args.limit is not None:
        packets = packets[: args.limit]

    order_stats = analyze_order(packets)
    sample_payload = normalize_packet(packets[0], "LIVE")
    device_id = sample_payload["meta"]["device_id"]
    first_time = parse_packet_time(packets[0])
    last_time = parse_packet_time(packets[-1])

    print_header("PrismaFlex Ingest Simulation")
    print_info(f"File: {filepath}")
    print_info(f"Packets: {len(packets)}")
    print_info(f"Device: {device_id}")
    if first_time and last_time:
        print_info(
            "Time range: "
            f"{first_time.astimezone(TZ_LOCAL).strftime('%Y-%m-%d %H:%M:%S')} -> "
            f"{last_time.astimezone(TZ_LOCAL).strftime('%Y-%m-%d %H:%M:%S')}"
        )
    print_info(f"Route style: {args.route_style}")
    print_info(f"Mode: {args.mode.upper()}")
    print_info(
        f"Order check: out_of_order_pairs={order_stats.out_of_order_pairs}, "
        f"max_backward={order_stats.max_backward_seconds:.0f}s"
    )
    if order_stats.out_of_order_pairs > 0:
        print_warn("Input is not monotonic by timestamp; chronology tests may fail unless you sort first.")

    session = requests.Session()

    if args.mode == "live":
        target_url = endpoint_for_mode(args.base_url, "LIVE", args.route_style)
        send_packets(
            session,
            packets,
            "LIVE",
            target_url,
            speed=args.live_speed if args.live_speed is not None else args.speed,
            max_delay=args.max_delay,
            progress_every=args.progress_every,
            dry_run=args.dry_run,
        )
        return

    if args.mode == "backfill":
        target_url = endpoint_for_mode(args.base_url, "BACKFILL", args.route_style)
        send_packets(
            session,
            packets,
            "BACKFILL",
            target_url,
            speed=args.backfill_speed if args.backfill_speed is not None else args.speed,
            max_delay=args.max_delay,
            progress_every=args.progress_every,
            dry_run=args.dry_run,
        )
        return

    cutover_index = select_cutover_index(packets, args.cutover_at_index, args.cutover_at_timestamp)
    backfill_packets = packets[:cutover_index]
    live_packets = packets[cutover_index:]
    print_section("CUTOVER plan")
    print_info(f"Backfill segment: {len(backfill_packets)} packets")
    print_info(f"Live segment: {len(live_packets)} packets")
    if live_packets:
        live_start = parse_packet_time(live_packets[0])
        if live_start:
            print_info(f"Live resumes at: {live_start.astimezone(TZ_LOCAL).strftime('%Y-%m-%d %H:%M:%S')}")

    send_packets(
        session,
        backfill_packets,
        "BACKFILL",
        endpoint_for_mode(args.base_url, "BACKFILL", args.route_style),
        speed=args.backfill_speed if args.backfill_speed is not None else args.speed,
        max_delay=args.max_delay,
        progress_every=args.progress_every,
        dry_run=args.dry_run,
    )
    maybe_call_handoff(session, args.base_url, args.route_style, device_id, args.dry_run)
    send_packets(
        session,
        live_packets,
        "LIVE",
        endpoint_for_mode(args.base_url, "LIVE", args.route_style),
        speed=args.live_speed if args.live_speed is not None else args.speed,
        max_delay=args.max_delay,
        progress_every=args.progress_every,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
