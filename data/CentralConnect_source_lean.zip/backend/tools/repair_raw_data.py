"""
Repair Raw Data — One-Time Fix for Split Treatment Files
=========================================================
Bug v3.7.0–v3.7.3: When a treatment received END status, the raw .jsonl
was compressed to .gz and the original deleted. On Resume, a new empty
.jsonl was created, fragmenting data into two files.

This script:
  1. Scans the raw data directory for treatments with BOTH .gz and .jsonl
  2. Decompresses the .gz (old data)
  3. Appends the .jsonl (new data) to the decompressed content
  4. Saves as a single unified .jsonl
  5. Removes the orphaned .gz

Usage:
    python backend/tools/repair_raw_data.py
    
    Add --dry-run to preview without changing anything:
    python backend/tools/repair_raw_data.py --dry-run
"""

import os
import sys
import gzip
import shutil
import argparse
from datetime import datetime

# ─── Auto-detect data directory ────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
# Try both possible locations (depends on CWD when backend starts)
CANDIDATES = [
    os.path.join(SCRIPT_DIR, '..', 'data', 'treatments', 'raw'),        # backend/data/...
    os.path.join(SCRIPT_DIR, '..', '..', 'data', 'treatments', 'raw'),  # project root/data/...
]


def find_raw_dir():
    for path in CANDIDATES:
        resolved = os.path.abspath(path)
        if os.path.isdir(resolved):
            return resolved
    return None


def find_split_treatments(raw_dir: str) -> list:
    """Find treatments that have BOTH .gz and .jsonl files (fragmented data)."""
    gz_files = {}
    jsonl_files = {}
    
    for fname in os.listdir(raw_dir):
        if fname.startswith('treatment_') and fname.endswith('.raw.jsonl.gz'):
            tid = fname.replace('treatment_', '').replace('.raw.jsonl.gz', '')
            gz_files[tid] = os.path.join(raw_dir, fname)
        elif fname.startswith('treatment_') and fname.endswith('.raw.jsonl'):
            tid = fname.replace('treatment_', '').replace('.raw.jsonl', '')
            jsonl_files[tid] = os.path.join(raw_dir, fname)
    
    splits = []
    for tid in gz_files:
        if tid in jsonl_files:
            splits.append({
                'treatment_id': tid,
                'gz_path': gz_files[tid],
                'jsonl_path': jsonl_files[tid],
                'gz_size': os.path.getsize(gz_files[tid]),
                'jsonl_size': os.path.getsize(jsonl_files[tid]),
            })
    return splits


def count_lines(filepath: str) -> int:
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return sum(1 for line in f if line.strip())
    except Exception:
        return 0


def repair_treatment(split: dict, dry_run: bool = False) -> bool:
    """Merge .gz (old data) + .jsonl (new data) into a single .jsonl."""
    tid = split['treatment_id'][:8]
    gz_path = split['gz_path']
    jsonl_path = split['jsonl_path']
    
    print(f"\n  {'[DRY-RUN] ' if dry_run else ''}Repairing {tid}...")
    print(f"    .gz  = {split['gz_size'] / 1024:.1f} KB (old data)")
    print(f"    .jsonl = {split['jsonl_size'] / 1024:.1f} KB (new data after Resume)")
    
    if dry_run:
        return True
    
    # Step 1: Create backup of .jsonl (new data)
    backup_path = jsonl_path + '.repair_backup'
    try:
        shutil.copy2(jsonl_path, backup_path)
    except Exception as e:
        print(f"    ❌ Failed to backup .jsonl: {e}")
        return False
    
    # Step 2: Decompress .gz → overwrite .jsonl with old data
    try:
        with gzip.open(gz_path, 'rb') as f_in:
            with open(jsonl_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
    except Exception as e:
        print(f"    ❌ Failed to decompress .gz: {e}")
        # Restore backup
        shutil.copy2(backup_path, jsonl_path)
        os.remove(backup_path)
        return False
    
    old_lines = count_lines(jsonl_path)
    
    # Step 3: Append new data (from backup) to end of decompressed old data
    try:
        with open(backup_path, 'r', encoding='utf-8') as f_new:
            new_content = f_new.read()
        
        if new_content.strip():  # Only append if there's actual data
            with open(jsonl_path, 'a', encoding='utf-8') as f_out:
                # Ensure newline separator
                if not new_content.startswith('\n'):
                    f_out.write('\n')
                f_out.write(new_content)
    except Exception as e:
        print(f"    ❌ Failed to append new data: {e}")
        return False
    
    total_lines = count_lines(jsonl_path)
    merged_size = os.path.getsize(jsonl_path)
    
    # Step 4: Verify merged file is larger than either source
    if merged_size < split['gz_size']:
        print(f"    ❌ Merged file smaller than expected. Aborting.")
        shutil.copy2(backup_path, jsonl_path)
        os.remove(backup_path)
        return False
    
    # Step 5: Remove .gz and backup
    try:
        os.remove(gz_path)
        os.remove(backup_path)
    except Exception as e:
        print(f"    ⚠️  Cleanup warning: {e}")
    
    print(f"    ✅ Merged: {old_lines} old + {total_lines - old_lines} new = {total_lines} packets")
    print(f"    ✅ Final size: {merged_size / 1024:.1f} KB")
    return True


def main():
    parser = argparse.ArgumentParser(description='Repair split raw treatment files')
    parser.add_argument('--dry-run', action='store_true', help='Preview without making changes')
    parser.add_argument('--dir', type=str, help='Override raw data directory path')
    args = parser.parse_args()
    
    print("\n" + "═" * 60)
    print("  🔧 Raw Data Repair Tool — Fix Split Treatment Files")
    print("═" * 60)
    
    raw_dir = args.dir or find_raw_dir()
    if not raw_dir:
        print("\n  ❌ Cannot find raw data directory!")
        print("     Run from project root or use --dir <path>")
        sys.exit(1)
    
    print(f"\n  📂 Scanning: {raw_dir}")
    
    splits = find_split_treatments(raw_dir)
    
    if not splits:
        print("\n  ✅ No fragmented files found — all data is intact!")
        print("═" * 60)
        return
    
    print(f"\n  ⚠️  Found {len(splits)} fragmented treatment(s):")
    for s in splits:
        tid = s['treatment_id'][:8]
        print(f"    • {tid}...  .gz={s['gz_size']/1024:.1f}KB  .jsonl={s['jsonl_size']/1024:.1f}KB")
    
    if args.dry_run:
        print(f"\n  [DRY-RUN MODE] No files will be modified.")
    
    success = 0
    for s in splits:
        if repair_treatment(s, dry_run=args.dry_run):
            success += 1
    
    print(f"\n{'═' * 60}")
    mode = "[DRY-RUN] " if args.dry_run else ""
    print(f"  {mode}Result: {success}/{len(splits)} treatments repaired")
    if not args.dry_run and success == len(splits):
        print("  ✅ All data successfully merged!")
    print("═" * 60 + "\n")


if __name__ == '__main__':
    main()
