"""
Export all raw files for a patient/device bundle to investigate split treatments.

Use this when you want every treatment segment for the same patient, not just
the latest one.

Examples:
    python -m tools.export_patient_raw_bundle --patient g21
    python -m tools.export_patient_raw_bundle --patient g21 --device PF_004
    python -m tools.export_patient_raw_bundle --patient "TRAN VAN VU"
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import psycopg2
import psycopg2.extras

BACKEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)

from config import settings
from tools.helpers import RAW_DIR, fmt_time, print_err, print_header, print_info, print_ok, print_section, print_warn


def normalize_device_id(raw: Any) -> str:
    text = str(raw or "").strip()
    if not text or text.lower() == "unknown":
        return "unknown"

    upper = text.upper()
    if upper.startswith("PF_"):
        suffix = upper[3:].strip()
        return f"PF_{int(suffix):03d}" if suffix.isdigit() else upper

    if text.isdigit():
        return f"PF_{int(text):03d}"

    return text


def slugify(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9]+", "_", str(value or "").strip())
    text = re.sub(r"_+", "_", text).strip("_")
    return text or "unknown"


def pg_dsn() -> str:
    return settings.POSTGRES_URL.replace("postgresql+psycopg2://", "postgresql://")


def chunk_sort_key(path: str) -> Tuple[int, str]:
    name = os.path.basename(path)
    marker = "_chunk"
    if marker in name:
        suffix = name.split(marker, 1)[1]
        digits = []
        for ch in suffix:
            if ch.isdigit():
                digits.append(ch)
            else:
                break
        if digits:
            return (int("".join(digits)), name)
    return (0, name)


def find_raw_files(treatment_id: str) -> List[str]:
    if not os.path.isdir(RAW_DIR):
        return []

    prefix = f"treatment_{treatment_id}_chunk"
    chunked = [
        os.path.join(RAW_DIR, f)
        for f in os.listdir(RAW_DIR)
        if f.startswith(prefix) and (f.endswith(".jsonl") or f.endswith(".jsonl.gz"))
    ]
    if chunked:
        return sorted(chunked, key=chunk_sort_key)

    legacy = []
    for suffix in (".raw.jsonl", ".raw.jsonl.gz"):
        path = os.path.join(RAW_DIR, f"treatment_{treatment_id}{suffix}")
        if os.path.exists(path):
            legacy.append(path)
    return legacy


def fetch_treatments(patient_query: str, device_filter: Optional[str], backfill_only: bool = True) -> List[Dict[str, Any]]:
    conn = psycopg2.connect(pg_dsn())
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            sql = """
                SELECT
                    t.id::text AS treatment_id,
                    COALESCE(p.patient_id, t.patient_id) AS patient_id,
                    COALESCE(p.device_id, t.device_id) AS device_id,
                    COALESCE(p.start_time, t.start_time) AS start_time,
                    COALESCE(p.end_time, t.end_time) AS end_time,
                    COALESCE(t.outcome, '') AS outcome,
                    COALESCE(t.total_packets, 0) AS total_packets,
                    EXISTS (
                        SELECT 1
                        FROM treatment_journal_rows j
                        WHERE j.treatment_id = t.id
                          AND j.source = 'BACKFILL'
                    ) AS has_backfill
                FROM treatments t
                LEFT JOIN treatment_list_projection p ON p.id = t.id
                WHERE COALESCE(p.patient_id, t.patient_id) ILIKE %s
            """
            params: List[Any] = [f"%{patient_query}%"]

            if device_filter:
                sql += " AND COALESCE(p.device_id, t.device_id) IN (%s, %s)"
                params.extend([device_filter, normalize_device_id(device_filter)])

            if backfill_only:
                sql += """
                    AND EXISTS (
                        SELECT 1
                        FROM treatment_journal_rows j
                        WHERE j.treatment_id = t.id
                          AND j.source = 'BACKFILL'
                    )
                """

            sql += " ORDER BY COALESCE(p.start_time, t.start_time) DESC"
            cur.execute(sql, params)
            return list(cur.fetchall())
    finally:
        conn.close()


def copy_raw_files(raw_files: List[str], destination_dir: str) -> List[str]:
    copied = []
    os.makedirs(destination_dir, exist_ok=True)
    for src in raw_files:
        dst = os.path.join(destination_dir, os.path.basename(src))
        shutil.copy2(src, dst)
        copied.append(dst)
    return copied


def iso_or_none(value: Any) -> Optional[str]:
    if value is None:
        return None
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)


def main() -> int:
    parser = argparse.ArgumentParser(description="Export all raw segments for a patient continuity analysis")
    parser.add_argument("--patient", required=True, help="Patient id/name fragment, e.g. g21 or TRAN VAN VU")
    parser.add_argument("--device", help="Optional device filter, e.g. PF_004")
    parser.add_argument(
        "--output-dir",
        default=os.path.join(BACKEND_DIR, "tools", "_exports"),
        help="Base output directory",
    )
    parser.add_argument(
        "--include-non-backfill",
        action="store_true",
        help="Include treatments without BACKFILL journal rows",
    )
    args = parser.parse_args()

    print_header("EXPORT PATIENT RAW BUNDLE")
    print_info(f"RAW_DIR: {RAW_DIR}")
    print_info(f"Patient query: {args.patient}")
    if args.device:
        print_info(f"Device filter: {args.device}")

    if not os.path.isdir(RAW_DIR):
        print_err(f"Raw directory not found: {RAW_DIR}")
        return 2

    rows = fetch_treatments(
        patient_query=args.patient,
        device_filter=args.device,
        backfill_only=not args.include_non_backfill,
    )
    if not rows:
        print_err("No treatments found for that patient filter")
        return 3

    patient_slug = slugify(args.patient)
    device_slug = slugify(normalize_device_id(args.device)) if args.device else "ALL_DEVICES"
    bundle_dir = os.path.join(args.output_dir, f"{patient_slug}__{device_slug}__bundle")
    os.makedirs(bundle_dir, exist_ok=True)

    manifest: Dict[str, Any] = {
        "exported_at": datetime.now().isoformat(),
        "patient_query": args.patient,
        "device_filter": args.device,
        "backfill_only": not args.include_non_backfill,
        "bundle_dir": bundle_dir,
        "treatments": [],
    }

    print_section(f"Found {len(rows)} treatments")
    exported_count = 0
    missing_raw = 0

    chronological_rows = list(sorted(rows, key=lambda r: r["start_time"] or datetime.min))

    for idx, row in enumerate(chronological_rows, start=1):
        treatment_id = row["treatment_id"]
        patient_id = str(row["patient_id"] or "").strip()
        device_id = normalize_device_id(row["device_id"])
        raw_files = find_raw_files(treatment_id)
        start_label = fmt_time(row["start_time"]).replace(":", "").replace(" ", "_").replace("+07:00", "")

        print_info(
            f"{idx:02d}. {treatment_id[:8]}  {device_id}  {patient_id}  start={fmt_time(row['start_time'])}  end={fmt_time(row['end_time'])}"
        )

        treatment_entry = {
            "order": idx,
            "treatment_id": treatment_id,
            "patient_id": patient_id,
            "device_id": device_id,
            "start_time": iso_or_none(row["start_time"]),
            "end_time": iso_or_none(row["end_time"]),
            "outcome": str(row["outcome"] or ""),
            "total_packets": int(row["total_packets"] or 0),
            "has_backfill": bool(row["has_backfill"]),
            "raw_files": [os.path.basename(p) for p in raw_files],
        }

        if not raw_files:
            missing_raw += 1
            treatment_entry["exported_dir"] = None
            treatment_entry["warning"] = "raw_not_found"
            manifest["treatments"].append(treatment_entry)
            print_warn(f"    raw not found for {treatment_id}")
            continue

        target_dir = os.path.join(bundle_dir, f"{idx:02d}__{start_label}__{device_id}__{treatment_id[:8]}")
        copied = copy_raw_files(raw_files, target_dir)
        treatment_entry["exported_dir"] = target_dir
        treatment_entry["copied_files"] = [os.path.basename(p) for p in copied]
        manifest["treatments"].append(treatment_entry)
        exported_count += 1
        print_ok(f"    exported {len(copied)} raw file(s) -> {target_dir}")

    manifest_path = os.path.join(bundle_dir, "bundle_manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2, ensure_ascii=False)

    summary_txt = os.path.join(bundle_dir, "bundle_summary.txt")
    with open(summary_txt, "w", encoding="utf-8") as fh:
        fh.write("Patient raw bundle summary\n")
        fh.write("==========================\n")
        fh.write(f"patient_query: {args.patient}\n")
        fh.write(f"device_filter: {args.device or 'ALL'}\n")
        fh.write(f"backfill_only: {not args.include_non_backfill}\n")
        fh.write(f"bundle_dir: {bundle_dir}\n")
        fh.write(f"exported_count: {exported_count}\n")
        fh.write(f"missing_raw: {missing_raw}\n\n")
        for item in manifest["treatments"]:
            fh.write(
                f"{item['order']:02d}. {item['treatment_id']}  {item['device_id']}  {item['patient_id']}  "
                f"{item['start_time']} -> {item['end_time']}  raw={len(item['raw_files'])}\n"
            )

    print_section("Export Result")
    print_ok(f"Bundle dir   : {bundle_dir}")
    print_ok(f"Manifest     : {manifest_path}")
    print_ok(f"Summary      : {summary_txt}")
    print_ok(f"Exported raw : {exported_count} treatment(s)")
    if missing_raw:
        print_warn(f"Missing raw  : {missing_raw} treatment(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
