"""
May4 Full-Scenario Test Harness
================================
Replays May4_data.ndjson through the HistoricalBackfillImporter
with mocked DB, evaluating ALL QA checklist items:

  - Treatment session boundaries
  - Hourly snapshot chronology (H00..Hxx)
  - OC detection and interleave
  - Gap handling (no fabrication)
  - Checkpoint state
  - OC baseline stability

Usage:
  python backend/tools/test_may4_full.py
"""

import json
import sys
import os
import collections
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock, patch
from pathlib import Path

# ─── Setup paths ───────────────────────────────────────────────
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from services.treatment.historical_backfill_importer import HistoricalBackfillImporter

DATA_FILE = ROOT.parent / "data" / "done" / "May4_data.ndjson"
TZ7 = timezone(timedelta(hours=7))

# ─── Helpers ───────────────────────────────────────────────────

def parse_time(ts_str: str) -> datetime:
    """Parse timestamps from data file (UTC suffix → GMT+7)."""
    ts = ts_str.strip()
    if ts.endswith(" UTC"):
        ts = ts[:-4]
    dt = datetime.fromisoformat(ts)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=TZ7)
    return dt


def load_packets(filepath: str, max_pkts: int = None):
    """Load NDJSON packets, grouped by patient sessions."""
    packets = []
    with open(filepath, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if max_pkts and i >= max_pkts:
                break
            d = json.loads(line)
            hdr = d.get("s_header", {})
            body = d.get("s_body", {})
            pid = hdr.get("patient_id", "N/A")
            sid = hdr.get("therapy_status_id", -1)
            machine_id = str(hdr.get("machine_id", "unk"))
            ts_raw = hdr.get("timestamp", "")
            packets.append({
                "line": i,
                "header": hdr,
                "body": body,
                "patient_id": pid,
                "status_id": sid,
                "device_id": machine_id,
                "ts_raw": ts_raw,
            })
    return packets


# ─── Mock DB ───────────────────────────────────────────────────

class MockDB:
    """Captures all DB writes for assertion."""

    def __init__(self):
        self.snapshots = []           # (treatment_id, hour_label, snapshot_time, auto_data, hour_slot, source)
        self.reasons = {}             # (treatment_id, hour_label) → reason
        self.checkpoints = {}         # treatment_id → checkpoint dict
        self.snapshot_map = {}        # (treatment_id, hour_label) → auto_data

    def upsert_snapshot(self, treatment_id, device_id, hour_label,
                        snapshot_time, auto_data, hour_slot, source='BACKFILL'):
        self.snapshots.append({
            "treatment_id": treatment_id,
            "device_id": device_id,
            "hour_label": hour_label,
            "snapshot_time": snapshot_time,
            "auto_data": dict(auto_data),
            "hour_slot": hour_slot,
            "source": source,
        })
        self.snapshot_map[(treatment_id, hour_label)] = dict(auto_data)

    def update_snapshot_reason(self, treatment_id, hour_label, reason):
        self.reasons[(treatment_id, hour_label)] = reason

    def upsert_projection_checkpoint(self, treatment_id, **kwargs):
        if treatment_id not in self.checkpoints:
            self.checkpoints[treatment_id] = {}
        self.checkpoints[treatment_id].update(kwargs)

    def get_projection_checkpoint(self, treatment_id):
        return self.checkpoints.get(treatment_id)

    def get_treatment_by_id(self, treatment_id):
        return {"device_id": "4"}


# ─── Session Detection ────────────────────────────────────────
# Replicate recorder session logic: split by patient changes and
# status transitions (RUN=4/5 open, END=8 close)

TRIGGER_START = {4, 5}

def detect_sessions(packets):
    """Detect treatment sessions from packet stream."""
    sessions = []
    current = None

    for pkt in packets:
        pid = pkt["patient_id"]
        sid = pkt["status_id"]
        ts_raw = pkt["ts_raw"]

        if pid == "N/A" or not pid:
            continue

        if current is None:
            if sid in TRIGGER_START:
                current = {
                    "patient_id": pid,
                    "device_id": pkt["device_id"],
                    "treatment_id": f"sim_{pid}_{len(sessions)}",
                    "start_ts": ts_raw,
                    "end_ts": ts_raw,
                    "packets": [pkt],
                }
            continue

        # Same patient → accumulate
        if pid == current["patient_id"]:
            current["end_ts"] = ts_raw
            current["packets"].append(pkt)
            if sid == 8:  # END
                sessions.append(current)
                current = None
            continue

        # Different patient → close current, maybe open new
        sessions.append(current)
        if sid in TRIGGER_START:
            current = {
                "patient_id": pid,
                "device_id": pkt["device_id"],
                "treatment_id": f"sim_{pid}_{len(sessions)}",
                "start_ts": ts_raw,
                "end_ts": ts_raw,
                "packets": [pkt],
            }
        else:
            current = None

    if current:
        sessions.append(current)

    return sessions


# ─── Main Test ─────────────────────────────────────────────────

def run_test():
    print("=" * 72)
    print("May4 Full-Scenario Test Harness")
    print("=" * 72)

    # 1. Load data
    print(f"\n[1] Loading {DATA_FILE}...")
    packets = load_packets(str(DATA_FILE))
    print(f"    Loaded {len(packets)} packets")

    # 2. Detect sessions
    print(f"\n[2] Detecting treatment sessions...")
    sessions = detect_sessions(packets)
    print(f"    Found {len(sessions)} sessions:")
    for s in sessions:
        print(f"      patient={s['patient_id']} | {len(s['packets'])} pkts | "
              f"{s['start_ts']} -> {s['end_ts']}")

    # 3. Run each session through importer
    print(f"\n[3] Running sessions through HistoricalBackfillImporter...")
    results = []

    for sess in sessions:
        if len(sess["packets"]) < 10:
            print(f"    SKIP: {sess['treatment_id']} ({len(sess['packets'])} pkts — too short)")
            continue

        db = MockDB()
        importer = HistoricalBackfillImporter(db)
        tid = sess["treatment_id"]
        did = sess["device_id"]
        start_time = parse_time(sess["start_ts"])

        errors = []
        for pkt in sess["packets"]:
            try:
                pt = parse_time(pkt["ts_raw"])
                importer.process_packet(tid, did, pt, start_time, pkt["body"])
            except Exception as e:
                errors.append(f"pkt#{pkt['line']}: {e}")

        # Flush remaining cache
        importer.flush_treatment(tid)

        # Collect results
        h_snaps = [s for s in db.snapshots if s["hour_label"].startswith("H")]
        oc_snaps = [s for s in db.snapshots if s["hour_label"].startswith("OC")]
        gap_snaps = [s for s in db.snapshots if "GAP" in s["hour_label"]]
        checkpoint = db.checkpoints.get(tid, {})

        result = {
            "session": sess,
            "h_count": len(h_snaps),
            "oc_count": len(oc_snaps),
            "gap_count": len(gap_snaps),
            "total_snaps": len(db.snapshots),
            "h_labels": [s["hour_label"] for s in h_snaps],
            "oc_labels": [s["hour_label"] for s in oc_snaps],
            "oc_reasons": {s["hour_label"]: db.reasons.get((tid, s["hour_label"]), "?") for s in oc_snaps},
            "checkpoint": checkpoint,
            "h_snaps": h_snaps,
            "oc_snaps": oc_snaps,
            "errors": errors,
        }
        results.append(result)

    # 4. Evaluate QA criteria
    print(f"\n{'=' * 72}")
    print("QA EVALUATION RESULTS")
    print("=" * 72)

    total_pass = 0
    total_fail = 0
    total_warn = 0

    for r in results:
        sess = r["session"]
        pid = sess["patient_id"]
        pkt_cnt = len(sess["packets"])
        print(f"\n{'─' * 60}")
        print(f"Session: patient={pid} | {pkt_cnt} pkts | tid={sess['treatment_id']}")
        print(f"  Snapshots: H={r['h_count']} OC={r['oc_count']} GAP={r['gap_count']} Total={r['total_snaps']}")
        print(f"  H labels: {r['h_labels']}")
        print(f"  OC labels: {r['oc_labels']}")
        for oc_lbl, reason in r["oc_reasons"].items():
            print(f"    {oc_lbl}: {reason}")
        print(f"  Checkpoint: {r['checkpoint']}")
        if r["errors"]:
            print(f"  ERRORS: {len(r['errors'])}")
            for e in r["errors"][:5]:
                print(f"    {e}")

        # ─── TC-B01: Golden chronology ─────────────────────
        checks = []

        # Check 1: H00 exists
        has_h00 = "H00" in r["h_labels"]
        checks.append(("H00 exists", has_h00))

        # Check 2: H labels are monotonic
        h_nums = []
        for lbl in r["h_labels"]:
            try: h_nums.append(int(lbl[1:]))
            except: pass
        monotonic = all(h_nums[i] <= h_nums[i+1] for i in range(len(h_nums)-1))
        checks.append(("H labels monotonic", monotonic))

        # Check 3: No duplicate H labels
        no_dup_h = len(r["h_labels"]) == len(set(r["h_labels"]))
        checks.append(("No duplicate H labels", no_dup_h))

        # Check 4: H timestamps are monotonic
        h_times = [s["snapshot_time"] for s in r["h_snaps"]]
        h_times_mono = all(h_times[i] <= h_times[i+1] for i in range(len(h_times)-1))
        checks.append(("H timestamps monotonic", h_times_mono))

        # Check 5: No GAP-fill rows fabricated
        checks.append(("No GAP-fill fabricated", r["gap_count"] == 0))

        # Check 6: OC timestamps sit between adjacent H
        oc_interleave_ok = True
        for oc in r["oc_snaps"]:
            oc_time = oc["snapshot_time"]
            # Find surrounding H rows
            before_h = [h for h in r["h_snaps"] if h["snapshot_time"] <= oc_time]
            after_h = [h for h in r["h_snaps"] if h["snapshot_time"] > oc_time]
            if not before_h:
                oc_interleave_ok = False
        checks.append(("OC interleaved with H", oc_interleave_ok))

        # Check 7: OC values differ from surrounding H
        oc_values_correct = True
        for oc in r["oc_snaps"]:
            ad = oc["auto_data"]
            reason = r["oc_reasons"].get(oc["hour_label"], "")
            if not reason or reason == "?":
                oc_values_correct = False
        checks.append(("OC reasons populated", oc_values_correct))

        # Check 8: H00 baseline differs from later H (frozen early)
        h00_frozen = True
        if len(r["h_snaps"]) >= 2:
            h00_data = r["h_snaps"][0]["auto_data"]
            h01_data = r["h_snaps"][1]["auto_data"]
            # At least one value should differ (H00 frozen at ~pkt10, H01 at pkt end)
            if h00_data == h01_data:
                h00_frozen = False  # Not necessarily wrong, but suspicious
        checks.append(("H00 baseline check", h00_frozen or len(r["h_snaps"]) < 2))

        # Check 9: Checkpoint advanced
        cp = r["checkpoint"]
        cp_ok = cp.get("last_hour_slot", -1) >= 0 if r["h_count"] > 0 else True
        checks.append(("Checkpoint advanced", cp_ok))

        # Check 10: No processing errors
        checks.append(("No runtime errors", len(r["errors"]) == 0))

        # Print results
        for name, passed in checks:
            icon = "✅" if passed else "❌"
            print(f"  {icon} {name}")
            if passed:
                total_pass += 1
            else:
                total_fail += 1

    # 5. Final Summary
    print(f"\n{'=' * 72}")
    print(f"FINAL: {total_pass} PASS | {total_fail} FAIL | {total_warn} WARN")
    print(f"{'=' * 72}")

    # Cross-session checks
    all_tids = [r["session"]["treatment_id"] for r in results]
    unique_tids = set(all_tids)
    print(f"\nCross-session: {len(unique_tids)} unique treatment IDs (expected={len(results)})")
    if len(unique_tids) == len(results):
        print("  ✅ No treatment ID collision across sessions")
    else:
        print("  ❌ Treatment ID collision detected!")

    return total_fail == 0


if __name__ == "__main__":
    success = run_test()
    sys.exit(0 if success else 1)
