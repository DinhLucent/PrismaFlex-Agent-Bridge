"""Debug: show first few OC PID values for patient g12"""
import json

f = open(r'd:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\data\done\May4_data.ndjson')
seen_vals = {}
changes = []
for i, line in enumerate(f):
    d = json.loads(line)
    hdr = d.get('s_header', {})
    if hdr.get('patient_id') != 'g12':
        continue
    body = d.get('s_body', {})
    params = body.get('parameters', [])
    for p in params:
        pid = p.get('id')
        if pid in (17, 21, 22, 25):
            val = float(p['value'])
            old = seen_vals.get(pid)
            if old is not None and abs(val - old) >= 1:
                changes.append((i, pid, old, val, hdr.get('timestamp', '')))
            seen_vals[pid] = val

f.close()

print(f"Total OC PID changes for g12: {len(changes)}")
for line_num, pid, old, new, ts in changes[:20]:
    names = {17: 'QB', 21: 'QD', 22: 'QPBP', 25: 'UF_RATE'}
    print(f"  Line {line_num}: {names[pid]}(PID{pid}) {old} -> {new} @ {ts}")
