"""
Export the latest treatment raw data for a patient into a single analysis folder.

Examples:
    python -m tools.export_latest_raw_for_analysis --patient g21
    python -m tools.export_latest_raw_for_analysis --patient "TRAN VAN VU"
    python -m tools.export_latest_raw_for_analysis --patient g21 --device PF_004
"""

from __future__ import annotations

import argparse
import gzip
import json
import os
import re
import shutil
import sys
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import psycopg2
import psycopg2.extras

BACKEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)

from config import settings
from tools.helpers import RAW_DIR, fmt_time, print_err, print_header, print_info, print_ok, print_section, print_warn


def normalize_device_id(raw: Any) -> str:
    text = str(raw or "").strip()
    if not text or text.lower() == "unknown":
        return "unknown"

    upper = text.upper()
    if upper.startswith("PF_"):
        suffix = upper[3:].strip()
        return f"PF_{int(suffix):03d}" if suffix.isdigit() else upper

    if text.isdigit():
        return f"PF_{int(text):03d}"

    return text


def slugify(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9]+", "_", value.strip())
    text = re.sub(r"_+", "_", text).strip("_")
    return text or "unknown"


def pg_dsn() -> str:
    return settings.POSTGRES_URL.replace("postgresql+psycopg2://", "postgresql://")


def chunk_sort_key(path: str) -> Tuple[int, str]:
    name = os.path.basename(path)
    marker = "_chunk"
    if marker in name:
        suffix = name.split(marker, 1)[1]
        digits = []
        for ch in suffix:
            if ch.isdigit():
                digits.append(ch)
            else:
                break
        if digits:
            return (int("".join(digits)), name)
    return (0, name)


def find_raw_files(treatment_id: str) -> List[str]:
    if not os.path.isdir(RAW_DIR):
        return []

    prefix = f"treatment_{treatment_id}_chunk"
    chunked = [
        os.path.join(RAW_DIR, f)
        for f in os.listdir(RAW_DIR)
        if f.startswith(prefix) and (f.endswith(".jsonl") or f.endswith(".jsonl.gz"))
    ]
    if chunked:
        return sorted(chunked, key=chunk_sort_key)

    legacy = []
    for suffix in (".raw.jsonl", ".raw.jsonl.gz"):
        path = os.path.join(RAW_DIR, f"treatment_{treatment_id}{suffix}")
        if os.path.exists(path):
            legacy.append(path)
    return legacy


def get_latest_treatment(patient_query: str, device_filter: Optional[str]) -> Optional[Dict[str, Any]]:
    conn = psycopg2.connect(pg_dsn())
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            sql = """
                SELECT
                    t.id::text AS treatment_id,
                    COALESCE(p.patient_id, t.patient_id) AS patient_id,
                    COALESCE(p.device_id, t.device_id) AS device_id,
                    COALESCE(p.start_time, t.start_time) AS start_time,
                    COALESCE(p.end_time, t.end_time) AS end_time,
                    COALESCE(t.outcome, '') AS outcome,
                    COALESCE(t.total_packets, 0) AS total_packets,
                    EXISTS (
                        SELECT 1
                        FROM treatment_journal_rows j
                        WHERE j.treatment_id = t.id
                          AND j.source = 'BACKFILL'
                    ) AS has_backfill
                FROM treatments t
                LEFT JOIN treatment_list_projection p ON p.id = t.id
                WHERE COALESCE(p.patient_id, t.patient_id) ILIKE %s
            """
            params: List[Any] = [f"%{patient_query}%"]

            if device_filter:
                sql += " AND COALESCE(p.device_id, t.device_id) IN (%s, %s)"
                params.extend([device_filter, normalize_device_id(device_filter)])

            sql += " ORDER BY COALESCE(p.start_time, t.start_time) DESC LIMIT 1"
            cur.execute(sql, params)
            return cur.fetchone()
    finally:
        conn.close()


def copy_and_merge_raw(raw_files: List[str], output_dir: str) -> Dict[str, Any]:
    copied_files = []
    merged_path = os.path.join(output_dir, "combined.raw.ndjson")
    packet_count = 0

    with open(merged_path, "w", encoding="utf-8") as merged:
        for src in raw_files:
            dst = os.path.join(output_dir, os.path.basename(src))
            shutil.copy2(src, dst)
            copied_files.append(dst)

            opener = gzip.open if src.endswith(".gz") else open
            with opener(src, "rt", encoding="utf-8") as fh:
                for line in fh:
                    if not line.strip():
                        continue
                    merged.write(line.rstrip("\n") + "\n")
                    packet_count += 1

    return {
        "copied_files": copied_files,
        "merged_path": merged_path,
        "packet_count": packet_count,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Export latest raw treatment for analysis")
    parser.add_argument("--patient", required=True, help="Patient id/name fragment, e.g. g21 or TRAN VAN VU")
    parser.add_argument("--device", help="Optional device filter, e.g. PF_004")
    parser.add_argument(
        "--output-dir",
        default=os.path.join(BACKEND_DIR, "tools", "_exports"),
        help="Base output directory",
    )
    args = parser.parse_args()

    print_header("EXPORT LATEST RAW FOR ANALYSIS")
    print_info(f"RAW_DIR: {RAW_DIR}")
    print_info(f"Patient query: {args.patient}")
    if args.device:
        print_info(f"Device filter: {args.device}")

    if not os.path.isdir(RAW_DIR):
        print_err(f"Raw directory not found: {RAW_DIR}")
        return 2

    treatment = get_latest_treatment(args.patient, args.device)
    if not treatment:
        print_err("No treatment found for that patient filter")
        return 3

    treatment_id = treatment["treatment_id"]
    patient_id = str(treatment["patient_id"] or "").strip()
    device_id = normalize_device_id(treatment["device_id"])
    raw_files = find_raw_files(treatment_id)
    if not raw_files:
        print_err(f"No raw files found for treatment {treatment_id}")
        return 4

    folder_name = f"{slugify(patient_id)}__{device_id}__{treatment_id[:8]}"
    output_dir = os.path.join(args.output_dir, folder_name)
    os.makedirs(output_dir, exist_ok=True)

    print_section("Selected Treatment")
    print_info(f"treatment_id : {treatment_id}")
    print_info(f"patient_id   : {patient_id}")
    print_info(f"device_id    : {device_id}")
    print_info(f"start_time   : {fmt_time(treatment['start_time'])}")
    print_info(f"end_time     : {fmt_time(treatment['end_time'])}")
    print_info(f"outcome      : {treatment['outcome']}")
    print_info(f"total_packets: {treatment['total_packets']}")
    print_info(f"has_backfill : {treatment['has_backfill']}")

    print_section("Raw Files")
    for path in raw_files:
        size_mb = os.path.getsize(path) / (1024 * 1024)
        print_info(f"{os.path.basename(path)}  ({size_mb:.2f} MB)")

    export_result = copy_and_merge_raw(raw_files, output_dir)

    metadata = {
        "exported_at": datetime.now().isoformat(),
        "patient_query": args.patient,
        "device_filter": args.device,
        "treatment": {
            "treatment_id": treatment_id,
            "patient_id": patient_id,
            "device_id": device_id,
            "start_time": treatment["start_time"].isoformat() if treatment["start_time"] else None,
            "end_time": treatment["end_time"].isoformat() if treatment["end_time"] else None,
            "outcome": treatment["outcome"],
            "total_packets": int(treatment["total_packets"] or 0),
            "has_backfill": bool(treatment["has_backfill"]),
        },
        "raw_files": [os.path.basename(path) for path in raw_files],
        "copied_files": [os.path.basename(path) for path in export_result["copied_files"]],
        "merged_file": os.path.basename(export_result["merged_path"]),
        "merged_packet_count": export_result["packet_count"],
    }
    metadata_path = os.path.join(output_dir, "metadata.json")
    with open(metadata_path, "w", encoding="utf-8") as fh:
        json.dump(metadata, fh, indent=2, ensure_ascii=False)

    print_section("Export Result")
    print_ok(f"Output dir        : {output_dir}")
    print_ok(f"Merged raw        : {export_result['merged_path']}")
    print_ok(f"Merged packet cnt : {export_result['packet_count']}")
    print_ok(f"Metadata          : {metadata_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
