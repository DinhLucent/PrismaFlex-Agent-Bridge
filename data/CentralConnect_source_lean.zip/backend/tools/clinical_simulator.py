import requests
import time
import json
import threading
from datetime import datetime, timezone, timedelta

BASE_URL = "http://localhost:8000"
DEVICE_ID = "SIM_DEVICE_001"
TZ = timezone(timedelta(hours=7))

class SimulationState:
    def __init__(self):
        self.running = False
        self.patient_id = "PT_SIM_001"
        self.status = 4  # WAITING START
        self.run_time_sec = 0
        self.packet_count = 0
        self.qb = 150
        self.qd = 1000
        self.fast_mode = False
        self.base_sim_time = None

state = SimulationState()

def get_snapshot():
    # Clinical Grade: Match the real PrismaFlex decoder format
    # which uses "YYYY-MM-DD HH:MM:SS UTC" (but the time is actually local)
    
    # Bypass ghost detection by pretending we started 10 minutes ago
    # only for the 'timestamp' fields, while run_time_sec stays accurate.
    base_time = datetime.now()
    if state.base_sim_time is None:
        # First packet: pretend we started 1 hour ago
        state.base_sim_time = base_time - timedelta(hours=1)
    
    # Each packet advances by 1 minute simulated time
    sim_time = state.base_sim_time + timedelta(minutes=state.packet_count)
    now_str = sim_time.strftime("%Y-%m-%d %H:%M:%S") + " UTC"
    
    return {
        "meta": {"device_id": DEVICE_ID, "timestamp": now_str, "packet_num": state.packet_count},
        "s_header": {
            "patient_id": state.patient_id, 
            "therapy_type_id": 1,
            "therapy_type_id_name": "CVVHDF", 
            "therapy_status_id": state.status,
            "machine_id": 999,
            "timestamp": now_str
        },
        "s_body": {"parameters": [
            {"id": 17, "type": "Actual", "value": state.qb}, # Blood flow
            {"id": 21, "type": "Actual", "value": state.qd}, # Dialysate flow
            {"id": 461, "type": "Actual", "value": state.run_time_sec}, # RUN_TIME
            {"id": 1, "type": "Actual", "value": 50},  # Access Pressure
            {"id": 4, "type": "Actual", "value": 120}, # Return Pressure
            {"id": 6, "type": "Actual", "value": 80},  # TMP
        ]}
    }

def sender_thread():
    global state
    while True:
        if state.running:
            # Update metrics
            if state.status == 5: # RUN
                state.run_time_sec += 10
                
            state.packet_count += 1
            payload = get_snapshot()
            
            try:
                res = requests.post(f"{BASE_URL}/api/v1/telemetry", json=payload, timeout=2)
                print(f"[SEND] pkt={state.packet_count} | stat={state.status} | pat={state.patient_id} | time={state.run_time_sec}s -> HTTP {res.status_code}")
            except Exception as e:
                print(f"[FAIL] Không thể kết nối Backend: {type(e).__name__}")
                
        # Handle speed
        sleep_time = 10.0 if not state.fast_mode else 0.2
        time.sleep(sleep_time)

def menu():
    print(f"""
===================================================
  🚀 PRISMAFLEX CLINICAL SIMULATOR (Demo)
  Chạy độc lập để test: Tắt/mở backend thoải mái
===================================================
1. Start/Resume (Status=5: RUN)
2. Send END (Status=8)
3. Send STOP (Status=7) - Báo động
4. Change Patient ID
5. Ngắt mạng (Dừng gửi packets)
6. Reset RunTime về 0 (Máy khởi động lại)
7. Toggle Fast Mode (Hiện tại: {"ON (0.2s)" if state.fast_mode else "OFF (10s)"})
8. Trạng thái hiện tại
===================================================
    """)

if __name__ == "__main__":
    t = threading.Thread(target=sender_thread, daemon=True)
    t.start()
    
    while True:
        menu()
        cmd = input("Chọn lệnh: ")
        if cmd == "1":
            state.status = 5
            state.running = True
            print(f"▶ Đã chuyển status=RUN, tốc độ: {'0.2s' if state.fast_mode else '10s'}/packet.")
        elif cmd == "2":
            state.status = 8
            print("⏹ Đã chuyển status=END. Cứ để nó chạy hoặc chọn (5) để ngắt mạng.")
        elif cmd == "3":
            state.status = 7 
            print("⏸ Đã chuyển status=STOP (Bơm máu dưng).")
        elif cmd == "4":
            new_id = input(f"Nhập Patient ID mới (hiện tại: {state.patient_id}): ")
            if new_id.strip():
                state.patient_id = new_id.strip()
                state.run_time_sec = 0
                state.status = 4 
                print(f"👤 Patient ID đổi sang: {state.patient_id}")
        elif cmd == "5":
            state.running = False
            print("🔌 Đã ngắt kết nối hệ thống (Dừng gửi data).")
        elif cmd == "6":
            state.run_time_sec = 0
            print("🔄 Đã reset RunTime = 0.")
        elif cmd == "7":
            state.fast_mode = not state.fast_mode
            print(f"⏩ Fast Mode: {'ON' if state.fast_mode else 'OFF'}")
        elif cmd == "8":
             print(f"Info: Running={state.running}, Status={state.status}, FastMode={state.fast_mode}")

