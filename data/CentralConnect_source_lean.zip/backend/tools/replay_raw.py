"""
PrismaFlex Raw Data Replay Engine
===================================
Replay raw JSONL telemetry data through the snapshot/recorder pipeline.
Essential for testing algorithm changes without a live PrismaFlex machine.

Usage:
    python -m tools.replay_raw <treatment_id>              # Replay by ID (finds JSONL)
    python -m tools.replay_raw <path/to/file.jsonl>        # Replay by file path
    python -m tools.replay_raw <treatment_id> --dry-run    # Analysis only, no DB writes
    python -m tools.replay_raw <treatment_id> --to-db test.db  # Write to separate DB

Features:
    - Reads .jsonl and .jsonl.gz files
    - Tracks parameter changes and OC trigger events
    - Shows hourly snapshot creation timeline
    - Validates what OC snapshots WOULD be created
    - Supports --speed for fast replay
"""

import sys
import os
import json
import gzip
import time as time_mod
from datetime import datetime, timezone, timedelta
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tools.helpers import (
    C, PID_NAMES, ORDER_CHANGE_PIDS, VOLATILE_PIDS, PID_TO_COLUMN,
    print_header, print_section, print_ok, print_warn, print_err, print_info,
    pid_name, fmt_time, fmt_duration, find_raw_file, TZ_LOCAL, BACKEND_DIR
)


def read_packets(filepath: str):
    """Read packets from JSONL or JSONL.GZ file."""
    packets = []
    opener = gzip.open if filepath.endswith('.gz') else open
    
    with opener(filepath, 'rt', encoding='utf-8') as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                pkt = json.loads(line)
                packets.append(pkt)
            except json.JSONDecodeError as e:
                print(f"  {C.YELLOW}⚠ Line {line_no}: JSON error: {e}{C.RESET}")
    
    return packets


def analyze_packets(packets: list):
    """Full analysis of raw packet data."""
    if not packets:
        print_err("No packets to analyze.")
        return
    
    # ── Basic Stats ──
    print_section("📈 Packet Statistics")
    
    first_ts = packets[0].get('meta', {}).get('timestamp', '')
    last_ts = packets[-1].get('meta', {}).get('timestamp', '')
    print_info(f"Total packets: {len(packets)}")
    print_info(f"Time range: {fmt_time(first_ts, '%Y-%m-%d %H:%M:%S')} → {fmt_time(last_ts, '%Y-%m-%d %H:%M:%S')}")
    
    # Parse first/last time for duration
    try:
        t1 = datetime.fromisoformat(first_ts.replace('Z', '+00:00'))
        t2 = datetime.fromisoformat(last_ts.replace('Z', '+00:00'))
        dur = (t2 - t1).total_seconds()
        print_info(f"Duration: {fmt_duration(dur)}")
        if dur > 0:
            print_info(f"Avg packet interval: {dur / len(packets):.1f}s")
    except Exception:
        pass
    
    # ── PID Frequency ──
    print_section("📊 PID Frequency")
    pid_counter = Counter()
    pid_values = defaultdict(set)  # pid -> set of unique values
    
    for pkt in packets:
        params = pkt.get('s_body', {}).get('parameters', [])
        for p in params:
            pid = p.get('id')
            val = p.get('value_text', str(p.get('value', '')))
            pid_counter[pid] += 1
            if pid not in VOLATILE_PIDS:
                pid_values[pid].add(val)
    
    print(f"\n  {'PID':>5}  {'Name':35}  {'Count':>6}  {'Unique':>6}  {'Values (sample)'}")
    print(f"  {'─'*5}  {'─'*35}  {'─'*6}  {'─'*6}  {'─'*30}")
    for pid, count in pid_counter.most_common(30):
        name = pid_name(pid)
        is_order = pid in ORDER_CHANGE_PIDS
        uq = len(pid_values.get(pid, set()))
        sample = ', '.join(list(pid_values.get(pid, set()))[:5]) if pid not in VOLATILE_PIDS else '(volatile)'
        marker = '⚡' if is_order else '  '
        color = C.CYAN if is_order else C.DIM
        print(f"  {marker}{color}{pid:>4}  {name:35}  {count:>6}  {uq:>6}  {sample[:30]}{C.RESET}")
    
    # ── Parameter Change Timeline ──
    print_section("🔄 Parameter Changes (Non-Volatile)")
    cache = {}
    all_changes = []
    order_changes = []
    
    for pkt in packets:
        ts = pkt.get('meta', {}).get('timestamp', '')
        params = pkt.get('s_body', {}).get('parameters', [])
        
        for p in params:
            pid = p.get('id')
            if pid in VOLATILE_PIDS:
                continue
            val = p.get('value_text', str(p.get('value', '')))
            
            if pid in cache and cache[pid] != val:
                change = (ts, pid, cache[pid], val)
                all_changes.append(change)
                if pid in ORDER_CHANGE_PIDS:
                    order_changes.append(change)
            cache[pid] = val
    
    if not all_changes:
        print_info("No parameter changes detected.")
    else:
        print_info(f"Total changes: {len(all_changes)} ({len(order_changes)} order-related)")
        
        # Group changes by time
        print(f"\n  {'Time':10}  {'PID':>5}  {'Parameter':30}  {'Old':>10}  →  {'New':<10}")
        print(f"  {'─'*10}  {'─'*5}  {'─'*30}  {'─'*10}     {'─'*10}")
        
        shown = 0
        for ts, pid, old, new in all_changes:
            is_order = pid in ORDER_CHANGE_PIDS
            color = C.RED + C.BOLD if is_order else C.DIM
            marker = '⚡' if is_order else '  '
            print(f"  {fmt_time(ts):10}  {marker}{color}{pid:>4}  {pid_name(pid):30}  {str(old):>10}  →  {str(new):<10}{C.RESET}")
            shown += 1
            if shown >= 100:
                print(f"  {C.DIM}... {len(all_changes) - shown} more{C.RESET}")
                break
    
    # ── OC Trigger Simulation ──
    print_section("📋 Simulated OC Triggers (60s Cooldown)")
    if not order_changes:
        print_info("No order changes → no OC snapshots would be created.")
    else:
        oc_count = 0
        last_oc_time = None
        
        for ts, pid, old, new in order_changes:
            try:
                pkt_time = datetime.fromisoformat(ts.replace('Z', '+00:00'))
            except Exception:
                continue
            
            # Anti-flicker
            try:
                diff = abs(float(str(new).replace(',','')) - float(str(old).replace(',','')))
                if diff < 1:
                    print(f"  {C.DIM}  FILTERED (flicker Δ<1): {pid_name(pid)} {old}→{new}{C.RESET}")
                    continue
            except (ValueError, TypeError):
                pass
            
            # Cooldown
            if last_oc_time and (pkt_time - last_oc_time).total_seconds() < 60:
                print(f"  {C.YELLOW}  GROUPED into OC_{oc_count:02d}: {pid_name(pid)} {old}→{new}{C.RESET}")
            else:
                oc_count += 1
                last_oc_time = pkt_time
                print(f"  {C.GREEN}  NEW OC_{oc_count:02d} @ {fmt_time(ts)}: {pid_name(pid)} {old}→{new}{C.RESET}")
        
        print(f"\n  {C.BOLD}Result: {oc_count} OC snapshots would be created{C.RESET}")
    
    # ── Hourly Snapshot Simulation ──
    print_section("⏰ Hourly Snapshot Boundaries")
    first_pkt_time = None
    hour_boundaries = []
    
    for pkt in packets:
        ts = pkt.get('meta', {}).get('timestamp', '')
        try:
            pkt_time = datetime.fromisoformat(ts.replace('Z', '+00:00'))
        except Exception:
            continue
        
        if first_pkt_time is None:
            first_pkt_time = pkt_time
            print_info(f"Treatment start: {pkt_time.astimezone(TZ_LOCAL).strftime('%H:%M:%S')}")
        
        elapsed = (pkt_time - first_pkt_time).total_seconds()
        hour_num = max(1, int(elapsed / 3600) + 1)
        hour_label = f"H{hour_num:02d}"
        
        if not hour_boundaries or hour_boundaries[-1] != hour_label:
            hour_boundaries.append(hour_label)
            local = pkt_time.astimezone(TZ_LOCAL)
            print(f"  {C.CYAN}{hour_label}{C.RESET} starts at {local.strftime('%H:%M:%S')} (elapsed: {fmt_duration(elapsed)})")
    
    print(f"\n  {C.BOLD}Total: {len(hour_boundaries)} hourly snapshots{C.RESET}")
    
    # ── Summary ──
    print_header("📝 Replay Summary")
    print(f"  Packets:           {len(packets)}")
    print(f"  Unique PIDs:       {len(pid_counter)}")
    print(f"  Parameter changes: {len(all_changes)}")
    print(f"  Order changes:     {len(order_changes)}")
    print(f"  Simulated OCs:     {oc_count if order_changes else 0}")
    print(f"  Hourly snapshots:  {len(hour_boundaries)}")
    print()


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    
    target = sys.argv[1]
    dry_run = '--dry-run' in sys.argv
    
    # Resolve file path
    if os.path.isfile(target):
        filepath = target
    else:
        filepath = find_raw_file(target)
        if not filepath:
            print_err(f"No raw file found for '{target}'")
            print_info(f"Raw data dir: {os.path.join(BACKEND_DIR, 'data', 'treatments', 'raw')}")
            return
    
    fsize = os.path.getsize(filepath) / 1024 / 1024
    print_header(f"🔄 Replay: {os.path.basename(filepath)}")
    print_info(f"File size: {fsize:.1f} MB")
    print_info(f"Mode: {'DRY RUN (analysis only)' if dry_run else 'LIVE (will process)'}")
    
    print_info("Reading packets...")
    packets = read_packets(filepath)
    print_ok(f"Loaded {len(packets)} packets")
    
    analyze_packets(packets)


if __name__ == '__main__':
    main()
