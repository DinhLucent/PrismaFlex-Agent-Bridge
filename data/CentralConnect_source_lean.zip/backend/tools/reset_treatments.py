#!/usr/bin/env python3
"""
Treatment Data Reset Tool
==========================
Wipes ALL treatment data from PostgreSQL + SQLite + raw JSONL files.
Designed for backfill/backtest cycles (re-import from Mirth).

Usage:
    python -m tools.reset_treatments              # Interactive (shows stats, asks confirm)
    python -m tools.reset_treatments --yes         # Skip confirmation
    python -m tools.reset_treatments --dry-run     # Show what would be deleted
    python -m tools.reset_treatments --pg-only     # Only wipe PostgreSQL (keep SQLite/files)
"""
import os
import sys
import glob
import shutil
import argparse
import logging
from datetime import datetime, timezone, timedelta

# Add project root
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger("ResetTool")

# ─── PostgreSQL Tables (child → parent order for FK safety) ──────
PG_TABLES_ORDERED = [
    "snapshot_audit_log",
    "snapshot_originals",
    "treatment_journal_rows",
    "treatment_notes",
    "treatment_review_state",
    "treatment_status_events",
    "treatment_phases",
    "treatment_config",
    "raw_packet_manifest",
    "treatment_list_projection",
    "treatment_projection_checkpoint",   # Sprint 7: projection checkpoint
    "device_state",                      # Sprint 7: device runtime state
    "treatments",                        # master table — last
]

# ─── SQLite Tables (legacy — treatments.db) ─────────────────────
SQLITE_TABLES = [
    "treatment_snapshot_originals",
    "treatment_snapshots",
    "treatment_status_log",
    "treatment_approval_log",
    "treatment_notes",
    "treatment_index",
    "treatments",
]

# ─── Raw Data Directory (matches RawDataStreamer default) ──────────
RAW_DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data', 'treatments', 'raw'))


def get_pg_engine():
    """Create PostgreSQL engine from config."""
    try:
        from config import settings
        from sqlalchemy import create_engine
        return create_engine(settings.POSTGRES_URL)
    except Exception as e:
        logger.error(f"Cannot connect to PostgreSQL: {e}")
        return None


def get_sqlite_path():
    """Locate the SQLite treatments database."""
    candidates = [
        os.path.join(os.path.dirname(__file__), '..', 'treatments.db'),
        os.path.join(os.path.dirname(__file__), '..', 'data', 'treatments.db'),
    ]
    for p in candidates:
        full = os.path.abspath(p)
        if os.path.exists(full):
            return full
    return None


def count_raw_files():
    """Count JSONL and GZ files in raw_data directory."""
    if not os.path.isdir(RAW_DATA_DIR):
        return 0, 0
    jsonl_files = glob.glob(os.path.join(RAW_DATA_DIR, '**', '*.jsonl'), recursive=True)
    gz_files = glob.glob(os.path.join(RAW_DATA_DIR, '**', '*.gz'), recursive=True)
    total_size = sum(os.path.getsize(f) for f in jsonl_files + gz_files)
    return len(jsonl_files) + len(gz_files), total_size


def show_stats(pg_engine, sqlite_path):
    """Display current data counts before reset."""
    local_tz = timezone(timedelta(hours=7))
    now_str = datetime.now(local_tz).strftime("%Y-%m-%d %H:%M:%S GMT+7")
    
    print("\n" + "═" * 60)
    print(f"  PrismaFlex Treatment Reset Tool — {now_str}")
    print("═" * 60)

    # PostgreSQL Stats
    if pg_engine:
        from sqlalchemy import text
        with pg_engine.connect() as conn:
            print("\n📊 PostgreSQL:")
            for table in PG_TABLES_ORDERED:
                try:
                    result = conn.execute(text(f"SELECT COUNT(*) FROM {table}"))
                    count = result.scalar()
                    marker = " ⚠️" if count > 0 else ""
                    print(f"   {table:40s} {count:>8,d} rows{marker}")
                except Exception:
                    print(f"   {table:40s} (table not found)")
            
            # Pending review count
            try:
                result = conn.execute(text(
                    "SELECT COUNT(*) FROM treatment_review_state WHERE status = 'PENDING_REVIEW'"))
                pending = result.scalar()
                print(f"\n   🔔 Pending reviews: {pending}")
            except Exception:
                pass
    else:
        print("\n📊 PostgreSQL: Not connected")

    # SQLite Stats
    if sqlite_path:
        import sqlite3
        conn = sqlite3.connect(sqlite_path)
        print(f"\n📊 SQLite ({os.path.basename(sqlite_path)}):")
        for table in SQLITE_TABLES:
            try:
                count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                marker = " ⚠️" if count > 0 else ""
                print(f"   {table:40s} {count:>8,d} rows{marker}")
            except Exception:
                print(f"   {table:40s} (table not found)")
        conn.close()
    else:
        print("\n📊 SQLite: Not found")

    # Raw Files
    file_count, total_size = count_raw_files()
    size_mb = total_size / (1024 * 1024) if total_size > 0 else 0
    print(f"\n📊 Raw Files ({RAW_DATA_DIR}):")
    print(f"   JSONL + GZ files: {file_count} ({size_mb:.1f} MB)")
    print("═" * 60)


def wipe_postgres(pg_engine, dry_run=False):
    """TRUNCATE all PostgreSQL treatment tables."""
    if not pg_engine:
        logger.warning("PostgreSQL not available — skipping")
        return
    
    from sqlalchemy import text
    with pg_engine.begin() as conn:
        for table in PG_TABLES_ORDERED:
            try:
                if dry_run:
                    count = conn.execute(text(f"SELECT COUNT(*) FROM {table}")).scalar()
                    logger.info(f"[DRY] Would TRUNCATE {table} ({count} rows)")
                else:
                    conn.execute(text(f"TRUNCATE TABLE {table} CASCADE"))
                    logger.info(f"✅ TRUNCATED {table}")
            except Exception as e:
                logger.warning(f"Skip {table}: {e}")


def wipe_sqlite(sqlite_path, dry_run=False):
    """DELETE all rows from SQLite treatment tables."""
    if not sqlite_path:
        logger.warning("SQLite DB not found — skipping")
        return

    import sqlite3
    conn = sqlite3.connect(sqlite_path)
    try:
        for table in SQLITE_TABLES:
            try:
                if dry_run:
                    count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                    logger.info(f"[DRY] Would DELETE FROM {table} ({count} rows)")
                else:
                    conn.execute(f"DELETE FROM {table}")
                    logger.info(f"✅ CLEARED {table}")
            except Exception as e:
                logger.warning(f"Skip {table}: {e}")
        if not dry_run:
            conn.execute("VACUUM")
            conn.commit()
    finally:
        conn.close()


def wipe_raw_files(dry_run=False):
    """Remove all JSONL and GZ files from raw_data directory."""
    if not os.path.isdir(RAW_DATA_DIR):
        logger.warning(f"Raw data dir not found: {RAW_DATA_DIR}")
        return

    files = glob.glob(os.path.join(RAW_DATA_DIR, '**', '*.jsonl'), recursive=True)
    files += glob.glob(os.path.join(RAW_DATA_DIR, '**', '*.gz'), recursive=True)

    if dry_run:
        logger.info(f"[DRY] Would delete {len(files)} raw files")
        return

    deleted = 0
    for f in files:
        try:
            os.remove(f)
            deleted += 1
        except Exception as e:
            logger.warning(f"Cannot delete {f}: {e}")
    
    # Remove empty subdirectories
    for dirpath, dirnames, filenames in os.walk(RAW_DATA_DIR, topdown=False):
        if dirpath != RAW_DATA_DIR and not os.listdir(dirpath):
            try:
                os.rmdir(dirpath)
            except Exception:
                pass

    logger.info(f"✅ Deleted {deleted}/{len(files)} raw files")


def main():
    parser = argparse.ArgumentParser(description="Wipe ALL treatment data for backfill/backtest")
    parser.add_argument("--yes", "-y", action="store_true", help="Skip confirmation prompt")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be deleted")
    parser.add_argument("--pg-only", action="store_true", help="Only wipe PostgreSQL tables")
    parser.add_argument("--sqlite-only", action="store_true", help="Only wipe SQLite tables")
    parser.add_argument("--files-only", action="store_true", help="Only wipe raw JSONL/GZ files")
    args = parser.parse_args()

    pg_engine = get_pg_engine()
    sqlite_path = get_sqlite_path()

    # Show current state
    show_stats(pg_engine, sqlite_path)

    if args.dry_run:
        print("\n🔍 DRY RUN MODE — no data will be deleted\n")

    # Determine scope
    scope_parts = []
    do_pg = not args.sqlite_only and not args.files_only
    do_sqlite = not args.pg_only and not args.files_only
    do_files = not args.pg_only and not args.sqlite_only
    
    if do_pg: scope_parts.append("PostgreSQL")
    if do_sqlite: scope_parts.append("SQLite")
    if do_files: scope_parts.append("Raw Files")

    print(f"\n🎯 Scope: {' + '.join(scope_parts)}")

    # Confirm
    if not args.dry_run and not args.yes:
        print("\n⚠️  THIS WILL PERMANENTLY DELETE ALL TREATMENT DATA!")
        print("    You should only do this if you plan to backfill from Mirth.\n")
        answer = input("Type 'RESET' to confirm: ").strip()
        if answer != "RESET":
            print("❌ Cancelled.")
            sys.exit(0)

    # Execute
    print()
    if do_pg:
        wipe_postgres(pg_engine, dry_run=args.dry_run)
    if do_sqlite:
        wipe_sqlite(sqlite_path, dry_run=args.dry_run)
    if do_files:
        wipe_raw_files(dry_run=args.dry_run)

    if args.dry_run:
        print("\n🔍 Dry run complete. No data was modified.")
    else:
        local_tz = timezone(timedelta(hours=7))
        print(f"\n✅ Reset complete at {datetime.now(local_tz).strftime('%H:%M:%S GMT+7')}")
        print("   Ready for Mirth backfill.")
        print("   Restart backend to clear in-memory caches: Ctrl+C → python -m uvicorn main:app")


if __name__ == "__main__":
    main()
