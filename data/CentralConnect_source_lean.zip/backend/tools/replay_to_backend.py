"""
PrismaFlex Replay to Backend
==============================
Gửi lại (replay) file JSONL cũ vào backend API, giống y hệt máy thật gửi.
Backend xử lý toàn bộ pipeline: Recorder → Snapshot → Event → OC triggers.

Usage:
    python -m tools.replay_to_backend <file_or_treatment_id>
    python -m tools.replay_to_backend <file> --speed 10      # 10x faster
    python -m tools.replay_to_backend <file> --speed 0        # Max speed (no delay)
    python -m tools.replay_to_backend <file> --url http://host:8000  # Custom backend

Examples:
    python -m tools.replay_to_backend treatment_1db6345f.raw.jsonl --speed 0
    python -m tools.replay_to_backend 00070fca --speed 5
"""

import sys
import os
import json
import gzip
import time
import argparse
import requests
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tools.helpers import (
    C, print_header, print_section, print_ok, print_warn, print_err, print_info,
    find_raw_file, fmt_time, BACKEND_DIR, RAW_DIR
)

DEFAULT_URL = "http://localhost:8000/api/v1/telemetry"


def find_any_jsonl(target: str):
    """Find JSONL file by path, treatment ID, or partial match."""
    # Direct file path
    if os.path.isfile(target):
        return target
    
    # Full path with different base
    for base in [BACKEND_DIR, os.path.join(BACKEND_DIR, 'data', 'treatments', 'raw'),
                 os.path.join(os.path.dirname(BACKEND_DIR), 'data', 'treatments', 'raw'),
                 os.path.join(os.path.dirname(BACKEND_DIR), 'data', 'test_raw')]:
        full = os.path.join(base, target)
        if os.path.isfile(full):
            return full
    
    # Search by treatment ID
    result = find_raw_file(target)
    if result:
        return result
    
    # Search in all known raw directories
    search_dirs = [
        RAW_DIR,
        os.path.join(os.path.dirname(BACKEND_DIR), 'data', 'treatments', 'raw'),
        os.path.join(os.path.dirname(BACKEND_DIR), 'data', 'test_raw'),
    ]
    for d in search_dirs:
        if not os.path.isdir(d):
            continue
        for fn in os.listdir(d):
            if target.lower() in fn.lower():
                return os.path.join(d, fn)
    
    return None


def read_packets(filepath: str):
    """Read packets from JSONL or JSONL.GZ."""
    packets = []
    opener = gzip.open if filepath.endswith('.gz') else open
    with opener(filepath, 'rt', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                pkt = json.loads(line)
                packets.append(pkt)
            except json.JSONDecodeError:
                pass
    return packets


def replay(filepath: str, url: str, speed: float):
    """Replay packets to the backend API."""
    packets = read_packets(filepath)
    if not packets:
        print_err("No packets found in file.")
        return
    
    total = len(packets)
    fsize = os.path.getsize(filepath) / 1024 / 1024
    
    print_header(f"🔄 Replay: {os.path.basename(filepath)}")
    print_info(f"File size: {fsize:.1f} MB")
    print_info(f"Total packets: {total}")
    print_info(f"Target: {url}")
    print_info(f"Speed: {'MAX (no delay)' if speed == 0 else f'{speed}x'}")
    
    # Extract time range
    first_ts = packets[0].get('meta', {}).get('timestamp', '')
    last_ts = packets[-1].get('meta', {}).get('timestamp', '')
    print_info(f"Data range: {fmt_time(first_ts, '%Y-%m-%d %H:%M')} → {fmt_time(last_ts, '%Y-%m-%d %H:%M')}")
    
    # Check backend is alive
    try:
        r = requests.get(url.replace('/telemetry', '/health'), timeout=3)
        print_ok(f"Backend is reachable ({r.status_code})")
    except requests.ConnectionError:
        print_err(f"Backend not reachable at {url}")
        print_info("Start backend first: .\\start_backend.bat")
        return
    
    print_section("▶ Sending packets...")
    
    success = 0
    errors = 0
    prev_pkt_time = None
    start_wall = time.time()
    
    for i, pkt in enumerate(packets):
        # Parse packet timestamp for pacing
        pkt_ts = pkt.get('meta', {}).get('timestamp', '')
        
        # Speed control: delay between packets based on original timing
        if speed > 0 and prev_pkt_time and pkt_ts:
            try:
                t1 = datetime.fromisoformat(prev_pkt_time.replace('Z', '+00:00'))
                t2 = datetime.fromisoformat(pkt_ts.replace('Z', '+00:00'))
                real_gap = (t2 - t1).total_seconds()
                if real_gap > 0:
                    delay = real_gap / speed
                    # Cap max delay at 5 seconds even at 1x speed
                    delay = min(delay, 5.0)
                    time.sleep(delay)
            except Exception:
                pass
        prev_pkt_time = pkt_ts
        
        # Send to backend
        try:
            r = requests.post(url, json=pkt, timeout=10)
            if r.status_code == 200:
                success += 1
            else:
                errors += 1
                if errors <= 3:
                    print_warn(f"Packet {i+1}: HTTP {r.status_code} — {r.text[:100]}")
        except Exception as e:
            errors += 1
            if errors <= 3:
                print_err(f"Packet {i+1}: {e}")
        
        # Progress bar
        if (i + 1) % 50 == 0 or i == total - 1:
            pct = (i + 1) / total * 100
            elapsed = time.time() - start_wall
            rate = (i + 1) / elapsed if elapsed > 0 else 0
            ts_display = fmt_time(pkt_ts) if pkt_ts else ''
            bar_len = 30
            filled = int(bar_len * (i + 1) / total)
            bar = '█' * filled + '░' * (bar_len - filled)
            sys.stdout.write(f"\r  {bar} {pct:5.1f}% [{i+1}/{total}] {rate:.0f} pkt/s  {ts_display}     ")
            sys.stdout.flush()
    
    elapsed = time.time() - start_wall
    print(f"\n")
    
    # Summary
    print_header("📝 Replay Complete")
    print(f"  Sent:       {success} / {total}")
    print(f"  Errors:     {errors}")
    print(f"  Duration:   {elapsed:.1f}s")
    print(f"  Avg rate:   {total / elapsed:.0f} packets/sec" if elapsed > 0 else "")
    
    if success == total:
        print_ok("All packets sent successfully!")
        print_info("Check the frontend to see the treatment + snapshots.")
    elif errors > 0:
        print_warn(f"{errors} packets failed. Check backend logs for details.")


def main():
    parser = argparse.ArgumentParser(description='Replay JSONL to PrismaFlex Backend')
    parser.add_argument('target', help='JSONL file path or treatment ID')
    parser.add_argument('--speed', type=float, default=0,
                       help='Replay speed multiplier (0 = max speed, 1 = real-time, 10 = 10x)')
    parser.add_argument('--url', default=DEFAULT_URL,
                       help=f'Backend API URL (default: {DEFAULT_URL})')
    
    args = parser.parse_args()
    
    filepath = find_any_jsonl(args.target)
    if not filepath:
        print_err(f"File not found: {args.target}")
        print_info("Available raw files:")
        for d in [RAW_DIR, os.path.join(os.path.dirname(BACKEND_DIR), 'data', 'treatments', 'raw'),
                   os.path.join(os.path.dirname(BACKEND_DIR), 'data', 'test_raw')]:
            if os.path.isdir(d):
                for fn in os.listdir(d):
                    if fn.endswith(('.jsonl', '.jsonl.gz')):
                        print(f"    {fn}")
        return
    
    replay(filepath, args.url, args.speed)


if __name__ == '__main__':
    main()
