"""
PrismaFlex System Health Check
================================
Validates system integrity: DB schema, orphan records, raw data files,
and service status.

Usage:
    python -m tools.health_check           # Full health check
    python -m tools.health_check --quick   # Quick check (skip raw data scan)
"""

import sys
import os
import glob

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tools.helpers import (
    get_treatment_db, C, print_header, print_section,
    print_ok, print_warn, print_err, print_info,
    TREATMENT_DB_PATH, RAW_DIR, BACKEND_DIR
)


def check_db_integrity():
    """Check database integrity and schema completeness."""
    print_section("💾 Database Integrity")
    
    if not os.path.exists(TREATMENT_DB_PATH):
        print_err(f"Database not found: {TREATMENT_DB_PATH}")
        return False
    
    fsize = os.path.getsize(TREATMENT_DB_PATH) / 1024 / 1024
    print_info(f"DB file: {TREATMENT_DB_PATH}")
    print_info(f"DB size: {fsize:.1f} MB")
    
    db = get_treatment_db()
    
    # Integrity check
    result = db.execute("PRAGMA integrity_check").fetchone()
    if result[0] == 'ok':
        print_ok("SQLite integrity check: PASSED")
    else:
        print_err(f"SQLite integrity check: FAILED — {result[0]}")
    
    # Required tables
    required_tables = [
        'treatments', 'treatment_index', 'treatment_status_log',
        'treatment_hourly_snapshots'
    ]
    tables = [r['name'] for r in db.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()]
    
    for t in required_tables:
        if t in tables:
            count = db.execute(f"SELECT COUNT(*) as cnt FROM [{t}]").fetchone()['cnt']
            print_ok(f"Table '{t}': {count} rows")
        else:
            print_err(f"Table '{t}': MISSING")
    
    # Required indexes
    indexes = [r['name'] for r in db.execute(
        "SELECT name FROM sqlite_master WHERE type='index'"
    ).fetchall()]
    required_indexes = ['idx_snap_hour', 'idx_treat_device']
    for idx in required_indexes:
        if idx in indexes:
            print_ok(f"Index '{idx}': exists")
        else:
            print_warn(f"Index '{idx}': missing (performance impact)")
    
    # Snapshot 'reason' column (for OC snapshots)
    cols = [r['name'] for r in db.execute("PRAGMA table_info(treatment_hourly_snapshots)").fetchall()]
    if 'reason' in cols:
        print_ok("Column 'reason' in snapshots: exists")
    else:
        print_warn("Column 'reason' in snapshots: MISSING (OC reasons won't be stored)")
    
    db.close()
    return True


def check_orphan_records():
    """Check for orphaned records across tables."""
    print_section("🔗 Record Consistency")
    
    db = get_treatment_db()
    
    # Snapshots without treatment
    orphan_snaps = db.execute("""
        SELECT COUNT(*) as cnt FROM treatment_hourly_snapshots s
        WHERE NOT EXISTS (SELECT 1 FROM treatments t WHERE t.id = s.treatment_id)
    """).fetchone()['cnt']
    
    if orphan_snaps == 0:
        print_ok("No orphaned snapshots")
    else:
        print_warn(f"{orphan_snaps} orphaned snapshots (no parent treatment)")
    
    # Index without treatment
    try:
        orphan_idx = db.execute("""
            SELECT COUNT(*) as cnt FROM treatment_index i
            WHERE NOT EXISTS (SELECT 1 FROM treatments t WHERE t.id = i.id)
        """).fetchone()['cnt']
        
        if orphan_idx == 0:
            print_ok("No orphaned index entries")
        else:
            print_warn(f"{orphan_idx} orphaned index entries")
    except Exception:
        print_info("Could not check treatment_index (table may not exist)")
    
    # Treatments without any snapshots
    no_snaps = db.execute("""
        SELECT COUNT(*) as cnt FROM treatments t
        WHERE NOT EXISTS (
            SELECT 1 FROM treatment_hourly_snapshots s WHERE s.treatment_id = t.id
        )
    """).fetchone()['cnt']
    total_t = db.execute("SELECT COUNT(*) as cnt FROM treatments").fetchone()['cnt']
    
    if no_snaps == 0:
        print_ok(f"All {total_t} treatments have snapshots")
    else:
        print_info(f"{no_snaps}/{total_t} treatments have no snapshots (may be very short)")
    
    # OC snapshot statistics
    oc_count = db.execute(
        "SELECT COUNT(*) as cnt FROM treatment_hourly_snapshots WHERE hour_label LIKE 'OC%'"
    ).fetchone()['cnt']
    h_count = db.execute(
        "SELECT COUNT(*) as cnt FROM treatment_hourly_snapshots WHERE hour_label LIKE 'H%'"
    ).fetchone()['cnt']
    print_info(f"Snapshot breakdown: {h_count} hourly + {oc_count} OC = {h_count + oc_count} total")
    
    db.close()


def check_raw_data(quick: bool = False):
    """Check raw data files vs DB records."""
    print_section("📦 Raw Data Files")
    
    if not os.path.exists(RAW_DIR):
        print_warn(f"Raw data directory not found: {RAW_DIR}")
        return
    
    files = os.listdir(RAW_DIR)
    total_size = sum(os.path.getsize(os.path.join(RAW_DIR, f)) for f in files) / 1024 / 1024
    
    jsonl = [f for f in files if f.endswith('.jsonl')]
    gz = [f for f in files if f.endswith('.jsonl.gz')]
    
    print_info(f"Directory: {RAW_DIR}")
    print_info(f"Total files: {len(files)} ({len(jsonl)} JSONL, {len(gz)} compressed)")
    print_info(f"Total size: {total_size:.1f} MB")
    
    if quick:
        print_info("(Detailed scan skipped in --quick mode)")
        return
    
    # Cross-reference with DB
    db = get_treatment_db()
    db_ids = set()
    for row in db.execute("SELECT id FROM treatments").fetchall():
        db_ids.add(row['id'])
    
    matched = 0
    unmatched = 0
    for f in files:
        # Extract treatment ID from filename
        # Format: treatment_<uuid>.raw.jsonl
        name = f.replace('.raw.jsonl.gz', '').replace('.raw.jsonl', '')
        tid = name.replace('treatment_', '')
        
        if tid in db_ids:
            matched += 1
        else:
            unmatched += 1
            if unmatched <= 5:
                print_warn(f"Raw file without DB record: {f}")
    
    # Check DB records without raw files
    file_ids = set()
    for f in files:
        name = f.replace('.raw.jsonl.gz', '').replace('.raw.jsonl', '')
        file_ids.add(name.replace('treatment_', ''))
    
    no_raw = 0
    for tid in db_ids:
        if tid not in file_ids:
            no_raw += 1
    
    print_ok(f"{matched} raw files matched to DB treatments")
    if unmatched > 0:
        print_warn(f"{unmatched} raw files without DB records")
    if no_raw > 0:
        print_info(f"{no_raw} DB treatments without raw files (normal for old/archived)")
    
    db.close()


def check_services():
    """Check if backend/frontend services are reachable."""
    print_section("🌐 Service Status")
    
    import socket
    
    services = [
        ('Backend API', 'localhost', 8000),
        ('Frontend', 'localhost', 3000),
    ]
    
    for name, host, port in services:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex((host, port))
            sock.close()
            if result == 0:
                print_ok(f"{name}: Running on port {port}")
            else:
                print_warn(f"{name}: Not responding on port {port}")
        except Exception:
            print_warn(f"{name}: Could not check port {port}")


def main():
    quick = '--quick' in sys.argv
    
    print_header("🏥 PrismaFlex System Health Check")
    
    ok = check_db_integrity()
    if ok:
        check_orphan_records()
    check_raw_data(quick)
    check_services()
    
    print(f"\n{C.BOLD}{'═' * 70}{C.RESET}")
    print(f"  {C.GREEN}Health check complete.{C.RESET}\n")


if __name__ == '__main__':
    main()
