"""
May4 HTTP Replay Script
========================
Sends May4_data.ndjson packets to the running backend via HTTP POST.
Tests the FULL pipeline: route -> recorder -> importer -> real DB -> raw streamer.

Pre-sorts packets by timestamp per BACKFILL_INPUT_CONTRACT.

Usage:
  python backend/tools/replay_may4.py [--limit N] [--no-sort]
"""

import json
import sys
import time
import argparse
import requests
from datetime import datetime
from pathlib import Path

DATA_FILE = Path(__file__).resolve().parent.parent.parent / "data" / "done" / "May4_data.ndjson"
BACKEND_URL = "http://localhost:8000/api/v1/telemetry/backfill"
BATCH_SIZE = 50  # Print progress every N packets


def parse_ts(ts_str: str) -> datetime:
    ts = ts_str.strip()
    if ts.endswith(" UTC"):
        ts = ts[:-4]
    return datetime.fromisoformat(ts)


def load_and_sort(filepath: str, do_sort: bool = True, limit: int = None):
    """Load NDJSON, inject meta.device_id, optionally sort by timestamp."""
    packets = []
    print(f"Loading {filepath}...")
    with open(filepath, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if limit and i >= limit:
                break
            d = json.loads(line)
            hdr = d.get("s_header", {})
            machine_id = str(hdr.get("machine_id", "unknown"))
            ts_raw = hdr.get("timestamp", "")

            # Inject device_id into meta (May4 data has empty meta)
            if "meta" not in d:
                d["meta"] = {}
            d["meta"]["device_id"] = machine_id
            d["meta"]["timestamp"] = ts_raw

            packets.append({
                "data": d,
                "ts_raw": ts_raw,
                "ts_parsed": parse_ts(ts_raw) if ts_raw else None,
                "patient_id": hdr.get("patient_id", "N/A"),
            })

    print(f"  Loaded {len(packets)} packets")

    if do_sort:
        valid = [p for p in packets if p["ts_parsed"]]
        invalid = [p for p in packets if not p["ts_parsed"]]
        valid.sort(key=lambda p: p["ts_parsed"])
        packets = valid + invalid
        print(f"  Sorted by timestamp ({len(invalid)} packets had no timestamp)")

    return packets


def send_packets(packets: list):
    """Send packets to backend via HTTP POST with progress reporting."""
    total = len(packets)
    success = 0
    errors = 0
    t_start = time.time()
    session = requests.Session()

    print(f"\nSending {total} packets to {BACKEND_URL}...")
    print(f"{'=' * 60}")

    for i, pkt in enumerate(packets):
        try:
            resp = session.post(BACKEND_URL, json=pkt["data"], timeout=10)
            if resp.status_code == 200:
                success += 1
            elif resp.status_code == 409:
                # Device mode conflict — expected if device is in LIVE mode
                print(f"  [409] Device conflict at pkt#{i} ({pkt['patient_id']})")
                errors += 1
            else:
                print(f"  [{resp.status_code}] Error at pkt#{i}: {resp.text[:100]}")
                errors += 1
        except requests.exceptions.ConnectionError:
            print(f"\n  CONNECTION ERROR at pkt#{i} — is backend running at {BACKEND_URL}?")
            return success, errors
        except Exception as e:
            print(f"  Exception at pkt#{i}: {e}")
            errors += 1

        # Progress
        if (i + 1) % BATCH_SIZE == 0 or i == total - 1:
            elapsed = time.time() - t_start
            rate = (i + 1) / elapsed if elapsed > 0 else 0
            pct = (i + 1) / total * 100
            eta = (total - i - 1) / rate if rate > 0 else 0
            sys.stdout.write(
                f"\r  [{pct:5.1f}%] {i+1}/{total} | "
                f"{rate:.0f} pkt/s | "
                f"OK={success} ERR={errors} | "
                f"ETA={eta:.0f}s     "
            )
            sys.stdout.flush()

    elapsed = time.time() - t_start
    print(f"\n{'=' * 60}")
    print(f"Done: {success} OK / {errors} ERR in {elapsed:.1f}s ({success/elapsed:.0f} pkt/s)")
    return success, errors


def main():
    parser = argparse.ArgumentParser(description="Replay May4 data to backend")
    parser.add_argument("--limit", type=int, default=None, help="Max packets to send")
    parser.add_argument("--no-sort", action="store_true", help="Skip pre-sort (test OOO handling)")
    args = parser.parse_args()

    if not DATA_FILE.exists():
        print(f"ERROR: Data file not found: {DATA_FILE}")
        sys.exit(1)

    # Check backend is running
    try:
        r = requests.get("http://localhost:8000/docs", timeout=3)
        print(f"Backend reachable (status={r.status_code})")
    except Exception:
        print("ERROR: Backend not reachable at localhost:8000")
        sys.exit(1)

    packets = load_and_sort(str(DATA_FILE), do_sort=not args.no_sort, limit=args.limit)
    success, errors = send_packets(packets)

    if errors > 0:
        print(f"\n WARNING: {errors} errors during replay")
        sys.exit(1)
    else:
        print(f"\n ALL {success} packets sent successfully")
        print(f"\nNext steps:")
        print(f"  1. Check UI at http://localhost:3000")
        print(f"  2. Check DB: SELECT * FROM treatments ORDER BY start_time;")
        print(f"  3. Check snapshots: SELECT treatment_id, row_code, snapshot_time FROM treatment_journal_rows;")
        print(f"  4. Check checkpoint: SELECT * FROM treatment_projection_checkpoint;")
        print(f"  5. Check device_state: SELECT * FROM device_state;")


if __name__ == "__main__":
    main()
