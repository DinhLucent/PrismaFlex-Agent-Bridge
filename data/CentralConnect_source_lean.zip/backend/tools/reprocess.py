"""
PrismaFlex Treatment Reprocessor
==================================
Safely reprocess snapshots for closed treatments using stored raw JSONL data.
Essential when algorithms change — update snapshots without re-sending from Mirth.

Usage:
    python -m tools.reprocess <treatment_id>          # Reprocess 1 treatment
    python -m tools.reprocess --all                   # Reprocess ALL closed treatments
    python -m tools.reprocess --since 2026-03-01      # Reprocess from date
    python -m tools.reprocess <treatment_id> --force  # Force even if APPROVED

Safety Guards:
    ✅ Only processes CLOSED treatments (never active ones)
    ✅ Requires JSONL file to exist
    ✅ Backs up old snapshots before deleting
    ✅ Warns if treatment is APPROVED (requires --force)
    ✅ Uses same SnapshotService as production pipeline
"""

import sys
import os
import json
import gzip
import argparse
from datetime import datetime, timezone, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tools.helpers import (
    C, print_header, print_section, print_ok, print_warn, print_err, print_info,
    find_raw_file, fmt_time, fmt_duration, get_treatment_db, TREATMENT_DB_PATH
)
from services.treatment.treatment_database import TreatmentDatabase
from services.treatment.treatment_snapshot_service import TreatmentSnapshotService


def read_packets(filepath: str):
    """Read packets from JSONL or JSONL.GZ."""
    packets = []
    opener = gzip.open if filepath.endswith('.gz') else open
    with opener(filepath, 'rt', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                packets.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return packets


def get_eligible_treatments(db, treatment_id=None, since=None):
    """Get treatments eligible for reprocessing."""
    if treatment_id:
        # Partial match
        row = db.fetch_one(
            "SELECT * FROM treatments WHERE id LIKE ?",
            (f"%{treatment_id}%",)
        )
        return [row] if row else []
    
    query = "SELECT * FROM treatments WHERE fsm_state = 'CLOSED'"
    params = ()
    if since:
        query += " AND start_time >= ?"
        params = (since,)
    query += " ORDER BY start_time"
    return db.fetch_all(query, params)


def check_safety(treatment: dict, force: bool = False):
    """Safety checks before reprocessing. Returns (ok, message)."""
    tid = treatment['id']
    
    # 1. Must be CLOSED
    state = treatment.get('fsm_state', '')
    if state != 'CLOSED':
        return False, f"Treatment {tid[:8]} is {state} (must be CLOSED). Active treatments cannot be reprocessed."
    
    # 2. Must have JSONL file
    raw_file = find_raw_file(tid)
    if not raw_file:
        return False, f"No raw JSONL file found for {tid[:8]}. Cannot reprocess without raw data."
    
    # 3. Warn if APPROVED
    approval = treatment.get('approval_status', '')
    if approval == 'APPROVED' and not force:
        return False, f"Treatment {tid[:8]} is APPROVED by doctor. Use --force to override."
    
    return True, raw_file


def backup_snapshots(db, treatment_id: str):
    """Backup existing snapshots to snapshot_originals table."""
    # Table already exists in production schema with:
    # id, treatment_id, hour_label, snapshot_time, snapshot_json, frozen_at
    db.execute("""
        CREATE TABLE IF NOT EXISTS snapshot_originals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            treatment_id TEXT NOT NULL,
            hour_label TEXT,
            snapshot_time TEXT,
            snapshot_json TEXT,
            frozen_at TEXT
        )
    """)
    
    snapshots = db.fetch_all(
        "SELECT * FROM treatment_hourly_snapshots WHERE treatment_id = ?",
        (treatment_id,)
    )
    
    if not snapshots:
        return 0
    
    # Clear previous backups for this treatment (allows re-runs)
    db.execute("DELETE FROM snapshot_originals WHERE treatment_id = ?", (treatment_id,))
    
    frozen_at = datetime.now(timezone(timedelta(hours=7))).isoformat()
    for s in snapshots:
        db.execute(
            "INSERT INTO snapshot_originals (treatment_id, hour_label, snapshot_time, snapshot_json, frozen_at) VALUES (?, ?, ?, ?, ?)",
            (treatment_id, s.get('hour_label'), s.get('snapshot_time'), json.dumps(s), frozen_at)
        )
    
    return len(snapshots)


def reprocess_one(db_instance: TreatmentDatabase, treatment: dict, force: bool = False):
    """Reprocess a single treatment."""
    tid = treatment['id']
    device_id = treatment.get('device_id', 'UNKNOWN')
    short_id = tid[:8]
    
    print_section(f"🔄 Reprocessing {short_id}")
    print_info(f"Device: {device_id} | Patient: {treatment.get('patient_id', '?')}")
    print_info(f"Start: {fmt_time(treatment.get('start_time', ''), '%Y-%m-%d %H:%M')}")
    
    # Safety checks
    ok, result = check_safety(treatment, force)
    if not ok:
        print_err(result)
        return False
    
    raw_file = result
    
    # Read raw packets
    print_info(f"Reading: {os.path.basename(raw_file)}")
    packets = read_packets(raw_file)
    if not packets:
        print_err("No packets in JSONL file.")
        return False
    print_info(f"Loaded {len(packets)} packets")
    
    # Get existing snapshot count
    existing = db_instance.fetch_all(
        "SELECT hour_label FROM treatment_hourly_snapshots WHERE treatment_id = ?",
        (tid,)
    )
    hourly_old = len([s for s in existing if s['hour_label'].startswith('H')])
    oc_old = len([s for s in existing if s['hour_label'].startswith('OC')])
    print_info(f"Existing snapshots: {hourly_old} hourly + {oc_old} OC = {len(existing)} total")
    
    # Backup old snapshots
    backed_up = backup_snapshots(db_instance, tid)
    if backed_up > 0:
        print_ok(f"Backed up {backed_up} snapshots to snapshot_originals")
    
    # Delete old snapshots
    db_instance.execute(
        "DELETE FROM treatment_hourly_snapshots WHERE treatment_id = ?",
        (tid,)
    )
    # Reset snapshot_count in index
    db_instance.execute(
        "UPDATE treatment_index SET snapshot_count = 0 WHERE id = ?",
        (tid,)
    )
    print_ok("Old snapshots deleted")
    
    # Replay packets through SnapshotService (offline)
    svc = TreatmentSnapshotService(db_instance)
    processed = 0
    
    # Order-change detection (mirrors event_service in main.py)
    ORDER_PIDS = {17, 21, 18, 19, 22, 25}  # QB, QD, QS_pre, QS_post, QPBP, UF_Rate
    last_values = {}  # pid → last seen value
    
    for pkt in packets:
        ts = pkt.get('meta', {}).get('timestamp', '')
        header = pkt.get('s_header', {})
        body = pkt.get('s_body', {})
        
        if not ts or not body:
            continue
        
        # 1. Process hourly snapshot
        svc.process_packet(device_id, ts, tid, header, body)
        
        # 2. Detect order changes (inline event_service logic)
        order_changes = []
        for p in body.get('parameters', []):
            pid = p.get('id')
            if pid not in ORDER_PIDS:
                continue
            raw_val = p.get('value')
            if raw_val is None:
                continue
            # Compare against last seen value
            prev = last_values.get(pid)
            if prev is not None:
                try:
                    if abs(float(raw_val) - float(prev)) >= 1:
                        order_changes.append((pid, prev, raw_val))
                except (ValueError, TypeError):
                    pass
            last_values[pid] = raw_val
        
        # 3. Trigger OC snapshot if changes detected
        if order_changes:
            svc.save_order_change_snapshot(device_id, ts, order_changes)
        
        processed += 1
    
    # Flush any remaining cached data
    svc.flush_device(device_id)
    
    # Count new snapshots
    new_snaps = db_instance.fetch_all(
        "SELECT hour_label FROM treatment_hourly_snapshots WHERE treatment_id = ?",
        (tid,)
    )
    hourly_new = len([s for s in new_snaps if s['hour_label'].startswith('H')])
    oc_new = len([s for s in new_snaps if s['hour_label'].startswith('OC')])
    
    print_ok(f"Reprocessed {processed} packets → {hourly_new} hourly + {oc_new} OC = {len(new_snaps)} snapshots")
    
    # Show diff
    if hourly_old != hourly_new or oc_old != oc_new:
        print_info(f"Change: {hourly_old}H+{oc_old}OC → {hourly_new}H+{oc_new}OC")
    
    return True


def main():
    parser = argparse.ArgumentParser(description='Reprocess treatment snapshots from raw JSONL')
    parser.add_argument('treatment_id', nargs='?', help='Treatment ID (partial match)')
    parser.add_argument('--all', action='store_true', help='Reprocess ALL closed treatments')
    parser.add_argument('--since', help='Reprocess treatments since date (YYYY-MM-DD)')
    parser.add_argument('--force', action='store_true', help='Force reprocess even if APPROVED')
    
    args = parser.parse_args()
    
    if not args.treatment_id and not args.all and not args.since:
        parser.print_help()
        return
    
    print_header("🔧 PrismaFlex Treatment Reprocessor")
    
    # Use TreatmentDatabase (same as production)
    db = TreatmentDatabase(TREATMENT_DB_PATH)
    
    # Get eligible treatments
    treatments = get_eligible_treatments(
        db, 
        treatment_id=args.treatment_id,
        since=args.since
    )
    
    if not treatments:
        print_err("No eligible treatments found.")
        db.close()
        return
    
    print_info(f"Found {len(treatments)} treatment(s) to reprocess")
    
    if args.all or args.since:
        print_warn(f"About to reprocess {len(treatments)} treatments!")
        try:
            confirm = input(f"  {C.BOLD}Continue? (y/N): {C.RESET}").strip().lower()
            if confirm != 'y':
                print_info("Cancelled.")
                db.close()
                return
        except (EOFError, KeyboardInterrupt):
            db.close()
            return
    
    # Process each treatment
    success = 0
    failed = 0
    for t in treatments:
        if reprocess_one(db, t, args.force):
            success += 1
        else:
            failed += 1
    
    # Summary
    print_header("📝 Reprocess Complete")
    print(f"  Success: {success}")
    print(f"  Failed:  {failed}")
    print(f"  Total:   {len(treatments)}")
    
    db.close()


if __name__ == '__main__':
    main()
