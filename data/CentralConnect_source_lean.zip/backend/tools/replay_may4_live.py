"""
May4 LIVE Replay Script
========================
Replays a subset of May4_data.ndjson as LIVE telemetry.
Timestamps are shifted so the first packet = NOW.

This tests the LIVE pipeline: recorder, snapshot_svc, raw_streamer,
WebSocket broadcast, event detection — everything backfill skips.

Usage:
  python backend/tools/replay_may4_live.py                  # Patient g12
  python backend/tools/replay_may4_live.py --patient g2     # Patient g2
  python backend/tools/replay_may4_live.py --limit 500      # First 500 pkts
"""

import json
import sys
import time
import argparse
import requests
from datetime import datetime, timezone, timedelta
from pathlib import Path

DATA_FILE = Path(__file__).resolve().parent.parent.parent / "data" / "done" / "May4_data.ndjson"
LIVE_URL = "http://localhost:8000/api/v1/telemetry/live"
TZ7 = timezone(timedelta(hours=7))
BATCH_PROGRESS = 50


def parse_ts(ts_str):
    ts = ts_str.strip()
    if ts.endswith(" UTC"):
        ts = ts[:-4]
    dt = datetime.fromisoformat(ts)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=TZ7)
    return dt


def load_patient(filepath, target_patient, limit=None):
    """Load packets for one patient, sorted by timestamp."""
    packets = []
    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            hdr = d.get("s_header", {})
            pid = hdr.get("patient_id", "N/A")
            if pid != target_patient:
                continue
            ts_raw = hdr.get("timestamp", "")
            if not ts_raw:
                continue
            packets.append({
                "data": d,
                "ts_parsed": parse_ts(ts_raw),
                "header": hdr,
            })
            if limit and len(packets) >= limit:
                break

    packets.sort(key=lambda p: p["ts_parsed"])
    return packets


def shift_and_send(packets, speed_factor=100):
    """Shift timestamps to start from NOW, send as live telemetry.
    
    speed_factor: compress time by this factor (100 = 100x faster than real)
    """
    if not packets:
        print("No packets to send")
        return 0, 0

    now = datetime.now(TZ7)
    first_ts = packets[0]["ts_parsed"]
    total = len(packets)
    session = requests.Session()
    success = 0
    errors = 0

    # Compute time span
    last_ts = packets[-1]["ts_parsed"]
    real_span = (last_ts - first_ts).total_seconds()
    compressed_span = real_span / speed_factor

    print(f"Sending {total} packets as LIVE telemetry")
    print(f"  Real time span: {real_span/3600:.1f}h")
    print(f"  Compressed to:  {compressed_span:.0f}s (x{speed_factor} speed)")
    print(f"  Start time:     {now.isoformat()}")
    print(f"{'=' * 60}")

    t_start = time.time()

    for i, pkt in enumerate(packets):
        # Shift timestamp: original_offset -> compressed_offset -> now + offset
        orig_offset = (pkt["ts_parsed"] - first_ts).total_seconds()
        shifted_time = now + timedelta(seconds=orig_offset / speed_factor)

        # Update timestamps in the packet
        shifted_str = shifted_time.strftime("%Y-%m-%d %H:%M:%S UTC")
        pkt["data"]["s_header"]["timestamp"] = shifted_str

        # Inject meta
        if "meta" not in pkt["data"]:
            pkt["data"]["meta"] = {}
        machine_id = str(pkt["header"].get("machine_id", "4"))
        pkt["data"]["meta"]["device_id"] = machine_id
        pkt["data"]["meta"]["timestamp"] = shifted_str

        try:
            resp = session.post(LIVE_URL, json=pkt["data"], timeout=10)
            if resp.status_code == 200:
                success += 1
            elif resp.status_code == 409:
                print(f"\n  [409] Mode conflict at pkt#{i}")
                errors += 1
            else:
                print(f"\n  [{resp.status_code}] pkt#{i}: {resp.text[:80]}")
                errors += 1
        except requests.exceptions.ConnectionError:
            print(f"\n  CONNECTION ERROR at pkt#{i}")
            return success, errors
        except Exception as e:
            errors += 1

        if (i + 1) % BATCH_PROGRESS == 0 or i == total - 1:
            elapsed = time.time() - t_start
            rate = (i + 1) / elapsed if elapsed > 0 else 0
            pct = (i + 1) / total * 100
            sys.stdout.write(
                f"\r  [{pct:5.1f}%] {i+1}/{total} | "
                f"{rate:.0f} pkt/s | "
                f"OK={success} ERR={errors}     "
            )
            sys.stdout.flush()

    elapsed = time.time() - t_start
    print(f"\n{'=' * 60}")
    print(f"Done: {success} OK / {errors} ERR in {elapsed:.1f}s ({success/elapsed:.0f} pkt/s)")
    return success, errors


def main():
    parser = argparse.ArgumentParser(description="Replay May4 data as LIVE telemetry")
    parser.add_argument("--patient", default="g12", help="Patient ID to replay (default: g12)")
    parser.add_argument("--limit", type=int, default=None, help="Max packets")
    parser.add_argument("--speed", type=int, default=100, help="Time compression factor (default: 100x)")
    args = parser.parse_args()

    if not DATA_FILE.exists():
        print(f"ERROR: {DATA_FILE}")
        sys.exit(1)

    try:
        requests.get("http://localhost:8000/docs", timeout=3)
        print("Backend reachable")
    except Exception:
        print("ERROR: Backend not reachable at localhost:8000")
        sys.exit(1)

    print(f"Loading patient={args.patient}...")
    packets = load_patient(str(DATA_FILE), args.patient, args.limit)
    print(f"  {len(packets)} packets loaded")

    if not packets:
        print(f"No packets found for patient '{args.patient}'")
        sys.exit(1)

    success, errors = shift_and_send(packets, speed_factor=args.speed)

    if errors == 0:
        print(f"\nAll {success} packets sent as LIVE telemetry")
        print(f"\nVerify:")
        print(f"  1. UI: http://localhost:3000")
        print(f"  2. DB: treatments, treatment_journal_rows")
        print(f"  3. device_state should show mode=LIVE")


if __name__ == "__main__":
    main()
