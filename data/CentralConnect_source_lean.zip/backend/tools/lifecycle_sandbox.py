"""
Lifecycle sandbox and backtest harness for treatment recording.

This script exercises the recorder, snapshot service, and raw streamer together
against a set of operational scenarios that mimic PrismaFlex workflow:

- hard END boundaries
- soft continuity without END
- app restart recovery
- multiple devices interleaved
- patient change handling
- backfill -> live promotion/fresh start handoff
- hourly + OC snapshot chronology
- ghost discard cleanup
- stale auto-close maintenance

Run:
    python backend/tools/lifecycle_sandbox.py
or from backend/tools:
    python lifecycle_sandbox.py
"""

from __future__ import annotations

import asyncio
import gzip
import os
import shutil
import sys
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from services.treatment.raw_streamer import RawDataStreamer
from services.treatment.treatment_database import TreatmentDatabase
from services.treatment.treatment_recorder import TreatmentRecorderService
from services.treatment.treatment_snapshot_service import (
    ORDER_CHANGE_PIDS,
    TreatmentSnapshotService,
)
from services.alarm_service import SmartAlarmService
from services.database import TrendDatabase
from services.event_service import EventService
from services.telemetry_contract import (
    apply_ingest_contract,
    normalize_device_id,
    parse_clinical_timestamp,
    resolve_mode_and_quality,
    resolve_packet_time,
)

TZ = timezone(timedelta(hours=7))
SANDBOX_RUNTIME_DIR = os.path.join(BACKEND_DIR, "tools", "_sandbox_runtime")
os.makedirs(SANDBOX_RUNTIME_DIR, exist_ok=True)


def local_time(year: int, month: int, day: int, hour: int, minute: int, second: int = 0) -> datetime:
    return datetime(year, month, day, hour, minute, second, tzinfo=TZ)


def ensure(condition: bool, message: str):
    if not condition:
        raise AssertionError(message)


def raw_line_count(filepath: str) -> int:
    if not os.path.exists(filepath):
        return 0
    opener = gzip.open if filepath.endswith(".gz") else open
    with opener(filepath, "rt", encoding="utf-8") as handle:
        return sum(1 for _ in handle)


@dataclass
class ScenarioResult:
    name: str
    status: str
    details: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


class SandboxEnv:
    def __init__(self):
        self.base_dir = os.path.join(
            SANDBOX_RUNTIME_DIR,
            f"treatment_lifecycle_sandbox_{uuid.uuid4().hex[:8]}",
        )
        os.makedirs(self.base_dir, exist_ok=False)
        self.db_path = os.path.join(self.base_dir, "sandbox_treatments.db")
        self.raw_dir = os.path.join(self.base_dir, "raw")
        self.order_baseline: Dict[str, Dict[int, float]] = {}
        self._build_services()

    def _build_services(self):
        self.db = TreatmentDatabase(self.db_path)
        self.streamer = RawDataStreamer(self.raw_dir)
        self.recorder = TreatmentRecorderService(self.db, self.streamer)
        self.snapshot = TreatmentSnapshotService(self.db)

    def restart_services(self):
        self._build_services()

    def cleanup(self):
        try:
            shutil.rmtree(self.base_dir, ignore_errors=True)
        except Exception:
            pass

    def _build_header(self, device_id: str, patient_id: Optional[str], status_id: int, when: datetime) -> Dict[str, Any]:
        machine_suffix = "".join(ch for ch in device_id if ch.isdigit())
        machine_id = int(machine_suffix or "0")
        return {
            "machine_id": machine_id,
            "patient_id": patient_id,
            "therapy_type_id": 3,
            "therapy_type_id_name": "CRRT",
            "therapy_status_id": status_id,
            "timestamp": when.isoformat(),
            "sw_version": "SIM_8.20V04R00",
        }

    def _build_body(
        self,
        qb: float,
        qd: float,
        qs_pre: float,
        qs_post: float,
        qpbp: float,
        uf_total: float,
        uf_hourly: float,
        run_time_sec: Optional[float],
    ) -> Dict[str, Any]:
        params = [
            {"id": 17, "type": "Set", "value": qb},
            {"id": 21, "type": "Set", "value": qd},
            {"id": 18, "type": "Set", "value": qs_pre},
            {"id": 19, "type": "Set", "value": qs_post},
            {"id": 22, "type": "Set", "value": qpbp},
            {"id": 100, "type": "Actual", "value": uf_total},
            {"id": 24, "type": "Set", "value": uf_hourly},
            {"id": 1, "type": "Actual", "value": -80},
            {"id": 4, "type": "Actual", "value": 75},
            {"id": 2, "type": "Actual", "value": 130},
            {"id": 6, "type": "Actual", "value": 40},
        ]
        if run_time_sec is not None:
            params.append({"id": 461, "type": "Actual", "value": run_time_sec})
        return {"parameters": params}

    def _detect_order_changes(self, device_id: str, body: Dict[str, Any]) -> List[Tuple[int, float, float]]:
        current: Dict[int, float] = {}
        for param in body.get("parameters", []):
            pid = param.get("id")
            if pid in ORDER_CHANGE_PIDS:
                try:
                    current[pid] = float(param.get("value"))
                except (TypeError, ValueError):
                    continue

        previous = self.order_baseline.get(device_id)
        self.order_baseline[device_id] = current
        if previous is None:
            return []

        changes: List[Tuple[int, float, float]] = []
        for pid, new_val in current.items():
            old_val = previous.get(pid)
            if old_val is None:
                continue
            if abs(new_val - old_val) >= 1:
                changes.append((pid, old_val, new_val))
        return changes

    async def feed(
        self,
        *,
        device_id: str,
        patient_id: Optional[str],
        status_id: int,
        when: datetime,
        run_time_sec: Optional[float] = None,
        qb: float = 150,
        qd: float = 1000,
        qs_pre: float = 500,
        qs_post: float = 500,
        qpbp: float = 300,
        uf_total: float = 0,
        uf_hourly: float = 100,
        is_live: bool = True,
    ) -> Dict[str, Any]:
        timestamp = when.isoformat()
        header = self._build_header(device_id, patient_id, status_id, when)
        body = self._build_body(qb, qd, qs_pre, qs_post, qpbp, uf_total, uf_hourly, run_time_sec)
        meta = {"device_id": device_id, "timestamp": timestamp, "mode": "LIVE" if is_live else "BACKFILL"}

        routing = await self.recorder.process_packet(device_id, timestamp, header, body, meta, is_live=is_live)
        snapshot_treatment_id = (routing or {}).get("treatment_id")

        if snapshot_treatment_id:
            self.snapshot.process_packet(device_id, timestamp, snapshot_treatment_id, header, body)

        if (routing or {}).get("flush_snapshot_after"):
            self.snapshot.flush_device(device_id)

        changes = self._detect_order_changes(device_id, body)
        if snapshot_treatment_id and changes:
            self.snapshot.save_order_change_snapshot(device_id, timestamp, changes)

        return routing or {}

    def treatments(self) -> List[Dict[str, Any]]:
        return self.db.get_treatments(limit=1000, offset=0)

    def treatment(self, treatment_id: str) -> Dict[str, Any]:
        return self.db.get_treatment_by_id(treatment_id)

    def snapshots(self, treatment_id: str) -> List[Dict[str, Any]]:
        return self.db.get_snapshots(treatment_id)

    def status_log(self, treatment_id: str) -> List[Dict[str, Any]]:
        return self.db.get_status_log(treatment_id)

    def raw_path(self, treatment_id: str) -> str:
        return self.streamer.get_raw_filepath(treatment_id)


class DashboardEnv:
    def __init__(self):
        self.base_dir = os.path.join(
            SANDBOX_RUNTIME_DIR,
            f"dashboard_logic_sandbox_{uuid.uuid4().hex[:8]}",
        )
        os.makedirs(self.base_dir, exist_ok=False)
        self.db_path = os.path.join(self.base_dir, "sandbox_trends.db")
        self.db = TrendDatabase(self.db_path)
        self.event = EventService(self.db)
        self.alarm = SmartAlarmService(self.db)
        self.event.on_session_reset = self._on_session_reset

    def _on_session_reset(self, device_id: str):
        if device_id in self.alarm._active_alarms:
            del self.alarm._active_alarms[device_id]
        if device_id in self.alarm._pending_clears:
            del self.alarm._pending_clears[device_id]

    def cleanup(self):
        try:
            self.db.close()
        except Exception:
            pass
        try:
            shutil.rmtree(self.base_dir, ignore_errors=True)
        except Exception:
            pass

    def feed(
        self,
        *,
        device_id: str,
        patient_id: str,
        when: datetime,
        qb: float = 150,
        qd: float = 1000,
        pa: float = -80,
        pv: float = 75,
        pbe: float = 130,
        tmp: float = 40,
        alarms: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Tuple[Any, Any, Any]]:
        timestamp = when.isoformat()
        header = {
            "patient_id": patient_id,
            "therapy_status_id": 5,
        }
        body = {
            "parameters": [
                {"id": 17, "value": qb, "value_text": str(qb)},
                {"id": 21, "value": qd, "value_text": str(qd)},
                {"id": 1, "value": pa},
                {"id": 4, "value": pv},
                {"id": 2, "value": pbe},
                {"id": 6, "value": tmp},
            ]
        }
        changes = self.event.track_parameter_changes(device_id, timestamp, header, body)
        self.event.save_trend_point(device_id, timestamp, body["parameters"])
        self.alarm.process(device_id, alarms or [], timestamp, patient_id)
        self.alarm.set_last_broadcast(device_id, when)
        return changes


async def scenario_end_then_same_patient_runtime_continues() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 8, 0, 0)

        await env.feed(device_id="PF_004", patient_id="g21", status_id=5, when=start, run_time_sec=0, uf_total=0)
        first_id = env.recorder.get_active_sessions()["PF_004"]["treatment_id"]
        await env.feed(device_id="PF_004", patient_id="g21", status_id=5, when=start + timedelta(minutes=65), run_time_sec=3900, uf_total=120)
        await env.feed(device_id="PF_004", patient_id="g21", status_id=8, when=start + timedelta(minutes=80), run_time_sec=4800, uf_total=140)
        await env.feed(device_id="PF_004", patient_id="g21", status_id=0, when=start + timedelta(minutes=81), run_time_sec=4800, uf_total=140)
        await env.feed(device_id="PF_004", patient_id="g21", status_id=5, when=start + timedelta(minutes=95), run_time_sec=4800, uf_total=150)

        treatments = env.treatments()
        ensure(len(treatments) == 1, f"expected 1 treatment, found {len(treatments)}")
        first = env.treatment(first_id)

        ensure(first["outcome"] == "IN_PROGRESS", "same-patient continuation should reopen the original treatment")
        ensure(first.get("close_reason") in (None, ""), "resumed treatment should clear END close reason")

        first_raw = env.raw_path(first_id)
        ensure(os.path.exists(first_raw), "resumed treatment raw should be writable again")
        ensure(raw_line_count(first_raw) == 4, "raw should contain RUN/RUN/END plus resumed RUN")

        snapshots = env.snapshots(first_id)
        ensure(
            snapshots[-1]["snapshot_time"] == (start + timedelta(minutes=65)).isoformat(),
            "END close should not overwrite the frozen H01 snapshot time",
        )

        return ScenarioResult(
            name="END then same-patient RUN_TIME continuity resumes one treatment",
            status="PASS",
            details=[
                f"treatment={first_id[:8]} reopened after END",
                f"raw lines={raw_line_count(first_raw)}",
                "post-END idle packet was dropped from raw as intended",
            ],
        )
    finally:
        env.cleanup()


async def scenario_live_gap_keeps_same_treatment() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 9, 0, 0)
        await env.feed(device_id="PF_003", patient_id="TVV", status_id=5, when=start, run_time_sec=0)
        first_id = env.recorder.get_active_sessions()["PF_003"]["treatment_id"]
        await env.feed(
            device_id="PF_003",
            patient_id="TVV",
            status_id=5,
            when=start + timedelta(hours=4),
            run_time_sec=14400,
            uf_total=220,
        )
        active = env.recorder.get_active_sessions()["PF_003"]["treatment_id"]
        row = env.treatment(first_id)

        ensure(active == first_id, "same treatment should continue across a long gap without END")
        ensure(row["had_interruption"] == 1, "gap > 300s should mark had_interruption")
        ensure(len(env.treatments()) == 1, "gap resume should not create another treatment")

        return ScenarioResult(
            name="LIVE gap without END resumes same treatment",
            status="PASS",
            details=[f"treatment={first_id[:8]} retained across 4h gap", "had_interruption=1"],
        )
    finally:
        env.cleanup()


async def scenario_restart_recovery() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 10, 0, 0)
        await env.feed(device_id="PF_007", patient_id="restart-p", status_id=5, when=start, run_time_sec=0)
        await env.feed(device_id="PF_007", patient_id="restart-p", status_id=5, when=start + timedelta(minutes=20), run_time_sec=1200)
        first_id = env.recorder.get_active_sessions()["PF_007"]["treatment_id"]

        env.restart_services()
        await env.feed(device_id="PF_007", patient_id="restart-p", status_id=5, when=start + timedelta(minutes=40), run_time_sec=2400)

        treatments = env.treatments()
        ensure(len(treatments) == 1, "restart should not duplicate active treatment")
        ensure(treatments[0]["id"] == first_id, "restart should recover the same treatment id")
        ensure(treatments[0]["had_program_restart"] == 1, "recovery should mark had_program_restart")
        ensure(raw_line_count(env.raw_path(first_id)) == 3, "raw should continue in the same file after restart")

        return ScenarioResult(
            name="App restart recovers IN_PROGRESS treatment",
            status="PASS",
            details=[f"treatment={first_id[:8]} recovered", "raw continued in same file"],
        )
    finally:
        env.cleanup()


async def scenario_multi_device_isolation() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 11, 0, 0)
        device_specs = [
            ("PF_003", "A001", 0),
            ("PF_004", "B001", 2),
            ("PF_007", "C001", 4),
        ]
        for device_id, patient_id, offset_min in device_specs:
            await env.feed(
                device_id=device_id,
                patient_id=patient_id,
                status_id=5,
                when=start + timedelta(minutes=offset_min),
                run_time_sec=0,
            )
        for device_id, patient_id, offset_min in reversed(device_specs):
            await env.feed(
                device_id=device_id,
                patient_id=patient_id,
                status_id=5,
                when=start + timedelta(minutes=offset_min + 70),
                run_time_sec=4200,
                uf_total=120,
            )

        treatments = env.treatments()
        ensure(len(treatments) == 3, f"expected 3 isolated treatments, found {len(treatments)}")
        seen_devices = {t["device_id"] for t in treatments}
        ensure(seen_devices == {"PF_003", "PF_004", "PF_007"}, "device isolation failed")
        for row in treatments:
            ensure(os.path.exists(env.raw_path(row["id"])), f"raw file missing for {row['device_id']}")

        return ScenarioResult(
            name="Multiple devices stay isolated",
            status="PASS",
            details=[", ".join(sorted(seen_devices)), "each device retained its own raw/treatment identity"],
        )
    finally:
        env.cleanup()


async def scenario_patient_change_waits_for_start() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 12, 0, 0)
        await env.feed(device_id="PF_003", patient_id="old-p", status_id=5, when=start, run_time_sec=0)
        old_id = env.recorder.get_active_sessions()["PF_003"]["treatment_id"]
        await env.feed(device_id="PF_003", patient_id="new-p", status_id=0, when=start + timedelta(minutes=30), run_time_sec=0)

        ensure("PF_003" not in env.recorder.get_active_sessions(), "patient change with status 0 should close old session without opening a new one")
        ensure(len(env.treatments()) == 1, "status 0 after patient change should not create new treatment")
        ensure(env.treatment(old_id)["close_reason"].startswith("Patient change"), "old treatment should close on patient change")

        await env.feed(device_id="PF_003", patient_id="new-p", status_id=5, when=start + timedelta(minutes=31), run_time_sec=0)
        ensure(len(env.treatments()) == 2, "new RUN should create the replacement treatment")

        return ScenarioResult(
            name="Patient change closes old treatment and waits for new start gate",
            status="PASS",
            details=["old treatment closed on patient change", "new treatment opened only after RUN", "non-start patient-change packet was dropped from raw as intended"],
        )
    finally:
        env.cleanup()


async def scenario_backfill_live_promote() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 13, 0, 0)
        await env.feed(device_id="PF_004", patient_id="g21", status_id=5, when=start, run_time_sec=0, is_live=False)
        await env.feed(device_id="PF_004", patient_id="g21", status_id=5, when=start + timedelta(minutes=15), run_time_sec=900, is_live=False)
        backfill_id = env.recorder._backfill_sessions["PF_004"].treatment_id

        await env.feed(device_id="PF_004", patient_id="g21", status_id=5, when=start + timedelta(minutes=16), run_time_sec=960, is_live=True)

        treatments = env.treatments()
        active_id = env.recorder.get_active_sessions()["PF_004"]["treatment_id"]
        ensure(active_id == backfill_id, "live handoff with RUN_TIME>0 should promote backfill session")
        ensure(len(treatments) == 1, "promotion should collapse to one active treatment")
        ensure(raw_line_count(env.raw_path(backfill_id)) == 3, "promoted treatment should keep all raw packets together")

        return ScenarioResult(
            name="Backfill -> LIVE same-patient handoff promotes existing session",
            status="PASS",
            details=[f"promoted treatment={backfill_id[:8]}", "raw remained in one file"],
        )
    finally:
        env.cleanup()


async def scenario_backfill_live_fresh_start() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 14, 0, 0)
        await env.feed(device_id="PF_004", patient_id="g21", status_id=5, when=start, run_time_sec=0, is_live=False)
        await env.feed(device_id="PF_004", patient_id="g21", status_id=5, when=start + timedelta(minutes=10), run_time_sec=600, is_live=False)
        backfill_id = env.recorder._backfill_sessions["PF_004"].treatment_id

        await env.feed(device_id="PF_004", patient_id="g21", status_id=5, when=start + timedelta(minutes=11), run_time_sec=0, is_live=True)

        treatments = env.treatments()
        ensure(len(treatments) == 2, "fresh live start should keep backfill closed and open a new live treatment")
        old_row = env.treatment(backfill_id)
        ensure(old_row["outcome"] == "COMPLETED", "backfill treatment should be closed on fresh start handoff")
        ensure(str(old_row.get("close_reason") or "").startswith("Backfill closed on live handoff"), "backfill close reason should explain handoff")

        new_active = env.recorder.get_active_sessions()["PF_004"]["treatment_id"]
        ensure(new_active != backfill_id, "fresh start must create a new live treatment")

        return ScenarioResult(
            name="Backfill -> LIVE fresh start creates a new treatment",
            status="PASS",
            details=[f"closed backfill={backfill_id[:8]}", f"new live={new_active[:8]}"],
        )
    finally:
        env.cleanup()


async def scenario_same_patient_runtime_zero_starts_new_treatment() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 14, 30, 0)
        first = await env.feed(device_id="PF_009", patient_id="same-p", status_id=5, when=start, run_time_sec=1800)
        first_id = first["treatment_id"]

        waiting = await env.feed(
            device_id="PF_009",
            patient_id="same-p",
            status_id=4,
            when=start + timedelta(hours=2),
            run_time_sec=0,
        )
        ensure(waiting["treatment_id"] == first_id, "WAITINGSTART with RUN_TIME=0 should not split immediately")

        second = await env.feed(
            device_id="PF_009",
            patient_id="same-p",
            status_id=5,
            when=start + timedelta(hours=2, minutes=5),
            run_time_sec=0,
        )
        second_id = second["treatment_id"]
        ensure(second_id and second_id != first_id, "RUN with RUN_TIME=0 must create a fresh treatment")

        rows = env.treatments()
        ensure(len(rows) == 2, f"expected 2 treatments, got {len(rows)}")

        first_row = env.treatment(first_id)
        second_row = env.treatment(second_id)
        ensure(first_row["outcome"] == "COMPLETED", "old treatment should be closed on fresh start")
        ensure(first_row["close_reason"] == "RUN_TIME=0 fresh start", "close reason should capture the fresh start")
        ensure(second_row["outcome"] == "IN_PROGRESS", "new treatment should be active")

        return ScenarioResult(
            name="Same patient + RUN_TIME=0 splits only when RUN resumes",
            status="PASS",
            details=[f"first={first_id[:8]} closed", f"second={second_id[:8]} active"],
        )
    finally:
        env.cleanup()


async def scenario_hourly_and_oc_snapshots() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 15, 0, 0)
        await env.feed(device_id="PF_007", patient_id="oc-p", status_id=5, when=start, run_time_sec=0, uf_total=0, qd=1000)
        treatment_id = env.recorder.get_active_sessions()["PF_007"]["treatment_id"]

        await env.feed(device_id="PF_007", patient_id="oc-p", status_id=5, when=start + timedelta(seconds=61), run_time_sec=61, uf_total=2, qd=1000)
        await env.feed(device_id="PF_007", patient_id="oc-p", status_id=5, when=start + timedelta(hours=1, minutes=1), run_time_sec=3660, uf_total=120, qd=1000)
        await env.feed(device_id="PF_007", patient_id="oc-p", status_id=5, when=start + timedelta(hours=1, minutes=30), run_time_sec=5400, uf_total=150, qd=800)
        await env.feed(device_id="PF_007", patient_id="oc-p", status_id=5, when=start + timedelta(hours=2, minutes=1), run_time_sec=7260, uf_total=220, qd=800)

        snaps = env.snapshots(treatment_id)
        labels = [row["hour_label"] for row in snaps]
        ensure(labels == ["H00", "H01", "OC_01", "H02"], f"unexpected snapshot labels: {labels}")

        oc_row = next(row for row in snaps if row["hour_label"] == "OC_01")
        h0_row = next(row for row in snaps if row["hour_label"] == "H00")
        h1_row = next(row for row in snaps if row["hour_label"] == "H01")
        h2_row = next(row for row in snaps if row["hour_label"] == "H02")

        ensure(h0_row["snapshot_time"] == start.isoformat(), "H00 should freeze at the first packet time")
        ensure(abs(float(oc_row["qd"]) - 800.0) < 1, "OC snapshot should save changed values, not stale cache")
        ensure("qd" in str(oc_row.get("reason") or "").lower(), "OC reason should explain the QD change")
        ensure(h1_row["snapshot_time"] < oc_row["snapshot_time"] < h2_row["snapshot_time"], "OC chronology should sit between hourly rows")

        return ScenarioResult(
            name="Hourly + OC snapshots keep chronology and changed values",
            status="PASS",
            details=[f"labels={labels}", f"OC reason={oc_row.get('reason')}"],
        )
    finally:
        env.cleanup()


async def scenario_missing_hour_becomes_gap() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 15, 30, 0)
        await env.feed(device_id="PF_008", patient_id="gap-p", status_id=5, when=start, run_time_sec=0, uf_total=0)
        treatment_id = env.recorder.get_active_sessions()["PF_008"]["treatment_id"]

        # No packets during the whole second clinical hour [H01 window].
        await env.feed(
            device_id="PF_008",
            patient_id="gap-p",
            status_id=5,
            when=start + timedelta(hours=2, minutes=5),
            run_time_sec=7500,
            uf_total=240,
        )

        snaps = env.snapshots(treatment_id)
        labels = [row["hour_label"] for row in snaps]

        ensure(labels == ["H00", "H02"], f"missing-hour behavior should leave H01 absent, got {labels}")

        return ScenarioResult(
            name="Missing whole hour leaves GAP instead of fabricating H label",
            status="PASS",
            details=[f"labels={labels}", "frontend should render absent H01 as GAP"],
        )
    finally:
        env.cleanup()


async def scenario_ghost_discard() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 16, 0, 0)
        await env.feed(device_id="PF_009", patient_id="ghost", status_id=5, when=start, run_time_sec=0)
        ghost_id = env.recorder.get_active_sessions()["PF_009"]["treatment_id"]
        await env.feed(device_id="PF_009", patient_id="ghost", status_id=8, when=start + timedelta(minutes=2), run_time_sec=120)

        ensure(env.db.get_treatment_by_id(ghost_id) is None, "ghost treatment should be deleted from DB")
        ensure(not os.path.exists(env.raw_path(ghost_id)), "ghost raw file should be removed")
        ensure(not os.path.exists(env.raw_path(ghost_id) + ".gz"), "ghost gz file should be removed")

        return ScenarioResult(
            name="Ghost session discard removes DB row and raw",
            status="PASS",
            details=[f"ghost treatment={ghost_id[:8]} deleted"],
        )
    finally:
        env.cleanup()


async def scenario_auto_close_stale_live_session() -> ScenarioResult:
    env = SandboxEnv()
    try:
        start = local_time(2026, 4, 14, 17, 0, 0)
        await env.feed(device_id="PF_010", patient_id="stale", status_id=5, when=start, run_time_sec=0)
        treatment_id = env.recorder.get_active_sessions()["PF_010"]["treatment_id"]

        session = env.recorder._sessions["PF_010"]
        session.last_seen = datetime.now(timezone.utc) - timedelta(hours=25)
        session.start_pkt_time = session.last_seen - timedelta(hours=1)
        session.total_packets = 42

        closed = env.recorder.enforce_auto_close()
        await asyncio.sleep(0.2)

        row = env.treatment(treatment_id)
        ensure(closed == 1, f"expected 1 auto-closed session, got {closed}")
        ensure(row["outcome"] == "COMPLETED", "stale live session should auto-close")
        ensure(str(row.get("close_reason") or "").startswith("AUTO_TIMEOUT (Live)"), "auto-close reason should be recorded")
        ensure(os.path.exists(env.raw_path(treatment_id) + ".gz"), "auto-close should compress raw file")

        return ScenarioResult(
            name="Auto-close maintenance finalizes stale live sessions",
            status="PASS",
            details=[f"treatment={treatment_id[:8]} auto-closed", "raw compressed after maintenance"],
        )
    finally:
        env.cleanup()


async def scenario_dashboard_patient_change_purges_history() -> ScenarioResult:
    env = DashboardEnv()
    try:
        start = local_time(2026, 4, 14, 18, 0, 0)
        env.feed(
            device_id="PF_004",
            patient_id="old-p",
            when=start,
            alarms=[{"id": 9001, "title": "TMP High", "severity": "HIGH", "state": "PRESENT"}],
        )
        changes = env.feed(device_id="PF_004", patient_id="old-p", when=start + timedelta(minutes=1), qb=180)
        ensure(len(changes) == 1, "same-patient parameter change should be tracked")
        ensure(len(env.db.get_trends("PF_004")) == 2, "old patient should have two trend points before purge")
        ensure(len(env.db.get_alarm_history("PF_004")) == 1, "alarm history should be present before purge")

        changes_after_switch = env.feed(device_id="PF_004", patient_id="new-p", when=start + timedelta(minutes=2), qb=220)
        trends_after_switch = env.db.get_trends("PF_004")
        alarms_after_switch = env.db.get_alarm_history("PF_004")
        events_after_switch = env.db.get_events("PF_004")

        ensure(changes_after_switch == [], "first packet of new patient should not inherit old patient Was-cache")
        ensure(len(trends_after_switch) == 1, "patient change should purge old dashboard trends")
        ensure(len(alarms_after_switch) == 0, "patient change should purge alarm history for the device")
        ensure(len(events_after_switch) == 0, "patient change should purge event history for the device")
        ensure(env.db.get_last_patient_id("PF_004") == "new-p", "device session should now point to the new patient")

        return ScenarioResult(
            name="Dashboard data resets cleanly on patient change",
            status="PASS",
            details=["old device history purged", "new patient starts with clean trend/event/alarm state"],
        )
    finally:
        env.cleanup()


async def scenario_dashboard_multi_device_isolation() -> ScenarioResult:
    env = DashboardEnv()
    try:
        start = local_time(2026, 4, 14, 19, 0, 0)
        env.feed(device_id="PF_003", patient_id="A", when=start, qb=150)
        env.feed(device_id="PF_007", patient_id="B", when=start, qb=160)
        env.feed(device_id="PF_003", patient_id="A", when=start + timedelta(minutes=1), qb=170)
        env.feed(device_id="PF_007", patient_id="B", when=start + timedelta(minutes=1), qb=180)
        env.feed(device_id="PF_003", patient_id="A2", when=start + timedelta(minutes=2), qb=200)

        trends_pf003 = env.db.get_trends("PF_003")
        trends_pf007 = env.db.get_trends("PF_007")
        ensure(len(trends_pf003) == 1, "patient change on PF_003 should reset only PF_003 history")
        ensure(len(trends_pf007) == 2, "PF_007 trend history should remain intact")
        ensure(env.db.get_last_patient_id("PF_007") == "B", "PF_007 patient session should be unaffected")

        return ScenarioResult(
            name="Dashboard histories stay isolated per device",
            status="PASS",
            details=["PF_003 reset did not purge PF_007", "trend isolation per device is intact"],
        )
    finally:
        env.cleanup()


async def scenario_dashboard_alarm_cache_reset() -> ScenarioResult:
    env = DashboardEnv()
    try:
        start = local_time(2026, 4, 14, 20, 0, 0)
        env.feed(
            device_id="PF_012",
            patient_id="alarm-old",
            when=start,
            alarms=[{"id": 777, "title": "Return Pressure High", "severity": "MED", "state": "PRESENT"}],
        )
        ensure(777 in env.alarm._active_alarms.get("PF_012", {}), "alarm cache should hold the active alarm")

        env.feed(device_id="PF_012", patient_id="alarm-new", when=start + timedelta(minutes=1), alarms=[])
        ensure("PF_012" not in env.alarm._active_alarms or not env.alarm._active_alarms["PF_012"],
               "patient change should clear in-memory alarm cache")
        ensure("PF_012" not in env.alarm._pending_clears or not env.alarm._pending_clears["PF_012"],
               "patient change should clear pending alarm clears")

        return ScenarioResult(
            name="Alarm cache resets with dashboard session reset",
            status="PASS",
            details=["active alarm cache cleared on patient change"],
        )
    finally:
        env.cleanup()


async def scenario_dashboard_trend_retention_cap() -> ScenarioResult:
    env = DashboardEnv()
    try:
        start = local_time(2026, 4, 14, 21, 0, 0)
        for idx in range(1105):
            env.feed(
                device_id="PF_020",
                patient_id="trend-cap",
                when=start + timedelta(seconds=idx * 10),
                pa=-80 + (idx % 5),
                pv=70 + (idx % 7),
                pbe=130 + (idx % 11),
                tmp=40 + (idx % 3),
            )
        for idx in range(50):
            env.feed(
                device_id="PF_021",
                patient_id="other-device",
                when=start + timedelta(seconds=idx * 10),
            )

        pf020_count = env.db.fetch_one("SELECT COUNT(*) FROM pressure_trends WHERE device_id = ?", ("PF_020",))[0]
        pf021_count = env.db.fetch_one("SELECT COUNT(*) FROM pressure_trends WHERE device_id = ?", ("PF_021",))[0]

        ensure(pf020_count == 1000, f"PF_020 should be capped at 1000 trend rows, got {pf020_count}")
        ensure(pf021_count == 50, f"PF_021 should keep its 50 trend rows, got {pf021_count}")

        return ScenarioResult(
            name="Dashboard trend retention caps each device deterministically",
            status="PASS",
            details=[f"PF_020 rows={pf020_count}", f"PF_021 rows={pf021_count}"],
        )
    finally:
        env.cleanup()


async def scenario_timestamp_unix_precedence_contract() -> ScenarioResult:
    packet = {
        "meta": {
            "device_id": "4",
            "timestamp": "2026-04-13 20:48:18 UTC",
            "timestamp_unix": 1776088770,
            "mode": "BACKFILL",
        },
        "s_header": {
            "machine_id": 4,
            "timestamp": "2026-04-13 20:48:18 UTC",
            "timestamp_unix": 1776088770,
        },
        "timestamp": "2026-04-13T20:48:18Z",
    }
    resolved = resolve_packet_time(packet)
    quality = apply_ingest_contract(packet)
    expected = parse_clinical_timestamp(1776088770).isoformat()

    ensure(resolved["packet_time"] == expected, "timestamp_unix must override string timestamps")
    ensure(packet["meta"]["timestamp"] == expected, "normalized packet should expose canonical packet time")
    ensure(packet["meta"]["timestamp_source"] == "meta.timestamp_unix", "timestamp source should be attributed to unix epoch")
    ensure(packet["meta"]["device_id"] == "PF_004", "device id should be canonicalized from numeric source")
    ensure(packet["meta"].get("original_device_id") == "4", "original device id should be preserved for forensics")
    ensure(quality["mode"] == "BACKFILL", "explicit BACKFILL mode from Mirth should be preserved")

    return ScenarioResult(
        name="Ingest contract prefers unix time and canonical device ids",
        status="PASS",
        details=[f"packet_time={expected}", f"mode={quality['mode']}", f"device_id={packet['meta']['device_id']}"],
    )


async def scenario_mode_hint_overrides_latency_inference() -> ScenarioResult:
    old_time = local_time(2026, 4, 10, 8, 0, 0)
    inferred_only = resolve_mode_and_quality(
        {"meta": {"timestamp": old_time.isoformat()}, "s_header": {"machine_id": 7}},
        now=local_time(2026, 4, 14, 8, 0, 0),
    )
    explicit_live = resolve_mode_and_quality(
        {"meta": {"timestamp": old_time.isoformat(), "mode": "LIVE"}, "s_header": {"machine_id": 7}},
        now=local_time(2026, 4, 14, 8, 0, 0),
    )

    ensure(inferred_only["mode"] == "BACKFILL", "old packet without hint should infer BACKFILL")
    ensure(explicit_live["mode"] == "LIVE", "explicit LIVE mode should override latency inference")
    ensure(explicit_live["quality_source"] == "meta.mode", "mode source should document explicit Mirth mode")

    return ScenarioResult(
        name="Explicit Mirth mode overrides latency-only classification",
        status="PASS",
        details=[f"inferred={inferred_only['mode']}", f"explicit={explicit_live['mode']}"],
    )


async def scenario_device_id_normalization_contract() -> ScenarioResult:
    values = [
        normalize_device_id("4"),
        normalize_device_id("PF_004"),
        normalize_device_id("pf-4"),
        normalize_device_id(None, 4),
    ]
    ensure(all(value == "PF_004" for value in values), f"device id variants should normalize, got {values}")

    return ScenarioResult(
        name="Device identity normalizes across numeric and PF-prefixed forms",
        status="PASS",
        details=[", ".join(values)],
    )


SCENARIOS = [
    scenario_end_then_same_patient_runtime_continues,
    scenario_live_gap_keeps_same_treatment,
    scenario_restart_recovery,
    scenario_multi_device_isolation,
    scenario_patient_change_waits_for_start,
    scenario_backfill_live_promote,
    scenario_backfill_live_fresh_start,
    scenario_same_patient_runtime_zero_starts_new_treatment,
    scenario_hourly_and_oc_snapshots,
    scenario_missing_hour_becomes_gap,
    scenario_ghost_discard,
    scenario_auto_close_stale_live_session,
    scenario_dashboard_patient_change_purges_history,
    scenario_dashboard_multi_device_isolation,
    scenario_dashboard_alarm_cache_reset,
    scenario_dashboard_trend_retention_cap,
    scenario_timestamp_unix_precedence_contract,
    scenario_mode_hint_overrides_latency_inference,
    scenario_device_id_normalization_contract,
]


def format_report(results: List[ScenarioResult]) -> str:
    total = len(results)
    passed = sum(1 for item in results if item.status == "PASS")
    failed = sum(1 for item in results if item.status == "FAIL")
    warned = sum(1 for item in results if item.warnings)

    lines = [
        "Lifecycle Sandbox Report",
        "=" * 72,
        f"Generated: {datetime.now(TZ).isoformat()}",
        f"Scenarios: {total} | PASS: {passed} | FAIL: {failed} | WARN: {warned}",
        "",
    ]

    for index, result in enumerate(results, 1):
        lines.append(f"{index:02d}. [{result.status}] {result.name}")
        for detail in result.details:
            lines.append(f"    - {detail}")
        for warning in result.warnings:
            lines.append(f"    ! {warning}")
        lines.append("")

    lines.append("Operational Notes")
    lines.append("-" * 72)
    lines.append("- The sandbox now covers recorder/raw/snapshot plus backend trend/event/alarm behavior; it still does not render the React UI.")
    lines.append("- LIVE/BACKFILL are now validated both by scenario intent and by the shared ingest contract that honors Mirth mode hints before latency fallback.")
    lines.append("- Post-END idle packets and non-start patient-change packets are intentionally dropped from raw; a later same-patient RUN may still resume the treatment if counters continue.")
    lines.append("- H00 is now frozen at the first packet baseline; later H rows remain hourly boundary snapshots.")
    lines.append("- Canonical device ids and timestamp_unix precedence now protect Dashboard/Snap/Raw from split identities and fake-UTC drift.")
    lines.append("- Trend retention is now deterministic per device in the DB layer; random global maintenance in main.py still helps prune events/alarms.")
    return "\n".join(lines)


async def main() -> int:
    results: List[ScenarioResult] = []
    for scenario in SCENARIOS:
        try:
            result = await scenario()
        except Exception as exc:
            result = ScenarioResult(
                name=scenario.__name__,
                status="FAIL",
                details=[f"{type(exc).__name__}: {exc}"],
            )
        results.append(result)

    report = format_report(results)
    print(report)

    reports_dir = os.path.join(BACKEND_DIR, "tools", "_sandbox_reports")
    os.makedirs(reports_dir, exist_ok=True)
    report_path = os.path.join(reports_dir, "lifecycle_sandbox_report.txt")
    with open(report_path, "w", encoding="utf-8") as handle:
        handle.write(report + "\n")
    print(f"\nSaved report: {report_path}")

    return 1 if any(item.status == "FAIL" for item in results) else 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
