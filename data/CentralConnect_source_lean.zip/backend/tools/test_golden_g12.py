"""
Golden Replay Test — g12 treatment
====================================
Feeds g12's packets from May4_data.ndjson through HistoricalBackfillImporter
with a mock DB, asserts exact snapshot output.

Run: python backend/tools/test_golden_g12.py
"""
import json
import sys
import os
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from services.treatment.historical_backfill_importer import HistoricalBackfillImporter

DATA_FILE = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'done', 'May4_data.ndjson')
TZ = timezone(timedelta(hours=7))

def parse_time(unix_ts):
    return datetime.fromtimestamp(unix_ts, tz=TZ)

def load_g12_packets():
    packets = []
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            d = json.loads(line.strip())
            hdr = d.get('s_header', d.get('header', {}))
            if hdr.get('patient_id') != 'g12':
                continue
            meta = d.get('meta', {})
            body = d.get('s_body', d.get('body', {}))
            ts_unix = meta.get('timestamp_unix', hdr.get('timestamp_unix', 0))
            if ts_unix:
                packets.append({
                    'pkt_time': parse_time(ts_unix),
                    'body': body,
                })
    return sorted(packets, key=lambda p: p['pkt_time'])

def main():
    print("=" * 80)
    print("  Golden Replay Test -- g12")
    print("=" * 80)
    
    packets = load_g12_packets()
    print(f"  Loaded {len(packets)} packets")
    assert len(packets) > 4000, f"Expected ~4281 packets, got {len(packets)}"
    
    # Mock DB — capture all upsert calls
    mock_db = MagicMock()
    saved_snapshots = []
    
    def capture_upsert(**kwargs):
        saved_snapshots.append(dict(kwargs))
    
    mock_db.upsert_snapshot = MagicMock(side_effect=capture_upsert)
    
    # Run importer
    importer = HistoricalBackfillImporter(mock_db)
    treatment_id = "golden-g12-test"
    device_id = "PF_004"
    treatment_start = packets[0]['pkt_time']
    
    for pkt in packets:
        importer.process_packet(
            treatment_id, device_id,
            pkt['pkt_time'], treatment_start,
            pkt['body']
        )
    
    # Final flush
    importer.flush_device(device_id)
    
    # Print results
    print(f"\n  Snapshots saved: {len(saved_snapshots)}")
    print(f"  {'LABEL':<8} {'TIME':<22} {'SRC':<12} {'QB':>5} {'QD':>5} {'QS':>5} {'QPBP':>5} {'UF_TOT':>7}")
    print("-" * 80)
    
    for s in saved_snapshots:
        auto = s.get('auto_data', {})
        label = s.get('hour_label', '?')
        snap_time = s.get('snapshot_time', '?')
        source = s.get('source', '?')
        uf = auto.get('uf_total', '')
        if isinstance(uf, float):
            uf = f"{uf:.0f}"
        print(f"  {label:<8} {str(snap_time)[:22]:<22} {source:<12} "
              f"{auto.get('qb',''):>5} {auto.get('qd',''):>5} {auto.get('qs',''):>5} "
              f"{auto.get('qpbp',''):>5} {uf:>7}")
    
    # === ASSERTIONS ===
    errors = []
    
    # 1. Count assertions
    h_snaps = [s for s in saved_snapshots if s['hour_label'].startswith('H')]
    oc_snaps = [s for s in saved_snapshots if s['hour_label'].startswith('OC')]
    gap_snaps = [s for s in saved_snapshots if s.get('source') == 'BACKFILL_GAP']
    
    if len(gap_snaps) > 0:
        errors.append(f"FAIL: Expected 0 GAP snapshots, got {len(gap_snaps)}")
    
    if len(oc_snaps) < 2:
        errors.append(f"FAIL: Expected >= 2 OC snapshots (QD changes), got {len(oc_snaps)}")
    
    # 2. H00 should NOT equal H01 (H00 must be frozen baseline)
    h00 = next((s for s in saved_snapshots if s['hour_label'] == 'H00'), None)
    h01 = next((s for s in saved_snapshots if s['hour_label'] == 'H01'), None)
    if h00 and h01:
        h00_uf = h00['auto_data'].get('uf_total', 0)
        h01_uf = h01['auto_data'].get('uf_total', 0)
        if abs(h00_uf - h01_uf) < 1:
            errors.append(f"FAIL: H00 uf_total ({h00_uf}) == H01 uf_total ({h01_uf}) -- H00 not frozen!")
    
    # 3. OC snapshot must have NEW values (not stale)
    if oc_snaps:
        oc1 = oc_snaps[0]
        oc1_qd = oc1['auto_data'].get('qd', 0)
        if abs(oc1_qd - 1000) < 1:
            errors.append(f"FAIL: OC_01 has stale QD=1000 (should be 800)")
        if abs(oc1_qd - 800) < 1:
            pass  # Correct
    
    # 4. H00 baseline values
    if h00:
        h00_qb = h00['auto_data'].get('qb', 0)
        h00_qd = h00['auto_data'].get('qd', 0)
        if abs(h00_qb - 160) >= 1:
            errors.append(f"FAIL: H00 QB should be 160, got {h00_qb}")
        if abs(h00_qd - 1000) >= 1:
            errors.append(f"FAIL: H00 QD should be 1000, got {h00_qd}")
    
    # 5. H snapshots should be chronological (OC can interleave)
    h_only = [s for s in saved_snapshots if s['hour_label'].startswith('H')]
    for i in range(1, len(h_only)):
        t_prev = h_only[i-1].get('snapshot_time', '')
        t_curr = h_only[i].get('snapshot_time', '')
        if t_prev > t_curr:
            errors.append(f"FAIL: H non-chronological: {h_only[i-1]['hour_label']}({t_prev}) > {h_only[i]['hour_label']}({t_curr})")
    
    # Report
    print("\n" + "=" * 80)
    if errors:
        print(f"  FAILED: {len(errors)} assertions failed:")
        for e in errors:
            print(f"    {e}")
        sys.exit(1)
    else:
        print("  ALL ASSERTIONS PASSED")
        print(f"  H: {len(h_snaps)} | OC: {len(oc_snaps)} | GAP: {len(gap_snaps)}")
        sys.exit(0)

if __name__ == '__main__':
    main()
