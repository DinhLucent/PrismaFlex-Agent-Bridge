"""
Analyze continuity risks inside a folder of decoded PrismaFlex packets.

This is intended for forensic analysis of historical decoded raw files
(`decoded_*.json` / `decoded_*.json.gz`) before or after BACKFILL import.

It focuses on the user-agreed continuity rule:
    same device + same patient + RUN_TIME > 0  => likely same treatment

The script scans the folder in filename order, groups consecutive END packets
into "END episodes", and checks whether a later START packet (status 4/5)
reappears with a non-zero RUN_TIME. Those episodes are the strongest signals
for "this should have resumed instead of splitting into a new treatment".

Examples:
    python -m tools.analyze_decoded_folder_continuity --dir "D:\\Block\\DecodedData\\done"
    python analyze_decoded_folder_continuity.py --dir ".\\tools\\done" --report continuity.txt
"""

from __future__ import annotations

import argparse
import gzip
import json
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional


START_STATUSES = {4, 5}  # WAITINGSTART, RUN
END_STATUS = 8
RUN_TIME_PID = 461


@dataclass
class PacketBrief:
    idx: int
    file: str
    time: Optional[str]
    machine_id: str
    patient_id: str
    status: Optional[int]
    runtime: Optional[float]


@dataclass
class EndEpisode:
    start_idx: int
    end_idx: int
    count: int
    start_packet: PacketBrief
    end_packet: PacketBrief
    prev_runtime: Optional[float]
    next_non_end: Optional[PacketBrief]
    next_start: Optional[PacketBrief]
    next_start_packets_later: Optional[int]

    @property
    def suspicious_resume(self) -> bool:
        if not self.next_start:
            return False
        if self.next_start.patient_id != self.end_packet.patient_id:
            return False
        if self.next_start.machine_id != self.end_packet.machine_id:
            return False
        return self.next_start.runtime is not None and self.next_start.runtime > 0


def iter_decoded_files(root: Path) -> Iterable[Path]:
    patterns = ("decoded_*.json", "decoded_*.json.gz")
    seen: list[Path] = []
    for pattern in patterns:
        seen.extend(root.glob(pattern))
    for path in sorted(seen):
        if path.is_file():
            yield path


def load_packet(path: Path) -> dict:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as fh:
        return json.load(fh)


def extract_runtime(packet: dict) -> Optional[float]:
    params = packet.get("s_body", {}).get("parameters", [])
    for item in params:
        if item.get("id") == RUN_TIME_PID:
            try:
                return float(item.get("value"))
            except (TypeError, ValueError):
                return None
    return None


def load_briefs(root: Path) -> list[PacketBrief]:
    packets: list[PacketBrief] = []
    for idx, path in enumerate(iter_decoded_files(root), 1):
        packet = load_packet(path)
        header = packet.get("s_header", {})
        packets.append(
            PacketBrief(
                idx=idx,
                file=path.name,
                time=header.get("timestamp"),
                machine_id=str(header.get("machine_id")),
                patient_id=str(header.get("patient_id")),
                status=header.get("therapy_status_id"),
                runtime=extract_runtime(packet),
            )
        )
    return packets


def find_end_episodes(packets: list[PacketBrief], search_window: int) -> list[EndEpisode]:
    episodes: list[EndEpisode] = []
    i = 0
    while i < len(packets):
        if packets[i].status != END_STATUS:
            i += 1
            continue

        j = i
        while j + 1 < len(packets) and packets[j + 1].status == END_STATUS:
            j += 1

        prev_runtime = None
        for k in range(i - 1, -1, -1):
            if packets[k].runtime is not None:
                prev_runtime = packets[k].runtime
                break

        next_non_end = packets[j + 1] if j + 1 < len(packets) else None

        next_start = None
        next_start_packets_later = None
        upper = min(len(packets), j + 1 + search_window)
        for k in range(j + 1, upper):
            pkt = packets[k]
            if pkt.status in START_STATUSES:
                next_start = pkt
                next_start_packets_later = k - j
                break

        episodes.append(
            EndEpisode(
                start_idx=i + 1,
                end_idx=j + 1,
                count=(j - i + 1),
                start_packet=packets[i],
                end_packet=packets[j],
                prev_runtime=prev_runtime,
                next_non_end=next_non_end,
                next_start=next_start,
                next_start_packets_later=next_start_packets_later,
            )
        )
        i = j + 1

    return episodes


def fmt_runtime(value: Optional[float]) -> str:
    if value is None:
        return "None"
    if float(value).is_integer():
        return str(int(value))
    return f"{value:.2f}"


def packet_line(label: str, pkt: Optional[PacketBrief]) -> str:
    if not pkt:
        return f"{label}: None"
    return (
        f"{label}: idx={pkt.idx} time={pkt.time} status={pkt.status} "
        f"runtime={fmt_runtime(pkt.runtime)} patient={pkt.patient_id} file={pkt.file}"
    )


def build_report(root: Path, packets: list[PacketBrief], episodes: list[EndEpisode], search_window: int) -> str:
    lines: list[str] = []
    status_counts = Counter(pkt.status for pkt in packets)
    device_counts = Counter(pkt.machine_id for pkt in packets)
    patient_counts = Counter(pkt.patient_id for pkt in packets)
    runtime_packets = sum(1 for pkt in packets if pkt.runtime is not None)

    lines.append("=" * 68)
    lines.append("DECODED FOLDER CONTINUITY REPORT")
    lines.append("=" * 68)
    lines.append(f"folder: {root}")
    lines.append(f"packets: {len(packets)}")
    lines.append(f"search_window_packets: {search_window}")
    lines.append("")

    if packets:
        lines.append("Global Summary")
        lines.append(f"- first packet: {packets[0].time}  file={packets[0].file}")
        lines.append(f"- last packet : {packets[-1].time}  file={packets[-1].file}")
        lines.append(f"- devices     : {dict(device_counts)}")
        lines.append(f"- patients    : {dict(patient_counts)}")
        lines.append(f"- status cnt  : {dict(status_counts)}")
        lines.append(f"- RUN_TIME pid {RUN_TIME_PID} present in {runtime_packets}/{len(packets)} packets")
        lines.append("")

    suspicious = [ep for ep in episodes if ep.suspicious_resume]
    lines.append(f"END episodes: {len(episodes)}")
    lines.append(f"suspicious resume episodes: {len(suspicious)}")
    lines.append("")

    for n, ep in enumerate(episodes, 1):
        lines.append(f"[EP#{n:02d}] END x{ep.count}  idx={ep.start_idx}..{ep.end_idx}")
        lines.append(f"- end time range : {ep.start_packet.time} -> {ep.end_packet.time}")
        lines.append(f"- prev runtime   : {fmt_runtime(ep.prev_runtime)}")
        lines.append(packet_line("- next non-END", ep.next_non_end))
        lines.append(packet_line("- next START  ", ep.next_start))
        if ep.next_start_packets_later is not None:
            lines.append(f"- next START packets later: {ep.next_start_packets_later}")
        else:
            lines.append("- next START packets later: None within search window")

        if ep.suspicious_resume:
            lines.append(
                "- diagnosis: LIKELY_SPLIT_BUG "
                "(same device/patient, START returns with RUN_TIME > 0)"
            )
        elif ep.next_start and ep.next_start.runtime == 0:
            lines.append(
                "- diagnosis: CLEAN_RESTART_CANDIDATE "
                "(START returns with RUN_TIME = 0)"
            )
        elif ep.next_start and ep.next_start.runtime is None:
            lines.append(
                "- diagnosis: AMBIGUOUS_START_NO_RUNTIME "
                "(START returns but opening packet has no RUN_TIME)"
            )
        elif ep.next_non_end and ep.next_non_end.status == 0 and ep.next_non_end.runtime is not None:
            lines.append(
                "- diagnosis: END_WITH_RUNTIME_STILL_PRESENT "
                "(machine kept emitting packets after END with same RUN_TIME)"
            )
        else:
            lines.append("- diagnosis: NO_RESTART_FOUND_IN_WINDOW")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Analyze continuity risks in decoded raw folder")
    parser.add_argument("--dir", required=True, help="Directory containing decoded_*.json or decoded_*.json.gz")
    parser.add_argument(
        "--window",
        type=int,
        default=300,
        help="How many packets after an END episode to search for the next START packet",
    )
    parser.add_argument(
        "--report",
        help="Optional output report path. If omitted, prints to stdout only.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.dir).resolve()
    if not root.exists() or not root.is_dir():
        raise SystemExit(f"Folder does not exist: {root}")

    packets = load_briefs(root)
    episodes = find_end_episodes(packets, search_window=args.window)
    report = build_report(root, packets, episodes, search_window=args.window)

    if args.report:
        report_path = Path(args.report).resolve()
        report_path.write_text(report, encoding="utf-8")
        print(report)
        print(f"\nReport saved to: {report_path}")
    else:
        print(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
