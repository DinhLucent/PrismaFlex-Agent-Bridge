# 🔧 PrismaFlex Developer Tools

Bộ công cụ phát triển cho hệ thống PrismaFlex — phục vụ phân tích data, debug, và phát triển thuật toán.

## Quick Start

Chạy từ thư mục `backend/`:

```bash
# Xem tất cả treatments
python -m tools.analyze_treatment --all

# Phân tích chi tiết 1 treatment
python -m tools.analyze_treatment 00070fca

# Kiểm tra DB
python -m tools.inspect_db tables
python -m tools.inspect_db snapshots 00070fca
python -m tools.inspect_db sql "SELECT COUNT(*) FROM treatments"

# Phát lại raw data qua pipeline
python -m tools.replay_raw 00070fca --dry-run

# Kiểm tra sức khỏe hệ thống
python -m tools.health_check
python -m tools.health_check --quick
```

## Tools

### 1. `analyze_treatment.py` — Phân tích Treatment
- Liệt kê treatments với thông tin cơ bản
- Phân tích chi tiết: snapshot timeline, OC validation, raw data stats
- Highlight thay đổi tham số bằng màu sắc
- Interactive mode (chọn treatment từ danh sách)

### 2. `inspect_db.py` — Tra cứu Database
- Liệt kê tables + row count
- Xem nhanh treatments, snapshots
- Chạy SQL tự do
- Export ra CSV
- Mode interactive (gõ lệnh liên tục)

### 3. `replay_raw.py` — Phát lại Raw Data
- Đọc `.jsonl` và `.jsonl.gz`
- Phân tích PID frequency + unique values
- Track parameter changes (non-volatile)
- Mô phỏng OC triggers với anti-flicker + cooldown
- Hiển thị hourly snapshot boundaries

### 3b. `simulate_ingest.py` — Giả lập LIVE / BACKFILL / CUTOVER
- Nhận file raw cũ dạng `packet_num + s_header + s_body`
- Normalize thành payload giống Mirth/backend ingest
- Chạy ở 3 mode:
  - `LIVE`
  - `BACKFILL`
  - `CUTOVER` (backfill xong rồi live tiếp)
- Hỗ trợ:
  - `route-style split` cho backend mới
  - `route-style legacy` cho backend cũ
  - `sort-by-time` để tách lỗi thuật toán khỏi lỗi input ordering
- Dùng để kiểm continuity của:
  - `treatment_id`
  - `Hxx`
  - `OC_XX`
  - `raw_packet_manifest`

### 4. `health_check.py` — Kiểm tra Hệ thống
- SQLite integrity check
- Kiểm tra schema (tables, indexes, columns)
- Phát hiện orphaned records
- Cross-reference raw files vs DB
- Kiểm tra service ports (backend 8000, frontend 3000)

### 5. `helpers.py` — Shared Utilities
Module dùng chung: PID maps, DB access, terminal colors, formatters.
Import vào scripts khác:
```python
from tools.helpers import get_treatment_db, pid_name, C, fmt_time
```

## Khi nào dùng tool nào?

| Tình huống | Tool |
|------------|------|
| Debug OC snapshot bất thường | `analyze_treatment` + `replay_raw` |
| Kiểm tra DB sau update | `health_check` + `inspect_db` |
| Test thuật toán mới | `replay_raw --dry-run` |
| Export data cho báo cáo | `inspect_db export` |
| Tìm treatment cụ thể | `inspect_db treatments` |
