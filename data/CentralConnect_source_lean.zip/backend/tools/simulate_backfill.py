"""
Standalone Backfill Simulation v2 — matches historical_backfill_importer.py
============================================================================
Reads May4_data.ndjson, simulates ALL fixes:
- H00 early snap at packet 10, frozen (no re-flush)
- Hourly gap fill for missing hours
- OC detection with bounce fix (A->B->A where A!=B)
- OC detection runs BEFORE value extraction
- Last-snapshot dedup (compare against H or OC)
"""
import json
import sys
from datetime import datetime, timezone, timedelta
from collections import defaultdict

DATA_FILE = r"d:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\data\done\May4_data.ndjson"
TZ = timezone(timedelta(hours=7))

PID_MAP = {
    17: 'qb', 18: 'qs_pre', 19: 'qs_post', 21: 'qd', 22: 'qpbp',
    1: 'pa', 4: 'pv', 2: 'pbe', 6: 'tmp',
    100: 'uf_total', 24: 'uf_hourly', 23: 'effluent_flow',
    461: 'run_time_sec', 60: 'blood_vol', 38: 'heparin_rate',
    26: 'pt_weight', 25: 'uf_rate_target',
}
OC_PIDS = {17, 21, 22, 25}
OC_PID_COLS = {17: 'qb', 21: 'qd', 22: 'qpbp', 25: 'uf_rate_target'}
STABILIZE = 3
SCALE_MAP = {38: 0.1}

def parse_time(unix_ts):
    return datetime.fromtimestamp(unix_ts, tz=TZ)

def build_auto_data(vals):
    auto = {}
    for col in ['qb', 'qd', 'qpbp', 'pa', 'pv', 'pbe', 'tmp',
                 'uf_total', 'uf_hourly', 'effluent_flow',
                 'run_time_sec', 'blood_vol', 'heparin_rate',
                 'pt_weight', 'uf_rate_target']:
        if col in vals:
            auto[col] = vals[col]
    qs = vals.get('qs_pre', 0) + vals.get('qs_post', 0)
    if qs:
        auto['qs'] = qs
    return auto

def main():
    target_patient = sys.argv[1] if len(sys.argv) > 1 else 'g12'
    
    print("=" * 100)
    print(f"  Backfill Simulation v2 -- target: {target_patient}")
    print("=" * 100)
    
    # Read packets
    packets = []
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        for i, line in enumerate(f):
            try:
                d = json.loads(line.strip())
            except json.JSONDecodeError:
                continue
            meta = d.get('meta', {})
            header = d.get('s_header', d.get('header', {}))
            body = d.get('s_body', d.get('body', {}))
            device_id = str(meta.get('device_id', header.get('machine_id', 'UNK')))
            patient_id = header.get('patient_id', 'N/A')
            ts_unix = meta.get('timestamp_unix', header.get('timestamp_unix', 0))
            if ts_unix:
                packets.append({
                    'device_id': device_id, 'patient_id': patient_id,
                    'pkt_time': parse_time(ts_unix), 'body': body,
                })
    
    print(f"  Total packets: {len(packets)}")
    
    # Group by patient
    groups = defaultdict(list)
    for p in packets:
        groups[(p['device_id'], p['patient_id'])].append(p)
    
    print(f"  Groups:")
    for (dev, pat), plist in sorted(groups.items(), key=lambda x: -len(x[1])):
        times = [p['pkt_time'] for p in plist]
        marker = " <-- TARGET" if pat == target_patient else ""
        print(f"    {dev}/{pat}: {len(plist)} pkts, "
              f"{min(times).strftime('%m/%d %H:%M')} -> {max(times).strftime('%m/%d %H:%M')}{marker}")
    
    target_key = None
    for key in groups:
        if key[1] == target_patient:
            target_key = key
            break
    if not target_key:
        print(f"ERROR: patient '{target_patient}' not found!")
        sys.exit(1)
    
    target_packets = sorted(groups[target_key], key=lambda p: p['pkt_time'])
    dev_id, pat_id = target_key
    print(f"\n  Simulating: {dev_id}/{pat_id} ({len(target_packets)} packets)")
    
    # ====== SIMULATION ======
    treatment_start = target_packets[0]['pkt_time']
    cache_values = {}
    snapshots = []
    oc_counter = 0
    pkt_count = 0
    h00_flushed = False
    current_hour = 0
    
    # OC state (matches importer exactly)
    last_snap_vals = {}   # {col: val} from last written snapshot
    oc_candidates = {}    # {pid: (val, streak)}
    oc_history = {}       # {pid: [prev2, prev1]}
    
    def save_snapshot(label, slot, snap_time, auto_data, source='DATA'):
        snapshots.append({
            'label': label, 'slot': slot, 'time': snap_time,
            'auto_data': dict(auto_data), 'source': source
        })
        # Sync last-snap for OC dedup
        for col in ('qb', 'qd', 'qpbp', 'uf_rate_target'):
            if col in auto_data:
                last_snap_vals[col] = auto_data[col]
    
    def detect_oc(pkt_time, body):
        nonlocal oc_counter
        confirmed = []
        for p in body.get('parameters', []):
            pid = p.get('id')
            if pid not in OC_PIDS:
                continue
            raw = p.get('value')
            if raw is None:
                continue
            try:
                new_val = float(raw)
            except (ValueError, TypeError):
                continue
            
            col = OC_PID_COLS[pid]
            baseline = last_snap_vals.get(col)
            
            # First time -> set baseline
            if baseline is None:
                last_snap_vals[col] = new_val
                oc_history[pid] = [new_val]
                continue
            
            # Same as baseline -> reset candidate
            if abs(new_val - baseline) < 1:
                oc_candidates.pop(pid, None)
                h = oc_history.get(pid, [])
                h.append(new_val)
                oc_history[pid] = h[-2:]
                continue
            
            # Bounce: A->B->A (A != B)
            h = oc_history.get(pid, [])
            if len(h) >= 2:
                prev_prev = h[-2]
                prev = h[-1]
                if abs(new_val - prev_prev) < 1 and abs(prev - new_val) >= 1:
                    h.append(new_val)
                    oc_history[pid] = h[-2:]
                    oc_candidates.pop(pid, None)
                    continue
            
            # Track candidate
            cand = oc_candidates.get(pid)
            if cand and abs(new_val - cand[0]) < 1:
                oc_candidates[pid] = (cand[0], cand[1] + 1)
            else:
                oc_candidates[pid] = (new_val, 1)
            
            h.append(new_val)
            oc_history[pid] = h[-2:]
            
            # Stabilized?
            if oc_candidates[pid][1] >= STABILIZE:
                confirmed.append((pid, col, baseline, new_val))
                oc_candidates.pop(pid, None)
        
        if confirmed:
            oc_counter += 1
            label = f"OC_{oc_counter:02d}"
            auto = build_auto_data(cache_values)
            reasons = [f"{col}:{old}->{new}" for _, col, old, new in confirmed]
            auto['_reason'] = ', '.join(reasons)
            save_snapshot(label, None, pkt_time, auto, 'OC')
            for pid, col, old, new in confirmed:
                last_snap_vals[col] = new
    
    for pkt in target_packets:
        pkt_time = pkt['pkt_time']
        body = pkt['body']
        elapsed = (pkt_time - treatment_start).total_seconds()
        hour_num = max(0, int(elapsed / 3600))
        
        # 1. OC detection FIRST (before extract)
        detect_oc(pkt_time, body)
        
        # 2. Extract values
        for p in body.get('parameters', []):
            pid = p.get('id')
            val = p.get('value')
            if pid is not None and val is not None and pid in PID_MAP:
                scaled = float(val)
                if pid in SCALE_MAP:
                    scaled *= SCALE_MAP[pid]
                cache_values[PID_MAP[pid]] = scaled
        pkt_count += 1
        
        # 3. Hour transition
        if hour_num != current_hour and pkt_count > 1:
            prev_hour = current_hour
            
            # Skip H00 re-flush if already early-snapped
            if not (prev_hour == 0 and h00_flushed):
                auto = build_auto_data(cache_values)
                if auto:
                    save_snapshot(f"H{prev_hour:02d}", prev_hour, pkt_time, auto)
            
            # GAP FILL
            if hour_num > prev_hour + 1:
                gap_auto = build_auto_data(cache_values)
                for gap_h in range(prev_hour + 1, hour_num):
                    gap_time = treatment_start + timedelta(hours=gap_h)
                    if gap_auto:
                        save_snapshot(f"H{gap_h:02d}", gap_h, gap_time, dict(gap_auto), 'GAP')
            
            current_hour = hour_num
        
        # 4. H00 early snap
        if hour_num == 0 and not h00_flushed and pkt_count >= 10:
            auto = build_auto_data(cache_values)
            if auto:
                save_snapshot("H00", 0, pkt_time, auto, 'EARLY')
                h00_flushed = True
    
    # Final flush
    auto = build_auto_data(cache_values)
    if auto:
        save_snapshot(f"H{current_hour:02d}", current_hour, target_packets[-1]['pkt_time'], auto)
    
    # Print results
    print(f"\n{'='*130}")
    print(f"  SNAPSHOT TABLE -- {dev_id}/{pat_id} | Start: {treatment_start.strftime('%m/%d %H:%M:%S')}")
    print(f"{'='*130}")
    print(f"{'LABEL':<8} {'TIME':<20} {'SRC':<7} {'QB':>5} {'QD':>5} {'QS':>5} {'QPBP':>5} "
          f"{'UF_TOT':>7} {'UF_HR':>6} {'PA':>5} {'PV':>5} {'PBE':>5} {'TMP':>5}  REASON")
    print("-" * 130)
    
    for s in snapshots:
        a = s['auto_data']
        reason = a.pop('_reason', '')
        uf_t = a.get('uf_total', '')
        if isinstance(uf_t, float): uf_t = f"{uf_t:.0f}"
        print(f"{s['label']:<8} {s['time'].strftime('%m/%d %H:%M:%S'):<20} {s['source']:<7} "
              f"{a.get('qb',''):>5} {a.get('qd',''):>5} {a.get('qs',''):>5} "
              f"{a.get('qpbp',''):>5} {uf_t:>7} {a.get('uf_hourly',''):>6} "
              f"{a.get('pa',''):>5} {a.get('pv',''):>5} {a.get('pbe',''):>5} "
              f"{a.get('tmp',''):>5}  {reason}")
    
    h_count = sum(1 for s in snapshots if s['source'] not in ('OC',))
    oc_count = sum(1 for s in snapshots if s['source'] == 'OC')
    gap_count = sum(1 for s in snapshots if s['source'] == 'GAP')
    print(f"\n  Total: {len(snapshots)} snapshots | H: {h_count} | OC: {oc_count} | GAP: {gap_count}")

if __name__ == '__main__':
    main()
