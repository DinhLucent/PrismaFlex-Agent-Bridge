"""
PrismaFlex Database Schema Verifier
====================================
So sanh SQLAlchemy models voi Postgres thuc te.
Phat hien: cot thieu, cot thua, kieu sai, constraint thieu.

Cach dung:
    python -m tools.verify_schema           # Kiem tra va bao cao
    python -m tools.verify_schema --fix     # Tu dong sua loi
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import inspect, text, create_engine
from config import Settings

# Import all models to register with Base.metadata
from db.postgres.base import Base
from db.postgres.models import (
    Treatment, TreatmentPhase, TreatmentStatusEvent,
    TreatmentJournalRow, TreatmentConfig,
    SnapshotOriginal, TreatmentReviewState, TreatmentNote,
    SnapshotAuditLog, TreatmentListProjection, RawPacketManifest,
)
# Optional models that may not exist in all versions
try:
    from db.postgres.models import TreatmentProjectionCheckpoint
except ImportError:
    TreatmentProjectionCheckpoint = None
try:
    from db.postgres.models import DeviceState
except ImportError:
    DeviceState = None


def get_engine():
    settings = Settings()
    return create_engine(settings.POSTGRES_URL)


def check_schema(engine, fix=False):
    """Compare SQLAlchemy models with actual Postgres schema."""
    inspector = inspect(engine)
    actual_tables = set(inspector.get_table_names())

    # Get all model tables
    model_tables = {}
    for table in Base.metadata.sorted_tables:
        model_tables[table.name] = table

    print(f"\n{'=' * 70}")
    print(f"  PrismaFlex Database Schema Verification")
    print(f"  DB: {engine.url}")
    print(f"{'=' * 70}\n")

    total_issues = 0
    fixes_applied = 0

    # 1. Check missing tables
    print(f"  1. KIEM TRA BANG")
    print(f"  {'_' * 60}")
    for table_name in sorted(model_tables.keys()):
        if table_name in actual_tables:
            print(f"   OK  {table_name}")
        else:
            print(f"   LOI {table_name} (THIEU - chua tao)")
            total_issues += 1
            if fix:
                try:
                    model_tables[table_name].create(engine)
                    print(f"       -> Da tao bang {table_name}")
                    fixes_applied += 1
                except Exception as e:
                    print(f"       -> LOI tao bang: {e}")

    extra_tables = actual_tables - set(model_tables.keys()) - {'alembic_version'}
    for t in sorted(extra_tables):
        print(f"   ??  {t} (co trong DB nhung khong co model)")

    # 2. Check columns per table
    print(f"\n  2. KIEM TRA COT")
    print(f"  {'_' * 60}")

    for table_name, model_table in sorted(model_tables.items()):
        if table_name not in actual_tables:
            continue  # Already reported as missing

        actual_cols = {c['name']: c for c in inspector.get_columns(table_name)}
        model_cols = {c.name: c for c in model_table.columns}

        missing_cols = []
        extra_cols = []
        type_mismatches = []

        for col_name, col_obj in model_cols.items():
            if col_name not in actual_cols:
                missing_cols.append((col_name, col_obj))
            # Basic type check could be added here

        for col_name in actual_cols:
            if col_name not in model_cols:
                extra_cols.append(col_name)

        if missing_cols or extra_cols:
            print(f"\n   {table_name}:")
            for col_name, col_obj in missing_cols:
                col_type = str(col_obj.type)
                nullable = "NULL" if col_obj.nullable else "NOT NULL"
                pk = " PK" if col_obj.primary_key else ""
                fk = ""
                for fk_obj in col_obj.foreign_keys:
                    fk = f" FK->{fk_obj.target_fullname}"
                print(f"     THIEU COT: {col_name} ({col_type} {nullable}{pk}{fk})")
                total_issues += 1

                if fix:
                    try:
                        # Build ALTER TABLE ADD COLUMN
                        type_str = col_obj.type.compile(dialect=engine.dialect)
                        null_str = "" if col_obj.nullable else " NOT NULL"
                        default_str = ""
                        if col_obj.server_default is not None:
                            default_str = f" DEFAULT {col_obj.server_default.arg}"

                        sql = f'ALTER TABLE {table_name} ADD COLUMN "{col_name}" {type_str}{null_str}{default_str}'

                        with engine.begin() as conn:
                            conn.execute(text(sql))
                        print(f"     -> Da them cot {col_name}")
                        fixes_applied += 1
                    except Exception as e:
                        print(f"     -> LOI them cot: {e}")

            for col_name in extra_cols:
                print(f"     COT THUA: {col_name} (co trong DB, khong co model)")

    # 3. Check primary keys
    print(f"\n  3. KIEM TRA PRIMARY KEY")
    print(f"  {'_' * 60}")

    for table_name, model_table in sorted(model_tables.items()):
        if table_name not in actual_tables:
            continue

        actual_pk = inspector.get_pk_constraint(table_name)
        actual_pk_cols = set(actual_pk.get('constrained_columns', []))
        model_pk_cols = {c.name for c in model_table.primary_key.columns}

        if actual_pk_cols == model_pk_cols:
            print(f"   OK  {table_name}: PK = {sorted(actual_pk_cols)}")
        else:
            print(f"   LOI {table_name}:")
            print(f"        Model expects: {sorted(model_pk_cols)}")
            print(f"        Actual DB has: {sorted(actual_pk_cols)}")
            total_issues += 1

            if fix and model_pk_cols != actual_pk_cols:
                print(f"        -> PK mismatch can sua thu cong (ALTER TABLE)")
                # PK changes are complex, need manual intervention
                # But we can try to rename the column if simple case
                if len(model_pk_cols) == 1 and len(actual_pk_cols) == 1:
                    model_pk = list(model_pk_cols)[0]
                    actual_pk = list(actual_pk_cols)[0]
                    if model_pk != actual_pk:
                        try:
                            sql = f'ALTER TABLE {table_name} RENAME COLUMN "{actual_pk}" TO "{model_pk}"'
                            with engine.begin() as conn:
                                conn.execute(text(sql))
                            print(f"        -> Da doi ten cot {actual_pk} -> {model_pk}")
                            fixes_applied += 1
                        except Exception as e:
                            print(f"        -> LOI: {e}")

    # 4. Check foreign keys
    print(f"\n  4. KIEM TRA FOREIGN KEY")
    print(f"  {'_' * 60}")

    for table_name in sorted(model_tables.keys()):
        if table_name not in actual_tables:
            continue
        fks = inspector.get_foreign_keys(table_name)
        if fks:
            for fk in fks:
                print(f"   OK  {table_name}.{fk['constrained_columns']} -> "
                      f"{fk['referred_table']}.{fk['referred_columns']}")
        # Compare with model FKs
        model_fks = set()
        for col in model_tables[table_name].columns:
            for fk_obj in col.foreign_keys:
                model_fks.add((col.name, fk_obj.target_fullname))

        actual_fk_set = set()
        for fk in fks:
            for i, col in enumerate(fk['constrained_columns']):
                referred = f"{fk['referred_table']}.{fk['referred_columns'][i]}"
                actual_fk_set.add((col, referred))

        missing_fks = model_fks - actual_fk_set
        for col_name, target in missing_fks:
            print(f"   LOI {table_name}.{col_name} -> {target} (FK THIEU)")
            total_issues += 1

    # 5. Row counts
    print(f"\n  5. SO DONG HIEN TAI")
    print(f"  {'_' * 60}")
    with engine.connect() as conn:
        for table_name in sorted(model_tables.keys()):
            if table_name not in actual_tables:
                continue
            result = conn.execute(text(f"SELECT COUNT(*) FROM {table_name}"))
            count = result.scalar()
            print(f"   {table_name:<45} {count:>10,} rows")

    # Summary
    print(f"\n{'=' * 70}")
    if total_issues == 0:
        print(f"  PASS - Toan bo schema KHOP voi model")
    else:
        print(f"  FAIL - Tim thay {total_issues} van de")
        if fix:
            print(f"         Da tu dong sua: {fixes_applied}")
            if total_issues > fixes_applied:
                print(f"         Can sua thu cong: {total_issues - fixes_applied}")
        else:
            print(f"         Chay lai voi --fix de tu dong sua")
    print(f"{'=' * 70}\n")

    return total_issues


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Verify Postgres schema vs SQLAlchemy models")
    parser.add_argument("--fix", action="store_true", help="Tu dong sua loi (them cot thieu, rename PK)")
    args = parser.parse_args()

    engine = get_engine()
    issues = check_schema(engine, fix=args.fix)
    sys.exit(1 if issues > 0 else 0)


if __name__ == '__main__':
    main()
