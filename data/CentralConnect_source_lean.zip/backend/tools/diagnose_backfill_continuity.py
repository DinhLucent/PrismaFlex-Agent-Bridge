"""
Diagnose BACKFILL continuity splits from Postgres + raw packet files.

Goal:
- Find consecutive BACKFILL treatments that share the same device + patient.
- Inspect the tail of the earlier raw and the head of the later raw.
- Explain whether the split was likely caused by END packets, RUN_TIME reset,
  or the current BACKFILL rule that does not resume closed sessions from DB.

Usage:
    python -m tools.diagnose_backfill_continuity
    python -m tools.diagnose_backfill_continuity --device PF_004
    python -m tools.diagnose_backfill_continuity --device PF_004 --patient g21
    python -m tools.diagnose_backfill_continuity --limit-groups 5
"""

from __future__ import annotations

import argparse
import gzip
import json
import os
import sys
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple

import dateutil.parser
import psycopg2
import psycopg2.extras

BACKEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)

from config import settings
from tools.helpers import RAW_DIR, fmt_time, print_err, print_header, print_info, print_ok, print_section, print_warn


def normalize_device_id(raw: Any) -> str:
    text = str(raw or "").strip()
    if not text or text.lower() == "unknown":
        return "unknown"

    upper = text.upper()
    if upper.startswith("PF_"):
        suffix = upper[3:].strip()
        return f"PF_{int(suffix):03d}" if suffix.isdigit() else upper

    if text.isdigit():
        return f"PF_{int(text):03d}"

    return text


def normalize_patient_id(raw: Any) -> str:
    return str(raw or "").strip()


def parse_clinical_time(raw: Any) -> Optional[str]:
    if raw is None:
        return None
    try:
        text = str(raw).strip()
        if text.endswith(" UTC"):
            text = text[:-4]
            dt = dateutil.parser.parse(text)
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        dt = dateutil.parser.parse(text)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(raw)


def extract_header(packet: Dict[str, Any]) -> Dict[str, Any]:
    return packet.get("s_header") or packet.get("header") or {}


def extract_meta(packet: Dict[str, Any]) -> Dict[str, Any]:
    return packet.get("meta") or {}


def extract_body(packet: Dict[str, Any]) -> Dict[str, Any]:
    return packet.get("s_body") or packet.get("body") or {}


def extract_runtime(packet: Dict[str, Any]) -> Optional[float]:
    params = extract_body(packet).get("parameters") or []
    for p in params:
        if p.get("id") == 461:
            try:
                return float(p.get("value"))
            except (TypeError, ValueError):
                return None
    return None


def packet_brief(packet: Dict[str, Any]) -> Dict[str, Any]:
    header = extract_header(packet)
    meta = extract_meta(packet)
    return {
        "time": parse_clinical_time(meta.get("timestamp") or header.get("timestamp") or packet.get("timestamp")),
        "status": header.get("therapy_status_id"),
        "patient": header.get("patient_id"),
        "runtime": extract_runtime(packet),
        "packet_num": meta.get("packet_num", packet.get("packet_num")),
    }


def chunk_sort_key(path: str) -> Tuple[int, str]:
    name = os.path.basename(path)
    marker = "_chunk"
    if marker in name:
        suffix = name.split(marker, 1)[1]
        digits = []
        for ch in suffix:
            if ch.isdigit():
                digits.append(ch)
            else:
                break
        if digits:
            return (int("".join(digits)), name)
    return (0, name)


def find_raw_files(treatment_id: str) -> List[str]:
    if not os.path.isdir(RAW_DIR):
        return []

    prefix = f"treatment_{treatment_id}_chunk"
    chunked = [
        os.path.join(RAW_DIR, f)
        for f in os.listdir(RAW_DIR)
        if f.startswith(prefix) and (f.endswith(".jsonl") or f.endswith(".jsonl.gz"))
    ]
    if chunked:
        return sorted(chunked, key=chunk_sort_key)

    legacy = []
    for suffix in (".raw.jsonl", ".raw.jsonl.gz"):
        path = os.path.join(RAW_DIR, f"treatment_{treatment_id}{suffix}")
        if os.path.exists(path):
            legacy.append(path)
    return legacy


def iter_packets(path: str) -> Iterable[Dict[str, Any]]:
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue


@dataclass
class TreatmentRecord:
    treatment_id: str
    device_id: str
    normalized_device_id: str
    patient_id: str
    start_time: Any
    end_time: Any
    total_packets: int
    outcome: str


@dataclass
class TreatmentRawSummary:
    treatment_id: str
    files: List[str]
    first: Optional[Dict[str, Any]]
    last: Optional[Dict[str, Any]]
    head: List[Dict[str, Any]]
    tail: List[Dict[str, Any]]


def fetch_backfill_treatments() -> List[TreatmentRecord]:
    conn = psycopg2.connect(settings.POSTGRES_URL.replace("postgresql+psycopg2://", "postgresql://"))
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                """
                SELECT
                    t.id::text AS treatment_id,
                    COALESCE(p.device_id, t.device_id) AS device_id,
                    COALESCE(p.patient_id, t.patient_id) AS patient_id,
                    COALESCE(p.start_time, t.start_time) AS start_time,
                    COALESCE(p.end_time, t.end_time) AS end_time,
                    COALESCE(t.total_packets, 0) AS total_packets,
                    COALESCE(t.outcome, '') AS outcome
                FROM treatments t
                LEFT JOIN treatment_list_projection p ON p.id = t.id
                WHERE EXISTS (
                    SELECT 1
                    FROM treatment_journal_rows j
                    WHERE j.treatment_id = t.id
                      AND j.source = 'BACKFILL'
                )
                ORDER BY COALESCE(p.start_time, t.start_time)
                """
            )
            rows = cur.fetchall()
    finally:
        conn.close()

    return [
        TreatmentRecord(
            treatment_id=row["treatment_id"],
            device_id=row["device_id"],
            normalized_device_id=normalize_device_id(row["device_id"]),
            patient_id=normalize_patient_id(row["patient_id"]),
            start_time=row["start_time"],
            end_time=row["end_time"],
            total_packets=int(row["total_packets"] or 0),
            outcome=str(row["outcome"] or ""),
        )
        for row in rows
    ]


def summarize_raw(treatment_id: str, head_count: int = 8, tail_count: int = 12) -> TreatmentRawSummary:
    files = find_raw_files(treatment_id)
    if not files:
        return TreatmentRawSummary(treatment_id, [], None, None, [], [])

    head_packets: List[Dict[str, Any]] = []
    tail_packets: deque[Dict[str, Any]] = deque(maxlen=tail_count)
    first_packet: Optional[Dict[str, Any]] = None
    last_packet: Optional[Dict[str, Any]] = None

    for path in files:
        for packet in iter_packets(path):
            if first_packet is None:
                first_packet = packet
            last_packet = packet
            if len(head_packets) < head_count:
                head_packets.append(packet)
            tail_packets.append(packet)

    return TreatmentRawSummary(
        treatment_id=treatment_id,
        files=files,
        first=packet_brief(first_packet) if first_packet else None,
        last=packet_brief(last_packet) if last_packet else None,
        head=[packet_brief(p) for p in head_packets],
        tail=[packet_brief(p) for p in list(tail_packets)],
    )


def classify_split(prev_sum: TreatmentRawSummary, next_sum: TreatmentRawSummary) -> str:
    prev_tail_statuses = [p["status"] for p in prev_sum.tail if p.get("status") is not None]
    prev_tail_runtimes = [p["runtime"] for p in prev_sum.tail if p.get("runtime") is not None]
    next_head_runtimes = [p["runtime"] for p in next_sum.head if p.get("runtime") is not None]

    prev_last_runtime = prev_sum.last.get("runtime") if prev_sum.last else None
    next_first_runtime = next_sum.first.get("runtime") if next_sum.first else None

    if 8 in prev_tail_statuses:
        if next_first_runtime is not None and next_first_runtime > 0:
            return "END_in_tail + next_runtime>0 => BACKFILL closed and did not resume"
        return "END_in_tail => split likely intentional by current recorder"

    if any(rt == 0 for rt in next_head_runtimes):
        return "next_head runtime hits 0 => likely fresh-start or runtime-reset split"

    if prev_last_runtime is not None and next_first_runtime is not None:
        if prev_last_runtime > 0 and next_first_runtime > 0:
            return "runtime stayed >0 across boundary => candidate BACKFILL resume bug"

    if prev_tail_runtimes and all(rt > 0 for rt in prev_tail_runtimes if rt is not None):
        return "tail runtime still >0 and no END in tail => suspicious split"

    return "needs manual review"


def print_packet_series(label: str, packets: List[Dict[str, Any]]) -> None:
    print_info(label)
    for pkt in packets:
        runtime = "None" if pkt.get("runtime") is None else f"{pkt['runtime']:.0f}"
        print_info(
            f"    time={pkt.get('time')} status={pkt.get('status')} runtime={runtime} packet={pkt.get('packet_num')}"
        )


def main() -> int:
    parser = argparse.ArgumentParser(description="Diagnose BACKFILL continuity splits")
    parser.add_argument("--device", help="Filter by canonical device id, e.g. PF_004")
    parser.add_argument("--patient", help="Filter by patient id")
    parser.add_argument("--limit-groups", type=int, default=20, help="Limit suspicious groups printed")
    parser.add_argument("--head", type=int, default=6, help="Packets to inspect from next head")
    parser.add_argument("--tail", type=int, default=10, help="Packets to inspect from current tail")
    args = parser.parse_args()

    print_header("BACKFILL CONTINUITY DIAGNOSIS")
    print_info(f"RAW_DIR: {RAW_DIR}")

    if not os.path.isdir(RAW_DIR):
        print_err(f"Raw directory not found: {RAW_DIR}")
        return 2

    try:
        treatments = fetch_backfill_treatments()
    except Exception as exc:
        print_err(f"Cannot query Postgres backfill treatments: {exc}")
        return 3

    if args.device:
        want_device = normalize_device_id(args.device)
        treatments = [t for t in treatments if t.normalized_device_id == want_device]
    if args.patient:
        want_patient = normalize_patient_id(args.patient)
        treatments = [t for t in treatments if t.patient_id == want_patient]

    print_ok(f"Loaded {len(treatments)} BACKFILL treatments from Postgres")

    groups: Dict[Tuple[str, str], List[TreatmentRecord]] = defaultdict(list)
    for t in treatments:
        groups[(t.normalized_device_id, t.patient_id)].append(t)

    suspicious_groups = [(k, sorted(v, key=lambda x: x.start_time)) for k, v in groups.items() if len(v) > 1]
    suspicious_groups.sort(key=lambda item: item[1][0].start_time)

    if not suspicious_groups:
        print_ok("No multi-segment BACKFILL groups found for this filter")
        return 0

    print_warn(f"Found {len(suspicious_groups)} device/patient groups with >1 BACKFILL treatment")

    raw_cache: Dict[str, TreatmentRawSummary] = {}

    printed = 0
    for (device_id, patient_id), items in suspicious_groups:
        if printed >= args.limit_groups:
            break
        printed += 1

        print_section(f"{device_id} / {patient_id} ({len(items)} treatments)")
        for idx, item in enumerate(items, start=1):
            print_info(
                f"{idx}. {item.treatment_id[:8]} start={fmt_time(item.start_time)} end={fmt_time(item.end_time)} packets={item.total_packets} outcome={item.outcome}"
            )

        for prev_item, next_item in zip(items, items[1:]):
            if prev_item.treatment_id not in raw_cache:
                raw_cache[prev_item.treatment_id] = summarize_raw(prev_item.treatment_id, head_count=args.head, tail_count=args.tail)
            if next_item.treatment_id not in raw_cache:
                raw_cache[next_item.treatment_id] = summarize_raw(next_item.treatment_id, head_count=args.head, tail_count=args.tail)

            prev_sum = raw_cache[prev_item.treatment_id]
            next_sum = raw_cache[next_item.treatment_id]

            print_info("")
            print_info(f"Boundary {prev_item.treatment_id[:8]} -> {next_item.treatment_id[:8]}")
            print_info(
                f"  prev_last: time={prev_sum.last.get('time') if prev_sum.last else 'N/A'} status={prev_sum.last.get('status') if prev_sum.last else 'N/A'} runtime={prev_sum.last.get('runtime') if prev_sum.last else 'N/A'}"
            )
            print_info(
                f"  next_first: time={next_sum.first.get('time') if next_sum.first else 'N/A'} status={next_sum.first.get('status') if next_sum.first else 'N/A'} runtime={next_sum.first.get('runtime') if next_sum.first else 'N/A'}"
            )
            print_warn(f"  diagnosis: {classify_split(prev_sum, next_sum)}")
            print_packet_series("  prev tail:", prev_sum.tail)
            print_packet_series("  next head:", next_sum.head)

    print_info("")
    print_info("Interpretation note:")
    print_info("  Current recorder resumes SAME PATIENT by RUN_TIME > 0 only for LIVE.")
    print_info("  BACKFILL still closes on END(status=8) and does not DB-resume later segments.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
