"""
Replay one or more raw files into an isolated treatment pipeline sandbox.

Purpose:
- verify treatment continuity logic on old raw datasets
- confirm where recorder splits or resumes treatments
- inspect snapshot counts without touching the real database

Examples:
    python backend/tools/check_treatment_continuity.py --name g17 --mode live ^
        backend/data/treatments/raw/treatment_0428290d-257b-4bf6-9505-2a36f63a1976.raw.jsonl.gz

    python backend/tools/check_treatment_continuity.py --name TRAN_VAN_VU --mode live ^
        "D:\\...\\chunk001.jsonl" "D:\\...\\chunk002.jsonl"
"""

from __future__ import annotations

import argparse
import asyncio
import gzip
import json
import os
import shutil
import sys
import uuid
from typing import Dict, Iterable, List, Optional, Tuple


BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)

from services.telemetry_contract import apply_ingest_contract
from services.treatment.raw_streamer import RawDataStreamer
from services.treatment.treatment_database import TreatmentDatabase
from services.treatment.treatment_recorder import TreatmentRecorderService
from services.treatment.treatment_snapshot_service import ORDER_CHANGE_PIDS, TreatmentSnapshotService


SANDBOX_ROOT = os.path.join(BACKEND_DIR, "tools", "_sandbox_runtime")
REPORT_ROOT = os.path.join(BACKEND_DIR, "tools", "_sandbox_reports")


def iter_packets(path: str) -> Iterable[dict]:
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)


def detect_order_changes(previous: Optional[Dict[int, float]], body: dict) -> Tuple[Dict[int, float], List[Tuple[int, float, float]]]:
    current: Dict[int, float] = {}
    for param in body.get("parameters", []):
        pid = param.get("id")
        if pid not in ORDER_CHANGE_PIDS:
            continue
        try:
            current[pid] = float(param.get("value"))
        except (TypeError, ValueError):
            continue

    if previous is None:
        return current, []

    changes: List[Tuple[int, float, float]] = []
    for pid, new_val in current.items():
        old_val = previous.get(pid)
        if old_val is None:
            continue
        if abs(new_val - old_val) >= 1:
            changes.append((pid, old_val, new_val))
    return current, changes


async def replay_dataset(name: str, filepaths: List[str], mode: str) -> dict:
    runtime_dir = os.path.join(SANDBOX_ROOT, f"{name}_{uuid.uuid4().hex[:8]}")
    os.makedirs(runtime_dir, exist_ok=False)

    db = TreatmentDatabase(os.path.join(runtime_dir, "treatments.db"))
    streamer = RawDataStreamer(os.path.join(runtime_dir, "raw"))
    recorder = TreatmentRecorderService(db, streamer)
    snapshot = TreatmentSnapshotService(db)

    oc_baseline: Dict[str, Dict[int, float]] = {}
    total_packets = 0

    try:
        for path in filepaths:
            for packet in iter_packets(path):
                packet = dict(packet)
                meta = dict(packet.get("meta") or {})
                meta["mode"] = mode.upper()
                packet["meta"] = meta
                apply_ingest_contract(packet)

                header = packet.get("header") or packet.get("s_header") or {}
                body = packet.get("body") or packet.get("s_body") or {}
                device_id = packet["meta"]["device_id"]
                timestamp = packet["meta"]["timestamp"]
                is_live = mode.upper() == "LIVE"

                routing = await recorder.process_packet(
                    device_id,
                    timestamp,
                    header,
                    body,
                    packet["meta"],
                    is_live=is_live,
                )

                treatment_id = (routing or {}).get("treatment_id")
                if treatment_id:
                    snapshot.process_packet(device_id, timestamp, treatment_id, header, body)
                    current, changes = detect_order_changes(oc_baseline.get(device_id), body)
                    oc_baseline[device_id] = current
                    if changes:
                        snapshot.save_order_change_snapshot(device_id, timestamp, changes)

                if (routing or {}).get("flush_snapshot_after"):
                    snapshot.flush_device(device_id)

                total_packets += 1

        treatments = []
        for row in sorted(db.get_treatments(limit=500, offset=0), key=lambda item: item.get("start_time") or ""):
            snapshots = db.get_snapshots(row["id"])
            treatments.append(
                {
                    "id": row["id"],
                    "patient_id": row.get("patient_id"),
                    "device_id": row.get("device_id"),
                    "start_time": row.get("start_time"),
                    "end_time": row.get("end_time"),
                    "outcome": row.get("outcome"),
                    "close_reason": row.get("close_reason"),
                    "total_packets": row.get("total_packets"),
                    "snapshot_count": len(snapshots),
                }
            )

        return {
            "name": name,
            "mode": mode.upper(),
            "total_packets": total_packets,
            "runtime_dir": runtime_dir,
            "input_files": filepaths,
            "treatments": treatments,
        }
    except Exception:
        shutil.rmtree(runtime_dir, ignore_errors=True)
        raise


def print_report(report: dict):
    print()
    print("=" * 72)
    print(f"CONTINUITY CHECK: {report['name']} [{report['mode']}]")
    print("=" * 72)
    print(f"Packets    : {report['total_packets']}")
    print(f"Files      : {len(report['input_files'])}")
    print(f"Runtime dir: {report['runtime_dir']}")
    print(f"Treatments : {len(report['treatments'])}")
    print()
    for idx, item in enumerate(report["treatments"], start=1):
        print(
            f"{idx:02d}. {item['id'][:8]}  {item['device_id']}  {item['patient_id']}  "
            f"start={item['start_time']}  end={item['end_time']}  "
            f"outcome={item['outcome']}  close={item['close_reason']}  "
            f"packets={item['total_packets']}  snaps={item['snapshot_count']}"
        )


def save_report(report: dict, output_path: Optional[str]) -> Optional[str]:
    os.makedirs(REPORT_ROOT, exist_ok=True)
    if output_path is None:
        safe_name = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in report["name"])
        output_path = os.path.join(REPORT_ROOT, f"{safe_name}_continuity_report.json")
    with open(output_path, "w", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2, ensure_ascii=False)
    return output_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Replay raw data into an isolated continuity sandbox.")
    parser.add_argument("files", nargs="+", help="Raw .jsonl/.jsonl.gz files to replay in order.")
    parser.add_argument("--name", required=True, help="Dataset label for the report.")
    parser.add_argument(
        "--mode",
        choices=("live", "backfill"),
        default="live",
        help="Replay mode sent into the recorder. Default: live",
    )
    parser.add_argument(
        "--report",
        default=None,
        help="Optional output JSON report path. Default: backend/tools/_sandbox_reports/<name>_continuity_report.json",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    missing = [path for path in args.files if not os.path.exists(path)]
    if missing:
        for path in missing:
            print(f"Missing file: {path}")
        raise SystemExit(1)

    report = asyncio.run(replay_dataset(args.name, args.files, args.mode))
    report_path = save_report(report, args.report)
    print_report(report)
    if report_path:
        print()
        print(f"Report saved: {report_path}")


if __name__ == "__main__":
    main()
