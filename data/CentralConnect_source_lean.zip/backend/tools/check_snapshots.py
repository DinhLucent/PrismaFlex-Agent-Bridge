import os
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

# Explicitly load .env from the backend directory
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
env_path = os.path.join(backend_dir, ".env")
load_dotenv(dotenv_path=env_path)

db_url = os.getenv("POSTGRES_URL")
if not db_url:
    print(f"Error: POSTGRES_URL is not set. Looked in: {env_path}")
    exit(1)

e = create_engine(db_url)
with e.connect() as c:
    t = c.execute(text('SELECT id, start_time FROM treatments ORDER BY created_at DESC LIMIT 1')).fetchone()
    if t:
        print(f'TREATMENT: {t.id} (start: {t.start_time})')
        rows = c.execute(
            text('SELECT row_code, row_kind, snapshot_time FROM treatment_journal_rows WHERE treatment_id=:tid ORDER BY snapshot_time'),
            {'tid': t.id}
        ).fetchall()
        print(f'SNAPSHOTS ({len(rows)}):')
        for r in rows:
            print(f' - {r.row_code} ({r.row_kind}) @ {r.snapshot_time}')
    else:
        print('NO TREATMENTS FOUND')
e.dispose()
