"""
PrismaFlex DB Inspector
========================
Interactive CLI for inspecting treatment_records.db and telemetry.db.
Supports table listing, quick views, free-form SQL, and CSV export.

Usage:
    python -m tools.inspect_db                          # Interactive menu
    python -m tools.inspect_db tables                   # List all tables
    python -m tools.inspect_db treatments               # List all treatments
    python -m tools.inspect_db snapshots <treatment_id> # Snapshots for a treatment
    python -m tools.inspect_db sql "SELECT ..."         # Free-form SQL query
    python -m tools.inspect_db export <table> [filter]  # Export to CSV
"""

import sys
import csv
import os

# Allow running as `python -m tools.inspect_db` from backend/
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tools.helpers import (
    get_treatment_db, C, print_header, print_section,
    fmt_time, fmt_duration, safe_get, BACKEND_DIR
)


def list_tables():
    """Show all tables and row counts in treatment DB."""
    db = get_treatment_db()
    tables = db.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    ).fetchall()
    
    print_header("📋 Database Tables")
    print(f"  {'Table':40} {'Rows':>8}")
    print(f"  {'─'*40} {'─'*8}")
    for t in tables:
        name = t['name']
        count = db.execute(f"SELECT COUNT(*) as cnt FROM [{name}]").fetchone()['cnt']
        print(f"  {name:40} {count:>8}")
    db.close()


def list_treatments():
    """Show all treatments with key info."""
    db = get_treatment_db()
    rows = db.execute("""
        SELECT id, device_id, patient_id, start_time, end_time,
               outcome, fsm_state, total_packets, total_run_seconds
        FROM treatments ORDER BY start_time DESC
    """).fetchall()
    
    print_header("🏥 All Treatments")
    print(f"  {'#':>3}  {'ID':8}  {'Device':8}  {'Patient':10}  {'Start':19}  {'Duration':>10}  {'Pkts':>6}  {'State'}")
    print(f"  {'─'*3}  {'─'*8}  {'─'*8}  {'─'*10}  {'─'*19}  {'─'*10}  {'─'*6}  {'─'*10}")
    for i, t in enumerate(rows, 1):
        tid = t['id'][:8]
        dev = t['device_id'] or '?'
        pat = (t['patient_id'] or '?')[:10]
        start = fmt_time(t['start_time'], '%m-%d %H:%M') if t['start_time'] else '?'
        dur = fmt_duration(safe_get(t, 'total_run_seconds'))
        pkts = safe_get(t, 'total_packets', '?')
        state = safe_get(t, 'fsm_state') or safe_get(t, 'outcome') or '?'
        color = C.GREEN if state == 'CLOSED' else C.YELLOW
        print(f"  {i:>3}  {tid}  {dev:8}  {pat:10}  {start:19}  {dur:>10}  {pkts:>6}  {color}{state}{C.RESET}")
    db.close()
    return rows


def show_snapshots(treatment_id: str):
    """Show all snapshots for a treatment."""
    db = get_treatment_db()
    # Find by partial ID
    row = db.execute("SELECT id FROM treatments WHERE id LIKE ?", (f"%{treatment_id}%",)).fetchone()
    if not row:
        print(f"  {C.RED}❌ No treatment matching '{treatment_id}'{C.RESET}")
        db.close()
        return
    
    full_id = row['id']
    snaps = db.execute("""
        SELECT hour_label, snapshot_time, qb, qd, qs, qpbp, uf_rate_target,
               uf_hourly, uf_total, heparin_rate, reason, source
        FROM treatment_hourly_snapshots
        WHERE treatment_id = ?
        ORDER BY snapshot_time
    """, (full_id,)).fetchall()
    
    print_header(f"📊 Snapshots for {full_id[:8]}")
    print(f"  Total: {len(snaps)} snapshots")
    print(f"\n  {'Label':8} {'Time':10} {'QB':>5} {'QD':>5} {'QS':>5} {'QPBP':>5} {'UFR':>5} {'UF_H':>6} {'UF_T':>7} {'Src':6} Reason")
    print(f"  {'─'*8} {'─'*10} {'─'*5} {'─'*5} {'─'*5} {'─'*5} {'─'*5} {'─'*6} {'─'*7} {'─'*6} {'─'*30}")
    
    prev = {}
    for s in snaps:
        label = s['hour_label']
        time = fmt_time(s['snapshot_time'])
        is_oc = label.startswith('OC')
        
        vals = {k: s[k] for k in ['qb','qd','qs','qpbp','uf_rate_target']}
        
        def v(key, w=5):
            val = vals.get(key)
            if val is None: return f"{'·':>{w}}"
            txt = f"{int(val):>{w}}"
            if prev and key in prev and prev[key] != val:
                return f"{C.RED}{C.BOLD}{txt}{C.RESET}"
            return txt
        
        reason = (s['reason'] or '')[:30]
        src = s['source'] or 'AUTO'
        lc = C.YELLOW if is_oc else ''
        lr = C.RESET if lc else ''
        
        print(f"  {lc}{label:8}{lr} {time:10} {v('qb')} {v('qd')} {v('qs')} {v('qpbp')} {v('uf_rate_target')} "
              f"{s['uf_hourly'] or 0:>6.0f} {s['uf_total'] or 0:>7.0f} {src:6} {C.DIM}{reason}{C.RESET}")
        
        if not is_oc:
            prev = vals.copy()
    
    db.close()


def run_sql(query: str):
    """Execute free-form SQL and display results."""
    db = get_treatment_db()
    try:
        rows = db.execute(query).fetchall()
        if not rows:
            print(f"  {C.DIM}No results.{C.RESET}")
            db.close()
            return
        
        # Print header
        keys = rows[0].keys()
        header = " | ".join(f"{k:>15}" for k in keys)
        print(f"\n  {C.BOLD}{header}{C.RESET}")
        print(f"  {'─' * len(header)}")
        
        for r in rows[:100]:
            vals = " | ".join(f"{str(r[k] or ''):>15}" for k in keys)
            print(f"  {vals}")
        
        if len(rows) > 100:
            print(f"  {C.DIM}... {len(rows) - 100} more rows (showing first 100){C.RESET}")
        
        print(f"\n  Total: {len(rows)} rows")
    except Exception as e:
        print(f"  {C.RED}❌ SQL Error: {e}{C.RESET}")
    db.close()


def export_csv(table: str, filter_val: str = None):
    """Export table to CSV file."""
    db = get_treatment_db()
    try:
        if filter_val:
            query = f"SELECT * FROM [{table}] WHERE treatment_id LIKE ?"
            rows = db.execute(query, (f"%{filter_val}%",)).fetchall()
        else:
            rows = db.execute(f"SELECT * FROM [{table}] LIMIT 10000").fetchall()
        
        if not rows:
            print(f"  {C.DIM}No data to export.{C.RESET}")
            db.close()
            return
        
        out_file = os.path.join(BACKEND_DIR, f"export_{table}.csv")
        with open(out_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(rows[0].keys())
            for r in rows:
                writer.writerow([r[k] for k in r.keys()])
        
        print(f"  {C.GREEN}✅ Exported {len(rows)} rows → {out_file}{C.RESET}")
    except Exception as e:
        print(f"  {C.RED}❌ Export Error: {e}{C.RESET}")
    db.close()


def interactive():
    """Interactive menu."""
    print_header("🔧 PrismaFlex DB Inspector")
    print(f"""
  {C.BOLD}Commands:{C.RESET}
    {C.CYAN}tables{C.RESET}                      List all tables
    {C.CYAN}treatments{C.RESET}                  List all treatments
    {C.CYAN}snapshots <id>{C.RESET}              Snapshots for a treatment
    {C.CYAN}sql "SELECT ..."{C.RESET}            Free-form SQL query
    {C.CYAN}export <table> [filter]{C.RESET}     Export to CSV
    {C.CYAN}q{C.RESET}                           Quit
    """)
    while True:
        try:
            cmd = input(f"  {C.BOLD}>{C.RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        
        if not cmd or cmd == 'q':
            break
        
        parts = cmd.split(maxsplit=2)
        action = parts[0].lower()
        
        if action == 'tables':
            list_tables()
        elif action == 'treatments':
            list_treatments()
        elif action == 'snapshots' and len(parts) > 1:
            show_snapshots(parts[1])
        elif action == 'sql' and len(parts) > 1:
            run_sql(parts[1] if len(parts) == 2 else parts[1] + ' ' + parts[2])
        elif action == 'export':
            export_csv(parts[1] if len(parts) > 1 else 'treatments',
                      parts[2] if len(parts) > 2 else None)
        else:
            print(f"  {C.DIM}Unknown command. Type 'q' to quit.{C.RESET}")


def main():
    if len(sys.argv) < 2:
        interactive()
        return
    
    cmd = sys.argv[1].lower()
    if cmd == 'tables':
        list_tables()
    elif cmd == 'treatments':
        list_treatments()
    elif cmd == 'snapshots' and len(sys.argv) > 2:
        show_snapshots(sys.argv[2])
    elif cmd == 'sql' and len(sys.argv) > 2:
        run_sql(' '.join(sys.argv[2:]))
    elif cmd == 'export':
        export_csv(sys.argv[2] if len(sys.argv) > 2 else 'treatments',
                  sys.argv[3] if len(sys.argv) > 3 else None)
    else:
        print(__doc__)


if __name__ == '__main__':
    main()
