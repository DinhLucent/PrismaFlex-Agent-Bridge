"""
Treatment Monitor — Real-time observer for MIRTH data testing.
================================================================
Run this WHILE the backend is running to see treatment events in real-time.

Usage:  python monitor_treatments.py
        python monitor_treatments.py --watch   (auto-refresh every 5s)
"""
import requests
import time
import sys
from datetime import datetime, timezone, timedelta

BASE = "http://localhost:8000"
TZ = timezone(timedelta(hours=7))

def fmt_duration(sec):
    if not sec or sec == 0:
        return "0s"
    h = sec // 3600
    m = (sec % 3600) // 60
    if h > 0:
        return f"{h}h{m:02d}m"
    return f"{m}m"

def fmt_time(ts):
    if not ts:
        return "-"
    # Show only HH:MM:SS part
    try:
        if "T" in ts:
            return ts.split("T")[1][:8]
        return ts[:19]
    except:
        return ts

def show_status():
    now = datetime.now(TZ)
    print(f"\n{'='*80}")
    print(f"  TREATMENT MONITOR  |  {now.strftime('%H:%M:%S')}  |  Backend: {BASE}")
    print(f"{'='*80}")

    try:
        # 1. Active sessions (from recorder debug endpoint if available)
        try:
            r = requests.get(f"{BASE}/api/v1/treatments/active-sessions", timeout=2)
            if r.status_code == 200:
                sessions = r.json()
                if sessions:
                    print(f"\n  ACTIVE SESSIONS ({len(sessions)}):")
                    print(f"  {'Device':<12} {'Patient':<14} {'Packets':<10} {'Last Seen'}")
                    print(f"  {'-'*12} {'-'*14} {'-'*10} {'-'*20}")
                    for did, s in sessions.items():
                        print(f"  {did:<12} {s.get('patient_id','?'):<14} {s.get('packets',0):<10} {fmt_time(s.get('last_seen',''))}")
                else:
                    print(f"\n  ACTIVE SESSIONS: None")
        except:
            pass  # Endpoint might not exist

        # 2. Recent treatments from index
        r = requests.get(f"{BASE}/api/v1/treatments?limit=15", timeout=5)
        data = r.json()
        total = data.get("total", 0)
        items = data.get("items", [])

        print(f"\n  TREATMENT INDEX ({total} total):")
        print(f"  {'ID':<10} {'Device':<12} {'Patient':<14} {'Status':<12} {'Duration':<10} {'Start':<10} {'End':<10} {'Pkts'}")
        print(f"  {'-'*10} {'-'*12} {'-'*14} {'-'*12} {'-'*10} {'-'*10} {'-'*10} {'-'*6}")

        for t in items:
            tid = t.get("id", "")[:8]
            did = t.get("device_id", "?")
            pid = t.get("patient_id", "?")
            out = t.get("outcome", "?")
            dur = fmt_duration(t.get("duration_sec", 0))
            start = fmt_time(t.get("start_time"))
            end = fmt_time(t.get("end_time"))
            pkts = t.get("total_packets", 0)

            # Color coding via markers
            marker = ""
            if out == "IN_PROGRESS":
                marker = " [LIVE]"
            elif out == "COMPLETED":
                marker = ""

            print(f"  {tid:<10} {did:<12} {pid:<14} {out:<12} {dur:<10} {start:<10} {end:<10} {pkts}{marker}")

        # 3. Summary stats
        in_progress = sum(1 for t in items if t.get("outcome") == "IN_PROGRESS")
        completed = sum(1 for t in items if t.get("outcome") == "COMPLETED")
        print(f"\n  Summary: {in_progress} active, {completed} completed (showing last {len(items)})")

    except requests.ConnectionError:
        print("\n  ERROR: Cannot connect to backend. Is it running?")
    except Exception as e:
        print(f"\n  ERROR: {e}")

    print(f"\n{'='*80}")

def main():
    watch = "--watch" in sys.argv or "-w" in sys.argv

    if watch:
        print("Monitor mode: refreshing every 5s. Press Ctrl+C to stop.")
        try:
            while True:
                # Clear screen
                print("\033[2J\033[H", end="")
                show_status()
                time.sleep(5)
        except KeyboardInterrupt:
            print("\nMonitor stopped.")
    else:
        show_status()
        print("  Tip: Run with --watch for auto-refresh every 5s")

if __name__ == "__main__":
    main()
