
import requests
import json
import time
from datetime import datetime

# Configuration
API_URL = "http://localhost:8000/api/v1/telemetry"
DEVICE_ID_INT = 888
DEVICE_ID_STR = f"PF_{DEVICE_ID_INT:03d}"
PARAM_ID_FILTER = 2  # Filter Pressure (Body ID 2)
PARAM_ID_ACCESS = 1  # Access Pressure (Body ID 1)

def send_packet(value_filter, value_access):
    payload = {
        "s_header": {
            "machine_id": DEVICE_ID_INT,
            "patient_id": "DEMO_PATIENT",
            "timestamp": datetime.now().isoformat(),
            "therapy_type_id": 16, # CVVHDF
            "therapy_status_id": 4  # Running
        },
        "s_body": {
            "parameters": [
                {"id": PARAM_ID_FILTER, "value": value_filter},
                {"id": PARAM_ID_ACCESS, "value": value_access},
                # Add a few others to make it look real
                {"id": 3, "value": 50}, # Effluent
                {"id": 4, "value": 80}, # Return
            ]
        }
    }
    
    try:
        response = requests.post(API_URL, json=payload)
        print(f"Sent packet: Filter={value_filter}, Access={value_access} | Status: {response.status_code}")
        if response.status_code != 200:
            print(f"Response Body: {response.text}")
    except Exception as e:
        print(f"Error sending packet: {e}")

if __name__ == "__main__":
    print(f"--- Simulating 'Was' Events for {DEVICE_ID_STR} ---")
    
    # 1. Baseline
    print("1. Sending Baseline (Filter=100, Access=-50)...")
    send_packet(100, -50)
    
    # Wait for backend to process and establish cache
    print("   ... Waiting 5 seconds for backend to cache baseline ...")
    time.sleep(5)
    
    # 2. Change
    print("2. Sending CHANGE (Filter=120, Access=-60)...")
    print(f"   -> Expect 'Filter Pressure was 100' and 'Access Pressure was -50' on {DEVICE_ID_STR} Dashboard.")
    send_packet(120, -60)
    
    print(f"\nCheck the Dashboard now! You should see a new card for {DEVICE_ID_STR}.")
