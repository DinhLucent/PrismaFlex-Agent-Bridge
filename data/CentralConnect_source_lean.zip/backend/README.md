# PrismaFlex Backend Service

### Setup & Run
1. Create virtual environment (optional but recommended):
   ```bash
   python -m venv venv
   .\venv\Scripts\activate
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run the server:
   ```bash
   python main.py
   ```
   Or explicitly with uvicorn:
   ```bash
   uvicorn main:app --reload --host 0.0.0.0 --port 8000
   ```

### API Endpoints
- **GET /**: Health check `{"status": "online"}`
- **POST /api/v1/telemetry**: Endpoint for Mirth Connect to push data.
- **WS /ws**: WebSocket endpoint for Frontend real-time updates.

### Mirth Connect Format
Expected JSON payload:
```json
{
  "meta": {
    "device_id": "PF_001",
    "timestamp": "2024-01-01T12:00:00Z",
    "packet_num": 123
  },
  "header": { ... },
  "body": { ... }
}
```
