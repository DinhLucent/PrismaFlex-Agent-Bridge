import os
import sys
import uuid
import asyncio
from datetime import datetime, timezone, timedelta

# Add backend to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__))))
try:
    from services.treatment.postgres_treatment_db import PostgresTreatmentDB as TreatmentDatabase
except ImportError:
    print("Could not import PostgresTreatmentDB")
    sys.exit(1)
    
from services.treatment.treatment_recorder import TreatmentRecorderService
from services.treatment.raw_streamer import RawDataStreamer

class V378QA:
    def __init__(self):
        # postgres_treatment_db uses a Postgres connection by default.
        # But we can override it if we want, or just let it connect to the local QA DB.
        # The prompt says "tự chạy rồi check", so connecting to the local testing DB is fine.
        # But PostgresTreatmentDB might need the actual PG connection string. 
        # I will let it initialize with its default settings which point to localhost.
        self.db = TreatmentDatabase()
        self.streamer = RawDataStreamer()
        self.streamer.stream_packet = self.mock_stream
        self.recorder = TreatmentRecorderService(self.db, self.streamer)
        self.results = []

    async def mock_stream(self, device_id, treatment_id, packet_data):
        pass

    def log(self, tc, name, passed, detail=""):
        status = "PASS" if passed else "FAIL"
        print(f"[{status}] {tc}: {name} - {detail}")
        self.results.append(passed)

    def make_pkt(self, pid, status, run_time, dt=None):
        ts = dt or datetime.now(timezone(timedelta(hours=7))).isoformat()
        body = {"parameters": [{"id": 461, "value": run_time}]} if run_time is not None else {"parameters": []}
        return ts, {"patient_id": pid, "therapy_status_id": status, "therapy_type_id_name": "CVVH"}, body, {"timestamp": ts}

    async def test_L01(self):
        dev = "DEV_L01"
        ts1, h, b, m = self.make_pkt("PT_L01", 4, 0, "2026-04-14T10:00:00+07:00")
        t1 = await self.recorder.process_packet(dev, ts1, h, b, m, is_live=True)
        self.log("TC-L01", "Fresh start by WAITINGSTART", t1 is not None, f"Treatment UUID: {t1}")

    async def test_L02(self):
        dev = "DEV_L02"
        ts1, h, b, m = self.make_pkt("PT_L02", 5, 0, "2026-04-14T10:00:00+07:00")
        t1 = await self.recorder.process_packet(dev, ts1, h, b, m, is_live=True)
        self.log("TC-L02", "Fresh start by RUN", t1 is not None, f"Treatment UUID: {t1}")

    async def test_L03(self):
        dev = "DEV_L03"
        ts1, h, b, m = self.make_pkt("PT_L03", 5, 10, "2026-04-14T10:00:00+07:00")
        t1 = await self.recorder.process_packet(dev, ts1, h, b, m, is_live=True)
        ts2, h, b, m = self.make_pkt("PT_L03", 5, 20, "2026-04-14T10:10:00+07:00")
        t2 = await self.recorder.process_packet(dev, ts2, h, b, m, is_live=True)
        self.log("TC-L03", "Same treatment steady run", t1 == t2, f"UUID: {t1} vs {t2}")

    async def test_L04(self):
        dev = "DEV_L04"
        ts1, h, b, m = self.make_pkt("PT_L04", 5, 10, "2026-04-14T10:00:00+07:00")
        t1 = await self.recorder.process_packet(dev, ts1, h, b, m, is_live=True)
        # 1 hour disconnect
        ts2, h, b, m = self.make_pkt("PT_L04", 5, 4000, "2026-04-14T11:00:00+07:00")
        t2 = await self.recorder.process_packet(dev, ts2, h, b, m, is_live=True)
        self.log("TC-L04", "Disconnect / reconnect without END", t1 == t2, f"UUID: {t1} vs {t2}")

    async def test_L05(self):
        dev = "DEV_L05"
        ts1, h, b, m = self.make_pkt("PT_L05", 5, 10, "2026-04-14T10:00:00+07:00")
        t1 = await self.recorder.process_packet(dev, ts1, h, b, m, is_live=True)
        # END
        ts2, h, b, m = self.make_pkt("PT_L05", 8, 30, "2026-04-14T10:10:00+07:00")
        await self.recorder.process_packet(dev, ts2, h, b, m, is_live=True)
        # RUN_TIME > 0 (Resume)
        ts3, h, b, m = self.make_pkt("PT_L05", 5, 31, "2026-04-14T10:15:00+07:00")
        t2 = await self.recorder.process_packet(dev, ts3, h, b, m, is_live=True)
        self.log("TC-L05", "END then same patient with continuing counters", t1 == t2, f"UUID: {t1} vs {t2}")

    async def test_L06(self):
        dev = "DEV_L06"
        ts1, h, b, m = self.make_pkt("PT_L06", 5, 10, "2026-04-14T10:00:00+07:00")
        t1 = await self.recorder.process_packet(dev, ts1, h, b, m, is_live=True)
        # END
        ts2, h, b, m = self.make_pkt("PT_L06", 8, 30, "2026-04-14T10:10:00+07:00")
        await self.recorder.process_packet(dev, ts2, h, b, m, is_live=True)
        # RUN_TIME = 0 (Fresh start)
        ts3, h, b, m = self.make_pkt("PT_L06", 5, 0, "2026-04-14T10:15:00+07:00")
        t2 = await self.recorder.process_packet(dev, ts3, h, b, m, is_live=True)
        self.log("TC-L06", "END then same patient fresh start", t1 is not None and t2 is not None and t1 != t2, f"UUID: {t1} vs {t2}")

    async def test_L07(self):
        dev = "DEV_L07"
        ts1, h, b, m = self.make_pkt("PT_L07", 5, 10, "2026-04-14T10:00:00+07:00")
        t1 = await self.recorder.process_packet(dev, ts1, h, b, m, is_live=True)
        # END
        ts2, h, b, m = self.make_pkt("PT_L07", 8, 30, "2026-04-14T10:10:00+07:00")
        await self.recorder.process_packet(dev, ts2, h, b, m, is_live=True)
        # Idle non-start
        ts3, h, b, m = self.make_pkt("PT_L07", 0, 0, "2026-04-14T10:15:00+07:00")
        t2 = await self.recorder.process_packet(dev, ts3, h, b, m, is_live=True)
        # It's an idle packet so it should NOT create a new treatment.
        # But process_packet returns None if session didn't close (meaning it stayed open or we didn't open a new one)
        # Wait, if session is closed, process_packet returns None because no NEW treatment was opened OR returns closed_id if a closure happened.
        # But from code, if it doesn't open a new one, packet_id is None. Let's see what happens.
        self.log("TC-L07", "END then idle only", t2 is None or t1 == t2, f"UUID: {t1} vs {t2}")

    async def run(self):
        print("Running V3.7.8 LIVE Continuity QA Matrix...")
        await self.test_L01()
        await self.test_L02()
        await self.test_L03()
        await self.test_L04()
        await self.test_L05()
        await self.test_L06()
        await self.test_L07()
        passed = sum(self.results)
        print(f"Results: {passed}/{len(self.results)} Passed.")

if __name__ == "__main__":
    asyncio.run(V378QA().run())
