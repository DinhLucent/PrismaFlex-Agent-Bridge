import unittest
from datetime import timezone

from tools.simulate_ingest import (
    analyze_order,
    endpoint_for_mode,
    normalize_packet,
    parse_packet_time,
    select_cutover_index,
    sort_packets_by_time,
)


RAW_PACKET = {
    "packet_num": 169,
    "timestamp": "2026-01-30T08:37:13.347598",
    "s_header": {
        "machine_id": 7,
        "patient_id": "g7",
        "timestamp": "2026-01-30 08:37:09 UTC",
        "timestamp_unix": 1769762229,
    },
    "s_body": {"total_records": 0, "parameters": []},
}


class SimulateIngestTests(unittest.TestCase):
    def test_normalize_packet_builds_live_payload(self):
        payload = normalize_packet(RAW_PACKET, "LIVE")
        self.assertEqual(payload["meta"]["device_id"], "PF_007")
        self.assertEqual(payload["meta"]["mode"], "LIVE")
        self.assertEqual(payload["meta"]["timestamp_unix"], 1769762229)
        self.assertEqual(payload["s_header"]["timestamp"], "2026-01-30 08:37:09 UTC")

    def test_parse_packet_time_prefers_unix_epoch(self):
        payload = normalize_packet(RAW_PACKET, "BACKFILL")
        pkt_time = parse_packet_time(payload)
        self.assertIsNotNone(pkt_time)
        self.assertEqual(int(pkt_time.timestamp()), 1769762229)
        self.assertEqual(pkt_time.tzinfo, timezone.utc)

    def test_analyze_order_detects_backward_jump(self):
        p1 = dict(RAW_PACKET)
        p2 = json_clone(RAW_PACKET)
        p2["s_header"]["timestamp_unix"] = RAW_PACKET["s_header"]["timestamp_unix"] - 10
        stats = analyze_order([p1, p2])
        self.assertEqual(stats.out_of_order_pairs, 1)
        self.assertGreater(stats.max_backward_seconds, 0)

    def test_sort_packets_by_time_restores_monotonic_order(self):
        p1 = json_clone(RAW_PACKET)
        p2 = json_clone(RAW_PACKET)
        p1["packet_num"] = 2
        p1["s_header"]["timestamp_unix"] = 200
        p2["packet_num"] = 1
        p2["s_header"]["timestamp_unix"] = 100
        sorted_packets = sort_packets_by_time([p1, p2])
        self.assertEqual(sorted_packets[0]["packet_num"], 1)
        self.assertEqual(sorted_packets[1]["packet_num"], 2)

    def test_select_cutover_index_defaults_to_half(self):
        packets = [json_clone(RAW_PACKET) for _ in range(10)]
        self.assertEqual(select_cutover_index(packets, None, None), 5)

    def test_endpoint_for_mode_supports_split_and_legacy(self):
        self.assertTrue(endpoint_for_mode("http://localhost:8000", "LIVE", "split").endswith("/api/v1/telemetry/live"))
        self.assertTrue(endpoint_for_mode("http://localhost:8000", "BACKFILL", "legacy").endswith("/api/v1/telemetry"))


def json_clone(value):
    import json

    return json.loads(json.dumps(value))


if __name__ == "__main__":
    unittest.main()
