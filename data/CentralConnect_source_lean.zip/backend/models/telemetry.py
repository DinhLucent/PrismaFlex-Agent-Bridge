"""
Pydantic models for telemetry data validation
"""
from pydantic import BaseModel, Field, validator
from typing import List, Dict, Any, Optional
from datetime import datetime
import dateutil.parser


class Parameter(BaseModel):
    """Single parameter from PrismaFlex device"""
    record_num: int
    type: str  # "Actual" or "Set"
    id: int
    id_hex: str
    value: int
    record_time: int


class Header(BaseModel):
    """PrismaFlex packet header"""
    stx: Optional[str] = None
    crc: Optional[str] = None
    machine_id: int
    clinical_sw_id: Optional[str] = None
    message_counter: Optional[int] = None
    command_code: Optional[str] = None
    message_info: Optional[int] = None
    flags: Optional[str] = None
    patient_id: str
    sw_revision_hex: Optional[str] = None
    sw_version: str
    therapy_type_id: int
    therapy_status_id: int
    timestamp: str
    timestamp_unix: Optional[int] = None
    body_length_bytes: Optional[int] = None


class Body(BaseModel):
    """PrismaFlex packet body"""
    total_records: int
    parameters: List[Parameter]


class Meta(BaseModel):
    """Metadata for telemetry packet"""
    device_id: str
    timestamp: str
    packet_num: int
    mirth_received_time: Optional[str] = None
    
    @validator('timestamp')
    def validate_timestamp(cls, v):
        """Validate timestamp is in ISO 8601 format"""
        try:
            dateutil.parser.isoparse(v)
        except Exception as e:
            raise ValueError(f"Invalid timestamp format: {v}. Must be ISO 8601. Error: {e}")
        return v


class TelemetryRequest(BaseModel):
    """
    Complete telemetry request from Mirth Connect
    """
    meta: Meta
    header: Header
    body: Body
    
    class Config:
        json_schema_extra = {
            "example": {
                "meta": {
                    "device_id": "PF_001",
                    "timestamp": "2026-02-08T18:30:45.347598",
                    "packet_num": 169,
                    "mirth_received_time": "2026-02-08T18:30:46.123456"
                },
                "header": {
                    "machine_id": 7,
                    "patient_id": "g7",
                    "therapy_type_id": 3,
                    "therapy_status_id": 5,
                    "sw_version": "SW8.20V04R00",
                    "timestamp": "2026-02-08 18:30:41 UTC"
                },
                "body": {
                    "total_records": 172,
                    "parameters": [
                        {
                            "record_num": 1,
                            "type": "Actual",
                            "id": 1,
                            "id_hex": "0x000001",
                            "value": -40,
                            "record_time": 1769762229
                        }
                    ]
                }
            }
        }


class TelemetryResponse(BaseModel):
    """Response sent back to Mirth Connect"""
    status: str
    network_latency: float
    quality: str = Field(description="LIVE, DELAYED, or UNKNOWN")
    message: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "success",
                "network_latency": 1.23,
                "quality": "LIVE",
                "message": "Data received and broadcasted successfully"
            }
        }
