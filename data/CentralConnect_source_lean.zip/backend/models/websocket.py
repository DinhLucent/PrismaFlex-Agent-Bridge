"""
Pydantic models for WebSocket messages
"""
from pydantic import BaseModel, Field
from typing import Dict, Any, Optional, Literal
from datetime import datetime


class QualityStatus(BaseModel):
    """Data quality status information"""
    quality: Literal["LIVE", "DELAYED", "UNKNOWN"]
    latency_sec: float = Field(description="Latency in seconds")
    server_time: str = Field(description="Server timestamp in ISO 8601")
    error: Optional[str] = None


class WebSocketMessage(BaseModel):
    """
    WebSocket message format sent to frontend clients
    """
    type: Literal["TELEMETRY_UPDATE", "CONNECTION_STATUS", "ERROR", "HEARTBEAT"]
    quality_status: QualityStatus
    payload: Dict[str, Any]
    
    class Config:
        json_schema_extra = {
            "example": {
                "type": "TELEMETRY_UPDATE",
                "quality_status": {
                    "quality": "LIVE",
                    "latency_sec": 1.23,
                    "server_time": "2026-02-08T18:30:46.500000Z"
                },
                "payload": {
                    "meta": {
                        "device_id": "PF_001",
                        "timestamp": "2026-02-08T18:30:45.347598",
                        "packet_num": 169
                    },
                    "header": {
                        "machine_id": 7,
                        "patient_id": "g7",
                        "therapy_type_id": 3,
                        "therapy_status_id": 5
                    },
                    "body": {
                        "total_records": 172,
                        "parameters": []
                    }
                }
            }
        }


class ConnectionStatusMessage(BaseModel):
    """Connection status update message"""
    type: Literal["CONNECTION_STATUS"] = "CONNECTION_STATUS"
    status: Literal["CONNECTED", "DISCONNECTED", "RECONNECTING"]
    device_id: Optional[str] = None
    timestamp: str
    
    class Config:
        json_schema_extra = {
            "example": {
                "type": "CONNECTION_STATUS",
                "status": "CONNECTED",
                "device_id": "PF_001",
                "timestamp": "2026-02-08T18:30:46.500000Z"
            }
        }


class ErrorMessage(BaseModel):
    """Error message"""
    type: Literal["ERROR"] = "ERROR"
    error_code: str
    error_message: str
    timestamp: str
    details: Optional[Dict[str, Any]] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "type": "ERROR",
                "error_code": "VALIDATION_ERROR",
                "error_message": "Invalid data format received",
                "timestamp": "2026-02-08T18:30:46.500000Z",
                "details": {
                    "field": "meta.timestamp",
                    "reason": "Invalid ISO 8601 format"
                }
            }
        }
