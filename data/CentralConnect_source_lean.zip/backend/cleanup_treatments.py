"""
Treatment Cleanup Tool — Portable
====================================
Giu lai cac treatment co trong treatment_index (treatment journal).
Xoa sach rac: ghost sessions, orphan raw files, status_log bloat.

Su dung:
    1. Copy file nay vao folder: backend/
    2. TAT backend truoc khi chay!
    3. Chay:  python cleanup_treatments.py          (dry-run, chi xem)
              python cleanup_treatments.py --apply  (xoa that)

An toan: Mac dinh chi xem (dry-run), khong xoa gi ca.
"""

import os
import sys
import sqlite3
import shutil
from datetime import datetime

# ── Config ────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(SCRIPT_DIR, "services", "treatment_records.db")
RAW_DIR = os.path.join(SCRIPT_DIR, "data", "treatments", "raw")

DRY_RUN = "--apply" not in sys.argv


def main():
    print("=" * 70)
    print("  TREATMENT CLEANUP TOOL")
    print("  Mode: %s" % ("DRY-RUN (xem truoc, khong xoa)" if DRY_RUN else "APPLY (XOA THAT!)"))
    print("=" * 70)

    if not os.path.exists(DB_PATH):
        print("ERROR: DB not found: %s" % DB_PATH)
        print("Make sure you copy this script into the 'backend/' folder.")
        return

    # ── Backup DB ──────────────────────────────────────────────
    if not DRY_RUN:
        backup_name = "treatment_records.BACKUP_%s.db" % datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(os.path.dirname(DB_PATH), backup_name)
        shutil.copy2(DB_PATH, backup_path)
        print("\n[BACKUP] DB backed up to: %s" % backup_name)

    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row

    # ── 1. Get valid treatment IDs from treatment_index ────────
    valid_ids = set()
    rows = db.execute("SELECT id, patient_id, total_packets, outcome FROM treatment_index").fetchall()
    print("\n--- VALID TREATMENTS (treatment_index) ---")
    for r in rows:
        valid_ids.add(r["id"])
        print("  KEEP: %s | pt=%s | pkts=%s | out=%s" % (
            r["id"][:8], r["patient_id"], r["total_packets"], r["outcome"]))
    print("  Total valid: %d" % len(valid_ids))

    # ── 2. Find orphan treatments (in 'treatments' but not in index) ──
    all_treat_ids = set()
    orphan_treatments = []
    for r in db.execute("SELECT id, device_id, patient_id, total_packets, outcome FROM treatments").fetchall():
        all_treat_ids.add(r["id"])
        if r["id"] not in valid_ids:
            orphan_treatments.append(dict(r))

    print("\n--- ORPHAN TREATMENTS (in DB, not in journal) ---")
    print("  Found: %d orphans" % len(orphan_treatments))
    for t in orphan_treatments[:10]:
        print("  DELETE: %s | dev=%s | pt=%s | pkts=%s | out=%s" % (
            t["id"][:8], t["device_id"], t["patient_id"], t["total_packets"], t["outcome"]))
    if len(orphan_treatments) > 10:
        print("  ... and %d more" % (len(orphan_treatments) - 10))

    # ── 3. Find orphan status_log entries ──────────────────────
    orphan_log_count = db.execute(
        "SELECT COUNT(*) as c FROM treatment_status_log WHERE treatment_id NOT IN (SELECT id FROM treatment_index)"
    ).fetchone()["c"]
    total_log_count = db.execute("SELECT COUNT(*) as c FROM treatment_status_log").fetchone()["c"]
    valid_log_count = total_log_count - orphan_log_count

    print("\n--- STATUS LOG ---")
    print("  Total rows: %d" % total_log_count)
    print("  Orphan rows to delete: %d" % orphan_log_count)
    print("  Valid rows to keep: %d" % valid_log_count)

    # ── 4. Find orphan raw files ───────────────────────────────
    orphan_files = []
    valid_files = []
    total_orphan_size = 0
    total_valid_size = 0

    if os.path.exists(RAW_DIR):
        for f in os.listdir(RAW_DIR):
            fp = os.path.join(RAW_DIR, f)
            sz = os.path.getsize(fp)
            # Extract treatment ID from filename
            tid = f.replace("treatment_", "").replace(".raw.jsonl.gz", "").replace(".raw.jsonl", "")
            if tid in valid_ids:
                valid_files.append((f, sz))
                total_valid_size += sz
            else:
                orphan_files.append((f, sz))
                total_orphan_size += sz

    print("\n--- RAW FILES ON DISK ---")
    print("  Valid files: %d (%.2f MB)" % (len(valid_files), total_valid_size / 1024 / 1024))
    print("  Orphan files to delete: %d (%.2f MB)" % (len(orphan_files), total_orphan_size / 1024 / 1024))
    for f, sz in orphan_files[:10]:
        print("  DELETE: %s (%.2f MB)" % (f, sz / 1024 / 1024))
    if len(orphan_files) > 10:
        print("  ... and %d more" % (len(orphan_files) - 10))

    # ── 5. Other orphan data ───────────────────────────────────
    orphan_snapshots = db.execute(
        "SELECT COUNT(*) as c FROM treatment_hourly_snapshots WHERE treatment_id NOT IN (SELECT id FROM treatment_index)"
    ).fetchone()["c"]
    orphan_config = db.execute(
        "SELECT COUNT(*) as c FROM treatment_config WHERE treatment_id NOT IN (SELECT id FROM treatment_index)"
    ).fetchone()["c"]
    orphan_phases = db.execute(
        "SELECT COUNT(*) as c FROM treatment_phases WHERE treatment_id NOT IN (SELECT id FROM treatment_index)"
    ).fetchone()["c"]
    orphan_raw_pkts = db.execute(
        "SELECT COUNT(*) as c FROM treatment_raw_packets WHERE treatment_id NOT IN (SELECT id FROM treatment_index)"
    ).fetchone()["c"]
    orphan_snap_orig = db.execute(
        "SELECT COUNT(*) as c FROM snapshot_originals WHERE treatment_id NOT IN (SELECT id FROM treatment_index)"
    ).fetchone()["c"]

    print("\n--- OTHER ORPHAN DATA ---")
    print("  Orphan snapshots: %d" % orphan_snapshots)
    print("  Orphan config: %d" % orphan_config)
    print("  Orphan phases: %d" % orphan_phases)
    print("  Orphan raw_packets (DB): %d" % orphan_raw_pkts)
    print("  Orphan snapshot_originals: %d" % orphan_snap_orig)

    # ── SUMMARY ───────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("  CLEANUP SUMMARY")
    print("=" * 70)
    print("  Treatments to KEEP: %d" % len(valid_ids))
    print("  Treatments to DELETE: %d" % len(orphan_treatments))
    print("  Status log rows to DELETE: %d" % orphan_log_count)
    print("  Raw files to DELETE: %d (%.2f MB)" % (len(orphan_files), total_orphan_size / 1024 / 1024))
    print("  Disk space freed: ~%.2f MB" % (total_orphan_size / 1024 / 1024))

    if DRY_RUN:
        print("\n  >>> DRY-RUN: Khong xoa gi ca.")
        print("  >>> De xoa that, chay: python cleanup_treatments.py --apply")
        db.close()
        return

    # ── APPLY ─────────────────────────────────────────────────
    print("\n  APPLYING CLEANUP...")

    cursor = db.cursor()

    # Delete orphan DB data (order matters for foreign keys)
    cursor.execute("DELETE FROM treatment_status_log WHERE treatment_id NOT IN (SELECT id FROM treatment_index)")
    deleted_logs = cursor.rowcount
    print("  Deleted %d status_log rows" % deleted_logs)

    cursor.execute("DELETE FROM treatment_hourly_snapshots WHERE treatment_id NOT IN (SELECT id FROM treatment_index)")
    print("  Deleted %d snapshot rows" % cursor.rowcount)

    cursor.execute("DELETE FROM treatment_config WHERE treatment_id NOT IN (SELECT id FROM treatment_index)")
    print("  Deleted %d config rows" % cursor.rowcount)

    cursor.execute("DELETE FROM treatment_phases WHERE treatment_id NOT IN (SELECT id FROM treatment_index)")
    print("  Deleted %d phase rows" % cursor.rowcount)

    cursor.execute("DELETE FROM treatment_raw_packets WHERE treatment_id NOT IN (SELECT id FROM treatment_index)")
    print("  Deleted %d raw_packet rows" % cursor.rowcount)

    cursor.execute("DELETE FROM snapshot_originals WHERE treatment_id NOT IN (SELECT id FROM treatment_index)")
    print("  Deleted %d snapshot_original rows" % cursor.rowcount)

    cursor.execute("DELETE FROM treatments WHERE id NOT IN (SELECT id FROM treatment_index)")
    print("  Deleted %d orphan treatment rows" % cursor.rowcount)

    db.commit()

    # Delete orphan raw files
    deleted_files = 0
    for f, sz in orphan_files:
        fp = os.path.join(RAW_DIR, f)
        try:
            os.remove(fp)
            deleted_files += 1
        except Exception as e:
            print("  ERROR deleting %s: %s" % (f, e))
    print("  Deleted %d orphan raw files" % deleted_files)

    # VACUUM to reclaim space
    print("  Running VACUUM...")
    db.execute("VACUUM")
    print("  VACUUM complete")

    db.close()

    print("\n" + "=" * 70)
    print("  CLEANUP COMPLETE!")
    print("  DB backed up to: %s" % backup_name)
    print("=" * 70)


if __name__ == "__main__":
    main()
