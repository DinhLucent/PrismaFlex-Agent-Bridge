import os
import sys
import uuid
import asyncio
from datetime import datetime, timezone, timedelta

# Add backend to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__))))
from services.treatment.treatment_database import TreatmentDatabase
from services.treatment.treatment_recorder import TreatmentRecorderService
from services.treatment.raw_streamer import RawDataStreamer

class QA:
    def __init__(self):
        # Use an in-memory DB or temp DB
        self.db_path = ":memory:"
        self.db = TreatmentDatabase(self.db_path)
        self.streamer = RawDataStreamer()
        # Prevent actually writing to disk for tests
        self.streamer.stream_packet = self.mock_stream
        self.recorder = TreatmentRecorderService(self.db, self.streamer)

    async def mock_stream(self, device_id, treatment_id, packet_data):
        pass

    async def run(self):
        print("Running QA Matrix...")
        await self.test_c2a()
        await self.test_c3()
        await self.test_c5()
        await self.test_f6()
        await self.test_f7()
        await self.test_f8()
        print("All tests passed.")

    def assert_eq(self, expected, actual, msg):
        assert expected == actual, f"FAILED: {msg} - Expected {expected}, got {actual}"

    def make_pkt(self, pid, status, run_time, time_str=None):
        ts = time_str or datetime.now(timezone(timedelta(hours=7))).isoformat()
        body = {"parameters": [{"id": 461, "value": run_time}]} if run_time is not None else {"parameters": []}
        return ts, {"patient_id": pid, "therapy_status_id": status, "therapy_type_id_name": "CVVH"}, body, {"timestamp": ts}

    async def test_c2a(self):
        print("Testing C2a...")
        dev = "DEV_C2A"
        # Start T1
        ts1, h, b, m = self.make_pkt("PT1", 5, 100, "2026-04-02T10:00:00+07:00") # RUN
        t1 = await self.recorder.process_packet(dev, ts1, h, b, m, is_live=True)
        # End T1 (10 mins later, so elapsed > 300s)
        ts2, h, b, m = self.make_pkt("PT1", 8, 120, "2026-04-02T10:10:00+07:00") # END
        await self.recorder.process_packet(dev, ts2, h, b, m, is_live=True)
        # Resume T1 (1 min later)
        ts3, h, b, m = self.make_pkt("PT1", 5, 121, "2026-04-02T10:11:00+07:00") # RUN, same patient, run_time > 0
        t2 = await self.recorder.process_packet(dev, ts3, h, b, m, is_live=True)
        self.assert_eq(t1, t2, "C2a should resume same treatment")

    async def test_c3(self):
        print("Testing C3...")
        dev = "DEV_C3"
        # Start T1
        ts1, h, b, m = self.make_pkt("PT1", 5, 100, "2026-04-02T11:00:00+07:00") # RUN
        t1 = await self.recorder.process_packet(dev, ts1, h, b, m, is_live=True)
        # End T1
        ts2, h, b, m = self.make_pkt("PT1", 8, 120, "2026-04-02T11:10:00+07:00") # END
        await self.recorder.process_packet(dev, ts2, h, b, m, is_live=True)
        # New run T2
        ts3, h, b, m = self.make_pkt("PT1", 5, 0, "2026-04-02T11:11:00+07:00") # RUN, same patient, run_time = 0
        t2 = await self.recorder.process_packet(dev, ts3, h, b, m, is_live=True)
        assert t1 != t2, "C3 should start NEW treatment due to RUN_TIME=0"

    async def test_c5(self):
        print("Testing C5...")
        dev = "DEV_C5"
        ts1, h, b, m = self.make_pkt("PTA", 5, 100, "2026-04-02T12:00:00+07:00")
        t1 = await self.recorder.process_packet(dev, ts1, h, b, m, is_live=True)
        # Sudden patient change after 10 mins
        ts2, h, b, m = self.make_pkt("PTB", 5, 10, "2026-04-02T12:10:00+07:00")
        t2 = await self.recorder.process_packet(dev, ts2, h, b, m, is_live=True)
        assert t1 != t2, "C5 should start NEW treatment due to patient change"

    async def test_f6(self):
        print("Testing F6...")
        dev = "DEV_F6"
        ts1, h, b, m = self.make_pkt("PT1", 5, 100, "2026-04-02T13:00:00+07:00")
        t1 = await self.recorder.process_packet(dev, ts1, h, b, m, is_live=False) # Backfill
        ts2, h, b, m = self.make_pkt("PT1", 8, 120, "2026-04-02T13:10:00+07:00") # END
        await self.recorder.process_packet(dev, ts2, h, b, m, is_live=False)
        # Live run, RUN_TIME = 0
        ts3, h, b, m = self.make_pkt("PT1", 5, 0, "2026-04-02T13:11:00+07:00")
        t2 = await self.recorder.process_packet(dev, ts3, h, b, m, is_live=True)
        assert t1 != t2, "F6 should start NEW treatment due to live RUN_TIME=0"

    async def test_f7(self):
        print("Testing F7...")
        # Live device B doesn't close backfill A
        tsA1, hA1, bA1, mA1 = self.make_pkt("PTA", 5, 100, "2026-01-01T10:00:00+07:00")
        tA = await self.recorder.process_packet("DEV_A", tsA1, hA1, bA1, mA1, is_live=False)
        
        tsB, hB, bB, mB = self.make_pkt("PTB", 5, 10, "2026-04-02T10:00:00+07:00")
        await self.recorder.process_packet("DEV_B", tsB, hB, bB, mB, is_live=True)
        # Trigger auto-close
        self.recorder.enforce_auto_close()
        
        # DEV_A should still be active in backfill_sessions because enforce_auto_close doesn't use global clock
        assert "DEV_A" in self.recorder._backfill_sessions, "F7 backfill should not be auto closed by global clock"

    async def test_f8(self):
        print("Testing F8...")
        # Backfill device A advances time by a LOT, device B still in backfill
        tsB1, hB1, bB1, mB1 = self.make_pkt("PTB", 5, 100, "2026-01-01T10:00:00+07:00")
        await self.recorder.process_packet("DEV_B", tsB1, hB1, bB1, mB1, is_live=False)
        
        tsA1, hA1, bA1, mA1 = self.make_pkt("PTA", 5, 10, "2026-04-02T10:00:00+07:00")
        await self.recorder.process_packet("DEV_A", tsA1, hA1, bA1, mA1, is_live=False)
        
        self.recorder.enforce_auto_close()
        assert "DEV_B" in self.recorder._backfill_sessions, "F8 backfill B should not be auto closed by backfill A"

if __name__ == "__main__":
    asyncio.run(QA().run())
