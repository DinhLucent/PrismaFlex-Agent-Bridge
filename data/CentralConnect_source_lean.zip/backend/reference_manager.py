#!/usr/bin/env python3
"""
Reference Database Manager for CRRT form
Provides lookup functions to convert IDs to human-readable values
"""

import sqlite3
import logging
from typing import Dict, Optional, List

logger = logging.getLogger(__name__)

class ReferenceManager:
    """Manager for reference database lookups"""
    
    def __init__(self, db_path: str = "prismaflex_reference.db"):
        self.db_path = db_path
        self._therapy_types_cache = {}
        self._anticoag_methods_cache = {}
        self._filter_types_cache = {}
        self._load_reference_data()
    
    def _load_reference_data(self):
        """Load reference data into cache"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Load therapy types
            cursor.execute("SELECT id, name, description FROM therapy_types")
            for row in cursor.fetchall():
                id_val, name, description = row
                self._therapy_types_cache[id_val] = {
                    'name': name,
                    'description': description,
                    'display': f"{name} ({description})"
                }
            
            # Load anticoagulation methods
            cursor.execute("""
                SELECT ev.value, ev.meaning
                FROM enumerative_values ev
                JOIN enumerative_parameters ep ON ev.parameter_id = ep.id
                WHERE ep.id = 409
            """)
            for row in cursor.fetchall():
                value, meaning = row
                self._anticoag_methods_cache[value] = meaning

            # Load filter types (parameter ID 411)
            cursor.execute("""
                SELECT ev.value, ev.meaning
                FROM enumerative_values ev
                JOIN enumerative_parameters ep ON ev.parameter_id = ep.id
                WHERE ep.id = 411
            """)
            for row in cursor.fetchall():
                value, meaning = row
                self._filter_types_cache[value] = meaning
            
            conn.close()
            logger.info(f"Loaded {len(self._therapy_types_cache)} therapy types, {len(self._anticoag_methods_cache)} anticoag methods, {len(self._filter_types_cache)} filter types")
            
        except Exception as e:
            logger.error(f"Error loading reference data: {e}")
    
    def get_therapy_type_name(self, therapy_id: int) -> str:
        """Get therapy type name from ID"""
        if therapy_id in self._therapy_types_cache:
            return self._therapy_types_cache[therapy_id]['display']
        return f"Unknown Therapy ({therapy_id})"
    
    def get_therapy_type_short(self, therapy_id: int) -> str:
        """Get short therapy type name (abbreviation only)"""
        if therapy_id in self._therapy_types_cache:
            return self._therapy_types_cache[therapy_id]['name']
        return f"T{therapy_id}"
    
    def get_anticoag_method_name(self, method_id: int) -> str:
        """Get anticoagulation method name from ID"""
        if method_id in self._anticoag_methods_cache:
            return self._anticoag_methods_cache[method_id]
        return f"Unknown Method ({method_id})"

    def get_filter_type_name(self, filter_id: int) -> str:
        """Get filter type name from ID"""
        if filter_id in self._filter_types_cache:
            return self._filter_types_cache[filter_id]
        return f"Unknown Filter ({filter_id})"
    
    def get_all_therapy_types(self) -> List[str]:
        """Get all available therapy types for combo box"""
        return [data['display'] for data in self._therapy_types_cache.values()]
    
    def get_all_anticoag_methods(self) -> List[str]:
        """Get all available anticoag methods for combo box"""
        return list(self._anticoag_methods_cache.values())

    def get_all_filter_types(self) -> List[str]:
        """Get all available filter types for combo box"""
        return list(self._filter_types_cache.values())
    
    def get_therapy_id_by_name(self, name: str) -> Optional[int]:
        """Get therapy ID by name (reverse lookup)"""
        for id_val, data in self._therapy_types_cache.items():
            if data['name'] == name or data['display'] == name:
                return id_val
        return None
    
    def get_anticoag_id_by_name(self, name: str) -> Optional[int]:
        """Get anticoag method ID by name (reverse lookup)"""
        for id_val, method_name in self._anticoag_methods_cache.items():
            if method_name == name:
                return id_val
        return None

    def get_filter_id_by_name(self, name: str) -> Optional[int]:
        """Get filter type ID by name (reverse lookup)"""
        for id_val, filter_name in self._filter_types_cache.items():
            if filter_name == name:
                return id_val
        return None


def test_reference_manager():
    """Test reference manager functionality"""
    print("🔍 Testing Reference Manager")
    print("=" * 50)
    
    try:
        ref_mgr = ReferenceManager()
        
        print("📊 Therapy Types:")
        for i in range(6):
            name = ref_mgr.get_therapy_type_name(i)
            short = ref_mgr.get_therapy_type_short(i)
            print(f"   {i}: {short} -> {name}")
        
        print(f"\n🩸 Anticoagulation Methods:")
        for i in range(3):
            method = ref_mgr.get_anticoag_method_name(i)
            print(f"   {i}: {method}")

        print(f"\n🔧 Filter Types:")
        for i in range(10):
            filter_type = ref_mgr.get_filter_type_name(i)
            print(f"   {i}: {filter_type}")
        
        print(f"\n✅ Reference Manager loaded successfully!")
        print(f"   Therapy types: {len(ref_mgr._therapy_types_cache)}")
        print(f"   Anticoag methods: {len(ref_mgr._anticoag_methods_cache)}")
        print(f"   Filter types: {len(ref_mgr._filter_types_cache)}")
        
        # Test reverse lookup
        print(f"\n🔄 Testing reverse lookup:")
        cvvh_id = ref_mgr.get_therapy_id_by_name("CVVH")
        print(f"   'CVVH' -> ID: {cvvh_id}")
        
        citrate_id = ref_mgr.get_anticoag_id_by_name("Cit/Cal (Citrate/Calcium, External pump)")
        print(f"   'Citrate/Calcium' -> ID: {citrate_id}")

        # Test filter lookup (if available)
        if ref_mgr._filter_types_cache:
            first_filter = list(ref_mgr._filter_types_cache.values())[0]
            filter_id = ref_mgr.get_filter_id_by_name(first_filter)
            print(f"   '{first_filter}' -> ID: {filter_id}")
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_reference_manager()
