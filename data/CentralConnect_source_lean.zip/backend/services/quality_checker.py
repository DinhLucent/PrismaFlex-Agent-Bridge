"""
Service for checking data quality (LIVE vs DELAYED).

Prefer the shared telemetry contract so standalone helpers match runtime ingest.
"""
from datetime import datetime
import logging

from .telemetry_contract import LOCAL_TZ, apply_ingest_contract

logger = logging.getLogger(__name__)

# Threshold for considering data as "LIVE" (in seconds)
REALTIME_THRESHOLD_SECONDS = 15


def calculate_data_quality(packet_timestamp_str: str) -> dict:
    """
    Compare packet time vs server time to determine if raw data is LIVE or DELAYED.
    
    Args:
        packet_timestamp_str: Timestamp from the packet (ISO 8601 format)
        
    Returns:
        dict: {
            "quality": "LIVE" | "DELAYED" | "UNKNOWN",
            "latency_sec": float,
            "server_time": str (ISO 8601),
            "error": str (optional)
        }
    """
    try:
        return apply_ingest_contract(
            {"meta": {"timestamp": packet_timestamp_str}},
            realtime_threshold_seconds=REALTIME_THRESHOLD_SECONDS,
        )
    except Exception as e:
        logger.error(f"Error calculating data quality: {e}", exc_info=True)
        return {
            "quality": "UNKNOWN",
            "mode": "UNKNOWN",
            "latency_sec": 0.0,
            "server_time": datetime.now(LOCAL_TZ).isoformat(),
            "error": str(e)
        }


def is_data_live(packet_timestamp_str: str) -> bool:
    """
    Quick check if data is considered LIVE
    
    Args:
        packet_timestamp_str: Timestamp from the packet
        
    Returns:
        bool: True if data is LIVE, False otherwise
    """
    result = calculate_data_quality(packet_timestamp_str)
    return result["quality"] == "LIVE"


def get_latency_seconds(packet_timestamp_str: str) -> float:
    """
    Get latency in seconds
    
    Args:
        packet_timestamp_str: Timestamp from the packet
        
    Returns:
        float: Latency in seconds
    """
    result = calculate_data_quality(packet_timestamp_str)
    return result["latency_sec"]
