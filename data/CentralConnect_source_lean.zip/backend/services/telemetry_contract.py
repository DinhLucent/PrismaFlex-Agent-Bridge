"""
Shared telemetry ingest contract for PrismaFlex packets.

This module gives Dashboard, Snap, and Raw one canonical view of:
- device identity
- packet time
- LIVE/BACKFILL mode

Clinical convention:
- PrismaFlex machine strings are often emitted as local GMT+7 wall-clock time
  but mislabeled as ``UTC`` by upstream decode/Mirth transforms.
- When a precise unix epoch is present, it is authoritative.
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

import dateutil.parser


LOCAL_TZ = timezone(timedelta(hours=7))
_DEVICE_PATTERN = re.compile(r"^PF[_-]?(\d+)$", re.IGNORECASE)
_NUMERIC_PATTERN = re.compile(r"^-?\d+(?:\.\d+)?$")
_EPOCH_MS_THRESHOLD = 1_000_000_000_000


def normalize_device_id(raw_device_id: Any = None, machine_id: Any = None) -> str:
    """Return one canonical device id string, e.g. ``PF_004``."""
    if machine_id not in (None, ""):
        try:
            return f"PF_{int(machine_id):03d}"
        except (TypeError, ValueError):
            pass

    if raw_device_id is None:
        return "unknown"

    text = str(raw_device_id).strip()
    if not text:
        return "unknown"

    match = _DEVICE_PATTERN.match(text)
    if match:
        return f"PF_{int(match.group(1)):03d}"

    if text.isdigit():
        return f"PF_{int(text):03d}"

    return text.upper()


def _parse_epoch(value: Any) -> Optional[datetime]:
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return None

    if numeric > _EPOCH_MS_THRESHOLD:
        numeric /= 1000.0

    try:
        return datetime.fromtimestamp(numeric, tz=timezone.utc).astimezone(LOCAL_TZ)
    except (OverflowError, OSError, ValueError):
        return None


def parse_clinical_timestamp(value: Any, default: Optional[datetime] = None) -> datetime:
    """
    Parse PrismaFlex packet time into a GMT+7 aware datetime.

    Precedence rules are handled by ``resolve_packet_time``. This parser only
    interprets one value.
    """
    fallback = default or datetime.now(LOCAL_TZ)

    if isinstance(value, datetime):
        if value.tzinfo is None:
            return value.replace(tzinfo=LOCAL_TZ)
        return value.astimezone(LOCAL_TZ)

    if isinstance(value, (int, float)) and not isinstance(value, bool):
        parsed = _parse_epoch(value)
        return parsed or fallback

    if value is None:
        return fallback

    text = str(value).strip()
    if not text:
        return fallback

    if _NUMERIC_PATTERN.fullmatch(text):
        parsed = _parse_epoch(text)
        if parsed is not None:
            return parsed

    try:
        if text.endswith(" UTC"):
            # Decoder/Mirth often labels a local clinical wall-clock as UTC.
            parsed = dateutil.parser.parse(text[:-4].strip())
            return parsed.replace(tzinfo=LOCAL_TZ)

        if text.endswith("Z"):
            parsed = dateutil.parser.parse(text[:-1])
            return parsed.replace(tzinfo=LOCAL_TZ)

        parsed = dateutil.parser.parse(text)
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=LOCAL_TZ)
        return parsed.astimezone(LOCAL_TZ)
    except Exception:
        return fallback


def resolve_packet_time(packet: Dict[str, Any]) -> Dict[str, Any]:
    """Resolve authoritative packet time with source attribution."""
    meta = packet.get("meta", {}) or {}
    header = packet.get("s_header") or packet.get("header") or {}

    # Clinical strings from PrismaFlex/Mirth are the safest source in this stack.
    # Several upstream paths derive timestamp_unix by parsing a string that is
    # already mislabeled as UTC, which shifts the epoch +7h for Vietnam.
    #
    # Resolution strategy:
    # 1. Prefer explicit clinical timestamp strings.
    # 2. Fall back to unix epoch only when string fields are missing.
    candidates = [
        ("meta.timestamp", meta.get("timestamp")),
        ("header.timestamp", header.get("timestamp")),
        ("packet.timestamp", packet.get("timestamp")),
        ("meta.timestamp_unix", meta.get("timestamp_unix")),
        ("header.timestamp_unix", header.get("timestamp_unix")),
    ]

    for source, raw_value in candidates:
        if raw_value in (None, ""):
            continue
        parsed = parse_clinical_timestamp(raw_value)
        return {
            "datetime": parsed,
            "packet_time": parsed.isoformat(),
            "packet_time_source": source,
            "raw_value": raw_value,
        }

    now = datetime.now(LOCAL_TZ)
    return {
        "datetime": now,
        "packet_time": now.isoformat(),
        "packet_time_source": "server.now",
        "raw_value": None,
    }


def resolve_mode_and_quality(
    packet: Dict[str, Any],
    *,
    realtime_threshold_seconds: int = 25,
    now: Optional[datetime] = None,
    resolved_time: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Resolve effective ingest mode.

    Contract:
    - Trust explicit Mirth ``meta.mode`` when present.
    - Otherwise infer from packet latency against local clinical time.
    """
    meta = packet.get("meta", {}) or {}
    resolved_time = resolved_time or resolve_packet_time(packet)
    packet_time = resolved_time["datetime"]
    server_now = (now or datetime.now(LOCAL_TZ)).astimezone(LOCAL_TZ)
    latency = round((server_now - packet_time).total_seconds(), 2)

    raw_mode = str(meta.get("mode") or meta.get("ingest_mode") or "").strip().upper()
    if raw_mode in {"LIVE", "BACKFILL"}:
        mode = raw_mode
        quality = "LIVE" if mode == "LIVE" else "DELAYED"
        quality_source = "meta.mode"
    else:
        if latency < -realtime_threshold_seconds:
            mode = "UNKNOWN"
            quality = "UNKNOWN"
        elif latency <= realtime_threshold_seconds:
            mode = "LIVE"
            quality = "LIVE"
        else:
            mode = "BACKFILL"
            quality = "DELAYED"
        quality_source = "latency"

    return {
        "quality": quality,
        "mode": mode,
        "latency_sec": latency,
        "server_time": server_now.isoformat(),
        "packet_time": resolved_time["packet_time"],
        "packet_time_source": resolved_time["packet_time_source"],
        "quality_source": quality_source,
    }


def apply_ingest_contract(packet: Dict[str, Any], *, realtime_threshold_seconds: int = 25) -> Dict[str, Any]:
    """
    Normalize one packet in place for downstream processing.

    This keeps the original forensic values under ``meta.original_*`` when we
    need to canonicalize device id or timestamp for runtime behavior.
    """
    meta = packet.setdefault("meta", {})
    header = packet.get("s_header") or packet.get("header") or {}

    canonical_device_id = normalize_device_id(meta.get("device_id"), header.get("machine_id"))
    previous_device_id = meta.get("device_id")
    if previous_device_id not in (None, "", canonical_device_id):
        meta.setdefault("original_device_id", previous_device_id)
    meta["device_id"] = canonical_device_id

    resolved_time = resolve_packet_time(packet)
    previous_timestamp = meta.get("timestamp")
    if previous_timestamp not in (None, "", resolved_time["packet_time"]):
        meta.setdefault("original_timestamp", previous_timestamp)
    meta["timestamp"] = resolved_time["packet_time"]
    meta["timestamp_source"] = resolved_time["packet_time_source"]

    if meta.get("timestamp_unix") is None and resolved_time["packet_time_source"] == "header.timestamp_unix":
        meta["timestamp_unix"] = header.get("timestamp_unix")

    quality_info = resolve_mode_and_quality(
        packet,
        realtime_threshold_seconds=realtime_threshold_seconds,
        resolved_time=resolved_time,
    )
    meta["mode_resolved"] = quality_info["mode"]
    return quality_info
