"""
Smart Alarm Service
====================
Clinical-grade alarm debouncing with 5-minute cooldown,
server restart recovery, and network blackout handling.

Usage:
    alarm_svc = SmartAlarmService(db)
    alarm_svc.process(device_id, current_alarms, packet_timestamp, patient_id)
"""
import logging
from datetime import datetime, timezone, timedelta
from typing import Dict
import dateutil.parser

from .database import TrendDatabase

logger = logging.getLogger("PrismaFlexBackend")

# --- Constants ---
ALARM_CLEAR_THRESHOLD_SEC = 300  # 5 minutes wait before declaring clear


class SmartAlarmService:
    """
    Manages alarm debouncing, state recovery, and blackout handling.
    Extracted from main.py for clarity and testability.
    """

    def __init__(self, db: TrendDatabase):
        self._db = db
        # device_id -> { alarm_id: { title, severity, start_time, recovered? } }
        self._active_alarms: Dict[str, Dict[int, Dict]] = {}
        # device_id -> { alarm_id: datetime_first_missing }
        self._pending_clears: Dict[str, Dict[int, datetime]] = {}
        # Track last known broadcast time per device (for blackout detection)
        self._device_last_broadcast: Dict[str, datetime] = {}

    def set_last_broadcast(self, device_id: str, time: datetime):
        """Called externally to update the last broadcast time for blackout detection."""
        self._device_last_broadcast[device_id] = time

    def process(self, device_id: str, current_alarms_list: list,
                packet_timestamp_str: str, patient_id: str = "Unknown"):
        """
        Main entry point. Process alarms for a single device packet.
        Handles debouncing, state recovery, and blackout resilience.
        """
        try:
            # Parse packet timestamp (clinical accuracy)
            now = self._parse_timestamp(packet_timestamp_str)
            timestamp_str = now.isoformat()

            # State Recovery: Load orphaned alarms from DB on first contact
            is_first_contact = device_id not in self._active_alarms
            if is_first_contact:
                self._init_device(device_id)
                self._recover_orphans(device_id, now)

            active_map = self._active_alarms[device_id]
            pending_map = self._pending_clears[device_id]
            current_set = {a["id"]: a for a in current_alarms_list if a["state"] == "PRESENT"}

            # Recovery Logic: Close orphaned alarms not present on reconnect
            if is_first_contact:
                self._close_missing_orphans(device_id, active_map, current_set, timestamp_str)

            # 1. Check existing active alarms (did they disappear?)
            self._process_active_alarms(device_id, active_map, pending_map,
                                        current_set, now, timestamp_str)

            # 2. Register new alarms
            self._register_new_alarms(device_id, active_map, current_set,
                                      now, timestamp_str, patient_id)

        except Exception as e:
            logger.error(f"Smart Alarm Error: {e}")

    # ─── Private Helpers ───────────────────────────────────────────

    def _parse_timestamp(self, timestamp_str: str) -> datetime:
        """Parse packet timestamp with clinical-grade timezone shift (GMT+7)."""
        local_tz = timezone(timedelta(hours=7))
        try:
            dt = dateutil.parser.parse(timestamp_str)
            if dt.tzinfo is None:
                return dt.replace(tzinfo=local_tz)
            else:
                return dt.astimezone(local_tz)
        except Exception:
            return datetime.now(local_tz)

    def _init_device(self, device_id: str):
        """Initialize in-memory state for a new device."""
        self._active_alarms[device_id] = {}
        self._pending_clears[device_id] = {}

    def _recover_orphans(self, device_id: str, now: datetime):
        """Load active alarms from DB that were never closed (server restart recovery)."""
        try:
            orphaned = self._db.get_orphaned_alarms(device_id)
            for aid, title, severity, start_t in orphaned:
                logger.info(f"🔄 Recovering Active Alarm from DB: [{aid}] {title}")
                try:
                    st = dateutil.parser.isoparse(start_t)
                except:
                    st = now

                self._active_alarms[device_id][aid] = {
                    "title": title,
                    "severity": severity,
                    "start_time": st,
                    "recovered": True
                }
        except Exception as e:
            logger.error(f"Recovery Error: {e}")

    def _close_missing_orphans(self, device_id: str, active_map: dict,
                               current_set: dict, timestamp_str: str):
        """On first contact, close orphaned alarms not present in current packet."""
        for aid in list(active_map.keys()):
            if aid not in current_set:
                logger.info(f"🏁 Closing Orphaned Alarm (not found on reconnect): [{aid}]")
                self._db.close_alarm(device_id, aid, timestamp_str)
                del active_map[aid]

    def _process_active_alarms(self, device_id: str, active_map: dict,
                               pending_map: dict, current_set: dict,
                               now: datetime, timestamp_str: str):
        """Check if active alarms disappeared or came back."""
        for aid in list(active_map.keys()):
            if aid not in current_set:
                # Alarm is MISSING from this packet
                if aid not in pending_map:
                    # First time missing → start timer
                    pending_map[aid] = now
                else:
                    # Already pending → check duration
                    gone_duration = (now - pending_map[aid]).total_seconds()

                    # Blackout Resilience: If reconnecting after >5m silence
                    last_broadcast = self._device_last_broadcast.get(device_id, now)
                    is_reconnection = (now - last_broadcast).total_seconds() > 300

                    if gone_duration > ALARM_CLEAR_THRESHOLD_SEC or is_reconnection:
                        # CONFIRMED CLEAR
                        alarm_info = active_map[aid]
                        actual_end_str = pending_map[aid].isoformat()
                        self._db.close_alarm(device_id, aid, actual_end_str)

                        from .event_service import EventService
                        EventService.log_device_alarm(
                            device_id,
                            f"CLEARED: [{aid}] {alarm_info['title']} (Resilient Cleared)",
                            "INFO"
                        )

                        del active_map[aid]
                        del pending_map[aid]
            else:
                # Alarm is STILL PRESENT → cancel pending clear
                if aid in pending_map:
                    del pending_map[aid]

    def _register_new_alarms(self, device_id: str, active_map: dict,
                             current_set: dict, now: datetime,
                             timestamp_str: str, patient_id: str):
        """Register new alarms that weren't previously tracked."""
        for aid, alarm_obj in current_set.items():
            if aid not in active_map:
                # New Alarm!
                active_map[aid] = {
                    "title": alarm_obj["title"],
                    "severity": alarm_obj["severity"],
                    "start_time": now
                }
                self._db.insert_alarm(
                    device_id, aid, alarm_obj["title"],
                    alarm_obj["severity"], timestamp_str, patient_id
                )

                from .event_service import EventService
                EventService.log_device_alarm(
                    device_id,
                    f"START: [{aid}] {alarm_obj['title']} (Patient: {patient_id})",
                    alarm_obj["severity"]
                )
