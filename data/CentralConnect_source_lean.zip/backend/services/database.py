"""
Centralized SQLite Database Service
====================================
Manages a single persistent connection for all trend data operations.
WAL mode enabled for concurrent read/write support (10+ devices).

Usage:
    db = TrendDatabase()
    db.insert_trend(...)
    db.close()
"""
import sqlite3
import os
import logging
import threading
import random
from typing import Dict, Optional
from datetime import datetime, timezone, timedelta

logger = logging.getLogger("PrismaFlexBackend")
LOCAL_TZ = timezone(timedelta(hours=7))
LEGACY_UTC_SHIFT = timedelta(hours=7)
FUTURE_SKEW_TOLERANCE = timedelta(minutes=2)

# --- Database Path ---
# --- Database Path ---
TREND_DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'trends.db')
OLD_DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data', 'trends.db')


class TrendDatabase:
    """
    Thread-safe SQLite wrapper with persistent connection.
    Replaces per-request connect/close pattern.
    """

    def __init__(self, db_path: str = TREND_DB_PATH):
        self._db_path = db_path
        self._lock = threading.Lock()
        self._insert_counters: Dict[str, int] = {} # Tracks inserts per device for lazy pruning
        
        # 1. Path Migration (V1 -> V2)
        self._migrate_old_database()
        
        # 2. Connection with Corruption Recovery
        try:
            self._conn = self._create_connection()
            # Test integrity early
            self._conn.execute("SELECT 1").fetchone()
        except sqlite3.DatabaseError as e:
            if "malformed" in str(e).lower():
                logger.error(f"🚨 Database Corrupted: {self._db_path}. Recovering...")
                self._handle_corruption()
                self._conn = self._create_connection()
            else:
                raise e

        # 3. Initialization
        self._init_tables()
        self.repair_future_timezone_skew()
        self.prune()  # Lean Mode: Clear old data on startup
        logger.info(f"TrendDatabase initialized: {db_path}")

    def _migrate_old_database(self):
        """Move database from old 'data/' folder to 'backend/' if needed."""
        if not os.path.exists(self._db_path) and os.path.exists(OLD_DB_PATH):
            try:
                logger.info(f"Migrating database from {OLD_DB_PATH} to {self._db_path}")
                os.makedirs(os.path.dirname(self._db_path), exist_ok=True)
                import shutil
                shutil.copy2(OLD_DB_PATH, self._db_path)
                logger.info("Migration Successful.")
            except Exception as e:
                logger.error(f"Migration Failed: {e}")

    def _handle_corruption(self):
        """Move corrupted DB to backup and start fresh."""
        corrupt_backup = self._db_path + f".corrupt.{int(datetime.now().timestamp())}"
        try:
            if os.path.exists(self._db_path):
                os.rename(self._db_path, corrupt_backup)
                logger.warning(f"⚠️ Malformed DB moved to: {corrupt_backup}")
            
            # Also clean up journal files
            for ext in ["-wal", "-shm", "-journal"]:
                if os.path.exists(self._db_path + ext):
                    os.remove(self._db_path + ext)
        except Exception as e:
            logger.error(f"🔥 Critical Failure handling corruption: {e}")

    def _create_connection(self) -> sqlite3.Connection:
        """Create an optimized SQLite connection."""
        conn = sqlite3.connect(self._db_path, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=5000")  # Wait up to 5s instead of failing
        return conn

    def _parse_db_timestamp(self, raw_value: str) -> Optional[datetime]:
        if raw_value is None:
            return None

        text = str(raw_value).strip()
        if not text:
            return None

        if text.endswith("Z"):
            text = text[:-1] + "+00:00"

        try:
            parsed = datetime.fromisoformat(text)
        except ValueError:
            return None

        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=LOCAL_TZ)
        return parsed.astimezone(LOCAL_TZ)

    def _shift_timestamp_if_future(self, raw_value: str, now_local: datetime) -> Optional[str]:
        parsed = self._parse_db_timestamp(raw_value)
        if parsed is None:
            return None

        if parsed <= now_local + FUTURE_SKEW_TOLERANCE:
            return None

        shifted = parsed - LEGACY_UTC_SHIFT
        if shifted <= now_local + FUTURE_SKEW_TOLERANCE:
            return shifted.isoformat()

        return None

    def _init_tables(self):
        """Create all required tables and indexes."""
        with self._lock:
            c = self._conn.cursor()

            # Pressure Trends
            c.execute('''CREATE TABLE IF NOT EXISTS pressure_trends
                         (device_id TEXT, timestamp TEXT, 
                          access REAL, filter REAL, effluent REAL, return REAL, tmp REAL)''')
            # Migration: Add tmp if missing
            try:
                c.execute("ALTER TABLE pressure_trends ADD COLUMN tmp REAL")
            except:
                pass
            # Migration: Add delta_p if missing (ΔP = ID 7)
            try:
                c.execute("ALTER TABLE pressure_trends ADD COLUMN delta_p REAL")
            except:
                pass
            c.execute('''CREATE INDEX IF NOT EXISTS idx_device_time 
                         ON pressure_trends (device_id, timestamp)''')

            # Parameter Change Events ("Was" Logic)
            c.execute('''CREATE TABLE IF NOT EXISTS parameter_events
                         (device_id TEXT, timestamp TEXT, param_id INTEGER, 
                          old_value TEXT, new_value TEXT)''')
            c.execute('''CREATE INDEX IF NOT EXISTS idx_events_device_time 
                         ON parameter_events (device_id, timestamp)''')

            # Smart Alarm History
            c.execute('''CREATE TABLE IF NOT EXISTS alarm_history
                         (device_id TEXT, alarm_id INTEGER, title TEXT, 
                          severity TEXT, start_time TEXT, end_time TEXT,
                          patient_id TEXT)''')
            # Migration: Add patient_id if missing
            try:
                c.execute("ALTER TABLE alarm_history ADD COLUMN patient_id TEXT")
            except:
                pass
            c.execute('''CREATE INDEX IF NOT EXISTS idx_alarms_device 
                         ON alarm_history (device_id, start_time)''')

            # Device Sessions (Persistent Patient ID for reset logic)
            c.execute('''CREATE TABLE IF NOT EXISTS device_sessions
                         (device_id TEXT PRIMARY KEY, last_patient_id TEXT)''')

            # Feedback
            c.execute('''CREATE TABLE IF NOT EXISTS feedback
                         (id TEXT PRIMARY KEY, user TEXT, content TEXT, 
                          timestamp TEXT, status TEXT)''')

            self._conn.commit()

    # ─── Core Execute Methods ──────────────────────────────────────

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        """Thread-safe execute with auto-commit for writes."""
        with self._lock:
            c = self._conn.cursor()
            c.execute(sql, params)
            if sql.strip().upper().startswith(("INSERT", "UPDATE", "DELETE")):
                self._conn.commit()
            return c

    def execute_many(self, sql: str, params_list: list):
        """Thread-safe batch execute with single commit."""
        with self._lock:
            c = self._conn.cursor()
            c.executemany(sql, params_list)
            self._conn.commit()

    def fetch_all(self, sql: str, params: tuple = ()) -> list:
        """Thread-safe query returning all rows."""
        with self._lock:
            c = self._conn.cursor()
            c.execute(sql, params)
            return c.fetchall()

    def fetch_one(self, sql: str, params: tuple = ()) -> tuple | None:
        """Thread-safe query returning first row."""
        with self._lock:
            c = self._conn.cursor()
            c.execute(sql, params)
            return c.fetchone()

    # ─── Trend Operations ──────────────────────────────────────────

    def insert_trend(self, device_id: str, timestamp: str,
                     access: float, filter_p: float, effluent: float, return_p: float,
                     tmp: float = 0.0, delta_p: float = 0.0):
        """Insert a pressure trend data point and deterministically cap the rolling buffer to 1000 rows per device."""
        with self._lock:
            c = self._conn.cursor()
            # Insert the new data point using explicit columns to avoid schema mismatch errors
            c.execute(
                """INSERT INTO pressure_trends 
                   (device_id, timestamp, access, filter, effluent, return, tmp, delta_p) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (device_id, timestamp, access, filter_p, effluent, return_p, tmp, delta_p)
            )

            counter = self._insert_counters.get(device_id, 0) + 1
            self._insert_counters[device_id] = counter
            if counter > 1000:
                c.execute(
                    """DELETE FROM pressure_trends
                       WHERE rowid NOT IN (
                           SELECT rowid FROM pressure_trends
                           WHERE device_id = ?
                           ORDER BY rowid DESC LIMIT 1000
                       ) AND device_id = ?""",
                    (device_id, device_id)
                )

            self._conn.commit()

    def repair_future_timezone_skew(self, device_id: str | None = None) -> dict[str, int]:
        """
        Repair legacy dashboard rows that landed +7h in the future because a
        local clinical wall-clock was mislabeled as UTC upstream.

        Only rows still in the future are shifted, which keeps the fix scoped
        to obviously broken runtime data.
        """
        now_local = datetime.now(LOCAL_TZ)
        counts = {
            "pressure_trends": 0,
            "parameter_events": 0,
            "alarm_history_start": 0,
            "alarm_history_end": 0,
        }

        with self._lock:
            c = self._conn.cursor()

            where = " WHERE device_id = ?" if device_id else ""
            params = (device_id,) if device_id else ()

            trend_rows = c.execute(
                f"SELECT rowid, timestamp FROM pressure_trends{where}",
                params,
            ).fetchall()
            for rowid, raw_ts in trend_rows:
                shifted = self._shift_timestamp_if_future(raw_ts, now_local)
                if shifted is None:
                    continue
                c.execute("UPDATE pressure_trends SET timestamp = ? WHERE rowid = ?", (shifted, rowid))
                counts["pressure_trends"] += 1

            event_rows = c.execute(
                f"SELECT rowid, timestamp FROM parameter_events{where}",
                params,
            ).fetchall()
            for rowid, raw_ts in event_rows:
                shifted = self._shift_timestamp_if_future(raw_ts, now_local)
                if shifted is None:
                    continue
                c.execute("UPDATE parameter_events SET timestamp = ? WHERE rowid = ?", (shifted, rowid))
                counts["parameter_events"] += 1

            alarm_rows = c.execute(
                f"SELECT rowid, start_time, end_time FROM alarm_history{where}",
                params,
            ).fetchall()
            for rowid, start_time, end_time in alarm_rows:
                shifted_start = self._shift_timestamp_if_future(start_time, now_local)
                shifted_end = self._shift_timestamp_if_future(end_time, now_local) if end_time else None

                if shifted_start is not None:
                    c.execute("UPDATE alarm_history SET start_time = ? WHERE rowid = ?", (shifted_start, rowid))
                    counts["alarm_history_start"] += 1
                if shifted_end is not None:
                    c.execute("UPDATE alarm_history SET end_time = ? WHERE rowid = ?", (shifted_end, rowid))
                    counts["alarm_history_end"] += 1

            self._conn.commit()

        total = sum(counts.values())
        if total:
            scope = device_id or "ALL"
            logger.warning(
                f"Repaired legacy +7h dashboard rows for {scope}: "
                f"trends={counts['pressure_trends']}, "
                f"events={counts['parameter_events']}, "
                f"alarm_start={counts['alarm_history_start']}, "
                f"alarm_end={counts['alarm_history_end']}"
            )
        return counts

    def get_trends(self, device_id: str, limit: int = 500) -> list:
        """Get latest trend points for a device (default: last 500 = ~2 hours)."""
        rows = self.fetch_all(
            """SELECT timestamp, access, filter, effluent, return, tmp, delta_p 
               FROM pressure_trends 
               WHERE device_id = ? ORDER BY timestamp DESC LIMIT ?""",
            (device_id, limit)
        )
        return [
            {"timestamp": r[0], "access": r[1], "filter": r[2], "effluent": r[3], "return": r[4],
             "tmp": r[5] if len(r) > 5 else 0, "delta_p": r[6] if len(r) > 6 else 0}
            for r in reversed(rows)
        ]

    # ─── Event Operations ──────────────────────────────────────────

    def insert_events(self, device_id: str, timestamp: str, changes: list):
        """Batch insert parameter change events. changes = [(param_id, old_val, new_val), ...]"""
        self.execute_many(
            "INSERT INTO parameter_events VALUES (?, ?, ?, ?, ?)",
            [(device_id, timestamp, str(pid), str(old_v), str(new_v)) for pid, old_v, new_v in changes]
        )

    def get_events(self, device_id: str) -> list:
        """Get parameter changes in the last 1 hour."""
        from datetime import datetime, timezone, timedelta
        # Calculate cutoff in ISO format to match stored timestamps
        cutoff = (datetime.now(timezone(timedelta(hours=7))) - timedelta(hours=1)).isoformat()
        rows = self.fetch_all(
            """SELECT timestamp, param_id, old_value, new_value 
               FROM parameter_events 
               WHERE device_id = ? AND timestamp > ?
               ORDER BY timestamp DESC""",
            (device_id, cutoff)
        )
        return [
            {"timestamp": r[0], "param_id": r[1], "old_value": r[2], "new_value": r[3]}
            for r in rows
        ]

    def purge_device_history(self, device_id: str):
        """Delete all trends, events, and alarm history for a device (patient change)."""
        self.execute("DELETE FROM pressure_trends WHERE device_id = ?", (device_id,))
        self.execute("DELETE FROM parameter_events WHERE device_id = ?", (device_id,))
        self.execute("DELETE FROM alarm_history WHERE device_id = ?", (device_id,))
        self.execute("DELETE FROM device_sessions WHERE device_id = ?", (device_id,))

    def get_last_patient_id(self, device_id: str) -> str | None:
        """Get the last known patient ID for session validation."""
        row = self.fetch_one("SELECT last_patient_id FROM device_sessions WHERE device_id = ?", (device_id,))
        return row[0] if row else None

    def update_patient_session(self, device_id: str, patient_id: str):
        """Persist the current patient ID to detect future transitions."""
        self.execute(
            "INSERT OR REPLACE INTO device_sessions (device_id, last_patient_id) VALUES (?, ?)",
            (device_id, patient_id)
        )

    # ─── Alarm Operations ──────────────────────────────────────────

    def get_orphaned_alarms(self, device_id: str) -> list:
        """Get active alarms (no end_time) for state recovery."""
        return self.fetch_all(
            "SELECT alarm_id, title, severity, start_time FROM alarm_history WHERE device_id = ? AND end_time IS NULL",
            (device_id,)
        )

    def insert_alarm(self, device_id: str, alarm_id: int, title: str,
                     severity: str, start_time: str, patient_id: str):
        """Record a new alarm start."""
        self.execute(
            "INSERT INTO alarm_history VALUES (?, ?, ?, ?, ?, ?, ?)",
            (device_id, alarm_id, title, severity, start_time, None, patient_id)
        )

    def close_alarm(self, device_id: str, alarm_id: int, end_time: str):
        """Mark an alarm as cleared."""
        self.execute(
            "UPDATE alarm_history SET end_time = ? WHERE device_id = ? AND alarm_id = ? AND end_time IS NULL",
            (end_time, device_id, alarm_id)
        )

    def get_alarm_history(self, device_id: str, limit: int = 100) -> list:
        """Get alarm history for a device."""
        rows = self.fetch_all(
            """SELECT start_time, end_time, title, severity, patient_id, alarm_id 
               FROM alarm_history 
               WHERE device_id = ? ORDER BY start_time DESC LIMIT ?""",
            (device_id, limit)
        )
        return [
            {"start_time": r[0], "end_time": r[1], "title": r[2],
             "severity": r[3], "patient_id": r[4], "alarm_id": r[5]}
            for r in rows
        ]

    # ─── Feedback Operations ───────────────────────────────────────

    def get_all_feedback(self) -> list:
        rows = self.fetch_all("SELECT id, user, content, timestamp, status FROM feedback ORDER BY id DESC")
        return [{"id": r[0], "user": r[1], "content": r[2], "timestamp": r[3], "status": r[4]} for r in rows]

    def insert_feedback(self, fid: str, user: str, content: str, timestamp: str, status: str):
        self.execute("INSERT INTO feedback (id, user, content, timestamp, status) VALUES (?, ?, ?, ?, ?)",
                     (fid, user, content, timestamp, status))

    def delete_feedback(self, feedback_id: str):
        self.execute("DELETE FROM feedback WHERE id = ?", (feedback_id,))

    def update_feedback_status(self, feedback_id: str, status: str):
        self.execute("UPDATE feedback SET status = ? WHERE id = ?", (status, feedback_id))

    # ─── Maintenance ───────────────────────────────────────────────

    def prune(self):
        """
        Clinical-Grade Retention Policy:
        1. Pressure Trends: Keep latest 1000 per device (~4-6 hours).
        2. Parameter Events: Keep last 48 hours for clinical review.
        3. Alarm History: Keep last 90 days (Mandatory audit trail).
        """
        try:
            tz = timezone(timedelta(hours=7))
            now = datetime.now(tz)
            cutoff_events = (now - timedelta(days=2)).isoformat()
            cutoff_alarms = (now - timedelta(days=90)).isoformat()
            
            with self._lock:
                c = self._conn.cursor()
                
                # A. Per-Device Trend Pruning (Rolling 1000)
                # First, find all device_ids to avoid universal scan
                c.execute("SELECT DISTINCT device_id FROM pressure_trends")
                devices = [row[0] for row in c.fetchall()]
                
                for d_id in devices:
                    c.execute(
                        """DELETE FROM pressure_trends 
                           WHERE rowid NOT IN (
                               SELECT rowid FROM pressure_trends 
                               WHERE device_id = ? 
                               ORDER BY rowid DESC LIMIT 1000
                           ) AND device_id = ?""",
                        (d_id, d_id)
                    )

                # B. Time-based Event & Alarm pruning
                c.execute("DELETE FROM parameter_events WHERE timestamp < ?", (cutoff_events,))
                c.execute("DELETE FROM alarm_history WHERE start_time < ?", (cutoff_alarms,))
                
                # C. Performance: Only VACUUM if we removed a lot (expensive)
                total_deleted = c.rowcount
                self._conn.commit()
                
                if total_deleted > 100:
                    logger.info(f"🧹 Database Pruning: Optimized storage. Freed records.")
                    
                # D. Rare deep maintenance (1 in 100 prunes = every ~10,000 packets)
                if random.randint(1, 100) == 1:
                    logger.info("⚡ Running SQLite VACUUM (Deep Storage Optimization)...")
                    self._conn.execute("VACUUM")
                    
        except Exception as e:
            logger.error(f"Pruning Error: {e}")

    def close(self):
        """Close the database connection."""
        with self._lock:
            if self._conn:
                self._conn.close()
                logger.info("TrendDatabase connection closed.")
