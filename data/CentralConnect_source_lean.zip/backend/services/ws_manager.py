"""
WebSocket Connection Manager
=============================
Manages WebSocket connections with parallel broadcast.
Uses asyncio.gather() for concurrent message delivery.

Usage:
    manager = ConnectionManager()
    await manager.connect(websocket)
    await manager.broadcast({"type": "UPDATE", ...})
"""
import asyncio
import logging
from typing import List, Dict, Any
from fastapi import WebSocket

logger = logging.getLogger("PrismaFlexBackend")


class ConnectionManager:
    """
    WebSocket connection manager with parallel broadcast.
    Replaces sequential send_json loop.
    """

    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        """Accept and register a new WebSocket connection."""
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"New Client Connected. Total: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        """Remove a disconnected WebSocket."""
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
            logger.info(f"Client Disconnected. Total: {len(self.active_connections)}")

    async def broadcast(self, message: Dict[str, Any]):
        """
        Send message to ALL connected clients in parallel.
        Uses asyncio.gather() instead of sequential loop.
        Dead connections are automatically cleaned up.
        """
        if not self.active_connections:
            return

        async def _safe_send(ws: WebSocket) -> WebSocket | None:
            """Send to one client, return the socket if it failed."""
            try:
                await ws.send_json(message)
                return None
            except Exception:
                return ws

        # Fire all sends concurrently
        results = await asyncio.gather(
            *[_safe_send(ws) for ws in self.active_connections],
            return_exceptions=True
        )

        # Cleanup dead connections
        for result in results:
            if isinstance(result, WebSocket):
                self.disconnect(result)

    @property
    def client_count(self) -> int:
        """Number of active connections."""
        return len(self.active_connections)
