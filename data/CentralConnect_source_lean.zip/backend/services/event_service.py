"""
Event & Trend Service
======================
Handles parameter change tracking ("Was" indicator),
pressure trend storage, and clinical alarm logging.

Usage:
    event_svc = EventService(db)
    event_svc.track_parameter_changes(device_id, timestamp, header, body)
    event_svc.save_trend_point(device_id, timestamp, params)
"""
import os
import logging
from datetime import datetime
from typing import Dict, Any

from .database import TrendDatabase

logger = logging.getLogger("PrismaFlexBackend")

# --- Constants ---
# Only track clinically relevant params that are shown in UI
# Excluded: Pressures (1-4, 6) - too volatile, Time counters (59, 415, 461) - too frequent
TRACKED_PARAM_IDS = {
    17, 22, 21, 19, 18, 24, 414, 413, 410, 412, 409, 37, 38, 400, 406, 460, 47, 411,
}

LOGS_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ALARM_LOGS'))
if not os.path.exists(LOGS_DIR):
    os.makedirs(LOGS_DIR)


class EventService:
    """
    Manages parameter change detection and trend data persistence.
    Extracted from main.py for clarity.
    """

    def __init__(self, db: TrendDatabase):
        self._db = db
        # Cache: { device_id: { param_id: display_value } }
        self._param_cache: Dict[str, Dict[Any, Any]] = {}

        # Callback for external cleanup (e.g., alarm service cache reset)
        self.on_session_reset = None  # set externally: fn(device_id)

    # ─── Session Reset States ──────────────────────────────────────
    STOPPED_STATES = {0, 6, 7, 8}   # Idle, Paused, Stopped, End
    RUNNING_STATES = {1, 2, 3, 4, 5, 10, 11, 12, 13, 14, 15}

    def _purge_session(self, device_id: str, reason: str):
        """Clear all cached and stored data for a device session."""
        logger.info(f"🔄 Session Reset [{device_id}]: {reason}. Purging history.")
        self._db.purge_device_history(device_id)
        current = self._param_cache.get(device_id, {})
        old_pid = current.get("patient_id")
        current.clear()
        if old_pid:
            current["patient_id"] = old_pid
        self._param_cache[device_id] = current
        # Notify external services (e.g., alarm service)
        if self.on_session_reset:
            self.on_session_reset(device_id)

    def track_parameter_changes(self, device_id: str, timestamp: str,
                                header: dict, body: dict):
        """
        Compare current values with cached values.
        If changed, save to DB for the "Was" indicator.
        Includes patient change AND new treatment detection with history purge.
        """
        try:
            if device_id not in self._param_cache:
                self._param_cache[device_id] = {}

            current_cache = self._param_cache[device_id]

            # 1. Patient Change Detection (Persistent during prime) → Purge
            patient_id = header.get("patient_id")
            if patient_id is not None:
                pid_str = str(patient_id).strip()
                
                # Ignore empty/idle states (like "N/A" during prime). 
                # This retains the history if ID temporarily blanks out and resumes with same ID.
                if pid_str and pid_str.upper() not in ["N/A", "NONE", "NULL"]:
                    # Update cache normally (and fallback to DB for restart resilience)
                    old_pid = current_cache.get("patient_id")
                    if old_pid is None:
                        # Cache is empty (likely restart), check persistent storage
                        old_pid = self._db.get_last_patient_id(device_id)
                        if old_pid and str(old_pid).strip() != pid_str:
                            logger.info(f"🔄 Persistent Patient Match Failed: {old_pid} → {pid_str}. Cold Purge triggered.")
                            self._purge_session(device_id, f"Persistent patient changed: {old_pid} → {pid_str}")

                    if old_pid and str(old_pid).strip() != pid_str:
                        logger.info(f"🔄 Patient Changed: {old_pid} → {pid_str}")
                        self._purge_session(device_id, f"Patient changed: {old_pid} → {pid_str}")
                    
                    # Update both cache and persistence
                    current_cache["patient_id"] = pid_str
                    self._db.update_patient_session(device_id, pid_str)

            # 2. Check Body Params for Changes
            changes = []
            params = body.get("parameters") or []
            for p in params:
                pid = p.get("id")
                val = p.get("value")

                if pid in TRACKED_PARAM_IDS:
                    display_val = p.get("value_text", str(val))

                    if pid in current_cache and current_cache[pid] != display_val:
                        changes.append((pid, current_cache[pid], display_val))

                    current_cache[pid] = display_val

            # 4. Batch Save Changes
            if changes:
                self._db.insert_events(device_id, timestamp, changes)
            
            return changes

        except Exception as e:
            logger.error(f"Event Log Error: {e}")
            return []

    def save_trend_point(self, device_id: str, timestamp: str, params: list):
        """
        Save pressure data points to the trend database.
        Source data is already ~10s per packet, so no additional throttling needed.
        """
        try:
            p_map = {1: 0, 2: 0, 3: 0, 4: 0, 6: 0, 7: 0}
            has_data = False

            for p in params:
                pid = p.get("id")
                if pid in p_map:
                    try:
                        p_map[pid] = float(p.get("value", 0))
                        has_data = True
                    except:
                        pass

            if not has_data:
                return

            self._db.insert_trend(
                device_id, timestamp,
                p_map[1], p_map[2], p_map[3], p_map[4], p_map[6], p_map[7]
            )

        except Exception as e:
            logger.error(f"Trend DB Error: {e}")

    # ─── Static Utility: Alarm File Logging ────────────────────────

    @staticmethod
    def log_device_alarm(device_id: str, message: str, severity: str = "INFO"):
        """Append a clinical alarm event to a daily log file for a specific device."""
        try:
            now = datetime.now()
            date_str = now.strftime("%Y-%m-%d")
            time_str = now.strftime("%H:%M:%S")

            device_log_dir = os.path.join(LOGS_DIR, device_id)
            if not os.path.exists(device_log_dir):
                os.makedirs(device_log_dir)

            log_file = os.path.join(device_log_dir, f"alarms_{date_str}.log")

            with open(log_file, "a", encoding="utf-8") as f:
                f.write(f"[{time_str}] [{severity}] {message}\n")
        except Exception as e:
            logger.error(f"Failed to write alarm log: {e}")
