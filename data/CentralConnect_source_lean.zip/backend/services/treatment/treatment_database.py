"""
Treatment Records Database
===========================
Separate SQLite database for treatment session recording.
Isolated from trends.db to avoid interference with the monitor system.

Usage:
    treat_db = TreatmentDatabase()
    treat_db.create_treatment(...)
    treat_db.update_treatment(...)
"""
import os
import shutil
import sqlite3
import threading
import logging
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any, Optional

logger = logging.getLogger("PrismaFlexBackend")

TREATMENT_DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'treatment_records.db')


class TreatmentDatabase:
    """
    Thread-safe SQLite wrapper for treatment records.
    Separate file from trends.db — zero impact on monitor system.
    """

    def __init__(self, db_path: str = TREATMENT_DB_PATH):
        self._db_path = db_path
        self._lock = threading.Lock()
        self._conn = None

        try:
            self._conn = self._create_connection()
            self._init_tables()
            logger.info(f"Treatment DB initialized at: {self._db_path}")
        except sqlite3.DatabaseError as e:
            logger.error(f"Treatment DB corrupt: {e}")
            self._handle_corruption()
            self._conn = self._create_connection()
            self._init_tables()

    def _handle_corruption(self):
        """Backup corrupted DB and start fresh."""
        if os.path.exists(self._db_path):
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup = f"{self._db_path}.corrupt.{ts}"
            shutil.move(self._db_path, backup)
            logger.warning(f"⚠️ Corrupt Treatment DB moved to: {backup}")

    def _create_connection(self):
        """Create optimized SQLite connection with WAL mode."""
        conn = sqlite3.connect(self._db_path, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.row_factory = sqlite3.Row
        return conn

    def _init_tables(self):
        """Create all tables and indexes."""
        with self._lock:
            c = self._conn.cursor()

            # Main treatments table
            c.execute('''CREATE TABLE IF NOT EXISTS treatments (
                id                  TEXT PRIMARY KEY,
                device_id           TEXT NOT NULL,
                machine_id          INTEGER,
                patient_id          TEXT,
                patient_name        TEXT,
                patient_yob         INTEGER,
                patient_gender      TEXT,
                patient_weight      REAL,
                bed_number          TEXT,
                admission_number    TEXT,
                diagnosis           TEXT,
                therapy_type_id     INTEGER,
                therapy_type_name   TEXT,
                anticoag_type_id    INTEGER,

                start_time          TEXT NOT NULL,
                first_run_time      TEXT,
                end_time            TEXT,
                last_seen_time      TEXT NOT NULL,

                outcome             TEXT NOT NULL DEFAULT 'IN_PROGRESS',
                fsm_state           TEXT NOT NULL DEFAULT 'RECORDING',

                total_run_seconds   INTEGER DEFAULT 0,
                total_paused_seconds INTEGER DEFAULT 0,
                total_phases        INTEGER DEFAULT 1,
                total_packets       INTEGER DEFAULT 0,

                is_valid            INTEGER DEFAULT 1,
                had_interruption    INTEGER DEFAULT 0,
                had_program_restart INTEGER DEFAULT 0,
                sw_version          TEXT,
                created_at          TEXT NOT NULL,
                updated_at          TEXT NOT NULL
            )''')
            c.execute('CREATE INDEX IF NOT EXISTS idx_treat_device ON treatments(device_id, start_time)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_treat_patient ON treatments(patient_id)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_treat_outcome ON treatments(outcome)')

            # Treatment phases
            c.execute('''CREATE TABLE IF NOT EXISTS treatment_phases (
                id              TEXT PRIMARY KEY,
                treatment_id    TEXT NOT NULL,
                phase_number    INTEGER NOT NULL DEFAULT 1,
                start_time      TEXT NOT NULL,
                end_time        TEXT,
                phase_type      TEXT NOT NULL,
                FOREIGN KEY (treatment_id) REFERENCES treatments(id)
            )''')
            c.execute('CREATE INDEX IF NOT EXISTS idx_phase_treat ON treatment_phases(treatment_id)')

            # Status transition log
            c.execute('''CREATE TABLE IF NOT EXISTS treatment_status_log (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                treatment_id    TEXT NOT NULL,
                device_id       TEXT NOT NULL,
                timestamp       TEXT NOT NULL,
                therapy_status_id INTEGER NOT NULL,
                fsm_state       TEXT NOT NULL,
                patient_id      TEXT,
                note            TEXT,
                FOREIGN KEY (treatment_id) REFERENCES treatments(id)
            )''')
            c.execute('CREATE INDEX IF NOT EXISTS idx_log_treat ON treatment_status_log(treatment_id)')

            # ── Hourly snapshots (CRRT report) ──────────────────────
            c.execute('''CREATE TABLE IF NOT EXISTS treatment_hourly_snapshots (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                treatment_id    TEXT NOT NULL,
                device_id       TEXT NOT NULL,
                hour_label      TEXT NOT NULL,
                snapshot_time   TEXT NOT NULL,
                source          TEXT DEFAULT 'AUTO',

                -- Auto-fill from telemetry
                qb              REAL,
                qs              REAL,
                qd              REAL,
                qpbp            REAL,
                pa              REAL,
                pv              REAL,
                pbe             REAL,
                tmp             REAL,
                uf_total        REAL,
                uf_hourly       REAL,
                effluent_flow   REAL,
                run_time_sec    INTEGER,
                blood_vol       REAL,
                heparin_rate    REAL,
                pt_weight       REAL,
                uf_rate_target  REAL,

                -- Citrate/Calcium support (Auto)
                citrate_dose    REAL,
                citrate_conc    REAL,
                citrate_load    REAL,
                calcium_comp    REAL,
                calcium_rate    REAL,
                anticoag_type_id INTEGER,

                -- Manual entry
                heparin_bolus   TEXT,
                solution_type   TEXT,
                duosol_count    REAL,
                prismasol_count REAL,
                filter_type     TEXT,
                kali            REAL,
                notes           TEXT,

                created_at      TEXT DEFAULT (datetime('now')),
                updated_at      TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (treatment_id) REFERENCES treatments(id)
            )''')
            c.execute('''CREATE UNIQUE INDEX IF NOT EXISTS idx_snap_hour
                         ON treatment_hourly_snapshots(treatment_id, hour_label)''')

            # ── Schema migrations (safe for existing DBs) ────────────
            try:
                c.execute('ALTER TABLE treatment_hourly_snapshots ADD COLUMN filter_type TEXT')
            except Exception:
                pass

            try:
                c.execute('ALTER TABLE treatment_hourly_snapshots ADD COLUMN duosol_count REAL')
                c.execute('ALTER TABLE treatment_hourly_snapshots ADD COLUMN prismasol_count REAL')
            except Exception:
                pass

            # Citrate/Calcium migrations
            for col in [('citrate_dose', 'REAL'), ('citrate_conc', 'REAL'), 
                        ('citrate_load', 'REAL'), ('calcium_comp', 'REAL'), 
                        ('calcium_rate', 'REAL'), ('anticoag_type_id', 'INTEGER')]:
                try:
                    c.execute(f'ALTER TABLE treatment_hourly_snapshots ADD COLUMN {col[0]} {col[1]}')
                except Exception:
                    pass

            # Order-Change snapshot reason migration
            try:
                c.execute('ALTER TABLE treatment_hourly_snapshots ADD COLUMN reason TEXT')
            except Exception:
                pass

            # Close reason migration
            try:
                c.execute('ALTER TABLE treatments ADD COLUMN close_reason TEXT')
            except Exception:
                pass

            # Patient info migration for treatments
            patient_cols = [
                ('patient_name', 'TEXT'),
                ('patient_yob', 'INTEGER'),
                ('patient_gender', 'TEXT'),
                ('patient_weight', 'REAL'),
                ('bed_number', 'TEXT'),
                ('admission_number', 'TEXT'),
                ('diagnosis', 'TEXT')
            ]
            for col in patient_cols:
                try:
                    c.execute(f'ALTER TABLE treatments ADD COLUMN {col[0]} {col[1]}')
                except Exception:
                    pass

            # ── Treatment config (setup info) ───────────────────────
            c.execute('''CREATE TABLE IF NOT EXISTS treatment_config (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                treatment_id    TEXT NOT NULL UNIQUE,
                kit_type        TEXT,
                kit_enum_value  INTEGER,
                solution_type   TEXT,
                has_adsorption  INTEGER DEFAULT 0,
                therapy_type    TEXT,
                patient_weight  REAL,
                anticoag_method TEXT,
                heparin_bolus   TEXT,
                created_at      TEXT DEFAULT (datetime('now')),
                updated_at      TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (treatment_id) REFERENCES treatments(id)
            )''')

            # ── Treatment index (permanent, lightweight) ────────────
            # Stays in Hot DB even after archive. Only metadata.
            c.execute('''CREATE TABLE IF NOT EXISTS treatment_index (
                id              TEXT PRIMARY KEY,
                device_id       TEXT NOT NULL,
                patient_id      TEXT,
                patient_name    TEXT,
                patient_yob     INTEGER,
                patient_gender  TEXT,
                patient_weight  REAL,
                bed_number      TEXT,
                admission_number TEXT,
                diagnosis       TEXT,
                therapy_type    TEXT,
                start_time      TEXT NOT NULL,
                end_time        TEXT,
                duration_sec    INTEGER DEFAULT 0,
                outcome         TEXT NOT NULL DEFAULT 'IN_PROGRESS',
                snapshot_count  INTEGER DEFAULT 0,
                total_packets   INTEGER DEFAULT 0,
                archive_path    TEXT,
                created_at      TEXT NOT NULL
            )''')
            # Migrations for treatment_index (Clinical Grade: Safe for existing data)
            for col, col_type in [('duration_sec', 'INTEGER DEFAULT 0'), 
                                  ('snapshot_count', 'INTEGER DEFAULT 0'),
                                  ('close_reason', 'TEXT'),
                                  ('patient_name', 'TEXT'),
                                  ('patient_yob', 'INTEGER'),
                                  ('patient_gender', 'TEXT'),
                                  ('patient_weight', 'REAL'),
                                  ('bed_number', 'TEXT'),
                                  ('admission_number', 'TEXT'),
                                  ('diagnosis', 'TEXT'),
                                  ('created_at', "TEXT NOT NULL DEFAULT '2026-01-01 00:00:00'"),
                                  ('anticoag_type_id', 'INTEGER'),
                                  ('anticoag_type', 'TEXT'),
                                  ('approval_status', "TEXT NOT NULL DEFAULT 'DRAFT'"),
                                  ('reject_reason', 'TEXT'),
                                  ('start_time_override', 'TEXT'),
                                  ('end_time_override', 'TEXT'),
                                  ('clinical_notes', 'TEXT')]:
                try:
                    c.execute(f'ALTER TABLE treatment_index ADD COLUMN {col} {col_type}')
                except Exception:
                    pass
            
            # Migrate treatments
            for col, col_type in [('anticoag_type_id', 'INTEGER'),
                                  ('close_reason', 'TEXT'),
                                  ('start_time_override', 'TEXT'),
                                  ('end_time_override', 'TEXT'),
                                  ('clinical_notes', 'TEXT')]:
                try:
                    c.execute(f'ALTER TABLE treatments ADD COLUMN {col} {col_type}')
                except Exception:
                    pass
            c.execute('CREATE INDEX IF NOT EXISTS idx_tidx_outcome ON treatment_index(outcome)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_tidx_start ON treatment_index(start_time DESC)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_tidx_patient ON treatment_index(patient_id)')

            # ── Raw telemetry packets (Forensic Export) ────────────
            c.execute('''CREATE TABLE IF NOT EXISTS treatment_raw_packets (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                treatment_id    TEXT NOT NULL,
                timestamp       TEXT NOT NULL,
                packet_json     TEXT NOT NULL,
                FOREIGN KEY (treatment_id) REFERENCES treatments(id)
            )''')
            c.execute('CREATE INDEX IF NOT EXISTS idx_raw_treat ON treatment_raw_packets(treatment_id)')

            # ── Snapshot Originals (Freeze-on-Submit audit trail) ───
            c.execute('''CREATE TABLE IF NOT EXISTS snapshot_originals (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                treatment_id    TEXT NOT NULL,
                hour_label      TEXT NOT NULL,
                snapshot_time   TEXT,
                snapshot_json   TEXT NOT NULL,
                frozen_at       TEXT NOT NULL,
                UNIQUE(treatment_id, hour_label)
            )''')
            c.execute('CREATE INDEX IF NOT EXISTS idx_snap_orig_treat ON snapshot_originals(treatment_id)')

            self._conn.commit()

    # ─── Core CRUD ────────────────────────────────────────────────

    def execute(self, sql: str, params: tuple = ()):
        with self._lock:
            self._conn.execute(sql, params)
            self._conn.commit()

    def fetch_all(self, sql: str, params: tuple = ()):
        with self._lock:
            return [dict(r) for r in self._conn.execute(sql, params).fetchall()]

    def fetch_one(self, sql: str, params: tuple = ()):
        with self._lock:
            row = self._conn.execute(sql, params).fetchone()
            return dict(row) if row else None

    # ─── Treatment Operations ─────────────────────────────────────

    def create_treatment(self, treatment_id: str, device_id: str, timestamp: str,
                         machine_id: int = None, patient_id: str = None,
                         therapy_type_id: int = None, therapy_type_name: str = None,
                         anticoag_type_id: int = None,
                         sw_version: str = None):
        # Use Local Clinical Time (UTC+7) for internal audit columns
        now = datetime.now(timezone(timedelta(hours=7))).isoformat()
        self.execute('''
            INSERT INTO treatments
            (id, device_id, machine_id, patient_id, therapy_type_id, therapy_type_name,
             anticoag_type_id, start_time, last_seen_time, sw_version, created_at, updated_at, outcome, fsm_state)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'IN_PROGRESS', 'RECORDING')
        ''', (treatment_id, device_id, machine_id, patient_id,
              therapy_type_id, therapy_type_name, anticoag_type_id,
              timestamp, timestamp, sw_version, now, now))

    def update_treatment(self, treatment_id: str, **kwargs):
        """Update any columns on a treatment. Pass column=value as kwargs."""
        if not kwargs:
            return
        kwargs['updated_at'] = datetime.now(timezone(timedelta(hours=7))).isoformat()
        cols = ", ".join(f"{k} = ?" for k in kwargs)
        vals = list(kwargs.values()) + [treatment_id]
        self.execute(f"UPDATE treatments SET {cols} WHERE id = ?", tuple(vals))

    def close_treatment(self, treatment_id: str, end_time: str, outcome: str):
        self.update_treatment(treatment_id, end_time=end_time, outcome=outcome, fsm_state="CLOSED")

    def get_active_treatment(self, device_id: str):
        """Get the IN_PROGRESS treatment for a device (should be 0 or 1)."""
        return self.fetch_one(
            "SELECT * FROM treatments WHERE device_id = ? AND outcome = 'IN_PROGRESS' "
            "ORDER BY start_time DESC LIMIT 1",
            (device_id,))

    def get_all_in_progress(self):
        """Get all IN_PROGRESS treatments (for recovery on startup)."""
        return self.fetch_all("SELECT * FROM treatments WHERE outcome = 'IN_PROGRESS'")

    def get_last_closed_treatment(self, device_id: str, patient_id: str, min_end_time: str):
        """Find the most recently active treatment for a patient on a device within a time window.
        Searches both COMPLETED and IN_PROGRESS to prevent duplicate creation on recovery failure.
        """
        return self.fetch_one(
            """SELECT * FROM treatments 
               WHERE device_id = ? AND patient_id = ? 
               AND outcome IN ('COMPLETED', 'IN_PROGRESS') 
               AND (end_time >= ? OR (outcome = 'IN_PROGRESS' AND last_seen_time >= ?))
               ORDER BY last_seen_time DESC LIMIT 1""",
            (device_id, patient_id, min_end_time, min_end_time))

    def get_latest_snapshot(self, treatment_id: str) -> Optional[dict]:
        """Fetch the most recent hourly snapshot for a given treatment."""
        row = self.fetch_one('''
            SELECT * 
            FROM treatment_hourly_snapshots 
            WHERE treatment_id = ? 
            ORDER BY snapshot_time DESC LIMIT 1
        ''', (treatment_id,))
        if not row:
            return None
            
        auto_vars = ['qb', 'qs', 'qd', 'qpbp', 'pa', 'pv', 'pbe', 'tmp',
                     'uf_total', 'uf_hourly', 'effluent_flow',
                     'run_time_sec', 'blood_vol', 'heparin_rate',
                     'pt_weight', 'uf_rate_target', 'citrate_dose',
                     'citrate_conc', 'citrate_load', 'calcium_comp',
                     'calcium_rate', 'anticoag_type_id']
        row['auto_data'] = {k: row[k] for k in auto_vars if k in row and row[k] is not None}
        return row

    def get_treatments(self, limit: int = 100, offset: int = 0):
        return self.fetch_all(
            "SELECT * FROM treatments ORDER BY start_time DESC LIMIT ? OFFSET ?",
            (limit, offset))

    def get_treatment_by_id(self, treatment_id: str):
        return self.fetch_one("SELECT * FROM treatments WHERE id = ?", (treatment_id,))

    # ─── Phase Operations ──────────────────────────────────────────

    def create_phase(self, phase_id: str, treatment_id: str, phase_number: int,
                     start_time: str, phase_type: str):
        self.execute('''
            INSERT INTO treatment_phases (id, treatment_id, phase_number, start_time, phase_type)
            VALUES (?, ?, ?, ?, ?)
        ''', (phase_id, treatment_id, phase_number, start_time, phase_type))

    def close_phase(self, phase_id: str, end_time: str):
        self.execute("UPDATE treatment_phases SET end_time = ? WHERE id = ?", (end_time, phase_id))

    def get_phases(self, treatment_id: str):
        return self.fetch_all(
            "SELECT * FROM treatment_phases WHERE treatment_id = ? ORDER BY phase_number",
            (treatment_id,))

    # ─── Status Log ────────────────────────────────────────────────

    def log_status(self, treatment_id: str, device_id: str, timestamp: str,
                   therapy_status_id: int, fsm_state: str,
                   patient_id: str = None, note: str = None):
        self.execute('''
            INSERT INTO treatment_status_log
            (treatment_id, device_id, timestamp, therapy_status_id, fsm_state, patient_id, note)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (treatment_id, device_id, timestamp, therapy_status_id,
              fsm_state, patient_id, note))

    def get_status_log(self, treatment_id: str):
        return self.fetch_all(
            "SELECT * FROM treatment_status_log WHERE treatment_id = ? ORDER BY timestamp",
            (treatment_id,))

    # ─── Hourly Snapshots ───────────────────────────────────────

    def upsert_snapshot(self, treatment_id: str, device_id: str,
                        hour_label: str, snapshot_time: str,
                        auto_data: dict = None, manual_data: dict = None):
        """Insert or update an hourly snapshot. auto_data and manual_data are dicts of column=value."""
        existing = self.fetch_one(
            "SELECT id FROM treatment_hourly_snapshots WHERE treatment_id = ? AND hour_label = ?",
            (treatment_id, hour_label))

        if existing:
            # Update existing snapshot
            updates = {}
            if auto_data:
                updates.update(auto_data)
                updates['source'] = 'MERGED' if manual_data else 'AUTO'
            if manual_data:
                updates.update(manual_data)
                updates['source'] = 'MERGED' if auto_data else 'MANUAL'
            if updates:
                # Always update snapshot_time so H-snaps reflect latest telemetry time
                updates['snapshot_time'] = snapshot_time
                updates['updated_at'] = datetime.now(timezone(timedelta(hours=7))).isoformat()
                cols = ", ".join(f"{k} = ?" for k in updates)
                vals = list(updates.values()) + [existing['id']]
                self.execute(f"UPDATE treatment_hourly_snapshots SET {cols} WHERE id = ?", tuple(vals))
        else:
            # Insert new snapshot
            data = {
                'treatment_id': treatment_id,
                'device_id': device_id,
                'hour_label': hour_label,
                'snapshot_time': snapshot_time,
                'source': 'AUTO'
            }
            if auto_data:
                data.update(auto_data)
            if manual_data:
                data.update(manual_data)
                data['source'] = 'MERGED' if auto_data else 'MANUAL'
            
            data['updated_at'] = datetime.now(timezone(timedelta(hours=7))).isoformat()
            cols = ", ".join(data.keys())
            placeholders = ", ".join("?" for _ in data)
            self.execute(
                f"INSERT INTO treatment_hourly_snapshots ({cols}) VALUES ({placeholders})",
                tuple(data.values()))
            
            # Clinical Grade: Keep the lightweight index synced for UI list views
            self.execute(
                "UPDATE treatment_index SET snapshot_count = snapshot_count + 1 WHERE id = ?",
                (treatment_id,)
            )

    def get_snapshots(self, treatment_id: str):
        return self.fetch_all(
            "SELECT * FROM treatment_hourly_snapshots WHERE treatment_id = ? ORDER BY snapshot_time ASC",
            (treatment_id,))

    def delete_snapshot(self, treatment_id: str, hour_label: str):
        """Delete a specific hourly snapshot and decrement count."""
        with self._lock:
            c = self._conn.cursor()
            c.execute(
                "DELETE FROM treatment_hourly_snapshots WHERE treatment_id = ? AND hour_label = ?",
                (treatment_id, hour_label)
            )
            # Clinical Grade: Keep the lightweight index synced
            if c.rowcount > 0:
                c.execute(
                    "UPDATE treatment_index SET snapshot_count = snapshot_count - 1 WHERE id = ?",
                    (treatment_id,)
                )
            self._conn.commit()
            logger.info(f"🗑️ Deleted snapshot {hour_label} for treatment {treatment_id[:8]}")

    def update_snapshot_manual(self, treatment_id: str, hour_label: str, data: Dict[str, Any]):
        """Update or insert a manual entry for a specific hourly snapshot."""
        t = self.get_treatment_by_id(treatment_id)
        if not t: return
        self.upsert_snapshot(treatment_id, t['device_id'], hour_label, 
                             datetime.now(timezone(timedelta(hours=7))).isoformat(),
                             manual_data=data)

    def update_snapshots_bulk(self, treatment_id: str, data: Dict[str, Any]):
        """Update multiple columns for all snapshots of a treatment."""
        if not data:
            return
        now = datetime.now(timezone(timedelta(hours=7))).isoformat()
        cols = ", ".join(f"{k} = ?" for k in data)
        vals = list(data.values()) + [now, treatment_id]
        self.execute(f"UPDATE treatment_hourly_snapshots SET {cols}, updated_at = ? WHERE treatment_id = ?", tuple(vals))

    # ─── Treatment Config ───────────────────────────────────────

    def upsert_config(self, treatment_id: str, **kwargs):
        """Insert or update treatment config."""
        existing = self.fetch_one(
            "SELECT id FROM treatment_config WHERE treatment_id = ?", (treatment_id,))
        if existing:
            kwargs['updated_at'] = datetime.now(timezone(timedelta(hours=7))).isoformat()
            cols = ", ".join(f"{k} = ?" for k in kwargs)
            vals = list(kwargs.values()) + [treatment_id]
            self.execute(f"UPDATE treatment_config SET {cols} WHERE treatment_id = ?", tuple(vals))
        else:
            kwargs['treatment_id'] = treatment_id
            cols = ", ".join(kwargs.keys())
            placeholders = ", ".join("?" * len(kwargs))
            self.execute(f"INSERT INTO treatment_config ({cols}) VALUES ({placeholders})",
                         tuple(kwargs.values()))

    def get_config(self, treatment_id: str):
        return self.fetch_one(
            "SELECT * FROM treatment_config WHERE treatment_id = ?", (treatment_id,))

    # ─── Raw Packets ───────────────────────────────────────────

    def log_raw_packet(self, treatment_id: str, timestamp: str, packet_json: str):
        """Insert a raw telemetry packet for forensic export."""
        self.execute(
            "INSERT INTO treatment_raw_packets (treatment_id, timestamp, packet_json) VALUES (?, ?, ?)",
            (treatment_id, timestamp, packet_json))

    def get_raw_packets(self, treatment_id: str):
        """Get all raw packets for a treatment."""
        return self.fetch_all(
            "SELECT timestamp, packet_json FROM treatment_raw_packets WHERE treatment_id = ? ORDER BY timestamp",
            (treatment_id,))

    # ─── Full Report ────────────────────────────────────────────

    def get_full_report(self, treatment_id: str):
        """Get treatment + config + all hourly snapshots."""
        treatment = self.get_treatment_by_id(treatment_id)
        if not treatment:
            return None
        return {
            "treatment": treatment,
            "config": self.get_config(treatment_id),
            "snapshots": self.get_snapshots(treatment_id),
            "status_log_count": self.fetch_one(
                "SELECT COUNT(*) as cnt FROM treatment_status_log WHERE treatment_id = ?",
                (treatment_id,))['cnt']
        }

    # ─── Treatment Index (permanent, lightweight) ───────────────

    def upsert_index(self, treatment_id: str, device_id: str,
                     patient_id: str = None, therapy_type: str = None,
                     start_time: str = None, end_time: str = None,
                     duration_sec: int = None, outcome: str = None,
                     snapshot_count: int = None, total_packets: int = None,
                     archive_path: str = None, close_reason: str = None,
                     patient_name: str = None, patient_yob: int = None,
                     patient_gender: str = None, patient_weight: float = None,
                     bed_number: str = None, admission_number: str = None,
                     diagnosis: str = None, anticoag_type: str = None):
        """Insert or update the treatment index entry. Robust against partial updates."""
        now = datetime.now(timezone(timedelta(hours=7))).isoformat()
        existing = self.fetch_one("SELECT id FROM treatment_index WHERE id = ?", (treatment_id,))
        
        if existing:
            # Dynamic Update: Only update fields that are NOT None
            updates = []
            params = []
            
            field_map = {
                "device_id": device_id,
                "patient_id": patient_id,
                "therapy_type": therapy_type,
                "start_time": start_time,
                "end_time": end_time,
                "duration_sec": duration_sec,
                "outcome": outcome,
                "snapshot_count": snapshot_count,
                "total_packets": total_packets,
                "archive_path": archive_path,
                "close_reason": close_reason,
                "patient_name": patient_name,
                "patient_yob": patient_yob,
                "patient_gender": patient_gender,
                "patient_weight": patient_weight,
                "bed_number": bed_number,
                 "admission_number": admission_number,
                "diagnosis": diagnosis,
                "anticoag_type": anticoag_type
            }
            
            for field, val in field_map.items():
                if val is not None:
                    updates.append(f"{field}=?")
                    params.append(val)
            
            if updates:
                sql = f"UPDATE treatment_index SET {', '.join(updates)} WHERE id=?"
                params.append(treatment_id)
                self.execute(sql, tuple(params))
        else:
            # Insert: Use provided values or sensible defaults
            self.execute('''INSERT INTO treatment_index
                (id, device_id, patient_id, therapy_type, start_time,
                 end_time, duration_sec, outcome, snapshot_count,
                  total_packets, archive_path, close_reason, created_at,
                 patient_name, patient_yob, patient_gender, patient_weight,
                 bed_number, admission_number, diagnosis, anticoag_type)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (treatment_id, device_id, patient_id, therapy_type, start_time or '',
                 end_time, duration_sec or 0, outcome or 'IN_PROGRESS',
                 snapshot_count or 0, total_packets or 0, archive_path, close_reason, now,
                 patient_name, patient_yob, patient_gender, patient_weight,
                 bed_number, admission_number, diagnosis, anticoag_type))

    def get_index_list(self, limit: int = 20, offset: int = 0,
                       outcome: str = None, patient_id: str = None,
                       device_id: str = None, start_time: str = None, end_time: str = None,
                       approval_status: str = None):
        """Paginated list from treatment_index. Fast, lightweight. Supports advanced filters."""
        sql = "SELECT * FROM treatment_index WHERE 1=1"
        params = []
        if outcome:
            sql += " AND outcome = ?"
            params.append(outcome)
        if patient_id:
            sql += " AND patient_id LIKE ?"
            params.append(f"%{patient_id}%")
        if device_id:
            sql += " AND device_id LIKE ?"
            params.append(f"%{device_id}%")
        if start_time:
            sql += " AND start_time >= ?"
            params.append(start_time)
        if end_time:
            sql += " AND start_time <= ?"
            params.append(end_time)
        if approval_status:
            sql += " AND approval_status = ?"
            params.append(approval_status)
        sql += " ORDER BY start_time DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        return self.fetch_all(sql, tuple(params))

    def get_index_count(self, outcome: str = None, patient_id: str = None,
                        device_id: str = None, start_time: str = None, end_time: str = None,
                        approval_status: str = None):
        """Count for pagination with advanced filters."""
        sql = "SELECT COUNT(*) as cnt FROM treatment_index WHERE 1=1"
        params = []
        if outcome:
            sql += " AND outcome = ?"
            params.append(outcome)
        if patient_id:
            sql += " AND patient_id LIKE ?"
            params.append(f"%{patient_id}%")
        if device_id:
            sql += " AND device_id LIKE ?"
            params.append(f"%{device_id}%")
        if start_time:
            sql += " AND start_time >= ?"
            params.append(start_time)
        if end_time:
            sql += " AND start_time <= ?"
            params.append(end_time)
        if approval_status:
            sql += " AND approval_status = ?"
            params.append(approval_status)
        return self.fetch_one(sql, tuple(params))['cnt']

    def update_approval_status(self, treatment_id: str, status: str):
        """Change the approval_status of a treatment in the index.
        Valid statuses: DRAFT, PENDING_REVIEW, APPROVED
        Clinical Grade: Safe for v3.2.1 upgrade — column defaults to 'DRAFT'.
        """
        self.execute(
            "UPDATE treatment_index SET approval_status = ? WHERE id = ?",
            (status, treatment_id))

    def get_pending_review_count(self) -> int:
        """Quick count of treatments awaiting doctor review (for Sidebar badge)."""
        result = self.fetch_one(
            "SELECT COUNT(*) as cnt FROM treatment_index WHERE approval_status = 'PENDING_REVIEW'")
        return result['cnt'] if result else 0

    def freeze_snapshots(self, treatment_id: str):
        """Freeze-on-Submit: Copy all snapshot rows into snapshot_originals.
        Called once when nurse submits for review. Idempotent — skips if already frozen.
        Clinical Grade: Safe for v3.2.1 upgrade.
        """
        import json
        existing = self.fetch_one(
            "SELECT COUNT(*) as cnt FROM snapshot_originals WHERE treatment_id = ?",
            (treatment_id,))
        if existing and existing['cnt'] > 0:
            return  # Already frozen, skip

        now = datetime.now(timezone(timedelta(hours=7))).isoformat()
        snapshots = self.fetch_all(
            "SELECT * FROM treatment_hourly_snapshots WHERE treatment_id = ? ORDER BY hour_label",
            (treatment_id,))

        if not snapshots:
            return

        with self._lock:
            c = self._conn.cursor()
            for snap in snapshots:
                snap_dict = dict(snap)
                hour = snap_dict.pop('hour_label', '')
                snap_time = snap_dict.get('snapshot_time', '')
                try:
                    c.execute(
                        '''INSERT OR IGNORE INTO snapshot_originals
                           (treatment_id, hour_label, snapshot_time, snapshot_json, frozen_at)
                           VALUES (?, ?, ?, ?, ?)''',
                        (treatment_id, hour, snap_time, json.dumps(snap_dict), now))
                except Exception:
                    pass
            self._conn.commit()
            logger.info(f"🧊 Frozen {len(snapshots)} snapshots for treatment {treatment_id[:8]}")

    def get_snapshot_originals(self, treatment_id: str) -> list:
        """Retrieve frozen original snapshots for comparison view."""
        import json
        rows = self.fetch_all(
            "SELECT hour_label, snapshot_time, snapshot_json, frozen_at FROM snapshot_originals WHERE treatment_id = ? ORDER BY hour_label",
            (treatment_id,))
        result = []
        for row in rows:
            entry = {'hour_label': row['hour_label'], 'snapshot_time': row['snapshot_time'], 'frozen_at': row['frozen_at']}
            try:
                entry['data'] = json.loads(row['snapshot_json'])
            except Exception:
                entry['data'] = {}
            result.append(entry)
        return result

    def log_approval_event(self, treatment_id: str, action: str, details: str = ""):
        """Log approval workflow events for audit trail."""
        now = datetime.now(timezone(timedelta(hours=7))).isoformat()
        try:
            self.execute(
                '''INSERT INTO treatment_status_log (treatment_id, device_id, timestamp, therapy_status_id, fsm_state, patient_id, note)
                   VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (treatment_id, 'SYSTEM', now, -99, action, '', details))
        except Exception as e:
            logger.error(f"Failed to log approval event: {e}")

    # ─── Archive Cleanup ────────────────────────────────────────

    def collect_for_archive(self, treatment_id: str) -> dict:
        """Gather all data for a treatment into a single dict for archiving."""
        return {
            "treatment": self.get_treatment_by_id(treatment_id),
            "config": self.get_config(treatment_id),
            "snapshots": self.get_snapshots(treatment_id),
            "status_log": self.get_status_log(treatment_id),
            "phases": self.get_phases(treatment_id)
        }

    def purge_treatment_data(self, treatment_id: str):
        """Remove heavy data from Hot DB after archiving. Index stays."""
        with self._lock:
            c = self._conn.cursor()
            c.execute("DELETE FROM treatment_hourly_snapshots WHERE treatment_id = ?", (treatment_id,))
            c.execute("DELETE FROM treatment_status_log WHERE treatment_id = ?", (treatment_id,))
            c.execute("DELETE FROM treatment_phases WHERE treatment_id = ?", (treatment_id,))
            c.execute("DELETE FROM treatment_config WHERE treatment_id = ?", (treatment_id,))
            c.execute("DELETE FROM treatment_raw_packets WHERE treatment_id = ?", (treatment_id,))
            c.execute("DELETE FROM treatments WHERE id = ?", (treatment_id,))
            self._conn.commit()
            logger.info(f"🗑️ Purged Hot DB data for treatment {treatment_id[:8]}")

    def delete_treatment(self, treatment_id: str):
        """Completely wipe treatment from DB including the index."""
        with self._lock:
            c = self._conn.cursor()
            # 1. Purge heavy data (same as purge_treatment_data)
            c.execute("DELETE FROM treatment_hourly_snapshots WHERE treatment_id = ?", (treatment_id,))
            c.execute("DELETE FROM treatment_status_log WHERE treatment_id = ?", (treatment_id,))
            c.execute("DELETE FROM treatment_phases WHERE treatment_id = ?", (treatment_id,))
            c.execute("DELETE FROM treatment_config WHERE treatment_id = ?", (treatment_id,))
            c.execute("DELETE FROM treatment_raw_packets WHERE treatment_id = ?", (treatment_id,))
            c.execute("DELETE FROM treatments WHERE id = ?", (treatment_id,))
            # 2. ALSO remove from index
            c.execute("DELETE FROM treatment_index WHERE id = ?", (treatment_id,))
            self._conn.commit()
            logger.info(f"🔥 DELETED all database records for treatment {treatment_id[:8]}")

    # ─── Lifecycle ──────────────────────────────────────────────

    def close(self):
        if self._conn:
            self._conn.close()
            logger.info("🔒 Treatment DB closed.")
