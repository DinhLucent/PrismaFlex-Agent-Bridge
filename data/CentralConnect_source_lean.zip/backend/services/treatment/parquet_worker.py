"""
Background Parquet Compression Worker (Sprint 4 — TASK-112)
============================================================
Periodically scans raw_packet_manifest for CLOSED JSONL chunks
and converts them to Parquet format for ~90% compression and
blazingly fast DuckDB analysis.

Architecture: RAW_TELEMETRY_ARCHITECTURE_SPEC Section 2.3

Safety rules:
- Only compresses CLOSED chunks (never ACTIVE)
- Verifies Parquet integrity before deleting JSONL
- Runs in a background thread (non-blocking to live recording)
- On failure: logs error, keeps JSONL, retries next cycle
"""
import os
import json
import logging
import threading
import time
from datetime import datetime

logger = logging.getLogger("PrismaFlex.ParquetWorker")

# Compression interval (seconds)
SCAN_INTERVAL = 60  # Check every 60s


class ParquetCompressionWorker:
    """
    Background worker that converts CLOSED JSONL chunks to Parquet.

    Lifecycle: started after app boot, runs until shutdown.
    """

    def __init__(self):
        self._running = False
        self._thread: threading.Thread | None = None

    def start(self):
        """Start the background worker thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._run_loop,
            name="ParquetWorker",
            daemon=True,
        )
        self._thread.start()
        logger.info("🔧 Parquet compression worker started")

    def stop(self):
        """Signal the worker to stop."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=10)
            logger.info("🔧 Parquet compression worker stopped")

    def _run_loop(self):
        """Main worker loop: scan → compress → sleep."""
        while self._running:
            try:
                self._process_closed_chunks()
            except Exception as e:
                logger.error(f"Parquet worker cycle error: {e}")
            time.sleep(SCAN_INTERVAL)

    def _process_closed_chunks(self):
        """Find CLOSED JSONL chunks and convert them to Parquet."""
        try:
            from db.postgres.session import get_session
            from db.postgres.models.raw_packet_manifest import RawPacketManifest
            from sqlalchemy import select

            with get_session() as session:
                stmt = (
                    select(RawPacketManifest)
                    .where(
                        RawPacketManifest.status == "CLOSED",
                        RawPacketManifest.format == "JSONL",
                    )
                    .order_by(RawPacketManifest.created_at.asc())
                    .limit(5)  # Process max 5 chunks per cycle
                )
                chunks = list(session.scalars(stmt).all())

                for chunk in chunks:
                    self._compress_chunk(session, chunk)

        except Exception as e:
            logger.error(f"Failed to scan for closed chunks: {e}")

    def _compress_chunk(self, session, chunk) -> bool:
        """Convert a single JSONL chunk to Parquet."""
        jsonl_path = chunk.file_path
        parquet_path = jsonl_path.replace(".jsonl", ".parquet")

        if not os.path.exists(jsonl_path):
            logger.warning(f"JSONL file missing: {jsonl_path}")
            chunk.status = "ARCHIVED"
            chunk.format = "PARQUET"
            chunk.file_path = parquet_path
            session.flush()
            return False

        try:
            import pyarrow as pa
            import pyarrow.parquet as pq

            # Read JSONL lines into records
            records = []
            with open(jsonl_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            records.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue

            if not records:
                logger.warning(f"Empty JSONL chunk: {jsonl_path}")
                return False

            # Convert to PyArrow Table and write Parquet
            table = pa.Table.from_pylist(records)
            pq.write_table(
                table, parquet_path,
                compression='snappy',
                use_dictionary=True,
            )

            # Verify Parquet integrity
            verify_table = pq.read_table(parquet_path)
            if len(verify_table) != len(records):
                logger.error(
                    f"Parquet verification failed: {len(verify_table)} != {len(records)} rows"
                )
                if os.path.exists(parquet_path):
                    os.remove(parquet_path)
                return False

            # Success — update manifest and delete JSONL
            parquet_size = os.path.getsize(parquet_path)
            chunk.format = "PARQUET"
            chunk.status = "ARCHIVED"
            chunk.file_path = parquet_path
            chunk.size_bytes = parquet_size
            session.flush()

            # Safe delete of JSONL
            from services.treatment.raw_streamer import _safe_remove
            _safe_remove(jsonl_path)

            compression_ratio = (1 - parquet_size / max(1, os.path.getsize(jsonl_path) if os.path.exists(jsonl_path) else chunk.size_bytes or 1)) * 100
            logger.info(
                f"✅ Compressed: {os.path.basename(jsonl_path)} -> "
                f"{os.path.basename(parquet_path)} "
                f"({len(records)} rows, ~{compression_ratio:.0f}% reduction)"
            )
            return True

        except ImportError:
            logger.warning(
                "pyarrow not installed — Parquet compression disabled. "
                "Install with: pip install pyarrow"
            )
            return False
        except Exception as e:
            logger.error(f"Compression failed for {jsonl_path}: {e}")
            if os.path.exists(parquet_path):
                try:
                    os.remove(parquet_path)
                except Exception:
                    pass
            return False
