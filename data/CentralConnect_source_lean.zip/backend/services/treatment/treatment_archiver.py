"""
Treatment Archiver Service
===========================
Handles Hot → Cold storage migration for completed treatments.

Hot DB (SQLite) keeps only ACTIVE treatments.
Cold Archive (JSON files) stores completed treatments permanently.
Treatment index stays in Hot DB for fast list queries.

Archive structure:
    backend/archive/{year}/{month}/{treatment_id}.json
"""
import os
import json
import logging
from datetime import datetime, timezone, timedelta
from typing import Optional

from .postgres_treatment_db import PostgresTreatmentDB as TreatmentDatabase

logger = logging.getLogger("PrismaFlexBackend")

ARCHIVE_ROOT = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'archive')


class TreatmentArchiver:
    """
    Archives completed treatments from Hot DB to JSON files.
    Called automatically when a treatment is closed.
    """

    def __init__(self, db: TreatmentDatabase, archive_root: str = ARCHIVE_ROOT):
        self._db = db
        self._archive_root = archive_root
        os.makedirs(self._archive_root, exist_ok=True)
        logger.info(f"📦 Archiver initialized. Root: {self._archive_root}")

    def archive_treatment(self, treatment_id: str) -> Optional[str]:
        """
        Archive a completed treatment:
        1. Collect all data from Hot DB
        2. Write to JSON file
        3. Update index with archive_path
        4. Purge heavy data from Hot DB

        Returns archive file path, or None if treatment not found.
        """
        try:
            # 1. Collect
            data = self._db.collect_for_archive(treatment_id)
            if not data or not data.get('treatment'):
                logger.warning(f"⚠️ Archive: treatment {treatment_id[:8]} not found")
                return None

            treatment = data['treatment']

            # 2. Build archive path: archive/YYYY/MM/{id}.json
            start = treatment.get('start_time', '')
            try:
                dt = datetime.fromisoformat(start.replace('Z', '+00:00'))
            except (ValueError, AttributeError):
                dt = datetime.now(timezone(timedelta(hours=7)))

            year_dir = os.path.join(self._archive_root, dt.strftime('%Y'))
            month_dir = os.path.join(year_dir, dt.strftime('%m'))
            os.makedirs(month_dir, exist_ok=True)

            archive_path = os.path.join(month_dir, f"{treatment_id}.json")

            # 3. Write archive file
            archive_data = {
                "version": 1,
                "archived_at": datetime.now(timezone(timedelta(hours=7))).isoformat(),
                "treatment": treatment,
                "config": data.get('config'),
                "snapshots": data.get('snapshots', []),
                "status_log": data.get('status_log', []),
                "phases": data.get('phases', [])
            }

            with open(archive_path, 'w', encoding='utf-8') as f:
                json.dump(archive_data, f, ensure_ascii=False, indent=2)

            # 3.1. Forensic Export: Raw packets (.jsonl format)
            raw_packets = self._db.get_raw_packets(treatment_id)
            if raw_packets:
                raw_path = archive_path.replace('.json', '.raw.jsonl')
                try:
                    with open(raw_path, 'w', encoding='utf-8') as f:
                        for row in raw_packets:
                            # Use named access for sqlite3.Row compatibility
                            f.write(row['packet_json'] + '\n')
                    logger.info(f"📦 Forensic Export: {len(raw_packets)} pkts saved to {raw_path}")
                except Exception as e:
                    logger.error(f"❌ Forensic Export error [{treatment_id[:8]}]: {e}")

            # 4. Calculate duration = end_time - start_time (simple, always correct)
            duration_sec = 0
            end_time = treatment.get('end_time')
            if end_time and start:
                try:
                    dt_start = datetime.fromisoformat(start.replace('Z', '+00:00'))
                    dt_end = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
                    duration_sec = max(0, int((dt_end - dt_start).total_seconds()))
                except (ValueError, AttributeError):
                    pass
            
            treatment['duration_sec'] = duration_sec

            # 5. Update index with archive path
            snapshot_count = len(data.get('snapshots', []))
            self._db.upsert_index(
                treatment_id=treatment_id,
                device_id=treatment.get('device_id', ''),
                patient_id=treatment.get('patient_id'),
                therapy_type=treatment.get('therapy_type_name'),
                start_time=start,
                end_time=end_time,
                duration_sec=duration_sec,
                outcome=treatment.get('outcome', 'COMPLETED'),
                snapshot_count=snapshot_count,
                total_packets=treatment.get('total_packets', 0),
                archive_path=archive_path,
                close_reason=treatment.get('close_reason')
            )

            # 6. Purge heavy data from Hot DB
            self._db.purge_treatment_data(treatment_id)

            logger.info(f"📦 Archived: {treatment_id[:8]} → {archive_path} "
                        f"({snapshot_count} snapshots)")
            return archive_path

        except Exception as e:
            logger.error(f"❌ Archive error [{treatment_id[:8]}]: {e}")
            return None

    def load_archive(self, treatment_id: str) -> Optional[dict]:
        """
        Load a treatment from its archive file.
        Looks up archive_path from the index.
        """
        try:
            index = self._db.fetch_one(
                "SELECT archive_path FROM treatment_index WHERE id = ?",
                (treatment_id,))

            if not index or not index.get('archive_path'):
                return None

            archive_path = index['archive_path']
            if not os.path.exists(archive_path):
                logger.warning(f"⚠️ Archive file missing: {archive_path}")
                return None

            with open(archive_path, 'r', encoding='utf-8') as f:
                return json.load(f)

        except Exception as e:
            logger.error(f"❌ Load archive error [{treatment_id[:8]}]: {e}")
            return None

    def delete_archive(self, treatment_id: str) -> bool:
        """
        Perform filesystem cleanup for an archived treatment.
        Deletes .json and .raw.jsonl files.
        """
        try:
            index = self._db.fetch_one(
                "SELECT archive_path FROM treatment_index WHERE id = ?",
                (treatment_id,))

            if not index or not index.get('archive_path'):
                return False

            path = index['archive_path']
            raw_path = path.replace('.json', '.raw.jsonl')

            # Delete main JSON
            if os.path.exists(path):
                os.remove(path)
                logger.info(f"🗑️ Deleted archive file: {path}")

            # Delete raw JSONL
            if os.path.exists(raw_path):
                os.remove(raw_path)
                logger.info(f"🗑️ Deleted raw forensic file: {raw_path}")

            return True
        except Exception as e:
            logger.error(f"❌ Delete archive error [{treatment_id[:8]}]: {e}")
            return False

    def ensure_index_for_active(self, treatment_id: str):
        """
        Ensure an active treatment has an index entry.
        Called when a treatment is opened.
        """
        treatment = self._db.get_treatment_by_id(treatment_id)
        if not treatment:
            return
        self._db.upsert_index(
            treatment_id=treatment_id,
            device_id=treatment.get('device_id', ''),
            patient_id=treatment.get('patient_id'),
            therapy_type=treatment.get('therapy_type_name'),
            start_time=treatment.get('start_time', ''),
            outcome='IN_PROGRESS',
            total_packets=treatment.get('total_packets', 0)
        )
