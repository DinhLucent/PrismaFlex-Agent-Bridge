import json
import os
import logging
import asyncio
import gzip
import shutil
import time
from datetime import datetime

logger = logging.getLogger(__name__)


def _safe_remove(filepath: str, retries: int = 3, delay: float = 0.5):
    """Remove a file with retry logic for Windows file locking.
    
    When Treatment Analyzer (or any external tool) has a file handle open,
    os.remove() on Windows raises PermissionError. This retries with
    exponential backoff to wait for the handle to be released.
    """
    for attempt in range(retries):
        try:
            os.remove(filepath)
            return True
        except PermissionError:
            if attempt < retries - 1:
                wait = delay * (2 ** attempt)  # 0.5s, 1s, 2s
                logger.warning(f"File locked, retry {attempt+1}/{retries} in {wait}s: {os.path.basename(filepath)}")
                time.sleep(wait)
            else:
                logger.error(f"Cannot delete (file locked by another process): {os.path.basename(filepath)}")
                return False
        except FileNotFoundError:
            return True  # Already gone
        except Exception as e:
            logger.error(f"Unexpected error deleting {os.path.basename(filepath)}: {e}")
            return False

class RawDataStreamer:
    """
    Handles streaming of raw telemetry packets to .jsonl files.
    This is the 'Heavy-Path' storage engine that bypasses SQLite.
    """
    
    def __init__(self, storage_dir: str = "data/treatments/raw"):
        self.storage_dir = storage_dir
        if not os.path.exists(self.storage_dir):
            os.makedirs(self.storage_dir, exist_ok=True)
            logger.info(f"Created raw treatment storage at: {self.storage_dir}")
            
        self._locks = {} # Per-device locks to prevent concurrent write corruption

    def _get_lock(self, device_id: str) -> asyncio.Lock:
        if device_id not in self._locks:
            self._locks[device_id] = asyncio.Lock()
        return self._locks[device_id]

    async def ensure_writable(self, treatment_id: str):
        """
        If raw file was compressed (.gz exists but .jsonl doesn't),
        decompress it back so we can resume appending.
        
        Clinical Grade: Prevents data loss when END → SAME PATIENT resume
        causes a new empty .jsonl to be created while all prior data is in .gz.
        """
        filepath = self.get_raw_filepath(treatment_id)
        gz_path = filepath + ".gz"
        if not os.path.exists(filepath) and os.path.exists(gz_path):
            try:
                def decompress():
                    with gzip.open(gz_path, 'rb') as f_in:
                        with open(filepath, 'wb') as f_out:
                            shutil.copyfileobj(f_in, f_out)
                    # Verify decompressed file before removing .gz
                    if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
                        _safe_remove(gz_path)
                        logger.info(f"🔄 Decompressed raw data for resumed treatment: {os.path.basename(filepath)}")
                    else:
                        logger.error(f"❌ Decompression verification failed for {treatment_id} — keeping .gz")
                        if os.path.exists(filepath):
                            _safe_remove(filepath)
                await asyncio.to_thread(decompress)
            except Exception as e:
                logger.error(f"Failed to decompress raw file for resumed treatment {treatment_id}: {e}")

    async def stream_packet(self, device_id: str, treatment_id: str, packet: dict):
        """
        Appends a packet to the treatment's raw JSONL file.
        Uses asyncio.to_thread for non-blocking I/O (no aiofiles req).
        """
        filename = f"treatment_{treatment_id}.raw.jsonl"
        filepath = os.path.join(self.storage_dir, filename)
        
        async with self._get_lock(device_id):
            try:
                # Clinical Grade: If .gz exists but .jsonl doesn't, decompress first
                # This handles END → SAME PATIENT resume where the file was compressed
                gz_path = filepath + ".gz"
                if not os.path.exists(filepath) and os.path.exists(gz_path):
                    def decompress():
                        with gzip.open(gz_path, 'rb') as f_in:
                            with open(filepath, 'wb') as f_out:
                                shutil.copyfileobj(f_in, f_out)
                        if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
                            _safe_remove(gz_path)
                            logger.info(f"🔄 Auto-decompressed raw data for resumed treatment {treatment_id[:8]}")
                        else:
                            logger.error(f"❌ Auto-decompression failed for {treatment_id[:8]} — keeping .gz")
                            if os.path.exists(filepath):
                                _safe_remove(filepath)
                    await asyncio.to_thread(decompress)

                line = json.dumps(packet) + "\n"
                
                # Clinical Grade: Offload disk I/O to a thread to keep event loop free
                def write_sync():
                    with open(filepath, mode='a', encoding='utf-8') as f:
                        f.write(line)
                        f.flush()
                        os.fsync(f.fileno())
                
                await asyncio.to_thread(write_sync)
                
            except Exception as e:
                logger.error(f"Failed to stream packet for {device_id} (Treatment {treatment_id}): {e}")

    def get_raw_filepath(self, treatment_id: str) -> str:
        return os.path.join(self.storage_dir, f"treatment_{treatment_id}.raw.jsonl")

    async def compress_treatment_file(self, device_id: str, treatment_id: str):
        """
        Compresses the .jsonl file to .gz and removes the original.
        Clinical Grade: Uses same per-device lock as stream_packet() to prevent
        race conditions between writing and compressing.
        """
        filepath = self.get_raw_filepath(treatment_id)
        if not os.path.exists(filepath):
            return

        gz_path = filepath + ".gz"
        async with self._get_lock(device_id):
            try:
                # Double-check after acquiring lock (file may have been removed)
                if not os.path.exists(filepath):
                    return

                # Offload heavy compression to a thread to not block the event loop
                def do_compress():
                    with open(filepath, 'rb') as f_in:
                        with gzip.open(gz_path, 'wb') as f_out:
                            shutil.copyfileobj(f_in, f_out)
                    # Verify .gz integrity before deleting original
                    if os.path.exists(gz_path) and os.path.getsize(gz_path) > 0:
                        _safe_remove(filepath)
                        logger.info(f"Compressed forensic log: {os.path.basename(gz_path)}")
                    else:
                        logger.error(f"Compression verification failed for {treatment_id} - keeping original")
                        if os.path.exists(gz_path):
                            _safe_remove(gz_path)

                await asyncio.to_thread(do_compress)
            except Exception as e:
                logger.error(f"Compression failed for {treatment_id}: {e}")
