"""
Treatment recorder for live and historical telemetry.

Key runtime rules:
- Open only on WAITINGSTART(4) or RUN(5) with a valid patient_id.
- RUN_TIME = 0 on a later RUN is the strongest signal for a fresh treatment.
- RUN_TIME > 0 may resume a previous treatment for the same device/patient
  even if an END packet was seen in between.
- END(8) closes the current writable segment, but does not permanently forbid
  same-patient continuation when machine counters clearly continue.

Raw packet ownership and snapshot ownership are coordinated here so the
timeline, raw files, and treatment identities stay aligned.
"""

import asyncio
import logging
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

from .raw_streamer import RawDataStreamer
from .treatment_database import TreatmentDatabase
from ..telemetry_contract import parse_clinical_timestamp

logger = logging.getLogger("PrismaFlexBackend")

TRIGGER_START_STATUSES = {4, 5}
AUTO_CLOSE_GAP_SECONDS = 86400
SAME_PATIENT_LOOKUP_HOURS = 48
IGNORED_PATIENT_IDS = {"N/A", "NONE", "NULL", ""}
RESUMPTION_WINDOW_MINUTES = 360

HARD_BOUNDARY_CLOSE_PREFIXES = (
    "Patient change",
    "RUN_TIME=0 fresh start",
    "Backfill closed on live handoff",
    "Replaced by promoted backfill session",
)


class ActiveSession:
    """Minimal in-memory tracking for one device's active recording."""

    __slots__ = (
        "treatment_id",
        "patient_id",
        "last_seen",
        "total_packets",
        "start_pkt_time",
        "last_status_id",
        "seen_positive_run_time",
    )

    def __init__(
        self,
        treatment_id: str,
        patient_id: str,
        last_seen: Optional[datetime] = None,
        total_packets: int = 0,
        start_pkt_time: Optional[datetime] = None,
        last_status_id: int = -1,
        seen_positive_run_time: bool = False,
    ):
        self.treatment_id = treatment_id
        self.patient_id = patient_id
        self.last_seen = last_seen or datetime.now(timezone.utc)
        self.total_packets = total_packets
        self.start_pkt_time = start_pkt_time or self.last_seen
        self.last_status_id = last_status_id
        self.seen_positive_run_time = seen_positive_run_time


@dataclass
class PacketRouting:
    """How the current packet should be persisted."""

    snapshot_treatment_id: Optional[str] = None
    raw_treatment_id: Optional[str] = None
    flush_snapshot_after: bool = False
    raw_finalizers: List[Tuple[str, bool]] = field(default_factory=list)


class TreatmentRecorderService:
    """
    Simple treatment recorder with explicit hard and soft boundaries.

    Hard boundaries:
    - patient change
    - explicit fresh start signaled by RUN_TIME = 0 on a later RUN

    Soft boundaries:
    - END received
    - timeout/recovery conditions where RUN_TIME > 0 may reconnect to the
      previous treatment when no hard boundary happened.
    """

    def __init__(self, db: TreatmentDatabase, streamer: RawDataStreamer):
        self._db = db
        self._streamer = streamer
        self._sessions: Dict[str, ActiveSession] = {}
        self._backfill_sessions: Dict[str, ActiveSession] = {}
        self.on_open = None
        self.on_close = None
        self._recover_from_db()

    def _recover_from_db(self):
        """Restore IN_PROGRESS sessions with simple conflict cleanup."""
        try:
            in_progress = self._db.get_all_in_progress()
            by_device: Dict[str, List[dict]] = {}
            for row in in_progress:
                by_device.setdefault(row["device_id"], []).append(row)

            active_list: List[dict] = []
            for device_id, treatments in by_device.items():
                if len(treatments) == 1:
                    active_list.append(treatments[0])
                    continue

                treatments.sort(key=lambda item: item.get("total_packets", 0), reverse=True)
                best = treatments[0]
                orphans = treatments[1:]
                logger.warning(
                    f"Recovery conflict for {device_id}: found {len(treatments)} active sessions. "
                    f"Keeping {best['id'][:8]} with {best.get('total_packets', 0)} packets."
                )
                for orphan in orphans:
                    orphan_id = orphan["id"]
                    packets = orphan.get("total_packets", 0)
                    if packets < 10:
                        logger.info(f"Recovery cleanup: deleting ghost {orphan_id[:8]} ({packets} packets)")
                        self._db.delete_treatment(orphan_id)
                    else:
                        now_iso = datetime.now(timezone(timedelta(hours=7))).isoformat()
                        logger.info(f"Recovery cleanup: auto-closing orphan {orphan_id[:8]}")
                        self._db.update_treatment(
                            orphan_id,
                            outcome="COMPLETED",
                            fsm_state="CLOSED",
                            close_reason="RECOVERY_CONFLICT_RESOLVED",
                            end_time=now_iso,
                        )
                        self._db.upsert_index(
                            treatment_id=orphan_id,
                            device_id=device_id,
                            outcome="COMPLETED",
                            close_reason="RECOVERY_CONFLICT_RESOLVED",
                            end_time=now_iso,
                        )
                active_list.append(best)

            now_fallback = datetime.now(timezone(timedelta(hours=7)))
            for row in active_list:
                try:
                    try:
                        last_seen = self._parse_time(row["last_seen_time"])
                    except Exception:
                        last_seen = now_fallback

                    start_pkt_time = last_seen
                    if row.get("start_time"):
                        try:
                            start_pkt_time = self._parse_time(row["start_time"])
                        except Exception:
                            pass

                    self._sessions[row["device_id"]] = ActiveSession(
                        treatment_id=row["id"],
                        patient_id=row["patient_id"],
                        last_seen=last_seen,
                        total_packets=row.get("total_packets", 0),
                        start_pkt_time=start_pkt_time,
                        seen_positive_run_time=bool((row.get("last_run_time_sec") or 0) > 0),
                    )
                    self._db.update_treatment(row["id"], had_program_restart=1)
                    logger.info(
                        f"Recovery resumed {row['id'][:8]} "
                        f"({row['device_id']}/{row['patient_id']}, {row.get('total_packets', 0)} pkts)"
                    )
                except Exception as exc:
                    logger.error(f"Recovery error for {row.get('id')}: {exc}")

            if active_list:
                logger.info(f"Recovery restored {len(self._sessions)} sessions")
        except Exception as exc:
            logger.error(f"Treatment recovery failed: {exc}")

    async def process_packet(
        self,
        device_id: str,
        timestamp: str,
        header: dict,
        body: dict,
        meta: dict = None,
        is_live: bool = True,
    ):
        """Process one telemetry packet and route raw/snapshot ownership."""
        routing = PacketRouting()
        try:
            status_id = header.get("therapy_status_id")
            if status_id is None:
                return {"treatment_id": None, "flush_snapshot_after": False}

            anticoag_type = None
            initial_run_time = None
            for param in body.get("parameters", []):
                pid = param.get("id")
                if pid == 409:
                    raw_val = param.get("value_text") or str(param.get("value"))
                    if "Heparin" in raw_val:
                        anticoag_type = "Heparin"
                    elif "Citrate" in raw_val or "Cit/Cal" in raw_val:
                        anticoag_type = "Citrate"
                    elif "None" in raw_val:
                        anticoag_type = "None"
                    else:
                        anticoag_type = raw_val
                elif pid == 461:
                    try:
                        initial_run_time = float(param.get("value", 0))
                    except (ValueError, TypeError):
                        initial_run_time = None

            patient_id = self._clean_patient_id(header.get("patient_id"))
            pkt_time = self._parse_time(timestamp)
            session_map = self._sessions if is_live else self._backfill_sessions
            session = session_map.get(device_id)

            if session is None:
                should_open = status_id in TRIGGER_START_STATUSES and patient_id
                if should_open:
                    self._open(
                        device_id,
                        patient_id,
                        pkt_time,
                        timestamp,
                        header,
                        session_map,
                        anticoag_type=anticoag_type,
                        initial_run_time=initial_run_time,
                    )
                    if is_live and device_id in self._backfill_sessions:
                        routing.raw_finalizers.extend(
                            self._handoff_backfill_to_live(device_id, patient_id, initial_run_time)
                        )
                    session = session_map.get(device_id)
                    if session:
                        routing.snapshot_treatment_id = session.treatment_id
                        routing.raw_treatment_id = session.treatment_id
            else:
                routing = self._process(
                    device_id,
                    session,
                    status_id,
                    patient_id,
                    pkt_time,
                    timestamp,
                    header,
                    session_map,
                    is_live=is_live,
                    anticoag_type=anticoag_type,
                    initial_run_time=initial_run_time,
                )

            if routing.raw_treatment_id:
                packet_data = {
                    "meta": meta or {"device_id": device_id, "timestamp": timestamp},
                    "s_header": header,
                    "s_body": body,
                }
                await self._streamer.stream_packet(device_id, routing.raw_treatment_id, packet_data)

            for treatment_id, discard_raw in routing.raw_finalizers:
                await self._finalize_raw_close(device_id, treatment_id, discard_raw)

        except Exception as exc:
            logger.error(f"Treatment recorder [{device_id}]: {exc}")

        return {
            "treatment_id": routing.snapshot_treatment_id,
            "flush_snapshot_after": routing.flush_snapshot_after,
        }

    def _open(
        self,
        device_id: str,
        patient_id: str,
        pkt_time: datetime,
        timestamp: str,
        header: dict,
        target_map: dict,
        anticoag_type: str = None,
        initial_run_time: float = None,
    ):
        local_timestamp = pkt_time.isoformat()

        if device_id in target_map:
            old_session = target_map[device_id]
            if old_session.patient_id == patient_id:
                logger.info(
                    f"[REC] CONTINUING session {old_session.treatment_id[:8]} "
                    f"for {device_id}/{patient_id}"
                )
                return

            logger.warning(
                f"[REC] Patient change: closing {old_session.treatment_id[:8]} "
                f"({old_session.patient_id} -> {patient_id})"
            )
            self._close(
                device_id,
                old_session,
                local_timestamp,
                reason=f"Patient change: {old_session.patient_id} -> {patient_id}",
                target_map=target_map,
            )

        explicit_new_run = initial_run_time is not None and initial_run_time == 0

        if initial_run_time is not None and initial_run_time > 0:
            wide_cutoff = (pkt_time - timedelta(hours=SAME_PATIENT_LOOKUP_HOURS)).isoformat()
            last_same = self._db.get_last_closed_treatment(device_id, patient_id, wide_cutoff)
            if last_same and self._can_resume_closed_treatment(last_same):
                treatment_id = last_same["id"]
                logger.info(
                    f"[REC] SAME PATIENT resume: {device_id}/{patient_id} "
                    f"RUN_TIME={initial_run_time:.0f}s -> {treatment_id[:8]}"
                )
                self._db.update_treatment(
                    treatment_id,
                    outcome="IN_PROGRESS",
                    fsm_state="RECORDING",
                    end_time=None,
                    close_reason=None,
                )
                self._db.upsert_index(
                    treatment_id=treatment_id,
                    device_id=device_id,
                    patient_id=patient_id,
                    outcome="IN_PROGRESS",
                    end_time=None,
                    total_packets=last_same.get("total_packets", 0),
                )
                self._db.log_status(
                    treatment_id,
                    device_id,
                    timestamp,
                    header.get("therapy_status_id", -1),
                    "RECORDING",
                    patient_id,
                    f"SAME PATIENT resume (RUN_TIME={initial_run_time:.0f}s)",
                )
                start_pkt_time = pkt_time
                if last_same.get("start_time"):
                    try:
                        start_pkt_time = self._parse_time(last_same["start_time"])
                    except Exception:
                        pass
                target_map[device_id] = ActiveSession(
                    treatment_id=treatment_id,
                    patient_id=patient_id,
                    last_seen=pkt_time,
                    total_packets=last_same.get("total_packets", 0) + 1,
                    start_pkt_time=start_pkt_time,
                    seen_positive_run_time=True,
                )
                if self.on_open:
                    try:
                        self.on_open(treatment_id)
                    except Exception as exc:
                        logger.error(f"on_open hook error: {exc}")
                return
            elif last_same:
                logger.info(
                    f"[REC] HARD boundary blocks SAME PATIENT resume: "
                    f"{device_id}/{patient_id} last={last_same['id'][:8]} "
                    f"reason={last_same.get('close_reason')}"
                )

        last_closed = None
        if not explicit_new_run:
            cutoff = (pkt_time - timedelta(minutes=RESUMPTION_WINDOW_MINUTES)).isoformat()
            last_closed = self._db.get_last_closed_treatment(device_id, patient_id, cutoff)

        if last_closed and self._can_resume_closed_treatment(last_closed):
            treatment_id = last_closed["id"]
            logger.info(f"[REC] RESUMING recently closed session: {treatment_id[:8]} for {device_id}/{patient_id}")
            self._db.update_treatment(
                treatment_id,
                outcome="IN_PROGRESS",
                fsm_state="RECORDING",
                end_time=None,
                close_reason=None,
            )
            self._db.upsert_index(
                treatment_id=treatment_id,
                device_id=device_id,
                patient_id=patient_id,
                outcome="IN_PROGRESS",
                end_time=None,
                total_packets=last_closed.get("total_packets", 0),
            )

            start_pkt_time = pkt_time
            if last_closed.get("start_time"):
                try:
                    start_pkt_time = self._parse_time(last_closed["start_time"])
                except Exception:
                    pass

            target_map[device_id] = ActiveSession(
                treatment_id=treatment_id,
                patient_id=patient_id,
                last_seen=pkt_time,
                total_packets=last_closed.get("total_packets", 0) + 1,
                start_pkt_time=start_pkt_time,
                seen_positive_run_time=bool((initial_run_time or 0) > 0),
            )
        else:
            if last_closed and not self._can_resume_closed_treatment(last_closed):
                logger.info(
                    f"[REC] HARD boundary blocks fallback resume: "
                    f"{device_id}/{patient_id} last={last_closed['id'][:8]} "
                    f"reason={last_closed.get('close_reason')}"
                )

            treatment_id = str(uuid.uuid4())
            self._db.create_treatment(
                treatment_id=treatment_id,
                device_id=device_id,
                machine_id=header.get("machine_id"),
                patient_id=patient_id,
                therapy_type_id=header.get("therapy_type_id"),
                therapy_type_name=header.get("therapy_type_id_name"),
                sw_version=header.get("sw_version"),
                timestamp=local_timestamp,
                anticoag_type_id=header.get("anticoag_type_id"),
            )
            self._db.log_status(
                treatment_id,
                device_id,
                local_timestamp,
                header.get("therapy_status_id", -1),
                "RECORDING",
                patient_id,
                "Record opened",
            )
            target_map[device_id] = ActiveSession(
                treatment_id=treatment_id,
                patient_id=patient_id,
                last_seen=pkt_time,
                total_packets=1,
                start_pkt_time=pkt_time,
                seen_positive_run_time=bool((initial_run_time or 0) > 0),
            )
            try:
                self._db.upsert_index(
                    treatment_id=treatment_id,
                    device_id=device_id,
                    patient_id=patient_id,
                    therapy_type=header.get("therapy_type_id_name") or "CRRT",
                    start_time=local_timestamp,
                    outcome="IN_PROGRESS",
                    anticoag_type=anticoag_type,
                )
            except Exception as exc:
                logger.error(f"Failed to sync index for {treatment_id}: {exc}")

        mode = "BACKFILL" if target_map is self._backfill_sessions else "LIVE"
        logger.info(f"[REC] {mode} OPEN: {device_id}/{patient_id} ({target_map[device_id].treatment_id[:8]})")
        if self.on_open:
            try:
                self.on_open(target_map[device_id].treatment_id)
            except Exception as exc:
                logger.error(f"on_open hook error: {exc}")

    def _handoff_backfill_to_live(
        self,
        device_id: str,
        live_patient_id: str,
        live_run_time: float = None,
    ) -> List[Tuple[str, bool]]:
        """
        When LIVE starts on a device that still has a backfill session:
        - same patient + RUN_TIME > 0 -> promote backfill session to live
        - otherwise -> close the stale backfill session
        """
        raw_finalizers: List[Tuple[str, bool]] = []
        bf_session = self._backfill_sessions.get(device_id)
        if bf_session is None:
            return raw_finalizers

        same_patient = live_patient_id == bf_session.patient_id
        has_run_time = live_run_time is not None and live_run_time > 0

        if same_patient and has_run_time:
            new_live = self._sessions.get(device_id)
            if new_live and new_live.treatment_id != bf_session.treatment_id:
                close_meta = self._close(
                    device_id,
                    new_live,
                    bf_session.last_seen.isoformat(),
                    "Replaced by promoted backfill session",
                    self._sessions,
                )
                raw_finalizers.append((close_meta["treatment_id"], close_meta["discard_raw"]))

            self._sessions[device_id] = bf_session
            del self._backfill_sessions[device_id]
            logger.info(
                f"[REC] PROMOTE backfill->live: {device_id}/{bf_session.patient_id} "
                f"({bf_session.treatment_id[:8]}) RUN_TIME={live_run_time}"
            )
        else:
            reason = "Patient change" if not same_patient else "RUN_TIME=0 (fresh start)"
            close_meta = self._close(
                device_id,
                bf_session,
                bf_session.last_seen.isoformat(),
                f"Backfill closed on live handoff: {reason}",
                self._backfill_sessions,
            )
            raw_finalizers.append((close_meta["treatment_id"], close_meta["discard_raw"]))
            logger.info(f"[REC] CLOSE backfill on handoff: {device_id} reason={reason}")

        return raw_finalizers

    def _process(
        self,
        device_id: str,
        session: ActiveSession,
        status_id: int,
        patient_id: Optional[str],
        pkt_time: datetime,
        timestamp: str,
        header: dict,
        session_map: dict,
        is_live: bool = True,
        anticoag_type: str = None,
        initial_run_time: float = None,
    ) -> PacketRouting:
        routing = PacketRouting()
        session.total_packets += 1
        had_positive_run_time = session.seen_positive_run_time
        is_forward_packet = pkt_time >= session.last_seen
        if initial_run_time is not None and initial_run_time > 0:
            session.seen_positive_run_time = True

        if pkt_time >= session.last_seen:
            gap_seconds = (pkt_time - session.last_seen).total_seconds()
            if gap_seconds > AUTO_CLOSE_GAP_SECONDS:
                close_meta = self._close(
                    device_id,
                    session,
                    session.last_seen.isoformat(),
                    f"AUTO_TIMEOUT: No data for {gap_seconds/3600:.1f}h",
                    session_map,
                )
                routing.raw_finalizers.append((close_meta["treatment_id"], close_meta["discard_raw"]))
                if status_id in TRIGGER_START_STATUSES and patient_id:
                    self._open(
                        device_id,
                        patient_id,
                        pkt_time,
                        timestamp,
                        header,
                        session_map,
                        anticoag_type=anticoag_type,
                    )
                    new_session = session_map.get(device_id)
                    if new_session:
                        routing.snapshot_treatment_id = new_session.treatment_id
                        routing.raw_treatment_id = new_session.treatment_id
                else:
                    routing.flush_snapshot_after = True
                return routing

            if gap_seconds > 300:
                self._db.update_treatment(session.treatment_id, had_interruption=1)
                self._db.log_status(
                    session.treatment_id,
                    device_id,
                    pkt_time.isoformat(),
                    status_id,
                    "RECONNECTED",
                    patient_id,
                    f"Gap: {int(gap_seconds)}s ({gap_seconds/3600:.1f}h)",
                )
                logger.warning(
                    f"[REC] GAP: {device_id}/{session.patient_id} "
                    f"gap={int(gap_seconds)}s ({gap_seconds/3600:.1f}h)"
                )

            session.last_seen = pkt_time

        if status_id == 8:
            close_meta = self._close(device_id, session, pkt_time.isoformat(), "END received", session_map)
            routing.snapshot_treatment_id = close_meta["treatment_id"]
            routing.raw_treatment_id = close_meta["treatment_id"]
            routing.flush_snapshot_after = True
            routing.raw_finalizers.append((close_meta["treatment_id"], close_meta["discard_raw"]))
            return routing

        if patient_id and patient_id != session.patient_id:
            close_meta = self._close(device_id, session, pkt_time.isoformat(), "Patient change", session_map)
            routing.raw_finalizers.append((close_meta["treatment_id"], close_meta["discard_raw"]))
            if status_id in TRIGGER_START_STATUSES:
                self._open(
                    device_id,
                    patient_id,
                    pkt_time,
                    timestamp,
                    header,
                    session_map,
                    anticoag_type=anticoag_type,
                )
                new_session = session_map.get(device_id)
                if new_session:
                    routing.snapshot_treatment_id = new_session.treatment_id
                    routing.raw_treatment_id = new_session.treatment_id
            else:
                routing.flush_snapshot_after = True
            return routing

        if patient_id and patient_id == session.patient_id:
            if status_id == 5 and initial_run_time == 0 and had_positive_run_time and is_forward_packet:
                close_meta = self._close(
                    device_id,
                    session,
                    pkt_time.isoformat(),
                    "RUN_TIME=0 fresh start",
                    session_map,
                )
                routing.raw_finalizers.append((close_meta["treatment_id"], close_meta["discard_raw"]))
                self._open(
                    device_id,
                    patient_id,
                    pkt_time,
                    timestamp,
                    header,
                    session_map,
                    anticoag_type=anticoag_type,
                    initial_run_time=initial_run_time,
                )
                new_session = session_map.get(device_id)
                if new_session:
                    routing.snapshot_treatment_id = new_session.treatment_id
                    routing.raw_treatment_id = new_session.treatment_id
                return routing

        if status_id != session.last_status_id:
            self._db.log_status(
                session.treatment_id,
                device_id,
                pkt_time.isoformat(),
                status_id,
                "RECORDING",
                patient_id or session.patient_id,
            )
            session.last_status_id = status_id

        if session.total_packets % 30 == 0:
            elapsed_sec = max(0, int((pkt_time - session.start_pkt_time).total_seconds()))
            self._db.update_treatment(
                session.treatment_id,
                last_seen_time=pkt_time.isoformat(),
                total_run_seconds=elapsed_sec,
                total_packets=session.total_packets,
            )
            try:
                self._db.upsert_index(
                    treatment_id=session.treatment_id,
                    device_id=device_id,
                    duration_sec=elapsed_sec,
                    total_packets=session.total_packets,
                    anticoag_type=anticoag_type,
                )
            except Exception as exc:
                logger.error(f"Failed periodic index sync: {exc}")

        routing.snapshot_treatment_id = session.treatment_id
        routing.raw_treatment_id = session.treatment_id
        return routing

    def _close(
        self,
        device_id: str,
        session: ActiveSession,
        timestamp: str,
        reason: str = "",
        target_map: dict = None,
    ) -> Dict[str, Any]:
        pkt_time = self._parse_time(timestamp)
        elapsed_sec = int((pkt_time - session.start_pkt_time).total_seconds())
        discard_raw = elapsed_sec < 300

        if discard_raw:
            logger.info(
                f"[REC] DISCARDING ghost session: {device_id}/{session.patient_id} "
                f"elapsed={elapsed_sec}s (<300s)"
            )
            self._db.delete_treatment(session.treatment_id)
        else:
            duration_sec = elapsed_sec
            self._db.update_treatment(
                session.treatment_id,
                end_time=pkt_time.isoformat(),
                last_seen_time=pkt_time.isoformat(),
                outcome="COMPLETED",
                fsm_state="CLOSED",
                total_packets=session.total_packets,
                total_run_seconds=duration_sec,
                close_reason=reason,
            )
            try:
                self._db.upsert_index(
                    treatment_id=session.treatment_id,
                    device_id=device_id,
                    patient_id=session.patient_id,
                    end_time=pkt_time.isoformat(),
                    outcome="COMPLETED",
                    close_reason=reason,
                    total_packets=session.total_packets,
                    duration_sec=duration_sec,
                )
            except Exception as exc:
                logger.error(f"Failed to sync index closure for {session.treatment_id}: {exc}")

        self._db.log_status(
            session.treatment_id,
            device_id,
            pkt_time.isoformat(),
            -1,
            "CLOSED",
            session.patient_id,
            f"CLOSED: {reason}",
        )

        mode = "BACKFILL" if target_map is self._backfill_sessions else "LIVE"
        logger.info(
            f"[REC] {mode} CLOSE: {device_id}/{session.patient_id} "
            f"({session.total_packets} pkts, {session.treatment_id[:8]}) reason={reason}"
        )

        treatment_id = session.treatment_id
        if target_map is not None and device_id in target_map:
            del target_map[device_id]
        elif device_id in self._sessions:
            del self._sessions[device_id]

        if self.on_close:
            try:
                self.on_close(device_id, treatment_id)
            except Exception as exc:
                logger.error(f"on_close hook error: {exc}")

        return {"treatment_id": treatment_id, "discard_raw": discard_raw}

    def enforce_auto_close(self, current_logical_time: datetime = None) -> int:
        """
        Close stale sessions and clean up leftover uncompressed raw files.

        LIVE sessions use wall clock.
        BACKFILL sessions use logical time when it is explicitly provided.
        """
        closed_count = 0
        live_reference = datetime.now(timezone.utc)

        for device_id, session in list(self._sessions.items()):
            gap_seconds = (live_reference - session.last_seen).total_seconds()
            if gap_seconds > AUTO_CLOSE_GAP_SECONDS:
                try:
                    close_meta = self._close(
                        device_id,
                        session,
                        session.last_seen.isoformat(),
                        f"AUTO_TIMEOUT (Live): No data for {gap_seconds/3600:.1f}h",
                        target_map=self._sessions,
                    )
                    closed_count += 1
                    loop = asyncio.get_running_loop()
                    loop.create_task(
                        self._finalize_raw_close(device_id, close_meta["treatment_id"], close_meta["discard_raw"])
                    )
                except Exception as exc:
                    logger.error(f"Failed to auto-close live session {session.treatment_id}: {exc}")

        if current_logical_time is not None:
            for device_id, session in list(self._backfill_sessions.items()):
                gap_seconds = (current_logical_time - session.last_seen).total_seconds()
                if gap_seconds > AUTO_CLOSE_GAP_SECONDS:
                    try:
                        close_meta = self._close(
                            device_id,
                            session,
                            session.last_seen.isoformat(),
                            f"AUTO_TIMEOUT (Backfill): No data for {gap_seconds/3600:.1f}h",
                            target_map=self._backfill_sessions,
                        )
                        closed_count += 1
                        loop = asyncio.get_running_loop()
                        loop.create_task(
                            self._finalize_raw_close(device_id, close_meta["treatment_id"], close_meta["discard_raw"])
                        )
                    except Exception as exc:
                        logger.error(f"Failed to auto-close backfill session {session.treatment_id}: {exc}")

        try:
            cutoff = (live_reference - timedelta(minutes=RESUMPTION_WINDOW_MINUTES)).isoformat()
            stale = self._db.fetch_all(
                "SELECT id, device_id FROM treatments WHERE outcome = 'COMPLETED' AND end_time < ? AND end_time IS NOT NULL",
                (cutoff,),
            )
            active_ids = {session.treatment_id for session in self._sessions.values()}
            active_ids.update(session.treatment_id for session in self._backfill_sessions.values())
            for row in stale:
                treatment_id = row["id"]
                device_id = row.get("device_id", "unknown")
                raw_path = self._streamer.get_raw_filepath(treatment_id)
                if treatment_id in active_ids or not os.path.exists(raw_path):
                    continue
                try:
                    loop = asyncio.get_running_loop()
                    loop.create_task(self._streamer.compress_treatment_file(device_id, treatment_id))
                except RuntimeError:
                    pass
        except Exception as exc:
            logger.error(f"Deferred compression scan error: {exc}")

        return closed_count

    def _clean_patient_id(self, raw: Any) -> Optional[str]:
        if raw is None:
            return None
        patient_id = str(raw).strip()
        if patient_id.upper() in IGNORED_PATIENT_IDS:
            return None
        return patient_id

    def _parse_time(self, timestamp: str) -> datetime:
        return parse_clinical_timestamp(timestamp)

    def _can_resume_closed_treatment(self, treatment_row: Optional[dict]) -> bool:
        if not treatment_row:
            return False
        reason = str(treatment_row.get("close_reason") or "").strip().lower()
        return not any(reason.startswith(prefix.lower()) for prefix in HARD_BOUNDARY_CLOSE_PREFIXES)

    async def _finalize_raw_close(self, device_id: str, treatment_id: str, discard_raw: bool):
        if discard_raw:
            from .raw_streamer import _safe_remove

            raw_path = self._streamer.get_raw_filepath(treatment_id)
            if os.path.exists(raw_path):
                await asyncio.to_thread(_safe_remove, raw_path)
            gz_path = raw_path + ".gz"
            if os.path.exists(gz_path):
                await asyncio.to_thread(_safe_remove, gz_path)
            return

        await self._streamer.compress_treatment_file(device_id, treatment_id)

    def clear_device(self, device_id: str):
        """Force-clear any active sessions for a device."""
        self._sessions.pop(device_id, None)
        self._backfill_sessions.pop(device_id, None)
        logger.info(f"[REC] Manual cache clear for {device_id}")

    def get_active_sessions(self) -> dict:
        return {
            device_id: {
                "treatment_id": session.treatment_id,
                "patient_id": session.patient_id,
                "packets": session.total_packets,
                "last_seen": session.last_seen.isoformat(),
            }
            for device_id, session in self._sessions.items()
        }
