"""
Historical Backfill Importer
============================
Specialized projector for historical data ingestion.
Decoupled from live paths (WebSocket, heartbeat, recovery).

v3.0: Core algorithm refactor
  - Removed gap-fill (frontend handles GAP display)
  - Fixed time semantics: slot_first_pkt_time for snapshot timestamp
  - Fixed OC value state: extract values FIRST, then detect OC
  - H00 frozen at first stable reading (not overwritten at hour end)
  - Bounce detection: true A->B->A only (A != B)
"""
import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, Optional, Any

from .postgres_treatment_db import PostgresTreatmentDB as TreatmentDatabase
from .treatment_snapshot_service import CRRT_PID_MAP, PID_SCALE_MAP

logger = logging.getLogger("PrismaFlexBackend")

DEFAULT_TZ = timezone(timedelta(hours=7))

# Columns to include in auto_data snapshots
_SNAPSHOT_COLS = [
    'qb', 'qd', 'qpbp', 'pa', 'pv', 'pbe', 'tmp',
    'uf_total', 'uf_hourly', 'effluent_flow',
    'run_time_sec', 'blood_vol', 'heparin_rate',
    'pt_weight', 'uf_rate_target', 'citrate_dose',
    'citrate_conc', 'citrate_load', 'calcium_comp',
    'calcium_rate', 'anticoag_type_id'
]

# OC detection: only true prescription PIDs (not cumulative counters)
_OC_PIDS = {17, 21, 22, 25}  # QB, QD, QPBP, UF_RATE_TARGET
_OC_PID_COLS = {17: 'qb', 21: 'qd', 22: 'qpbp', 25: 'uf_rate_target'}
_OC_STABILIZE = 3  # Consecutive packets to confirm a change


class HistoricalBackfillImporter:
    """
    Ingests raw packets from historical archives.
    Deterministic projection: same input always produces same output.
    """

    def __init__(self, db: TreatmentDatabase):
        self._db = db
        self._batch_cache: Dict[str, dict] = {}
        self._device_map: Dict[str, str] = {}
        self._oc_counters: Dict[str, int] = {}

        # OC detection state (per treatment_id)
        self._last_snap_vals: Dict[str, Dict[str, float]] = {}  # {tid: {col: val}}
        self._oc_candidates: Dict[str, Dict[int, tuple]] = {}   # {tid: {pid: (val, streak)}}
        self._oc_history: Dict[str, Dict[int, list]] = {}       # {tid: {pid: [prev2, prev1]}}

        # Out-of-order detection (BACKFILL_INPUT_CONTRACT enforcement)
        self._last_pkt_times: Dict[str, datetime] = {}  # {tid: last_packet_time}
        self._ooo_counters: Dict[str, int] = {}          # {tid: count}

    # ─── Main Entry Point ──────────────────────────────────────

    def process_packet(self, treatment_id: str, device_id: str,
                       packet_time: datetime, treatment_start: datetime,
                       body: dict):
        """Process a single historical packet.
        
        Algorithm (v3.0):
          1. Compute hour_num deterministically
          2. Extract PID values into cache (NEW values)
          3. Detect order changes (compare NEW cache against saved baseline)
          4. Handle hour transition (flush previous hour)
          5. H00 early snap (freeze baseline)
        """
        # Timezone guard
        if packet_time.tzinfo is None:
            packet_time = packet_time.replace(tzinfo=DEFAULT_TZ)
        if treatment_start.tzinfo is None:
            treatment_start = treatment_start.replace(tzinfo=DEFAULT_TZ)

        self._device_map[treatment_id] = device_id

        # Out-of-order detection
        last_seen = self._last_pkt_times.get(treatment_id)
        if last_seen and packet_time < last_seen:
            ooo = self._ooo_counters.get(treatment_id, 0) + 1
            self._ooo_counters[treatment_id] = ooo
            if ooo <= 5 or ooo % 100 == 0:
                logger.warning(f"[BACKFILL] OOO#{ooo}: {treatment_id[:8]} "
                               f"pkt={packet_time.isoformat()} < last={last_seen.isoformat()} "
                               f"(delta={int((last_seen - packet_time).total_seconds())}s)")
        self._last_pkt_times[treatment_id] = max(packet_time, last_seen) if last_seen else packet_time

        # 1. Deterministic Hour Slot
        elapsed = (packet_time - treatment_start).total_seconds()
        hour_num = max(0, int(elapsed / 3600))

        # Initialize cache if first packet for this treatment
        if treatment_id not in self._batch_cache:
            # Read checkpoint from DB (resume after restart)
            checkpoint = None
            try:
                checkpoint = self._db.get_projection_checkpoint(treatment_id)
            except Exception:
                pass  # First run or DB issue — start fresh

            resume_hour = -1
            resume_oc = 0
            h00_done = False

            if checkpoint:
                resume_hour = checkpoint.get('last_hour_slot', -1)
                resume_oc = checkpoint.get('last_oc_counter', 0)
                h00_done = resume_hour >= 0  # H00 already committed
                # Restore OC baseline from checkpoint
                oc_vals = checkpoint.get('last_oc_values') or {}
                if oc_vals and treatment_id not in self._last_snap_vals:
                    self._last_snap_vals[treatment_id] = dict(oc_vals)
                if resume_oc > 0:
                    self._oc_counters[treatment_id] = resume_oc
                logger.info(f"[BACKFILL] Resume checkpoint: {treatment_id[:8]} "
                            f"hour={resume_hour} oc={resume_oc}")

            self._batch_cache[treatment_id] = {
                'hour_num': hour_num,
                'values': {},
                'slot_first_pkt_time': packet_time,
                'slot_last_pkt_time': packet_time,
                'pkt_count': 0,
                'h00_flushed': h00_done,
            }

        cache = self._batch_cache[treatment_id]

        # 2. Extract PID values into cache FIRST
        #    This ensures cache['values'] has the NEW merged values.
        self._extract_values(cache, body)
        cache['slot_last_pkt_time'] = packet_time
        cache['pkt_count'] += 1

        # 3. OC detection — compares raw body PIDs against _last_snap_vals
        #    baseline. Since _last_snap_vals is only updated on snapshot SAVE,
        #    extracting first doesn't pollute the baseline.
        #    OC snapshot reads from cache['values'] which now has NEW state.
        self._detect_order_changes(treatment_id, device_id, packet_time, body)

        # 4. Hour transition — FORWARD-ONLY progression
        #    Late packets (hour_num < current) are absorbed into current cache
        #    without triggering flush. This handles out-of-order timestamps
        #    from multi-channel Mirth data.
        if hour_num > cache['hour_num']:
            prev_hour = cache['hour_num']
            # Skip H00 re-flush if already early-snapped (preserve baseline)
            if not (prev_hour == 0 and cache.get('h00_flushed')):
                self.flush_treatment(treatment_id)

            # No gap-fill: missing hours simply don't exist in DB.
            # Frontend already renders virtual GAP rows.

            # New hour cache — carry forward current values
            self._batch_cache[treatment_id] = {
                'hour_num': hour_num,
                'values': dict(cache['values']),       # Carry forward
                'slot_first_pkt_time': packet_time,    # First pkt of NEW hour
                'slot_last_pkt_time': packet_time,
                'pkt_count': 1,  # This packet already counted
                'h00_flushed': cache.get('h00_flushed', False),
            }
            cache = self._batch_cache[treatment_id]
        # Late packets (hour_num < cache['hour_num']): absorbed silently.
        # Values are already extracted (step 2) and OC is already checked (step 3).

        # 5. H00 early snap — freeze baseline after ~10 packets
        if hour_num == 0 and not cache.get('h00_flushed') and cache['pkt_count'] >= 10:
            self.flush_treatment(treatment_id)
            cache['h00_flushed'] = True

    # ─── Snapshot Persistence ──────────────────────────────────

    def flush_treatment(self, treatment_id: str):
        """Save the currently accumulated cache as an hourly snapshot."""
        cache = self._batch_cache.get(treatment_id)
        if not cache or not cache['values']:
            return

        hour_num = cache['hour_num']
        hour_label = f"H{hour_num:02d}"
        # Use FIRST packet time of the slot (not last — prevents baseline drift)
        snap_time = cache['slot_first_pkt_time']

        auto_data = self._build_auto_data(cache['values'])
        if not auto_data:
            return

        try:
            device_id = self._get_device_id(treatment_id)
            self._db.upsert_snapshot(
                treatment_id=treatment_id,
                device_id=device_id,
                hour_label=hour_label,
                snapshot_time=snap_time.isoformat(),
                auto_data=auto_data,
                hour_slot=hour_num,
                source='BACKFILL'
            )
            self._sync_oc_baseline(treatment_id, auto_data)
            # Write-through: projection checkpoint
            try:
                self._db.upsert_projection_checkpoint(
                    treatment_id,
                    last_hour_slot=hour_num,
                    slot_anchor_time=snap_time.isoformat(),
                )
            except Exception as e:
                logger.error(f"Projection checkpoint error [{treatment_id[:8]}]: {e}")
            logger.info(f"Backfill Snapshot: {treatment_id[:8]} {hour_label}")
        except Exception as e:
            logger.error(f"Backfill Save Error [{treatment_id[:8]}]: {e}")

    # ─── Value Extraction ──────────────────────────────────────

    def _extract_values(self, cache: dict, body: dict):
        """Extract PID values from body into cache['values']."""
        for p in body.get('parameters', []):
            pid = p.get('id')
            val = p.get('value')
            if pid is not None and val is not None and pid in CRRT_PID_MAP:
                col = CRRT_PID_MAP[pid]
                scaled = float(val)
                if pid in PID_SCALE_MAP:
                    scaled *= PID_SCALE_MAP[pid]
                cache['values'][col] = scaled

    # ─── Order Change Detection ────────────────────────────────

    def _detect_order_changes(self, treatment_id: str, device_id: str,
                              packet_time: datetime, body: dict):
        """Detect prescription changes with stabilization + bounce guard.
        
        Rules:
          1. Value must differ from last SAVED snapshot for 3+ consecutive pkts
          2. Bounce A->B->A (where A != B) is rejected
          3. OC snapshot carries the current cache values (already merged)
        """
        if treatment_id not in self._last_snap_vals:
            self._last_snap_vals[treatment_id] = {}
        if treatment_id not in self._oc_candidates:
            self._oc_candidates[treatment_id] = {}
        if treatment_id not in self._oc_history:
            self._oc_history[treatment_id] = {}

        baseline_map = self._last_snap_vals[treatment_id]
        candidates = self._oc_candidates[treatment_id]
        history = self._oc_history[treatment_id]
        confirmed = []

        for p in body.get('parameters', []):
            pid = p.get('id')
            if pid not in _OC_PIDS:
                continue
            raw_val = p.get('value')
            if raw_val is None:
                continue
            try:
                new_val = float(raw_val)
            except (ValueError, TypeError):
                continue

            col = _OC_PID_COLS[pid]
            baseline = baseline_map.get(col)

            # First encounter → set baseline
            if baseline is None:
                baseline_map[col] = new_val
                history[pid] = [new_val]
                continue

            # Same as baseline → reset candidate
            if abs(new_val - baseline) < 1:
                candidates.pop(pid, None)
                h = history.get(pid, [])
                h.append(new_val)
                history[pid] = h[-2:]
                continue

            # Bounce detection: A→B→A (prev_prev=A, prev=B, new=A, A!=B)
            h = history.get(pid, [])
            if len(h) >= 2:
                prev_prev, prev = h[-2], h[-1]
                if abs(new_val - prev_prev) < 1 and abs(prev - new_val) >= 1:
                    # True oscillation — skip
                    h.append(new_val)
                    history[pid] = h[-2:]
                    candidates.pop(pid, None)
                    continue

            # Track candidate streak
            cand = candidates.get(pid)
            if cand and abs(new_val - cand[0]) < 1:
                candidates[pid] = (cand[0], cand[1] + 1)
            else:
                candidates[pid] = (new_val, 1)

            h.append(new_val)
            history[pid] = h[-2:]

            # Stabilized?
            if candidates[pid][1] >= _OC_STABILIZE:
                confirmed.append((pid, baseline, new_val))
                candidates.pop(pid, None)

        if not confirmed:
            return

        # Update baselines and save OC snapshot
        for pid, old_val, new_val in confirmed:
            col = _OC_PID_COLS[pid]
            baseline_map[col] = new_val
        self._save_oc_snapshot(treatment_id, device_id, packet_time, confirmed)

    def _save_oc_snapshot(self, treatment_id: str, device_id: str,
                          packet_time: datetime, changes: list):
        """Save an OC_XX snapshot with CURRENT cache values (already merged)."""
        cache = self._batch_cache.get(treatment_id)
        if not cache or not cache['values']:
            return

        count = self._oc_counters.get(treatment_id, 0) + 1
        self._oc_counters[treatment_id] = count
        oc_label = f"OC_{count:02d}"

        auto_data = self._build_auto_data(cache['values'])
        if not auto_data:
            return

        # Build reason string
        reasons = []
        for pid, old_val, new_val in changes:
            col_name = CRRT_PID_MAP.get(pid, f'PID{pid}')
            reasons.append(f"{col_name}: {old_val}->{new_val}")
        reason = ", ".join(reasons)

        try:
            self._db.upsert_snapshot(
                treatment_id=treatment_id,
                device_id=device_id,
                hour_label=oc_label,
                snapshot_time=packet_time.isoformat(),
                auto_data=auto_data,
                hour_slot=None,
                source='BACKFILL'
            )
            self._db.update_snapshot_reason(treatment_id, oc_label, reason)
            self._sync_oc_baseline(treatment_id, auto_data)
            # Write-through: projection checkpoint (OC)
            oc_vals = {col: auto_data[col] for col in ('qb', 'qd', 'qpbp', 'uf_rate_target') if col in auto_data}
            try:
                self._db.upsert_projection_checkpoint(
                    treatment_id,
                    last_oc_counter=count,
                    last_oc_time=packet_time.isoformat(),
                    last_oc_values=oc_vals,
                )
            except Exception as e:
                logger.error(f"OC checkpoint error [{treatment_id[:8]}]: {e}")
            logger.info(f"Backfill OC: {treatment_id[:8]} {oc_label}: {reason}")
        except Exception as e:
            logger.error(f"Backfill OC Error [{treatment_id[:8]}]: {e}")

    # ─── Helpers ───────────────────────────────────────────────

    def _build_auto_data(self, values: dict) -> dict:
        """Build auto_data dict from cache values."""
        auto_data = {col: values[col] for col in _SNAPSHOT_COLS if col in values}
        qs_pre = values.get('qs_pre', 0)
        qs_post = values.get('qs_post', 0)
        if qs_pre or qs_post:
            auto_data['qs'] = qs_pre + qs_post
        return auto_data

    def _sync_oc_baseline(self, treatment_id: str, auto_data: dict):
        """Sync _last_snap_vals after any snapshot save (H or OC).
        
        Critical: do NOT overwrite baseline for PIDs with active OC candidates,
        since that would kill their stabilization streak mid-detection.
        """
        if treatment_id not in self._last_snap_vals:
            self._last_snap_vals[treatment_id] = {}
        active_candidates = self._oc_candidates.get(treatment_id, {})
        # Map col → pid for skip check
        _col_to_pid = {v: k for k, v in _OC_PID_COLS.items()}
        for col in ('qb', 'qd', 'qpbp', 'uf_rate_target'):
            if col in auto_data:
                pid = _col_to_pid.get(col)
                if pid and pid in active_candidates:
                    # Skip: OC detection is mid-stabilization for this PID
                    continue
                self._last_snap_vals[treatment_id][col] = auto_data[col]

    def _get_device_id(self, treatment_id: str) -> str:
        if treatment_id in self._device_map:
            return self._device_map[treatment_id]
        row = self._db.fetch_one("SELECT device_id FROM treatments WHERE id = ?", (treatment_id,))
        device_id = row['device_id'] if row else "UNKNOWN"
        self._device_map[treatment_id] = device_id
        return device_id

    def flush_all(self):
        """Flush all cached treatments. Call on shutdown."""
        for tid in list(self._batch_cache.keys()):
            self.flush_treatment(tid)

    def flush_device(self, device_id: str):
        """Flush all cached treatments for a specific device."""
        flushed = 0
        for tid in list(self._batch_cache.keys()):
            if self._device_map.get(tid) == device_id:
                self.flush_treatment(tid)
                flushed += 1
        if flushed:
            logger.info(f"[BACKFILL] Flushed {flushed} treatment(s) for {device_id}")
        return flushed
