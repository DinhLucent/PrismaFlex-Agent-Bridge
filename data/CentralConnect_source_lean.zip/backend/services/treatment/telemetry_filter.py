import logging

logger = logging.getLogger(__name__)

class TelemetryFilter:
    """
    Extracts vital parameters (PIDs) from a 36KB telemetry packet for the 'Fast-Path'.
    Reduces data size for WebSocket broadcasting to ensure zero dashboard lag.
    """
    
    # Vital PIDs for Dashboard and Monitor Detail
    VITAL_PIDS = {
        1: "access_pressure",
        2: "filter_pressure",
        3: "effluent_pressure",
        4: "return_pressure",
        6: "tmp",
        17: "blood_flow_qb",
        22: "pbp_flow",
        21: "dialysate_flow_qd",
        19: "replacement_flow_post",
        18: "replacement_flow_pre",
        23: "effluent_rate",
        24: "net_uf_rate",
        38: "heparin_flow",
        410: "effluent_dose"
    }

    @staticmethod
    def extract_dashboard_packet(raw_packet: dict) -> dict:
        """
        Extracts only essential fields from a heavy telemetry packet.
        Returns a lightweight dictionary suitable for WebSocket broadcast.
        """
        try:
            meta = raw_packet.get("meta", {})
            header = raw_packet.get("s_header", {}) or raw_packet.get("header", {})
            body = raw_packet.get("s_body", {}) or raw_packet.get("body", {})
            
            # 1. Base Info
            fast_packet = {
                "meta": {
                    "device_id": meta.get("device_id"),
                    "timestamp": meta.get("timestamp"),
                    "packet_num": meta.get("packet_num", 0)
                },
                "s_header": {
                    "patient_id": header.get("patient_id"),
                    "therapy_type_id": header.get("therapy_type_id"),
                    "therapy_type_id_name": header.get("therapy_type_id_name"),
                    "therapy_status_id": header.get("therapy_status_id"),
                    "therapy_status_id_name": header.get("therapy_status_id_name"),
                    "machine_id": header.get("machine_id"),
                    "sw_version": header.get("sw_version"),
                    "timestamp": header.get("timestamp"),
                },
                "vitals": {},
                "active_alarms": [] # Simplified for fast-path
            }
            
            # 2. Extract Vitals
            parameters = body.get("parameters", [])
            for p in parameters:
                p_id = p.get("id")
                p_type = p.get("type")
                
                # Only extract 'Actual' values for the vitals defined above
                if p_type == "Actual" and p_id in TelemetryFilter.VITAL_PIDS:
                    label = TelemetryFilter.VITAL_PIDS[p_id]
                    fast_packet["vitals"][label] = p.get("value")
                
                # Special Case: Alarms (IDs only for fast-path check)
                if p_type == "Alarm" and p.get("value") > 0:
                    fast_packet["active_alarms"].append({
                        "id": p_id,
                        "state": "PRESENT",
                        "priority_only": True
                    })
            
            return fast_packet
            
        except Exception as e:
            logger.error(f"Error extracting dashboard packet: {e}")
            return {"error": "extraction_failed", "device_id": raw_packet.get("meta", {}).get("device_id")}
