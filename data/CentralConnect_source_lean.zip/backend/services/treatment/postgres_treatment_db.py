"""
PostgreSQL Treatment Database Adapter
=======================================
Drop-in replacement for the legacy SQLite `TreatmentDatabase` class.
Implements the SAME method interface so that `TreatmentRecorderService`
and `TreatmentSnapshotService` can switch from SQLite to PostgreSQL
with ZERO changes to their business logic.

Sprint 6 — TASK-117: Legacy Codebase Cleanup
"""
import json as _json
import re as _re
import uuid as _uuid
import logging
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta
from decimal import Decimal as _Decimal
from typing import Optional, Dict, Any, List

from dateutil.parser import parse as _dt_parse
from sqlalchemy import select, update, delete, or_, and_, text, func
from sqlalchemy.orm import Session

from db.postgres.session import get_session_factory
from db.postgres.models.treatments import Treatment
from db.postgres.models.treatment_phases import TreatmentPhase
from db.postgres.models.treatment_status_events import TreatmentStatusEvent
from db.postgres.models.treatment_journal_rows import TreatmentJournalRow
from db.postgres.models.treatment_list_projection import TreatmentListProjection
from db.postgres.models.treatment_config import TreatmentConfig
from db.postgres.models.treatment_notes import TreatmentNote
from db.postgres.models.snapshot_originals import SnapshotOriginal
from db.postgres.models.snapshot_audit_log import SnapshotAuditLog
from db.postgres.models.raw_packet_manifest import RawPacketManifest
from db.postgres.models.treatment_review_state import TreatmentReviewState

logger = logging.getLogger("PrismaFlexBackend")

_LOCAL_TZ = timezone(timedelta(hours=7))
_H00_FREEZE_SECONDS = 60


def _now() -> datetime:
    return datetime.now(_LOCAL_TZ)


def _parse_iso(ts: str) -> Optional[datetime]:
    """Parse ISO timestamp string into a timezone-aware datetime."""
    if not ts:
        return None
    try:
        dt = _dt_parse(ts)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=_LOCAL_TZ)
        return dt
    except Exception:
        return None


def _row_to_dict(obj) -> Optional[dict]:
    """Convert a SQLAlchemy model instance to a dict matching old SQLite Row interface."""
    if obj is None:
        return None
    d = {}
    for col in obj.__table__.columns:
        val = getattr(obj, col.name)
        if isinstance(val, datetime):
            d[col.name] = val.isoformat()
        elif isinstance(val, _uuid.UUID):
            d[col.name] = str(val)
        elif isinstance(val, _Decimal):
            d[col.name] = float(val)
        else:
            d[col.name] = val
    return d


def _json_safe(value):
    """Convert DB scalar values to JSONB-safe primitives for audit rows."""
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, _uuid.UUID):
        return str(value)
    if isinstance(value, _Decimal):
        return float(value)
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    return value


def _audit_values_equal(left, right) -> bool:
    return _json.dumps(_json_safe(left), sort_keys=True, default=str) == _json.dumps(
        _json_safe(right), sort_keys=True, default=str
    )


class PostgresTreatmentDB:
    """
    Thread-safe PostgreSQL adapter for treatment records.
    Same method signatures as the legacy TreatmentDatabase (SQLite).
    """

    def __init__(self):
        self._factory = get_session_factory()
        self._projection_checked = False
        logger.info("PostgresTreatmentDB initialized (SQLAlchemy -> PostgreSQL)")
        self._ensure_projection_synced()

    @contextmanager
    def _session(self):
        """Context-managed session: auto-rollback on error, auto-close always."""
        session = self._factory()
        try:
            yield session
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _ensure_projection_synced(self) -> None:
        """Best-effort self-heal when master treatments exist but list projection is missing."""
        if self._projection_checked:
            return
        self._projection_checked = True

        try:
            from db.postgres.services.projection_service import ProjectionService

            with self._session() as s:
                treatment_ids = list(s.scalars(select(Treatment.id)).all())
                if not treatment_ids:
                    return

                projection_ids = set(s.scalars(select(TreatmentListProjection.id)).all())
                missing_ids = [tid for tid in treatment_ids if tid not in projection_ids]
                if not missing_ids:
                    return

                svc = ProjectionService(s)
                for treatment_id in missing_ids:
                    svc.refresh(treatment_id)
                s.commit()
                logger.warning(
                    "Projection self-heal rebuilt %s missing row(s) from treatments",
                    len(missing_ids),
                )
        except Exception as exc:
            logger.error("Projection self-heal failed: %s", exc)

    # ─── Treatment CRUD ───────────────────────────────────────────

    def create_treatment(self, treatment_id: str, device_id: str, timestamp: str,
                         machine_id: int = None, patient_id: str = None,
                         therapy_type_id: int = None, therapy_type_name: str = None,
                         anticoag_type_id: int = None, sw_version: str = None) -> None:
        pkt_time = _parse_iso(timestamp) or _now()
        with self._session() as s:
            t = Treatment(
                id=_uuid.UUID(treatment_id),
                device_id=device_id,
                patient_id=patient_id,
                therapy_type_id=therapy_type_id,
                anticoag_type_id=anticoag_type_id,
                start_time=pkt_time,
                last_seen_time=pkt_time,
                outcome="IN_PROGRESS",
                fsm_state="RECORDING",
                sw_version=sw_version,
                total_packets=0,
            )
            s.add(t)
            s.commit()

    def update_treatment(self, treatment_id: str, **kwargs) -> None:
        if not kwargs:
            return
        # Convert string timestamps to datetime objects
        for k in ('start_time', 'end_time', 'last_seen_time', 'first_run_time'):
            if k in kwargs and isinstance(kwargs[k], str):
                kwargs[k] = _parse_iso(kwargs[k])
        # Convert int booleans to Python bools
        for k in ('had_interruption', 'had_program_restart', 'is_valid'):
            if k in kwargs and isinstance(kwargs[k], int):
                kwargs[k] = bool(kwargs[k])

        # Safety: strip any kwargs that aren't actual Treatment columns
        valid_columns = {c.key for c in Treatment.__table__.columns}
        kwargs = {k: v for k, v in kwargs.items() if k in valid_columns}
        if not kwargs:
            return

        kwargs['updated_at'] = _now()
        with self._session() as s:
            tid = _uuid.UUID(treatment_id)
            s.execute(
                update(Treatment)
                .where(Treatment.id == tid)
                .values(**kwargs)
            )
            s.commit()

            # Refresh session state after commit to avoid stale identity-map data
            s.expire_all()

            # Sync to projection table (for patient_name/patient_id updates)
            treatment = s.get(Treatment, tid)
            if treatment:
                self.upsert_index(treatment_id, treatment.device_id,
                                  patient_id=treatment.patient_id,
                                  patient_name=treatment.patient_name,
                                  outcome=treatment.outcome,
                                  start_time=treatment.start_time,
                                  end_time=treatment.end_time)

    def delete_treatment(self, treatment_id: str) -> None:
        """Delete a treatment and ALL child records (full cascade)."""
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            # Delete all child tables (order matters for FK constraints)
            s.execute(delete(SnapshotAuditLog).where(SnapshotAuditLog.treatment_id == tid))
            s.execute(delete(SnapshotOriginal).where(SnapshotOriginal.treatment_id == tid))
            s.execute(delete(TreatmentJournalRow).where(TreatmentJournalRow.treatment_id == tid))
            s.execute(delete(TreatmentStatusEvent).where(TreatmentStatusEvent.treatment_id == tid))
            s.execute(delete(TreatmentPhase).where(TreatmentPhase.treatment_id == tid))
            s.execute(delete(TreatmentConfig).where(TreatmentConfig.treatment_id == tid))
            s.execute(delete(TreatmentNote).where(TreatmentNote.treatment_id == tid))
            s.execute(delete(RawPacketManifest).where(RawPacketManifest.treatment_id == tid))
            s.execute(delete(TreatmentReviewState).where(TreatmentReviewState.treatment_id == tid))
            s.execute(delete(TreatmentListProjection).where(TreatmentListProjection.id == tid))
            s.execute(delete(Treatment).where(Treatment.id == tid))
            s.commit()

    def get_treatment_by_id(self, treatment_id: str) -> Optional[dict]:
        with self._session() as s:
            t = s.get(Treatment, _uuid.UUID(treatment_id))
            return _row_to_dict(t)

    def get_active_treatment(self, device_id: str) -> Optional[dict]:
        with self._session() as s:
            t = s.scalars(
                select(Treatment)
                .where(Treatment.device_id == device_id, Treatment.outcome == "IN_PROGRESS")
                .order_by(Treatment.start_time.desc())
                .limit(1)
            ).first()
            return _row_to_dict(t)

    def get_all_in_progress(self) -> List[dict]:
        with self._session() as s:
            rows = s.scalars(
                select(Treatment).where(Treatment.outcome == "IN_PROGRESS")
            ).all()
            return [_row_to_dict(r) for r in rows]

    def get_last_closed_treatment(self, device_id: str, patient_id: str,
                                  min_end_time: str) -> Optional[dict]:
        cutoff = _parse_iso(min_end_time) or _now()
        with self._session() as s:
            t = s.scalars(
                select(Treatment)
                .where(
                    Treatment.device_id == device_id,
                    Treatment.patient_id == patient_id,
                    Treatment.outcome.in_(["COMPLETED", "IN_PROGRESS"]),
                    or_(
                        Treatment.end_time >= cutoff,
                        and_(Treatment.outcome == "IN_PROGRESS",
                             Treatment.last_seen_time >= cutoff)
                    )
                )
                .order_by(Treatment.last_seen_time.desc())
                .limit(1)
            ).first()
            return _row_to_dict(t)

    # ─── Status Log ────────────────────────────────────────────────

    def log_status(self, treatment_id: str, device_id: str, timestamp: str,
                   therapy_status_id: int, fsm_state: str,
                   patient_id: str = None, note: str = None) -> None:
        event_time = _parse_iso(timestamp) or _now()
        with self._session() as s:
            evt = TreatmentStatusEvent(
                treatment_id=_uuid.UUID(treatment_id),
                device_id=device_id,
                event_time=event_time,
                therapy_status_id=therapy_status_id,
                fsm_state=fsm_state,
                patient_id=patient_id,
                event_code=fsm_state,
                note=note,
            )
            s.add(evt)
            s.commit()

    def get_status_log(self, treatment_id: str) -> List[dict]:
        """Get status event log for a treatment, ordered by event_time."""
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            rows = s.scalars(
                select(TreatmentStatusEvent)
                .where(TreatmentStatusEvent.treatment_id == tid)
                .order_by(TreatmentStatusEvent.event_time.asc())
            ).all()
            return [_row_to_dict(r) for r in rows]

    # ─── Phase Operations ──────────────────────────────────────────

    def get_phases(self, treatment_id: str) -> List[dict]:
        """Get all phases for a treatment, ordered by phase_number."""
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            rows = s.scalars(
                select(TreatmentPhase)
                .where(TreatmentPhase.treatment_id == tid)
                .order_by(TreatmentPhase.phase_number.asc())
            ).all()
            return [_row_to_dict(r) for r in rows]

    # ─── Treatment Config ──────────────────────────────────────────

    def get_config(self, treatment_id: str) -> Optional[dict]:
        """Get treatment configuration snapshot."""
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            cfg = s.scalars(
                select(TreatmentConfig)
                .where(TreatmentConfig.treatment_id == tid)
            ).first()
            return _row_to_dict(cfg)

    # ─── Treatment Index (Projection) ──────────────────────────────

    def upsert_index(self, treatment_id: str, device_id: str, **kwargs) -> None:
        tid = _uuid.UUID(treatment_id)
        for k in ('start_time', 'end_time'):
            if k in kwargs and isinstance(kwargs[k], str):
                kwargs[k] = _parse_iso(kwargs[k])

        with self._session() as s:
            existing = s.get(TreatmentListProjection, tid)
            if existing:
                field_map = {
                    'device_id': 'device_id', 'patient_id': 'patient_id',
                    'patient_name': 'patient_name',
                    'start_time': 'start_time', 'end_time': 'end_time',
                    'outcome': 'outcome', 'total_packets': 'total_packets',
                    'duration_sec': 'total_run_seconds',
                    'therapy_type_id': 'therapy_type_id',
                    'anticoag_type_id': 'anticoag_type_id',
                    'therapy_type': 'therapy_type',
                    'anticoag_type': 'anticoag_type',
                }
                for src, dst in field_map.items():
                    v = kwargs.get(src)
                    if v is not None and hasattr(existing, dst):
                        setattr(existing, dst, v)
                existing.updated_at = _now()
            else:
                # Map anticoag string name if only ID provided
                anticoag_id = kwargs.get('anticoag_type_id')
                anticoag_name = kwargs.get('anticoag_type')
                if anticoag_id is not None and not anticoag_name:
                    anticoag_name = {0: 'None', 1: 'Heparin', 2: 'Citrate', 3: 'Citrate'}.get(anticoag_id, 'None')

                proj = TreatmentListProjection(
                    id=tid,
                    device_id=device_id,
                    patient_id=kwargs.get('patient_id'),
                    patient_name=kwargs.get('patient_name'),
                    therapy_type_id=kwargs.get('therapy_type_id'),
                    anticoag_type_id=anticoag_id,
                    therapy_type=kwargs.get('therapy_type'),
                    anticoag_type=anticoag_name,
                    start_time=kwargs.get('start_time') or _now(),
                    end_time=kwargs.get('end_time'),
                    outcome=kwargs.get('outcome', 'IN_PROGRESS'),
                    total_packets=kwargs.get('total_packets', 0),
                    total_run_seconds=kwargs.get('duration_sec', 0),
                )
                s.add(proj)
            s.commit()

    # ─── Journal Rows (Snapshots) ──────────────────────────────────

    def upsert_snapshot(self, treatment_id: str, device_id: str,
                        hour_label: str, snapshot_time: str,
                        auto_data: dict = None, manual_data: dict = None,
                        hour_slot: int = None, source: str = None) -> None:
        tid = _uuid.UUID(treatment_id)
        snap_time = _parse_iso(snapshot_time) or _now()
        row_kind = "ORDER_CHANGE" if hour_label.startswith("OC") else "HOUR"
        now_local = _now()

        with self._session() as s:
            existing = s.scalars(
                select(TreatmentJournalRow)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.row_code == hour_label)
            ).first()

            if existing:
                if auto_data:
                    for k, v in auto_data.items():
                        if hasattr(existing, k):
                            setattr(existing, k, v)
                    # Use provided source or default to appropriate transition value
                    existing.source = source or ("MERGED" if manual_data else "LIVE")
                
                if manual_data:
                    _immutable = ('id', 'treatment_id', 'row_code', 'created_at',
                                  'updated_at', 'stable_at', 'version')
                    for k, v in manual_data.items():
                        if hasattr(existing, k) and k not in _immutable:
                            setattr(existing, k, None if v == "" else v)
                    existing.source = source or ("MERGED" if auto_data else "MANUAL")
                
                if hour_slot is not None:
                    existing.hour_slot = hour_slot

                if existing.stable_at is None and self._row_should_be_stable(existing, now_local):
                    existing.stable_at = now_local

                existing.updated_at = now_local
            else:
                data = {
                    'treatment_id': tid,
                    'device_id': device_id,
                    'row_code': hour_label,
                    'row_kind': row_kind,
                    'hour_slot': hour_slot,
                    'snapshot_time': snap_time,
                    'source': source or ('LIVE' if auto_data else 'MANUAL'),
                    'stable_at': None, # Let projector set this after stabilization window
                }
                # Promote rows that are clinically stable on creation.
                if (
                    source == 'BACKFILL'
                    or row_kind == 'ORDER_CHANGE'
                    or (row_kind == 'HOUR' and hour_label != 'H00')
                ):
                    data['stable_at'] = now_local

                if auto_data:
                    data.update({k: v for k, v in auto_data.items()
                                 if hasattr(TreatmentJournalRow, k)})
                if manual_data:
                    _immutable = ('id', 'treatment_id', 'row_code', 'created_at',
                                  'updated_at', 'stable_at', 'version')
                    clean_manual = {k: (None if v == "" else v) for k, v in manual_data.items()
                                    if hasattr(TreatmentJournalRow, k) and k not in _immutable}
                    data.update(clean_manual)
                    data['source'] = source or ('MERGED' if auto_data else 'MANUAL')
                row = TreatmentJournalRow(**data)
                s.add(row)

            # Flush to DB so row_count query sees the new/updated row
            s.flush()

            # Update journal_row_count on the list projection
            row_count = s.scalar(
                select(func.count()).select_from(TreatmentJournalRow)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.is_deleted.is_(False))
            )
            proj = s.get(TreatmentListProjection, tid)
            if proj:
                proj.journal_row_count = row_count

            # Single commit for the entire operation
            s.commit()

    def get_snapshots(self, treatment_id: str) -> List[dict]:
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            rows = s.scalars(
                select(TreatmentJournalRow)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.is_deleted.is_(False))
                .order_by(TreatmentJournalRow.snapshot_time.asc())
            ).all()
            result = []
            for r in rows:
                d = _row_to_dict(r)
                d['hour_label'] = d.get('row_code', '')
                result.append(d)
            return result

    def get_snapshot_by_hour(self, treatment_id: str, hour_label: str) -> Optional[dict]:
        """Get a single snapshot row by treatment_id and hour_label (row_code)."""
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            row = s.scalars(
                select(TreatmentJournalRow)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.row_code == hour_label,
                       TreatmentJournalRow.is_deleted.is_(False))
            ).first()
            if not row:
                return None
            d = _row_to_dict(row)
            d['hour_label'] = d.get('row_code', '')
            return d

    def get_latest_snapshot(self, treatment_id: str) -> Optional[dict]:
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            row = s.scalars(
                select(TreatmentJournalRow)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.is_deleted.is_(False))
                .order_by(TreatmentJournalRow.snapshot_time.desc())
                .limit(1)
            ).first()
            if not row:
                return None
            d = _row_to_dict(row)
            auto_vars = ['qb', 'qs', 'qd', 'qpbp', 'pa', 'pv', 'pbe', 'tmp',
                         'uf_total', 'uf_hourly', 'effluent_flow',
                         'run_time_sec', 'blood_vol', 'heparin_rate',
                         'pt_weight', 'uf_rate_target', 'citrate_dose',
                         'citrate_conc', 'citrate_load', 'calcium_comp',
                         'calcium_rate', 'anticoag_type_id']
            d['auto_data'] = {k: d[k] for k in auto_vars if k in d and d[k] is not None}
            d['hour_label'] = d.get('row_code', '')
            return d

    def get_max_oc_count(self, treatment_id: str) -> int:
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            rows = s.scalars(
                select(TreatmentJournalRow.row_code)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.row_code.like('OC_%'))
            ).all()
            if not rows:
                return 0
            max_val = 0
            for code in rows:
                try:
                    val = int(code.split('_')[1])
                    max_val = max(max_val, val)
                except (ValueError, IndexError):
                    pass
            return max_val

    def get_previous_snapshot_values(self, treatment_id: str, exclude_hour: str) -> Optional[dict]:
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            row = s.scalars(
                select(TreatmentJournalRow)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.row_code != exclude_hour,
                       TreatmentJournalRow.is_deleted.is_(False))
                .order_by(TreatmentJournalRow.snapshot_time.desc())
                .limit(1)
            ).first()
            if not row:
                return None
            return {
                'qb': row.qb,
                'qd': row.qd,
                'qs': row.qs,
                'qpbp': row.qpbp,
                'uf_rate_target': row.uf_rate_target
            }

    def update_snapshot_reason(self, treatment_id: str, hour_label: str, reason: str) -> None:
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            row = s.scalars(
                select(TreatmentJournalRow)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.row_code == hour_label,
                       TreatmentJournalRow.is_deleted.is_(False))
                .limit(1)
            ).first()
            if row:
                row.notes = reason
                row.updated_at = _now()
                s.commit()

    def has_h00_snapshot(self, treatment_id: str) -> bool:
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            row = s.scalars(
                select(TreatmentJournalRow.id)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.row_code == 'H00',
                       TreatmentJournalRow.is_deleted.is_(False))
                .limit(1)
            ).first()
            return row is not None

    # ─── Backward-compat raw SQL ──────────────────────────────────

    def _prepare_legacy_sql(self, sql: str, params: tuple) -> tuple:
        """Convert legacy SQLite-style SQL (? placeholders) to SQLAlchemy named params."""
        replacements = {
            "treatment_index": "treatment_list_projection",
            "treatment_hourly_snapshots": "treatment_journal_rows",
            "treatment_status_log": "treatment_status_events",
            "hour_label": "row_code",
            "reason": "notes",
            "snapshot_count": "journal_row_count",
            "duration_sec": "total_run_seconds",
        }
        for old, new in replacements.items():
            sql = _re.sub(rf"\b{_re.escape(old)}\b", new, sql)
        named_sql = sql
        named_params = {}
        for i, val in enumerate(params):
            named_sql = named_sql.replace('?', f':p{i}', 1)
            named_params[f'p{i}'] = val
        return named_sql, named_params

    def _normalize_legacy_row(self, row: dict) -> dict:
        """Expose legacy SQLite field names expected by older services/routers."""
        if "row_code" in row and "hour_label" not in row:
            row["hour_label"] = row["row_code"]
        if "notes" in row and "reason" not in row:
            row["reason"] = row["notes"]
        if "journal_row_count" in row and "snapshot_count" not in row:
            row["snapshot_count"] = row["journal_row_count"]
        if "total_run_seconds" in row and "duration_sec" not in row:
            row["duration_sec"] = row["total_run_seconds"]
        return row

    def fetch_all(self, sql: str, params: tuple = ()) -> List[dict]:
        """Backward-compatible raw SQL for deferred compression scan."""
        named_sql, named_params = self._prepare_legacy_sql(sql, params)
        with self._session() as s:
            result = s.execute(text(named_sql), named_params)
            return [self._normalize_legacy_row(dict(r._mapping)) for r in result]

    def fetch_one(self, sql: str, params: tuple = ()) -> Optional[dict]:
        """Backward-compatible raw SQL returning a single row."""
        named_sql, named_params = self._prepare_legacy_sql(sql, params)
        with self._session() as s:
            result = s.execute(text(named_sql), named_params)
            row = result.first()
            return self._normalize_legacy_row(dict(row._mapping)) if row else None

    def execute(self, sql: str, params: tuple = ()) -> None:
        """Backward-compatible raw SQL execution."""
        named_sql, named_params = self._prepare_legacy_sql(sql, params)
        with self._session() as s:
            s.execute(text(named_sql), named_params)
            s.commit()

    # ─── Archive Support ──────────────────────────────────────────

    def collect_for_archive(self, treatment_id: str) -> dict:
        """Gather all data for a treatment into a single dict for archiving.
        Matches legacy TreatmentDatabase.collect_for_archive() interface.
        """
        return {
            "treatment": self.get_treatment_by_id(treatment_id),
            "config": self.get_config(treatment_id),
            "snapshots": self.get_snapshots(treatment_id),
            "status_log": self.get_status_log(treatment_id),
            "phases": self.get_phases(treatment_id),
        }

    def get_raw_packets(self, treatment_id: str) -> List[dict]:
        """Legacy compat: raw packets are now stored as chunked JSONL/Parquet
        files managed by raw_packet_manifest. Returns empty list since the
        archiver reads raw files directly from the manifest file paths.
        """
        logger.debug(f"get_raw_packets called for {treatment_id[:8]} — "
                     f"raw packets now use chunked manifest, returning []")
        return []

    def purge_treatment_data(self, treatment_id: str) -> None:
        """Remove heavy data from PostgreSQL after archiving.
        Projection index stays for fast list queries.
        Matches legacy TreatmentDatabase.purge_treatment_data() behavior.
        """
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            s.execute(delete(SnapshotAuditLog).where(SnapshotAuditLog.treatment_id == tid))
            s.execute(delete(SnapshotOriginal).where(SnapshotOriginal.treatment_id == tid))
            s.execute(delete(TreatmentJournalRow).where(TreatmentJournalRow.treatment_id == tid))
            s.execute(delete(TreatmentStatusEvent).where(TreatmentStatusEvent.treatment_id == tid))
            s.execute(delete(TreatmentPhase).where(TreatmentPhase.treatment_id == tid))
            s.execute(delete(TreatmentConfig).where(TreatmentConfig.treatment_id == tid))
            s.execute(delete(TreatmentNote).where(TreatmentNote.treatment_id == tid))
            s.execute(delete(RawPacketManifest).where(RawPacketManifest.treatment_id == tid))
            s.execute(delete(Treatment).where(Treatment.id == tid))
            s.commit()
            logger.info(f"Purged PostgreSQL data for treatment {str(tid)[:8]}")

    # ─── Index Queries (used by v1 router) ────────────────────────

    def _build_index_filter(self, query, outcome: str = None, patient_id: str = None,
                            device_id: str = None, start_time: str = None,
                            end_time: str = None, approval_status: str = None):
        """Shared filter builder for index count and list queries."""
        if outcome:
            query = query.where(TreatmentListProjection.outcome == outcome)
        if patient_id:
            query = query.where(TreatmentListProjection.patient_id.ilike(f"%{patient_id}%"))
        if device_id:
            query = query.where(TreatmentListProjection.device_id.ilike(f"%{device_id}%"))
        if start_time:
            query = query.where(TreatmentListProjection.start_time >= _parse_iso(start_time))
        if end_time:
            query = query.where(TreatmentListProjection.start_time <= _parse_iso(end_time))
        if approval_status:
            query = query.where(TreatmentListProjection.approval_status == approval_status)
        return query

    def get_index_count(self, outcome: str = None, patient_id: str = None,
                        device_id: str = None, start_time: str = None, end_time: str = None,
                        approval_status: str = None) -> int:
        with self._session() as s:
            q = select(func.count()).select_from(TreatmentListProjection)
            q = self._build_index_filter(q, outcome, patient_id, device_id,
                                         start_time, end_time, approval_status)
            return s.scalar(q) or 0

    def get_index_list(self, limit: int = 20, offset: int = 0,
                       outcome: str = None, patient_id: str = None,
                       device_id: str = None, start_time: str = None, end_time: str = None,
                       approval_status: str = None) -> List[dict]:
        with self._session() as s:
            q = select(TreatmentListProjection)
            q = self._build_index_filter(q, outcome, patient_id, device_id,
                                         start_time, end_time, approval_status)
            q = q.order_by(TreatmentListProjection.start_time.desc()).limit(limit).offset(offset)
            rows = s.scalars(q).all()
            result = []
            for r in rows:
                d = _row_to_dict(r)
                # Compat aliases expected by frontend
                d['duration_sec'] = d.get('total_run_seconds', 0)
                d['approval_status'] = d.get('approval_status', 'DRAFT')
                d['note_count'] = d.get('note_count') or 0
                d['snapshot_count'] = d.get('journal_row_count') or 0
                result.append(d)
            return result

    def get_pending_review_count(self) -> int:
        with self._session() as s:
            cnt = s.scalar(
                select(func.count()).select_from(TreatmentListProjection)
                .where(TreatmentListProjection.approval_status == 'PENDING_REVIEW')
            )
            return cnt or 0

    def get_full_report(self, treatment_id: str) -> Optional[dict]:
        treatment = self.get_treatment_by_id(treatment_id)
        if not treatment:
            return None
        return {
            "treatment": treatment,
            "config": self.get_config(treatment_id),
            "snapshots": self.get_snapshots(treatment_id),
            "notes": self.get_notes(treatment_id),
            "status_log": self.get_status_log(treatment_id),
        }

    # ─── Approval Workflow (used by v1 router) ─────────────────

    def update_approval_status(self, treatment_id: str, status: str) -> None:
        """Update approval_status in review_state and projection tables."""
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            # Upsert review_state row
            review = s.get(TreatmentReviewState, tid)
            if review:
                review.approval_status = status
                review.updated_at = _now()
            else:
                review = TreatmentReviewState(
                    treatment_id=tid,
                    approval_status=status,
                    updated_at=_now(),
                )
                s.add(review)
            # Update projection table for list view
            s.execute(
                update(TreatmentListProjection)
                .where(TreatmentListProjection.id == tid)
                .values(approval_status=status, updated_at=_now())
            )
            s.commit()
            logger.info(f"approval_status updated to '{status}' for {treatment_id[:8]}")

    def freeze_snapshots(self, treatment_id: str) -> None:
        """Freeze current snapshots as originals for compare view."""
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            existing = s.scalar(
                select(func.count()).select_from(SnapshotOriginal)
                .where(SnapshotOriginal.treatment_id == tid)
            )
            if existing and existing > 0:
                return
            rows = s.scalars(
                select(TreatmentJournalRow)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.is_deleted.is_(False))
                .order_by(TreatmentJournalRow.snapshot_time.asc())
            ).all()
            now = _now()
            for row in rows:
                # TASK-126: Preserve numeric types for high-fidelity restore
                row_data = {}
                _skip = ('id', 'treatment_id', 'row_code', 'created_at',
                         'updated_at', 'is_deleted', 'deleted_at', 'deleted_by')
                for k in row.__table__.columns.keys():
                    if k in _skip:
                        continue
                    val = getattr(row, k)
                    if isinstance(val, _Decimal):
                        val = float(val)
                    elif isinstance(val, datetime):
                        val = val.isoformat()
                    elif isinstance(val, _uuid.UUID):
                        val = str(val)
                    row_data[k] = val

                orig = SnapshotOriginal(
                    treatment_id=tid,
                    row_code=row.row_code,
                    snapshot_time=row.snapshot_time,
                    snapshot_json=row_data,
                    frozen_at=now,
                )
                s.add(orig)
            s.commit()
            logger.info(f"Frozen {len(rows)} snapshots for treatment {treatment_id[:8]}")

    def get_snapshot_originals(self, treatment_id: str) -> List[dict]:
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            rows = s.scalars(
                select(SnapshotOriginal)
                .where(SnapshotOriginal.treatment_id == tid)
                .order_by(SnapshotOriginal.snapshot_time.asc())
            ).all()
            result = []
            for r in rows:
                result.append({
                    'hour_label': r.row_code,
                    'snapshot_time': r.snapshot_time.isoformat() if r.snapshot_time else '',
                    'frozen_at': r.frozen_at.isoformat() if r.frozen_at else '',
                    'data': r.snapshot_json or {}
                })
            return result

    def log_approval_event(self, treatment_id: str, action: str, details: str = "") -> None:
        self.log_status(treatment_id, 'SYSTEM', _now().isoformat(), -99, action, note=details)

    # ─── Mutation helpers (used by v1 router) ──────────────────

    def _row_should_be_stable(self, row: TreatmentJournalRow, now: Optional[datetime] = None) -> bool:
        """Return True when a journal row is clinically safe to edit."""
        now_local = now or _now()

        if row.stable_at and row.stable_at <= now_local:
            return True

        if row.row_kind == "ORDER_CHANGE":
            return True

        row_code = (row.row_code or "").upper()
        if not row_code.startswith("H"):
            return False

        if row_code != "H00":
            return True

        if row.snapshot_time is None:
            return False

        snap_time = row.snapshot_time
        if snap_time.tzinfo is None:
            snap_time = snap_time.replace(tzinfo=_LOCAL_TZ)
        else:
            snap_time = snap_time.astimezone(_LOCAL_TZ)

        return (now_local - snap_time).total_seconds() >= _H00_FREEZE_SECONDS

    def _check_active_row_lock(self, treatment_id: str, hour_label: str) -> None:
        """Stable-Row Partial Lock Gate check.
        During IN_PROGRESS: only the active streaming row is locked.
        Active row = row where stable_at IS NULL.
        Raises if trying to edit the active streaming row.
        """
        t = self.get_treatment_by_id(treatment_id)
        if not t or t.get('outcome', '') != 'IN_PROGRESS':
            return

        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            target_row = s.scalars(
                select(TreatmentJournalRow)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.row_code == hour_label,
                       TreatmentJournalRow.is_deleted.is_(False))
            ).first()
            if not target_row:
                return

            now_local = _now()
            if target_row.stable_at is None and self._row_should_be_stable(target_row, now_local):
                target_row.stable_at = now_local
                target_row.updated_at = now_local
                s.commit()
                return

            if target_row.stable_at is None or target_row.stable_at > now_local:
                raise Exception(
                    "ACTIVE_ROW_LOCKED: Dòng đang phát trực tiếp không thể "
                    "chỉnh sửa khi đang ghi dữ liệu.")

    def update_snapshot_manual(
        self,
        treatment_id: str,
        hour_label: str,
        data: dict,
        operator_name: str = "Unknown",
        operator_role: str = "nurse",
    ) -> None:
        t = self.get_treatment_by_id(treatment_id)
        if not t:
            return

        # ── Stable-Row Partial Lock Gate ────────────────────────────
        self._check_active_row_lock(treatment_id, hour_label)
        # ── End Stable-Row Gate ─────────────────────────────────────

        existing = self.get_snapshots(treatment_id)
        # Use 'snap' to avoid shadowing any outer variable
        snap_exists = any(
            snap.get('hour_label') == hour_label or snap.get('row_code') == hour_label
            for snap in existing
        )
        if snap_exists:
            snap_time = None
            for snap in existing:
                if snap.get('hour_label') == hour_label or snap.get('row_code') == hour_label:
                    snap_time = snap.get('snapshot_time')
                    break
            if not snap_time:
                snap_time = _now().isoformat()
        elif 'snapshot_time' in data:
            snap_time = data['snapshot_time']
        else:
            m = _re.match(r'H(\d+)', hour_label)
            if m and t.get('start_time'):
                start = _parse_iso(t['start_time'])
                snap_time = (start + timedelta(hours=int(m.group(1)))).isoformat() if start else _now().isoformat()
            else:
                snap_time = _now().isoformat()
        audit_skip = {
            'id', 'treatment_id', 'device_id', 'row_code', 'row_kind',
            'hour_label', 'snapshot_time', 'hour_slot', 'stable_at',
            'source', 'is_deleted', 'deleted_at', 'deleted_by',
            'created_at', 'updated_at', 'created_by', 'updated_by', 'version',
        }
        audit_fields = {
            k: (None if v == "" else v)
            for k, v in data.items()
            if hasattr(TreatmentJournalRow, k) and k not in audit_skip
        }
        tid = _uuid.UUID(treatment_id)
        old_values = {field: None for field in audit_fields}
        if audit_fields:
            with self._session() as s:
                row = s.scalars(
                    select(TreatmentJournalRow)
                    .where(TreatmentJournalRow.treatment_id == tid,
                           TreatmentJournalRow.row_code == hour_label,
                           TreatmentJournalRow.is_deleted.is_(False))
                ).first()
                if row:
                    old_values = {field: getattr(row, field, None) for field in audit_fields}

        self.upsert_snapshot(treatment_id, t['device_id'], hour_label, snap_time, manual_data=data)

        if not audit_fields:
            return

        operator = (operator_name or "Unknown").strip()[:60] or "Unknown"
        role = (operator_role or "nurse").strip()[:40] or "nurse"
        with self._session() as s:
            row = s.scalars(
                select(TreatmentJournalRow)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.row_code == hour_label,
                       TreatmentJournalRow.is_deleted.is_(False))
            ).first()
            if not row:
                return

            changed = False
            for field, old_value in old_values.items():
                new_value = getattr(row, field, None)
                if _audit_values_equal(old_value, new_value):
                    continue
                s.add(SnapshotAuditLog(
                    treatment_id=tid,
                    row_code=hour_label,
                    action="edit_value",
                    field_name=field,
                    old_value=_json_safe(old_value),
                    new_value=_json_safe(new_value),
                    operator_name=operator,
                    operator_role=role,
                ))
                changed = True

            if changed:
                row.updated_by = operator
                row.version = (row.version or 1) + 1
                row.updated_at = _now()
                s.commit()

    def update_snapshots_bulk(self, treatment_id: str, data: dict) -> None:
        """Bulk-update all journal rows for a treatment.
        Respects the Stable-Row Partial Lock Gate: skips the active streaming row.
        """
        if not data:
            return
        tid = _uuid.UUID(treatment_id)

        # Only apply safe columns
        values = {k: (None if v == "" else v) for k, v in data.items()
                  if hasattr(TreatmentJournalRow, k)}
        if not values:
            return
        values['updated_at'] = _now()

        with self._session() as s:
            # Check treatment outcome for lock gate
            treatment = s.get(Treatment, tid)
            if treatment and treatment.outcome == 'IN_PROGRESS':
                # Only update stable (non-active) rows during IN_PROGRESS
                s.execute(
                    update(TreatmentJournalRow)
                    .where(TreatmentJournalRow.treatment_id == tid,
                           TreatmentJournalRow.stable_at.isnot(None))
                    .values(**values)
                )
            else:
                # Treatment is closed — update all rows
                s.execute(
                    update(TreatmentJournalRow)
                    .where(TreatmentJournalRow.treatment_id == tid)
                    .values(**values)
                )
            s.commit()

    def delete_snapshot(self, treatment_id: str, hour_label: str) -> None:
        """Soft-delete a snapshot row with audit metadata."""
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            row = s.scalars(
                select(TreatmentJournalRow)
                .where(TreatmentJournalRow.treatment_id == tid,
                       TreatmentJournalRow.row_code == hour_label)
            ).first()
            if row:
                row.is_deleted = True
                row.deleted_at = _now()
                row.updated_at = _now()
                s.commit()
                logger.info(f"Soft-deleted snapshot {hour_label} for treatment {treatment_id[:8]}")

    # ─── Clinical Notes ────────────────────────────────────────

    def get_notes(self, treatment_id: str) -> List[dict]:
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            rows = s.scalars(
                select(TreatmentNote)
                .where(TreatmentNote.treatment_id == tid)
                .order_by(TreatmentNote.created_at.asc())
            ).all()
            return [_row_to_dict(r) for r in rows]

    def add_note(self, treatment_id: str, content: str, author: str) -> dict:
        tid = _uuid.UUID(treatment_id)
        with self._session() as s:
            note = TreatmentNote(
                treatment_id=tid,
                author_name=author.strip(),
                content=content.strip(),
                created_at=_now(),
            )
            s.add(note)
            # Sync note_count on projection for list view indicator
            proj = s.get(TreatmentListProjection, tid)
            if proj:
                proj.note_count = (proj.note_count or 0) + 1
                proj.updated_at = _now()
            s.commit()
            s.refresh(note)
            logger.info(f"Note added to {treatment_id[:8]} by {author}")
            return _row_to_dict(note)

    # ─── DB Checkpoint: device_state ──────────────────────────────

    def upsert_device_state(self, device_id: str, **kwargs):
        """Write-through: update device_state checkpoint.
        
        Accepts: active_mode, active_treatment_id, last_patient_id,
                 last_seen_time, last_run_time_sec, active_chunk_index
        """
        from db.postgres.models.device_state import DeviceState
        with self._session() as s:
            row = s.get(DeviceState, device_id)
            if row is None:
                row = DeviceState(device_id=device_id, active_mode='IDLE')
                s.add(row)
            for k, v in kwargs.items():
                if hasattr(row, k):
                    setattr(row, k, v)
            row.updated_at = _now()
            s.commit()

    def get_device_state(self, device_id: str):
        """Read device_state checkpoint."""
        from db.postgres.models.device_state import DeviceState
        with self._session() as s:
            row = s.get(DeviceState, device_id)
            return _row_to_dict(row) if row else None

    def get_all_device_states(self):
        """Read all device_state rows."""
        from db.postgres.models.device_state import DeviceState
        with self._session() as s:
            rows = s.execute(select(DeviceState)).scalars().all()
            return [_row_to_dict(r) for r in rows]

    # ─── DB Checkpoint: treatment_projection_checkpoint ────────────

    def upsert_projection_checkpoint(self, treatment_id: str, **kwargs):
        """Write-through: update projection checkpoint.
        
        Accepts: last_hour_slot, slot_anchor_time, last_oc_counter,
                 last_oc_time, last_oc_values
        """
        from db.postgres.models.treatment_projection_checkpoint import TreatmentProjectionCheckpoint
        tid = _uuid.UUID(treatment_id) if isinstance(treatment_id, str) else treatment_id
        with self._session() as s:
            row = s.get(TreatmentProjectionCheckpoint, tid)
            if row is None:
                row = TreatmentProjectionCheckpoint(treatment_id=tid)
                s.add(row)
            for k, v in kwargs.items():
                if hasattr(row, k):
                    setattr(row, k, v)
            row.updated_at = _now()
            s.commit()

    def get_projection_checkpoint(self, treatment_id: str):
        """Read projection checkpoint for a treatment."""
        from db.postgres.models.treatment_projection_checkpoint import TreatmentProjectionCheckpoint
        tid = _uuid.UUID(treatment_id) if isinstance(treatment_id, str) else treatment_id
        with self._session() as s:
            row = s.get(TreatmentProjectionCheckpoint, tid)
            return _row_to_dict(row) if row else None

    # ─── Lifecycle ────────────────────────────────────────────────

    def close(self) -> None:
        """No-op — SQLAlchemy connection pool handles cleanup."""
        pass
