"""
Treatment Snapshot Service
============================
Captures hourly snapshots of CRRT parameters from telemetry.
Each packet updates the in-memory cache. When an hour boundary
is crossed, a snapshot is written to DB.

PID Mapping (from prismaflex_reference.db):
    Qb  = PID 17 (BLOOD_FLOW, ml/min, SET)
    Qs  = PID 18+19 (REPL_PRE + REPL_POST, ml/hr)
    Qd  = PID 21 (DIALYSATE_FLOW, ml/hr)
    QPBP = PID 22 (PRE_BLOOD_FLOW, ml/hr)
    PA  = PID 1 (ACCESS_PRESSURE, mmHg)
    PV  = PID 4 (RETURN_PRESSURE, mmHg)
    PBE = PID 2 (FILTER_PRESSURE, mmHg)
    TMP = PID 6 (TMP, mmHg)
    UF  = PID 100 (IO_HIST_UF_TOT, ml)
    UF/hr = PID 24 (IO_HIST_UF_1HR, ml)
    Effluent = PID 23 (EFFLUENT_FLOW, ml/hr)
    RunTime = PID 461 (RUN_TIME, sec)
    BloodVol = PID 60 (BLOOD_VOL_PROCESSED, l)
    HeparinRate = PID 38 (HEPARIN_CONT_RATE, ml/hr)
    HeparinBolus = MANUAL ENTRY (not auto-captured)
    PtWeight = PID 26 (PT_WEIGHT, kg)
    UfRateTarget = PID 25 (PT_WEIGHT_BALANCE, ml/hr)
"""
import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, Optional, Any

from .treatment_database import TreatmentDatabase
from ..telemetry_contract import parse_clinical_timestamp

logger = logging.getLogger("PrismaFlexBackend")

# ─── PID → column mapping ─────────────────────────────────────
CRRT_PID_MAP = {
    17:  'qb',           # BLOOD_FLOW
    18:  'qs_pre',       # REPLACEMENT_PRE_FLOW (internal, summed)
    19:  'qs_post',      # REPLACEMENT_POST_FLOW (internal, summed)
    21:  'qd',           # DIALYSATE_FLOW
    22:  'qpbp',         # PRE_BLOOD_FLOW
    1:   'pa',           # ACCESS_PRESSURE
    4:   'pv',           # RETURN_PRESSURE
    2:   'pbe',          # FILTER_PRESSURE
    6:   'tmp',          # TMP
    100: 'uf_total',     # IO_HIST_UF_TOT (New PID 100)
    24:  'uf_hourly',    # IO_HIST_UF_1HR (New PID 24)
    23:  'effluent_flow',# EFFLUENT_FLOW
    461: 'run_time_sec', # RUN_TIME
    60:  'blood_vol',    # BLOOD_VOL_PROCESSED
    38:  'heparin_rate', # HEPARIN_CONT_RATE (Heparin "duy trì")
    26:  'pt_weight',    # PT_WEIGHT
    25:  'uf_rate_target',# PT_WEIGHT_BALANCE (Reassigned to 25)
    400: 'citrate_dose', # CITRATE_DOSE
    401: 'citrate_conc', # CITRATE_CONCENTRATION
    403: 'citrate_load', # CITRATE_LOAD
    404: 'calcium_rate', # CALCIUM_SYRINGE_RATE
    406: 'calcium_comp', # CALCIUM_COMPENSATION
    409: 'anticoag_type_id', # Anticoagulation Type (enumerative)
}

# ─── PIDs that represent clinical orders (Y lệnh) ─────────────
# When any of these change → trigger an Order-Change snapshot
ORDER_CHANGE_PIDS = {17, 21, 18, 19, 22, 25}  # QB, QD, QS_PRE, QS_POST, QPBP, UF_RATE_TARGET (PID 25)

# ─── PID accuracy scale factors ───────────────────────────────
# PrismaFlex telemetry sends raw integer values for some PIDs
# that have a non-zero accuracy (decimal places).
# PID 38 (HEPARIN_CONT_RATE): accuracy=1 → raw / 10
# Add more PIDs here if similar scaling issues are found.
PID_SCALE_MAP = {38: 0.1}


class DeviceCache:
    """In-memory cache of the latest parameter values for one device."""
    __slots__ = (
        'values',
        'last_hour_label',
        'treatment_id',
        'start_time',
        'last_pkt_time',
        'h00_saved',
        'saved_hour_labels',
    )

    def __init__(self, treatment_id: str, start_time: datetime = None):
        self.values: Dict[str, float] = {}
        self.last_hour_label: Optional[str] = None
        self.treatment_id = treatment_id
        self.start_time = start_time or datetime.now(timezone(timedelta(hours=7)))
        self.last_pkt_time: Optional[datetime] = None
        self.h00_saved: bool = False
        self.saved_hour_labels: set[str] = set()


class TreatmentSnapshotService:
    """
    Captures hourly snapshots of CRRT parameters.
    Call process_packet() for each telemetry packet — it caches values
    and creates a DB snapshot when an hour boundary is crossed.
    """

    def __init__(self, db: TreatmentDatabase):
        self._db = db
        self._caches: Dict[str, DeviceCache] = {}
        self._oc_counters: Dict[str, int] = {}  # Per-device OC snapshot counter
        self._last_oc_times: Dict[str, datetime] = {}
        self._last_oc_reasons: Dict[str, str] = {}

    def process_packet(self, device_id: str, timestamp: str,
                       treatment_id: Optional[str],
                       header: dict, body: dict):
        """
        Process one telemetry packet for snapshot purposes.
        When treatment_id is None, flush any remaining cached data.
        """
        cache = self._caches.get(device_id)

        # Treatment just closed or changed → flush remaining data
        if not treatment_id:
            if cache and cache.values and cache.last_hour_label:
                pkt_time = self._parse_time(timestamp)
                self._save_snapshot(device_id, cache, pkt_time)
                del self._caches[device_id]
            return

        try:
            pkt_time = self._parse_time(timestamp)

            # New or changed treatment → flush old cache, start fresh
            if cache is not None and cache.treatment_id != treatment_id:
                if cache.values and cache.last_hour_label:
                    self._save_snapshot(device_id, cache, pkt_time)
                cache = None
                # Reset OC counter for new treatment
                self._oc_counters.pop(device_id, None)
                self._last_oc_times.pop(device_id, None)
                self._last_oc_reasons.pop(device_id, None)

            if cache is None:
                cache = self._initialize_cache(device_id, treatment_id)

            # Always extract PID values (regardless of timestamp order)
            self._extract_values(cache, body)

            # Treatment-relative hour: H01, H02, ... H30, H72...
            elapsed = (pkt_time - cache.start_time).total_seconds()
            if elapsed < 0:
                elapsed = 0
            hour_num = int(elapsed / 3600)
            hour_label = f"H{hour_num:02d}"

            # Soft monotonicity: only update time tracker forward, never backward
            if cache.last_pkt_time is None or pkt_time >= cache.last_pkt_time:
                cache.last_pkt_time = pkt_time

            # H00 = first packet baseline and freezes forever.
            if not cache.h00_saved:
                self._save_frozen_hourly_snapshot(device_id, cache, pkt_time, "H00")

            # H01+ = first packet that arrives inside that treatment-relative hour.
            # If a whole hour has no packet, we do not fabricate that label; the
            # frontend should render the missing label as GAP.
            if hour_num > 0 and hour_label not in cache.saved_hour_labels:
                self._save_frozen_hourly_snapshot(device_id, cache, pkt_time, hour_label)

            cache.last_hour_label = hour_label

        except Exception as e:
            logger.error(f"Snapshot process error [{device_id}]: {e}", exc_info=True)

    def flush_device(self, device_id: str):
        """Release cache when treatment closes without mutating frozen H labels."""
        self._caches.pop(device_id, None)

    def clear_device(self, device_id: str):
        """Clear cache when treatment ends."""
        self._caches.pop(device_id, None)
        self._oc_counters.pop(device_id, None)

    def save_order_change_snapshot(self, device_id: str, timestamp: str, changes: list):
        """
        Triggered when clinical order PIDs (QB, QD, QS, QPBP, UF Rate) change.
        Creates a new OC_XX snapshot with ALL current cached parameter values.
        changes = [(pid, old_val, new_val), ...]
        
        Anti-flicker: Uses numeric value comparison to filter display-text noise.
        Cooldown: Groups rapid changes (within 60s) into a single OC snapshot.
        Counter Recovery: Reads max OC label from DB to prevent collisions on restart.
        """
        cache = self._caches.get(device_id)
        if not cache or not cache.values:
            logger.debug(f"OC Snapshot skipped [{device_id}]: no cache")
            return

        try:
            # ── Anti-flicker: Compare numeric values, not display text ──
            # event_service uses value_text which can flicker ("160" → "150" → "160")
            # Only accept changes where the numeric difference is >= 1
            real_changes = []
            for pid, old_val, new_val in changes:
                try:
                    old_num = float(str(old_val).replace(',', ''))
                    new_num = float(str(new_val).replace(',', ''))
                    if abs(new_num - old_num) < 1:
                        logger.debug(f"OC flicker filtered [{device_id}]: PID {pid} {old_val}→{new_val} (Δ<1)")
                        continue
                except (ValueError, TypeError):
                    pass  # Non-numeric values (like therapy type text) pass through
                real_changes.append((pid, old_val, new_val))

            if not real_changes:
                logger.debug(f"OC Snapshot skipped [{device_id}]: all changes filtered as flicker")
                return

            pkt_time = self._parse_time(timestamp)
            
            # ── 60-second Cooldown & Grouping ──
            # Prevents redundant rows when nurse adjusts multiple parameters
            last_time = self._last_oc_times.get(device_id)
            is_update = False
            if last_time and (pkt_time - last_time).total_seconds() < 60:
                is_update = True
                count = self._oc_counters.get(device_id, 1)
            else:
                # ── Counter Recovery from DB ──
                # Prevents OC_01 collision after backend restart
                if device_id not in self._oc_counters:
                    existing_max = 0
                    try:
                        row = self._db.fetch_one(
                            "SELECT hour_label FROM treatment_hourly_snapshots "
                            "WHERE treatment_id = ? AND hour_label LIKE 'OC_%' "
                            "ORDER BY CAST(SUBSTR(hour_label, 4) AS INTEGER) DESC LIMIT 1",
                            (cache.treatment_id,)
                        )
                        if row:
                            existing_max = int(row['hour_label'].split('_')[1])
                            logger.info(f"OC counter recovered [{device_id}]: max existing = OC_{existing_max:02d}")
                    except Exception:
                        pass
                    self._oc_counters[device_id] = existing_max

                count = self._oc_counters[device_id] + 1
                self._oc_counters[device_id] = count
                self._last_oc_times[device_id] = pkt_time

            oc_label = f"OC_{count:02d}"

            # ── Revert Check: Skip if value flicker already resolved ──
            # event_service saw qd: 500→800, but by now the cache may have
            # reverted to 500 (from a subsequent packet). Only keep changes
            # where the new_val MATCHES what's currently in the cache.
            confirmed_changes = []
            for pid, old_val, new_val in real_changes:
                col = CRRT_PID_MAP.get(pid)
                if not col:
                    confirmed_changes.append((pid, old_val, new_val))
                    continue
                # Handle qs split
                if col in ('qs_pre', 'qs_post'):
                    confirmed_changes.append((pid, old_val, new_val))
                    continue
                cache_val = cache.values.get(col)
                if cache_val is not None:
                    try:
                        # Cache matches new_val → change is real and persistent
                        if abs(float(cache_val) - float(str(new_val).replace(',',''))) < 1:
                            confirmed_changes.append((pid, old_val, new_val))
                        else:
                            logger.info(f"OC change reverted [{device_id}]: {col} reported {old_val}→{new_val} but cache={cache_val}")
                    except (ValueError, TypeError):
                        confirmed_changes.append((pid, old_val, new_val))
                else:
                    confirmed_changes.append((pid, old_val, new_val))

            if not confirmed_changes:
                logger.info(f"OC Snapshot SKIP [{device_id}]: all changes reverted in cache")
                if not is_update:
                    self._oc_counters[device_id] = count - 1
                return
            
            real_changes = confirmed_changes

            # ── Final Dedup: Skip if OC values identical to previous snapshot ──
            # Compare against the PREVIOUS different snapshot (skip current hour,
            # which is updated on every packet and always matches the cache).
            current_hour = cache.last_hour_label or ''
            try:
                prev_snap = self._db.fetch_one(
                    "SELECT qb, qd, qs, qpbp, uf_rate_target FROM treatment_hourly_snapshots "
                    "WHERE treatment_id = ? AND hour_label != ? "
                    "ORDER BY snapshot_time DESC LIMIT 1",
                    (cache.treatment_id, current_hour)
                )
                if prev_snap:
                    qs_total = cache.values.get('qs_pre', 0) + cache.values.get('qs_post', 0)
                    all_same = True
                    for col, cache_key in [('qb','qb'), ('qd','qd'), ('qs',None), ('qpbp','qpbp'), ('uf_rate_target','uf_rate_target')]:
                        cv = qs_total if col == 'qs' else cache.values.get(cache_key)
                        pv = prev_snap.get(col)
                        if cv is not None and pv is not None:
                            try:
                                if abs(float(cv) - float(pv)) >= 1:
                                    all_same = False
                                    break
                            except (ValueError, TypeError):
                                pass
                    if all_same:
                        logger.info(f"OC Snapshot DEDUP [{device_id}]: {oc_label} identical to prev snapshot (excl {current_hour}) — skipped")
                        if not is_update:
                            self._oc_counters[device_id] = count - 1
                        return
            except Exception as e:
                logger.debug(f"OC final dedup error: {e}")

            # Build/Merge reason string: "qb: 150→200, qd: 1500→2000"
            new_reasons = []
            for pid, old_val, new_val in real_changes:
                col_name = CRRT_PID_MAP.get(pid, f'PID{pid}')
                new_reasons.append(f"{col_name}: {old_val}→{new_val}")
            
            if is_update and device_id in self._last_oc_reasons:
                reason = self._last_oc_reasons[device_id] + ", " + ", ".join(new_reasons)
            else:
                reason = ", ".join(new_reasons)
            
            self._last_oc_reasons[device_id] = reason

            # Save/Update snapshot
            self._save_snapshot(device_id, cache, pkt_time, oc_label)

            # Update the reason string (Clinical context)
            self._db.execute(
                "UPDATE treatment_hourly_snapshots SET reason = ? WHERE treatment_id = ? AND hour_label = ?",
                (reason, cache.treatment_id, oc_label)
            )

            if is_update:
                logger.info(f"🔄 OC Snapshot [{device_id}] UPDATED {oc_label}: {reason}")
            else:
                logger.info(f"📋 OC Snapshot [{device_id}] {oc_label}: {reason}")

        except Exception as e:
            logger.error(f"OC Snapshot error [{device_id}]: {e}")

    # ─── Internal ──────────────────────────────────────────────

    def _extract_values(self, cache: DeviceCache, body: dict):
        """Extract CRRT-relevant PID values from packet body."""
        params = body.get('parameters', [])
        for p in params:
            pid = p.get('id')
            val = p.get('value')
            if pid is not None and val is not None and pid in CRRT_PID_MAP:
                col = CRRT_PID_MAP[pid]
                scaled = float(val)
                # Apply accuracy scaling (e.g. PID 38 accuracy=1 → raw/10)
                if pid in PID_SCALE_MAP:
                    scaled *= PID_SCALE_MAP[pid]
                cache.values[col] = scaled

    def _save_snapshot(self, device_id: str, cache: DeviceCache, pkt_time: datetime, hour_label: str = None):
        """Save cached values as an hourly snapshot."""
        if not cache.values:
            return

        # Target hour label
        target_label = hour_label or cache.last_hour_label
        if not target_label:
            return

        # Build auto_data dict from cached values
        auto_data = {}
        for col in ['qb', 'qd', 'qpbp', 'pa', 'pv', 'pbe', 'tmp',
                     'uf_total', 'uf_hourly', 'effluent_flow',
                     'run_time_sec', 'blood_vol',
                     'heparin_rate', 'pt_weight', 'uf_rate_target',
                     'citrate_dose', 'citrate_conc', 'citrate_load',
                     'calcium_comp', 'calcium_rate', 'anticoag_type_id']:
            if col in cache.values:
                auto_data[col] = cache.values[col]

        # Calculate Qs = Pre + Post
        qs_pre = cache.values.get('qs_pre', 0)
        qs_post = cache.values.get('qs_post', 0)
        if qs_pre or qs_post:
            auto_data['qs'] = qs_pre + qs_post

        if not auto_data:
            return

        self._db.upsert_snapshot(
            treatment_id=cache.treatment_id,
            device_id=device_id,
            hour_label=target_label,
            snapshot_time=pkt_time.isoformat(),
            auto_data=auto_data
        )
        # Use debug level to avoid log spamming on every packet
        logger.debug(f"Snapshot saved: {device_id} hour={target_label} "
                      f"({len(auto_data)} params)")

    def _save_frozen_hourly_snapshot(self, device_id: str, cache: DeviceCache, pkt_time: datetime, hour_label: str):
        """Save one Hxx snapshot exactly once and remember it as frozen."""
        if hour_label in cache.saved_hour_labels:
            return
        self._save_snapshot(device_id, cache, pkt_time, hour_label)
        cache.saved_hour_labels.add(hour_label)
        if hour_label == 'H00':
            cache.h00_saved = True

    def _initialize_cache(self, device_id: str, treatment_id: str) -> DeviceCache:
        """Create a new cache and attempt to recover state from DB."""
        # 1. Get start time
        row = self._db.fetch_one("SELECT start_time FROM treatments WHERE id = ?", (treatment_id,))
        start_time = None
        if row and row.get('start_time'):
            start_time = self._parse_time(row['start_time'])
        
        cache = DeviceCache(treatment_id, start_time)

        # 2. Recover which Hxx rows already exist so they stay frozen after restart.
        existing_rows = self._db.fetch_all(
            "SELECT hour_label FROM treatment_hourly_snapshots WHERE treatment_id = ?",
            (treatment_id,)
        )
        for row in existing_rows:
            label = row.get('hour_label')
            if isinstance(label, str) and label.startswith('H'):
                cache.saved_hour_labels.add(label)
        if 'H00' in cache.saved_hour_labels:
            cache.h00_saved = True

        # 3. Recover most recent snapshot to pre-populate parameters and hour label
        latest = self._db.get_latest_snapshot(treatment_id)
        if latest:
            latest_label = latest.get('hour_label')
            if isinstance(latest_label, str) and latest_label.startswith('H'):
                cache.last_hour_label = latest_label
            elif cache.saved_hour_labels:
                cache.last_hour_label = sorted(cache.saved_hour_labels)[-1]
            auto_data = latest.get('auto_data')
            if isinstance(auto_data, str):
                try:
                    import json
                    auto_data = json.loads(auto_data)
                except:
                    auto_data = {}
            
            if auto_data:
                cache.values = {k: float(v) for k, v in auto_data.items() if v is not None}
                # Special cases for Qs pre/post if they were saved separately (not likely but safe)
                if 'qs' in auto_data:
                    # We can't perfectly split Qs back to pre/post, but we can put it in one
                    cache.values['qs_pre'] = float(auto_data['qs'])

        self._caches[device_id] = cache
        return cache

    def _get_treatment_start(self, treatment_id: str) -> datetime:
        """Look up treatment start_time from DB."""
        row = self._db.fetch_one(
            "SELECT start_time FROM treatments WHERE id = ?", (treatment_id,))
        if row and row.get('start_time'):
            return self._parse_time(row['start_time'])
        return datetime.now(timezone(timedelta(hours=7)))

    def _parse_time(self, timestamp: str) -> datetime:
        """Parse packet timestamp into the shared local clinical time contract."""
        return parse_clinical_timestamp(timestamp)

    def get_cache_status(self) -> dict:
        """Debug: show current cache state."""
        return {
            did: {
                "treatment_id": c.treatment_id[:8],
                "last_hour": c.last_hour_label,
                "cached_params": len(c.values)
            }
            for did, c in self._caches.items()
        }
