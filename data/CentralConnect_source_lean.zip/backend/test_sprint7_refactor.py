import os
import sys
import unittest
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.services.treatment.treatment_snapshot_service import TreatmentSnapshotService, DeviceCache
from backend.services.treatment.historical_backfill_importer import HistoricalBackfillImporter

class TestSprint7Refactor(unittest.TestCase):
    def setUp(self):
        self.mock_db = MagicMock()
        self.service = TreatmentSnapshotService(self.mock_db)
        self.local_tz = timezone(timedelta(hours=7))

    def test_deterministic_hour_slot(self):
        """Spec §3.1: hour_slot = floor((pkt_time - start_time) / 3600)"""
        start_time = datetime(2026, 4, 5, 10, 0, 0, tzinfo=self.local_tz)
        
        # H00: 30 mins after start
        pkt_time_h00 = start_time + timedelta(minutes=30)
        elapsed = (pkt_time_h00 - start_time)
        hour_num = int(elapsed.total_seconds() / 3600)
        self.assertEqual(hour_num, 0)
        
        # H01: 65 mins after start
        pkt_time_h01 = start_time + timedelta(minutes=65)
        elapsed = (pkt_time_h01 - start_time)
        hour_num = int(elapsed.total_seconds() / 3600)
        self.assertEqual(hour_num, 1)

    def test_flush_device_uses_clinical_time(self):
        """TASK-134: flush_device must use last_pkt_time, not wall clock."""
        device_id = "DEV01"
        treatment_id = "TREAT01"
        clinical_time = datetime(2026, 4, 5, 12, 0, 0, tzinfo=self.local_tz)
        
        cache = DeviceCache(treatment_id, clinical_time - timedelta(hours=1))
        cache.last_pkt_time = clinical_time
        cache.values = {'qb': 150}
        cache.last_hour_label = "H01"
        
        self.service._caches[device_id] = cache
        
        # Execute flush
        self.service.flush_device(device_id)
        
        # Verify upsert used clinical_time
        self.mock_db.upsert_snapshot.assert_called_with(
            treatment_id=treatment_id,
            device_id=device_id,
            hour_label="H01",
            snapshot_time=clinical_time.isoformat(),
            auto_data={'qb': 150.0},
            hour_slot=1, # extracted from "H01"
            source='LIVE'
        )

    def test_h00_stabilization(self):
        """TASK-133: H00 stabilization window (60s)."""
        device_id = "DEV01"
        treatment_id = "TREAT01"
        start_time = datetime(2026, 4, 5, 10, 0, 0, tzinfo=self.local_tz)
        
        # Mock DB initialization: 1st call for start_time, 2nd call for H00 existence
        self.mock_db.fetch_one.side_effect = [
            {'start_time': start_time.isoformat()}, # start_time look up
            None # H00 existence check
        ]
        self.mock_db.get_latest_snapshot.return_value = None
        
        # Packet 1: 10s elapsed
        self.service.process_packet(device_id, (start_time + timedelta(seconds=10)).isoformat(), 
                                    treatment_id, {}, {'parameters': [{'id': 17, 'value': 100}]})
        
        cache = self.service._caches[device_id]
        self.assertFalse(cache.h00_saved) # Not yet 60s
        
        # Packet 2: 70s elapsed
        self.service.process_packet(device_id, (start_time + timedelta(seconds=70)).isoformat(), 
                                    treatment_id, {}, {'parameters': [{'id': 17, 'value': 200}]})
        
        self.assertTrue(cache.h00_saved) # Should be locked

    def test_backfill_importer_deterministic(self):
        """TASK-136: Backfill importer logic."""
        importer = HistoricalBackfillImporter(self.mock_db)
        treatment_id = "TREAT01"
        device_id = "DEV01"
        start_time = datetime(2026, 4, 5, 10, 0, 0, tzinfo=self.local_tz)
        
        # Packet at 2.5 hours -> H02
        pkt_time = start_time + timedelta(hours=2, minutes=30)
        importer.process_packet(treatment_id, device_id, pkt_time, start_time, 
                                {'parameters': [{'id': 17, 'value': 150}]})
        
        # Mock device lookup
        self.mock_db.fetch_one.return_value = {'device_id': device_id}
        
        importer.flush_treatment(treatment_id)
        
        # Verify source is BACKFILL and hour_slot is 2
        self.mock_db.upsert_snapshot.assert_called_with(
            treatment_id=treatment_id,
            device_id=device_id,
            hour_label="H02",
            snapshot_time=pkt_time.isoformat(),
            auto_data={'qb': 150.0},
            hour_slot=2,
            source='BACKFILL'
        )

if __name__ == "__main__":
    unittest.main()
