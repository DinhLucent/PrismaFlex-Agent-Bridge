import sqlite3
import os

db_path = os.path.join(os.path.dirname(__file__), "treatment_records.db")
conn = sqlite3.connect(db_path)
cur = conn.cursor()
cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
print("treatment_records.db tables:", cur.fetchall())
conn.close()

db_path2 = os.path.join(os.path.dirname(__file__), "prismaflex_treatment.db")
if os.path.exists(db_path2):
    conn = sqlite3.connect(db_path2)
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
    print("prismaflex_treatment.db tables:", cur.fetchall())
    conn.close()
