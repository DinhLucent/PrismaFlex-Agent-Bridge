"""
Comprehensive schema fix — adds ALL missing columns.
Compares models vs actual DB and fixes gaps.
"""
from sqlalchemy import create_engine, text

DB_URL = "postgresql+psycopg2://prismaflex:prismaflex@127.0.0.1:5432/prismaflex"
engine = create_engine(DB_URL)

# All ALTER TABLE statements needed to bring schema up to date
fixes = [
    # ── treatments: missing columns added after initial migration ──
    "ALTER TABLE treatments ADD COLUMN IF NOT EXISTS patient_yob INTEGER",
    "ALTER TABLE treatments ADD COLUMN IF NOT EXISTS patient_gender VARCHAR",
    "ALTER TABLE treatments ADD COLUMN IF NOT EXISTS patient_weight NUMERIC(10,2)",
    "ALTER TABLE treatments ADD COLUMN IF NOT EXISTS bed_number VARCHAR",
    "ALTER TABLE treatments ADD COLUMN IF NOT EXISTS admission_number VARCHAR",
    "ALTER TABLE treatments ADD COLUMN IF NOT EXISTS diagnosis TEXT",
    "ALTER TABLE treatments ADD COLUMN IF NOT EXISTS last_packet_time TIMESTAMPTZ",
    "ALTER TABLE treatments ADD COLUMN IF NOT EXISTS last_run_time_sec DOUBLE PRECISION",
    "ALTER TABLE treatments ADD COLUMN IF NOT EXISTS continuity_source VARCHAR",

    # ── treatment_list_projection: missing columns ──
    "ALTER TABLE treatment_list_projection ADD COLUMN IF NOT EXISTS anticoag_type_id INTEGER",
    "ALTER TABLE treatment_list_projection ADD COLUMN IF NOT EXISTS anticoag_type VARCHAR",
    "ALTER TABLE treatment_list_projection ADD COLUMN IF NOT EXISTS therapy_type VARCHAR",
    "ALTER TABLE treatment_list_projection ADD COLUMN IF NOT EXISTS reject_reason TEXT",

    # ── device_state: create if not exists ──
    """CREATE TABLE IF NOT EXISTS device_state (
        device_id VARCHAR PRIMARY KEY,
        active_mode VARCHAR NOT NULL DEFAULT 'IDLE',
        active_treatment_id UUID REFERENCES treatments(id) ON DELETE SET NULL,
        last_patient_id VARCHAR,
        last_seen_time TIMESTAMPTZ,
        last_run_time_sec DOUBLE PRECISION,
        active_chunk_index INTEGER,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        CONSTRAINT ck_device_state_mode CHECK (active_mode IN ('LIVE', 'BACKFILL', 'IDLE'))
    )""",

    # ── treatment_projection_checkpoint: create if not exists ──
    """CREATE TABLE IF NOT EXISTS treatment_projection_checkpoint (
        id SERIAL PRIMARY KEY,
        last_processed_at TIMESTAMPTZ,
        last_treatment_id UUID,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )""",

    # ── treatment_journal_rows: added columns ──
    "ALTER TABLE treatment_journal_rows ADD COLUMN IF NOT EXISTS hour_slot INTEGER",

    # ── snapshot_audit_log: ensure all columns ──
    "ALTER TABLE snapshot_audit_log ADD COLUMN IF NOT EXISTS operator_role VARCHAR",
]

print("Fixing database schema...\n")
ok = 0
skip = 0
err = 0

with engine.begin() as conn:
    for i, sql in enumerate(fixes, 1):
        label = sql.strip().split('\n')[0][:75]
        try:
            conn.execute(text(sql))
            print(f"  {i:2d}. OK:   {label}")
            ok += 1
        except Exception as e:
            msg = str(e)
            if "already exists" in msg or "does not exist" in msg or "duplicate" in msg.lower():
                print(f"  {i:2d}. SKIP: {label}")
                skip += 1
            else:
                print(f"  {i:2d}. ERR:  {label}")
                print(f"        {msg[:120]}")
                err += 1

print(f"\nDone: {ok} fixed, {skip} skipped, {err} errors")
print("Restart: pm2 restart icub-backend")
