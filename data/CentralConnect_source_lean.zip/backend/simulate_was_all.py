import requests
import time
import json
from datetime import datetime, timezone

API_URL = "http://localhost:8000/api/v1/telemetry"
DEVICE_ID = "LIVE_WAS_OBSERVER"

def send_telemetry(data_values, therapy_status=1, therapy_type=1, weight=70.0):
    """
    Gửi 1 gói telemetry giả lập.
    """
    payload = {
        "meta": {
            "device_id": DEVICE_ID,
            "timestamp": datetime.now(timezone.utc).isoformat()
        },
        "header": {
            "machine_id": 777,
            "patient_id": "PT-SIM-WAS-001",
            "therapy_type_id": therapy_type,
            "therapy_status_id": therapy_status,
            "timestamp": datetime.now(timezone.utc).isoformat()
        },
        "body": {
            "parameters": []
        }
    }
    
    # Thêm Cân nặng (ID 26) - Không được WAS
    payload["body"]["parameters"].append({"id": 26, "value": weight, "type": "Actual"})
    
    # Thêm các thông số được theo dõi (TRACKED_PARAM_IDS)
    for pid, val in data_values.items():
        payload["body"]["parameters"].append({
            "id": pid,
            "value": val,
            "type": "Actual"
        })
        
    try:
        response = requests.post(API_URL, json=payload)
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Sent Telemetry. Status: {response.status_code}")
    except Exception as e:
        print(f"Error sending: {e}")

def run_simulation():
    print(f"🚀 Bắt đầu giả lập WAS cho thiết bị: {DEVICE_ID}")
    print("Mở Dashboard và trang chi tiết của LIVE_WAS_OBSERVER để theo dõi.\n")

    # 1. Khởi tạo giá trị ban đầu (Old Values)
    initial_values = {
        17: 150,  # Blood Flow
        22: 1200, # PBP
        21: 1500, # Dialysate
        19: 1000, # Replacement Post
        18: 500,  # Replacement Pre
        24: 100,  # Net UF
        414: 15,  # Post Dilution %
        413: 10,  # Pre Dilution %
        410: 25.5,# Effluent Dose
        412: 12,  # Filtration Fraction %
        409: 1,   # Anticoag Type (Heparin)
        37: 1000, # Heparin Bolus
        38: 500,  # Heparin Rate
        400: 3.0, # Citrate Dose
        406: 80,  # Calcium Comp
        460: 30,  # HCT Port
        47: 32,   # HCT Pre
        411: 1    # Filter Set
    }
    
    print("--- ĐỢT 1: Khởi tạo giá trị ban đầu ---")
    send_telemetry(initial_values, therapy_status=1, therapy_type=1, weight=70.0)
    
    print("Chờ 3 giây để hệ thống ghi nhận...")
    time.sleep(3)
    
    # 2. Thay đổi giá trị (New Values -> Sẽ tạo 'was' labels)
    new_values = {
        17: 200,  # Changed from 150
        22: 1500, # Changed from 1200
        21: 2000, # Changed from 1500
        19: 800,  # Changed from 1000
        18: 1200, # Changed from 500
        24: 150,  # Changed from 100
        414: 20,
        413: 15,
        410: 35.0,
        412: 18,
        409: 2,   # Changed to Citrate
        37: 0,
        38: 200,
        400: 4.5,
        406: 100,
        460: 35,
        47: 38,
        411: 2
    }
    
    print("\n--- ĐỢT 2: Thay đổi tất cả thông số (Kích hoạt WAS) ---")
    # Thay đổi cả Therapy Mode và Weight - Nhưng chúng KHÔNG được hiện nhãn 'was'
    send_telemetry(new_values, therapy_status=2, therapy_type=2, weight=85.0)
    
    print("\n✅ Xong! Kiểm tra trên Web xem các ô có nhãn 'was [giá trị cũ]' màu cam không.")
    print("Lưu ý: 'Weight' và 'Therapy Mode' sẽ thay đổi giá trị nhưng KHÔNG có nhãn 'was'.")

if __name__ == "__main__":
    run_simulation()
