"""
Treatment journal rows — the most critical table in the migration.

Spec reference: TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC Section 9.4
Maps from SQLite `treatment_hourly_snapshots`.

ADR-2: Wide-row relational model (not EAV).
Clinical rule: snapshot_time is IMMUTABLE after insertion.
"""
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, Integer, BigInteger, Boolean, Text, Numeric,
    DateTime, ForeignKey, CheckConstraint, Index, UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class TreatmentJournalRow(Base):
    """
    Source of truth for the journal grid.

    Each row is one H00-H99 (hourly) or OC_XX (order-change) record.
    The wide-row pattern keeps telemetry + manual fields in the same row,
    matching the clinical review/export grid shape.

    IMMUTABILITY RULE: snapshot_time must never change after row creation.
    """
    __tablename__ = "treatment_journal_rows"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    treatment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="CASCADE"),
        nullable=False,
    )
    device_id = Column(String, nullable=False)
    row_code = Column(String, nullable=False)   # H00, H01, OC_01, etc.
    row_kind = Column(String, nullable=False)    # HOUR | ORDER_CHANGE
    hour_slot = Column(Integer, nullable=True)   # Spec v2.1: Deterministic hour index
    snapshot_time = Column(DateTime(timezone=True), nullable=False)  # IMMUTABLE
    stable_at = Column(DateTime(timezone=True), nullable=True)
    source = Column(String, nullable=False, default="LIVE")  # LIVE|BACKFILL|MANUAL|RECOVERY

    # Soft delete
    is_deleted = Column(Boolean, nullable=False, default=False)
    deleted_at = Column(DateTime(timezone=True), nullable=True)
    deleted_by = Column(String, nullable=True)

    # ── Telemetry columns (machine-reported, NOT manually editable) ──
    qb = Column(Numeric(10, 2), nullable=True)
    qs = Column(Numeric(10, 2), nullable=True)
    qd = Column(Numeric(10, 2), nullable=True)
    qpbp = Column(Numeric(10, 2), nullable=True)
    pa = Column(Numeric(10, 2), nullable=True)
    pv = Column(Numeric(10, 2), nullable=True)
    pbe = Column(Numeric(10, 2), nullable=True)
    tmp = Column(Numeric(10, 2), nullable=True)
    uf_total = Column(Numeric(12, 2), nullable=True)
    uf_hourly = Column(Numeric(12, 2), nullable=True)
    effluent_flow = Column(Numeric(12, 2), nullable=True)
    run_time_sec = Column(Integer, nullable=True)
    blood_vol = Column(Numeric(12, 2), nullable=True)
    heparin_rate = Column(Numeric(12, 2), nullable=True)
    pt_weight = Column(Numeric(12, 2), nullable=True)
    uf_rate_target = Column(Numeric(12, 2), nullable=True)
    citrate_dose = Column(Numeric(12, 2), nullable=True)
    citrate_conc = Column(Numeric(12, 2), nullable=True)
    citrate_load = Column(Numeric(12, 2), nullable=True)
    calcium_comp = Column(Numeric(12, 2), nullable=True)
    calcium_rate = Column(Numeric(12, 2), nullable=True)
    anticoag_type_id = Column(Integer, nullable=True)

    # ── Manual-editable columns (nurse can edit on existing stable rows) ──
    heparin_bolus = Column(Text, nullable=True)
    solution_type = Column(Text, nullable=True)
    duosol_count = Column(Numeric(12, 2), nullable=True)
    prismasol_count = Column(Numeric(12, 2), nullable=True)
    filter_type = Column(Text, nullable=True)
    kali = Column(Numeric(12, 2), nullable=True)
    notes = Column(Text, nullable=True)

    # ── Audit columns ──
    created_at = Column(DateTime(timezone=True), nullable=False, default=_now_local)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=_now_local, onupdate=_now_local)
    created_by = Column(String, nullable=True)
    updated_by = Column(String, nullable=True)
    version = Column(Integer, nullable=False, default=1)

    # Relationships
    treatment = relationship("Treatment", back_populates="journal_rows")

    __table_args__ = (
        # Business key: one row per treatment + row_code
        UniqueConstraint("treatment_id", "row_code", name="uq_journal_rows_treatment_row_code"),

        # Row kind validation
        CheckConstraint(
            "row_kind IN ('HOUR','ORDER_CHANGE')",
            name="ck_journal_rows_row_kind",
        ),
        # Source validation
        CheckConstraint(
            "source IN ('LIVE','BACKFILL','MANUAL','RECOVERY')",
            name="ck_journal_rows_source",
        ),

        # ── Indexes (ADR-5: strong indexing from day one) ──
        Index("ix_journal_rows_treatment_snapshot", "treatment_id", snapshot_time.asc()),
        Index("ix_journal_rows_treatment_kind_snapshot", "treatment_id", "row_kind", snapshot_time.asc()),
        # Partial index for non-deleted rows (most common query pattern)
        Index(
            "ix_journal_rows_treatment_snapshot_active",
            "treatment_id", snapshot_time.asc(),
            postgresql_where=(is_deleted == False),
        ),
    )

    def __repr__(self) -> str:
        return f"<TreatmentJournalRow {self.id} code={self.row_code} time={self.snapshot_time}>"
