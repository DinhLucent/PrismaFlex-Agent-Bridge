"""
Snapshot audit log — append-only audit for every manual journal mutation.

Spec reference: TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC Section 9.8
Every manual edit command must write to this table (Handoff Section 14).
"""
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, BigInteger, Text, DateTime, ForeignKey, Index,
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class SnapshotAuditLog(Base):
    """
    Append-only audit trail for manual journal row mutations.

    Every command that modifies a journal row must log:
    - what changed (field, old value, new value)
    - who changed it (operator, role)
    - why (action, reason)

    ADR-6: Backend is policy source of truth. Audit capture
    must live in backend, not only in frontend UI logic.
    """
    __tablename__ = "snapshot_audit_log"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    treatment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="CASCADE"),
        nullable=False,
    )
    row_code = Column(String, nullable=False)
    action = Column(String, nullable=False)     # edit_value, restore, submit, etc.
    field_name = Column(String, nullable=True)
    old_value = Column(JSONB, nullable=True)
    new_value = Column(JSONB, nullable=True)
    operator_name = Column(String, nullable=False)
    operator_role = Column(String, nullable=True)
    reason = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=_now_local)

    __table_args__ = (
        Index("ix_audit_log_treatment_created", "treatment_id", created_at.desc()),
        Index("ix_audit_log_treatment_row_created", "treatment_id", "row_code", created_at.desc()),
        Index("ix_audit_log_operator_created", "operator_name", created_at.desc()),
    )

    def __repr__(self) -> str:
        return f"<SnapshotAuditLog {self.id} action={self.action} row={self.row_code}>"
