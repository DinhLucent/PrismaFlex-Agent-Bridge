"""
Treatment master record.

Spec reference: TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC Section 9.1
Maps from SQLite `treatments` table.
"""
import uuid
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, Integer, BigInteger, Boolean, Text, Numeric, Float,
    DateTime, CheckConstraint, Index,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from ..base import Base

# GMT+7 timezone for clinical timestamps
_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class Treatment(Base):
    """
    Treatment master record — lifecycle, patient context, outcome.

    ADR-1: PostgreSQL is the default operational database.
    Clinical rule: snapshot_time is immutable (enforced on journal rows, not here).
    """
    __tablename__ = "treatments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    device_id = Column(String, nullable=False)
    patient_id = Column(String, nullable=True)
    patient_name = Column(String, nullable=True)
    patient_yob = Column(Integer, nullable=True)
    patient_gender = Column(String, nullable=True)
    patient_weight = Column(Numeric(10, 2), nullable=True)
    bed_number = Column(String, nullable=True)
    admission_number = Column(String, nullable=True)
    diagnosis = Column(Text, nullable=True)
    therapy_type_id = Column(Integer, nullable=True)
    anticoag_type_id = Column(Integer, nullable=True)

    start_time = Column(DateTime(timezone=True), nullable=False)
    first_run_time = Column(DateTime(timezone=True), nullable=True)
    end_time = Column(DateTime(timezone=True), nullable=True)
    last_seen_time = Column(DateTime(timezone=True), nullable=False)

    outcome = Column(String, nullable=False, default="IN_PROGRESS")
    fsm_state = Column(String, nullable=False, default="IDLE")
    close_reason = Column(Text, nullable=True)

    total_run_seconds = Column(Integer, nullable=True)
    total_paused_seconds = Column(Integer, nullable=True)
    total_phases = Column(Integer, nullable=True)
    total_packets = Column(BigInteger, nullable=True)

    is_valid = Column(Boolean, nullable=True)
    had_interruption = Column(Boolean, nullable=True)
    had_program_restart = Column(Boolean, nullable=True)
    sw_version = Column(String, nullable=True)

    # DB Checkpoint columns (write-through from runtime state)
    last_packet_time = Column(DateTime(timezone=True), nullable=True)
    last_run_time_sec = Column(Float, nullable=True)
    continuity_source = Column(String, nullable=True)  # 'NEW' | 'RESUME'

    start_time_override = Column(DateTime(timezone=True), nullable=True)
    end_time_override = Column(DateTime(timezone=True), nullable=True)
    clinical_notes = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), nullable=False, default=_now_local)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=_now_local, onupdate=_now_local)
    version = Column(Integer, nullable=False, default=1)

    # Relationships
    phases = relationship("TreatmentPhase", back_populates="treatment", lazy="select")
    journal_rows = relationship("TreatmentJournalRow", back_populates="treatment", lazy="select")
    status_events = relationship("TreatmentStatusEvent", back_populates="treatment", lazy="select")
    notes = relationship("TreatmentNote", back_populates="treatment", lazy="select")
    review_state = relationship("TreatmentReviewState", back_populates="treatment", uselist=False, lazy="select")

    __table_args__ = (
        CheckConstraint(
            "outcome IN ('IN_PROGRESS','COMPLETED','INTERRUPTED','ARCHIVED','INVALID')",
            name="ck_treatments_outcome",
        ),
        Index("ix_treatments_device_start", "device_id", start_time.desc()),
        Index("ix_treatments_patient_start", "patient_id", start_time.desc()),
        Index("ix_treatments_outcome_start", "outcome", start_time.desc()),
    )

    def __repr__(self) -> str:
        return f"<Treatment {self.id} device={self.device_id} outcome={self.outcome}>"
