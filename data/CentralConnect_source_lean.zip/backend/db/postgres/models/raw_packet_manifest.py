"""
Raw packet manifest — metadata registry for chunked telemetry storage.

Sprint 4 spec: RAW_TELEMETRY_ARCHITECTURE_SPEC Section 2.2

Tracks each 50MB chunk of telemetry data for a treatment.
The actual packet bodies stay in JSONL/Parquet files on disk;
this table is the unified ledger telling the analyzer WHERE to find them.
"""
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, Integer, BigInteger, Text, DateTime,
    ForeignKey, Index, UniqueConstraint, CheckConstraint,
)
from sqlalchemy.dialects.postgresql import UUID

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class RawPacketManifest(Base):
    """
    Manifest-managed chunk registry per RAW_TELEMETRY_ARCHITECTURE_SPEC.

    Lifecycle:
    - ACTIVE: chunk is being written by raw_streamer (live treatment)
    - CLOSED: chunk is finalized (treatment ended or 50MB rotation)
    - ARCHIVED: chunk has been compressed to Parquet (JSONL deleted)
    """
    __tablename__ = "raw_packet_manifest"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    treatment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="CASCADE"),
        nullable=False,
    )
    chunk_index = Column(Integer, nullable=False)           # 1, 2, 3...
    file_path = Column(Text, nullable=False)                # Relative or absolute
    format = Column(String(10), nullable=False, default="JSONL")  # JSONL | PARQUET | GZ
    status = Column(String(20), nullable=False, default="ACTIVE") # ACTIVE | CLOSED | ARCHIVED

    first_timestamp = Column(DateTime(timezone=True), nullable=True)
    last_timestamp = Column(DateTime(timezone=True), nullable=True)
    packet_count = Column(BigInteger, nullable=False, default=0)
    size_bytes = Column(BigInteger, nullable=True)

    created_at = Column(DateTime(timezone=True), nullable=False, default=_now_local)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=_now_local, onupdate=_now_local)

    __table_args__ = (
        UniqueConstraint("treatment_id", "chunk_index", name="uq_manifest_treatment_chunk"),
        CheckConstraint("format IN ('JSONL','PARQUET','GZ')", name="ck_manifest_format"),
        CheckConstraint("status IN ('ACTIVE','CLOSED','ARCHIVED')", name="ck_manifest_status"),
        Index("ix_raw_manifest_treatment_status", "treatment_id", "status"),
        Index("ix_raw_manifest_treatment_chunk", "treatment_id", "chunk_index"),
    )

    def __repr__(self) -> str:
        return f"<RawPacketManifest treatment={self.treatment_id} chunk={self.chunk_index} format={self.format} status={self.status}>"
