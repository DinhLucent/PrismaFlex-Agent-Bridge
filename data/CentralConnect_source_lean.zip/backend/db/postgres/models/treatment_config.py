"""
Treatment configuration — therapy setup and device config snapshot.

Maps from SQLite `treatment_config`. Not explicitly in the 10-table
spec but referenced as treatment setup/config in Section 4.
"""
import uuid
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, Integer, Text, DateTime, ForeignKey, Index,
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class TreatmentConfig(Base):
    """
    Snapshot of therapy configuration at treatment start.

    Stores device-reported therapy settings (mode, flow targets,
    anticoagulation parameters) as both structured columns and
    a raw JSONB payload for forward compatibility.
    """
    __tablename__ = "treatment_config"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    treatment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
    )
    therapy_type_id = Column(Integer, nullable=True)
    anticoag_type_id = Column(Integer, nullable=True)
    config_json = Column(JSONB, nullable=True)

    created_at = Column(DateTime(timezone=True), nullable=False, default=_now_local)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=_now_local, onupdate=_now_local)

    __table_args__ = (
        Index("ix_treatment_config_treatment", "treatment_id"),
    )

    def __repr__(self) -> str:
        return f"<TreatmentConfig treatment={self.treatment_id}>"
