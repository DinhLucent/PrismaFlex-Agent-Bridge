"""
Treatment notes — append-only clinical note stream.

Spec reference: TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC Section 9.7
Maps from SQLite `treatment_notes`.
"""
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, BigInteger, Text, DateTime, ForeignKey, Index,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class TreatmentNote(Base):
    """
    Append-only clinical notes.

    Notes are never edited or deleted — only appended.
    Authorship and role are captured for audit trail.
    """
    __tablename__ = "treatment_notes"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    treatment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="CASCADE"),
        nullable=False,
    )
    author_name = Column(String, nullable=False)
    author_role = Column(String, nullable=True)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=_now_local)

    # Relationships
    treatment = relationship("Treatment", back_populates="notes")

    __table_args__ = (
        Index("ix_notes_treatment_created", "treatment_id", created_at.asc()),
    )

    def __repr__(self) -> str:
        return f"<TreatmentNote {self.id} by={self.author_name}>"
