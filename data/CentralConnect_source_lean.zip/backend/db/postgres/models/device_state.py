"""
Device State — DB checkpoint for per-device runtime state.

Replaces in-memory-only _sessions/_backfill_sessions after validation.
Write-through: updated alongside memory on every state change.
"""
import uuid
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, Integer, Float, DateTime, CheckConstraint,
    ForeignKey,
)
from sqlalchemy.dialects.postgresql import UUID

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class DeviceState(Base):
    """
    Per-device checkpoint — survives backend restart.
    
    Tracks:
      - active_mode: LIVE / BACKFILL / IDLE
      - active_treatment_id: which treatment is currently in-progress
      - last_seen_time: timestamp of the last packet processed
      - last_patient_id: for continuity checks
      - last_run_time_sec: PID 461 from the last packet
      - active_chunk_index: raw streamer chunk counter
    """
    __tablename__ = "device_state"

    device_id = Column(String, primary_key=True)
    active_mode = Column(
        String, nullable=False, default="IDLE",
    )
    active_treatment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="SET NULL"),
        nullable=True,
    )
    last_patient_id = Column(String, nullable=True)
    last_seen_time = Column(DateTime(timezone=True), nullable=True)
    last_run_time_sec = Column(Float, nullable=True)
    active_chunk_index = Column(Integer, nullable=True)
    updated_at = Column(
        DateTime(timezone=True), nullable=False,
        default=_now_local, onupdate=_now_local,
    )

    __table_args__ = (
        CheckConstraint(
            "active_mode IN ('LIVE', 'BACKFILL', 'IDLE')",
            name="ck_device_state_mode",
        ),
    )

    def __repr__(self) -> str:
        return f"<DeviceState {self.device_id} mode={self.active_mode}>"
