"""
Treatment review state — approval workflow state machine.

Spec reference: TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC Section 9.6
New table (no direct SQLite predecessor — approval metadata was embedded).
"""
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, Text, DateTime, ForeignKey, CheckConstraint, Index,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class TreatmentReviewState(Base):
    """
    Approval workflow state for a treatment.

    State machine: DRAFT -> PENDING_REVIEW -> APPROVED | REJECTED
    APPROVED can be unlocked back to DRAFT for correction.

    ADR-6: Review commands are explicit (submit, approve, reject, unlock),
    not generic CRUD operations.
    """
    __tablename__ = "treatment_review_state"

    treatment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="CASCADE"),
        primary_key=True,
    )
    approval_status = Column(String, nullable=False, default="DRAFT")

    submitted_at = Column(DateTime(timezone=True), nullable=True)
    submitted_by = Column(String, nullable=True)
    approved_at = Column(DateTime(timezone=True), nullable=True)
    approved_by = Column(String, nullable=True)
    rejected_at = Column(DateTime(timezone=True), nullable=True)
    rejected_by = Column(String, nullable=True)
    reject_reason = Column(Text, nullable=True)
    unlocked_at = Column(DateTime(timezone=True), nullable=True)
    unlocked_by = Column(String, nullable=True)

    updated_at = Column(DateTime(timezone=True), nullable=False, default=_now_local, onupdate=_now_local)

    # Relationships
    treatment = relationship("Treatment", back_populates="review_state")

    __table_args__ = (
        CheckConstraint(
            "approval_status IN ('DRAFT','PENDING_REVIEW','APPROVED','REJECTED')",
            name="ck_review_state_status",
        ),
        Index("ix_review_state_status_updated", "approval_status", updated_at.desc()),
    )

    def __repr__(self) -> str:
        return f"<TreatmentReviewState treatment={self.treatment_id} status={self.approval_status}>"
