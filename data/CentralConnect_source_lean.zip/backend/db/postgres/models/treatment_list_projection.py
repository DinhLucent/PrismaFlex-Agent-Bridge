"""
Treatment list projection — fast list/history/dashboard view.

Spec reference: TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC Section 9.9
Maps from SQLite `treatment_index`.

ADR-4: Projection table is a first-class part of the architecture.
Maintained by the application (not a materialized view).
"""
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, Integer, BigInteger, Boolean, Text,
    DateTime, ForeignKey, Index,
)
from sqlalchemy.dialects.postgresql import UUID

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class TreatmentListProjection(Base):
    """
    Fast list/history projection for paginated treatment views.

    This table is denormalized intentionally:
    - list/history screens should not join heavy journal/event tables
    - gives stable UX projection for filters and pagination
    - reduces query complexity for common list operations

    Updated by projection_service when treatment state changes.
    """
    __tablename__ = "treatment_list_projection"

    id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="CASCADE"),
        primary_key=True,
    )
    device_id = Column(String, nullable=False)
    patient_id = Column(String, nullable=True)
    patient_name = Column(String, nullable=True)
    therapy_type_id = Column(Integer, nullable=True)
    anticoag_type_id = Column(Integer, nullable=True)
    therapy_type = Column(String, nullable=True)
    anticoag_type = Column(String, nullable=True)

    start_time = Column(DateTime(timezone=True), nullable=False)
    end_time = Column(DateTime(timezone=True), nullable=True)
    outcome = Column(String, nullable=False, default="IN_PROGRESS")
    approval_status = Column(String, nullable=False, default="DRAFT")

    total_run_seconds = Column(Integer, nullable=True)
    total_phases = Column(Integer, nullable=True)
    total_packets = Column(BigInteger, nullable=True)
    journal_row_count = Column(Integer, nullable=True)
    note_count = Column(Integer, nullable=True)
    is_valid = Column(Boolean, nullable=True)
    reject_reason = Column(Text, nullable=True)

    updated_at = Column(DateTime(timezone=True), nullable=False, default=_now_local, onupdate=_now_local)

    __table_args__ = (
        Index("ix_projection_outcome_start", "outcome", start_time.desc()),
        Index("ix_projection_approval_start", "approval_status", start_time.desc()),
        Index("ix_projection_patient_start", "patient_id", start_time.desc()),
    )

    def __repr__(self) -> str:
        return f"<TreatmentListProjection treatment={self.id} outcome={self.outcome}>"
