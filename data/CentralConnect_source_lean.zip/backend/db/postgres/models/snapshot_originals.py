"""
Snapshot originals — frozen machine-original rows used in review and restore.

Spec reference: TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC Section 9.5
Maps from SQLite `snapshot_originals`.
"""
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, BigInteger, DateTime, ForeignKey, Index, UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class SnapshotOriginal(Base):
    """
    Frozen machine-original journal rows for review comparison and restore.

    Semantics:
    - Frozen on submit (when nurse submits treatment for review)
    - snapshot_json contains the full original row as JSONB
    - Used by review_service to compare current vs original values
    """
    __tablename__ = "snapshot_originals"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    treatment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="CASCADE"),
        nullable=False,
    )
    row_code = Column(String, nullable=False)
    snapshot_time = Column(DateTime(timezone=True), nullable=False)
    snapshot_json = Column(JSONB, nullable=False)
    frozen_at = Column(DateTime(timezone=True), nullable=False, default=_now_local)
    frozen_by = Column(String, nullable=True)

    __table_args__ = (
        UniqueConstraint("treatment_id", "row_code", name="uq_snapshot_originals_treatment_row"),
        Index("ix_snapshot_originals_treatment_time", "treatment_id", snapshot_time.asc()),
    )

    def __repr__(self) -> str:
        return f"<SnapshotOriginal treatment={self.treatment_id} row={self.row_code}>"
