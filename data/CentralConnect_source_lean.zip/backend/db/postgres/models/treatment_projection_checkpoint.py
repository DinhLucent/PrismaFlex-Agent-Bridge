"""
Treatment Projection Checkpoint — DB checkpoint for snapshot projection state.

Tracks the last committed hourly slot, OC counter, and anchor times
so that the importer can resume deterministically after restart.
"""
import uuid
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, Integer, DateTime, ForeignKey,
)
from sqlalchemy.dialects.postgresql import UUID, JSONB

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class TreatmentProjectionCheckpoint(Base):
    """
    Per-treatment snapshot projection checkpoint.
    
    Tracks:
      - last_hour_slot: the last H slot committed to DB (-1 = none yet)
      - slot_anchor_time: the timestamp used to anchor the current slot
      - last_oc_counter: OC_XX counter (how many OC snapshots saved)
      - last_oc_time: timestamp of the most recent OC snapshot
      - last_oc_values: {qb, qd, qpbp, uf_rate_target} baseline for dedup
    """
    __tablename__ = "treatment_projection_checkpoint"

    treatment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="CASCADE"),
        primary_key=True,
    )
    last_hour_slot = Column(Integer, nullable=False, default=-1)
    slot_anchor_time = Column(DateTime(timezone=True), nullable=True)
    last_oc_counter = Column(Integer, nullable=False, default=0)
    last_oc_time = Column(DateTime(timezone=True), nullable=True)
    last_oc_values = Column(JSONB, nullable=False, server_default='{}')
    updated_at = Column(
        DateTime(timezone=True), nullable=False,
        default=_now_local, onupdate=_now_local,
    )

    def __repr__(self) -> str:
        return (f"<ProjectionCheckpoint treatment={self.treatment_id} "
                f"slot={self.last_hour_slot} oc={self.last_oc_counter}>")
