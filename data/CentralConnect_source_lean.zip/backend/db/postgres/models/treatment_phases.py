"""
Treatment phase records — lifecycle segments for pauses, resumes, continuation.

Spec reference: TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC Section 9.2
Maps from SQLite `treatment_phases` table.
"""
import uuid
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, Integer, DateTime, ForeignKey, Index,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class TreatmentPhase(Base):
    """
    Lifecycle phase segments: pauses, resumes, same-patient continuation.

    Clinical rule: continuation only when same device + same patient + RUN_TIME > 0.
    """
    __tablename__ = "treatment_phases"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    treatment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="CASCADE"),
        nullable=False,
    )
    phase_number = Column(Integer, nullable=False)
    phase_type = Column(String, nullable=False)
    start_time = Column(DateTime(timezone=True), nullable=False)
    end_time = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), nullable=False, default=_now_local)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=_now_local, onupdate=_now_local)

    # Relationships
    treatment = relationship("Treatment", back_populates="phases")

    __table_args__ = (
        Index("ix_phases_treatment_number", "treatment_id", "phase_number"),
    )

    def __repr__(self) -> str:
        return f"<TreatmentPhase {self.id} phase={self.phase_number} type={self.phase_type}>"
