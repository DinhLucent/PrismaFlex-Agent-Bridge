"""
Treatment status event log — append-only state/event stream.

Spec reference: TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC Section 9.3
Maps from SQLite `treatment_status_log` with rename: timestamp -> event_time.
"""
from datetime import datetime, timezone, timedelta

from sqlalchemy import (
    Column, String, Integer, BigInteger, Text, DateTime, ForeignKey, Index,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from ..base import Base

_LOCAL_TZ = timezone(timedelta(hours=7))


def _now_local() -> datetime:
    return datetime.now(_LOCAL_TZ)


class TreatmentStatusEvent(Base):
    """
    Append-only event log for treatment state transitions.

    Renamed from `treatment_status_log`:
    - `timestamp` -> `event_time`
    - Added `event_code` for machine-readable event classification
    """
    __tablename__ = "treatment_status_events"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    treatment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("treatments.id", ondelete="CASCADE"),
        nullable=False,
    )
    device_id = Column(String, nullable=False)
    event_time = Column(DateTime(timezone=True), nullable=False)
    therapy_status_id = Column(Integer, nullable=True)
    fsm_state = Column(String, nullable=False)
    patient_id = Column(String, nullable=True)
    event_code = Column(String, nullable=False)
    note = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), nullable=False, default=_now_local)

    # Relationships
    treatment = relationship("Treatment", back_populates="status_events")

    __table_args__ = (
        Index("ix_status_events_treatment_time", "treatment_id", event_time.asc()),
        Index("ix_status_events_device_time", "device_id", event_time.desc()),
        Index("ix_status_events_code_time", "event_code", event_time.desc()),
    )

    def __repr__(self) -> str:
        return f"<TreatmentStatusEvent {self.id} code={self.event_code}>"
