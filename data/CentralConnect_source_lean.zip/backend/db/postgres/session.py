"""
PostgreSQL session and engine management.

Uses config.POSTGRES_URL by default. Engine and session factory
are created lazily to avoid import-time database connections.
"""
import logging
from functools import lru_cache
from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

logger = logging.getLogger("PrismaFlex.DB")


@lru_cache(maxsize=1)
def get_engine(url: str | None = None):
    """
    Create and cache a single SQLAlchemy engine.

    Args:
        url: PostgreSQL connection URL. If None, reads from config.
    """
    if url is None:
        from config import settings
        url = settings.POSTGRES_URL

    engine = create_engine(
        url,
        pool_size=5,
        max_overflow=10,
        pool_pre_ping=True,
        echo=False,
    )
    logger.info("PostgreSQL engine created: %s", url.split("@")[-1] if "@" in url else url)
    return engine


def get_session_factory(url: str | None = None) -> sessionmaker[Session]:
    """Return a session factory bound to the engine."""
    return sessionmaker(bind=get_engine(url), expire_on_commit=False)


@contextmanager
def get_session(url: str | None = None):
    """
    Context manager yielding a transactional session.

    Usage:
        with get_session() as session:
            session.query(Treatment).all()
    """
    factory = get_session_factory(url)
    session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
