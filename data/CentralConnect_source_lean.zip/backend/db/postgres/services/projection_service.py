"""
Projection service — maintains treatment_list_projection.

ADR-4: Projection table is a first-class part of the architecture.
"""
from uuid import UUID
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from ..repositories.projection_repository import ProjectionRepository
from ..repositories.treatment_repository import TreatmentRepository
from ..models.treatment_journal_rows import TreatmentJournalRow
from ..models.treatment_notes import TreatmentNote


class ProjectionService:
    """
    Keeps the treatment_list_projection table in sync with treatment state.
    Called after treatment lifecycle events and review commands.
    """

    def __init__(self, session: Session):
        self.session = session
        self.proj_repo = ProjectionRepository(session)
        self.treatment_repo = TreatmentRepository(session)

    def refresh(self, treatment_id: UUID) -> None:
        """Refresh projection row from current treatment state."""
        treatment = self.treatment_repo.get_by_id(treatment_id)
        if not treatment:
            return

        from ..models.treatment_review_state import TreatmentReviewState
        review = self.session.get(TreatmentReviewState, treatment_id)
        journal_row_count = self.session.scalar(
            select(func.count()).select_from(TreatmentJournalRow).where(
                TreatmentJournalRow.treatment_id == treatment_id,
                TreatmentJournalRow.is_deleted.is_(False),
            )
        ) or 0
        note_count = self.session.scalar(
            select(func.count()).select_from(TreatmentNote).where(
                TreatmentNote.treatment_id == treatment_id,
            )
        ) or 0

        self.proj_repo.upsert(
            treatment_id=treatment_id,
            device_id=treatment.device_id,
            patient_id=treatment.patient_id,
            patient_name=treatment.patient_name,
            therapy_type_id=treatment.therapy_type_id,
            start_time=treatment.start_time,
            end_time=treatment.end_time,
            outcome=treatment.outcome,
            approval_status=review.approval_status if review else "DRAFT",
            total_run_seconds=treatment.total_run_seconds,
            total_phases=treatment.total_phases,
            total_packets=treatment.total_packets,
            journal_row_count=journal_row_count,
            note_count=note_count,
            is_valid=treatment.is_valid,
        )
