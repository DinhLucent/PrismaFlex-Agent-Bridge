"""
Journal command service — owns edit, restore, and policy enforcement.

Spec reference: BACKEND_POSTGRES_PHASE1_HANDOFF Section 11
ADR-6: Clinical API is command-driven, not CRUD-driven.

Enforces:
- No mutation of snapshot_time
- Row must exist for edit
- Only safe fields are editable
- Role/policy rules
- Audit log creation
"""
import logging
from uuid import UUID

from sqlalchemy.orm import Session

from ..repositories.journal_repository import JournalRepository, NURSE_EDITABLE_FIELDS
from ..repositories.audit_repository import AuditRepository
from ..models.snapshot_originals import SnapshotOriginal
from ..models.treatment_review_state import TreatmentReviewState

logger = logging.getLogger("PrismaFlex.JournalCommand")


class JournalCommandService:
    """
    Command service for journal row mutations.

    All mutations go through this service. The router/endpoint layer
    only does HTTP validation, role extraction, and command dispatch.
    """

    def __init__(self, session: Session):
        self.session = session
        self.journal_repo = JournalRepository(session)
        self.audit_repo = AuditRepository(session)

    def edit_existing_snapshot_values(
        self,
        treatment_id: UUID,
        row_code: str,
        fields: dict,
        operator_name: str,
        operator_role: str = None,
        expected_version: int = None,
    ) -> dict:
        """
        Edit allowed manual fields on an existing stable journal row.

        This is the primary nurse workflow command.
        """
        # Strip any protected fields the caller tries to sneak in
        safe_fields = {k: v for k, v in fields.items() if k in NURSE_EDITABLE_FIELDS}
        if not safe_fields:
            return {"status": "no_changes", "message": "No editable fields provided"}

        # Gate-4: Block edits on APPROVED treatments (must unlock first)
        review_state = self.session.get(TreatmentReviewState, treatment_id)
        if review_state and review_state.approval_status == "APPROVED":
            return {"status": "error", "message": "Treatment is APPROVED and locked. Doctor must unlock before editing."}

        # ── Gate-5: Capture old values BEFORE mutation ──────────────
        # Reading after update_values() returns already-mutated values,
        # making audit old==new. We must snapshot old state first.
        row_before = self.journal_repo.get_row(treatment_id, row_code)
        if row_before is None:
            return {"status": "not_found", "message": f"Row {row_code} not found or deleted"}
        if row_before.is_deleted:
            return {"status": "not_found", "message": f"Row {row_code} is deleted"}

        # Gate-4b: Enforce stable-row policy
        from datetime import datetime, timezone
        now_utc = datetime.now(timezone.utc)
        if not row_before.stable_at or row_before.stable_at > now_utc:
            return {"status": "error", "message": f"Row {row_code} is not yet stable. Only stable rows can be edited manually."}

        old_values = {}
        for k in safe_fields:
            old_values[k] = getattr(row_before, k, None)

        row = self.journal_repo.update_values(
            treatment_id=treatment_id,
            row_code=row_code,
            fields=safe_fields,
            operator=operator_name,
            expected_version=expected_version,
        )
        if row is None:
            return {"status": "not_found", "message": f"Row {row_code} not found or deleted"}

        # Compute actual changes from pre-mutation snapshot
        changes = {}
        for k, new_val in safe_fields.items():
            old_val = old_values.get(k)
            # Only log if the value actually changed
            old_str = str(old_val) if old_val is not None else None
            new_str = str(new_val) if new_val is not None else None
            if old_str != new_str:
                changes[k] = {"old": old_str, "new": new_str}

        # Audit every change
        if changes:
            self.audit_repo.log_multi(
                treatment_id=treatment_id,
                row_code=row_code,
                action="edit_existing_snapshot_values",
                operator_name=operator_name,
                operator_role=operator_role,
                changes=changes,
            )

        logger.info(
            f"Edited {row_code} for treatment {treatment_id}: "
            f"{list(changes.keys())} by {operator_name}"
        )
        return {
            "status": "updated",
            "row_code": row_code,
            "version": row.version,
            "fields_changed": list(changes.keys()),
        }

    def restore_existing_snapshot(
        self,
        treatment_id: UUID,
        row_code: str,
        operator_name: str,
        operator_role: str = None,
    ) -> dict:
        """
        Restore a journal row to its machine-original values.

        Reads from snapshot_originals and overwrites current manual fields.
        """
        from sqlalchemy import select

        # Get the original
        stmt = select(SnapshotOriginal).where(
            SnapshotOriginal.treatment_id == treatment_id,
            SnapshotOriginal.row_code == row_code,
        )
        original = self.session.scalars(stmt).first()
        if not original:
            return {"status": "not_found", "message": f"No original found for {row_code}"}

        # Get current row
        row = self.journal_repo.get_row(treatment_id, row_code)
        if not row:
            return {"status": "not_found", "message": f"Row {row_code} not found"}

        # Gate-4b: Enforce stable-row policy
        from datetime import datetime, timezone
        now_utc = datetime.now(timezone.utc)
        if not row.stable_at or row.stable_at > now_utc:
            return {"status": "error", "message": f"Row {row_code} is not yet stable. It cannot be restored."}

        # Gate-4: Block restores on APPROVED treatments
        review_state = self.session.get(TreatmentReviewState, treatment_id)
        if review_state and review_state.approval_status == "APPROVED":
            return {"status": "error", "message": "Treatment is APPROVED and locked. Doctor must unlock before restoring."}

        # Restore fields from original snapshot JSON
        snapshot_data = original.snapshot_json or {}
        restore_fields = {}
        for field in NURSE_EDITABLE_FIELDS:
            if field in snapshot_data:
                old_val = getattr(row, field)
                new_val = snapshot_data[field]
                if old_val != new_val:
                    setattr(row, field, new_val)
                    restore_fields[field] = {"old": old_val, "new": new_val}

        if restore_fields:
            row.source = "RESTORED"
            row.updated_by = operator_name
            row.version += 1
            self.session.flush()

            self.audit_repo.log_multi(
                treatment_id=treatment_id,
                row_code=row_code,
                action="restore_existing_snapshot",
                operator_name=operator_name,
                operator_role=operator_role,
                changes=restore_fields,
            )

        logger.info(f"Restored {row_code} for treatment {treatment_id} by {operator_name}")
        return {
            "status": "restored",
            "row_code": row_code,
            "fields_restored": list(restore_fields.keys()),
        }
