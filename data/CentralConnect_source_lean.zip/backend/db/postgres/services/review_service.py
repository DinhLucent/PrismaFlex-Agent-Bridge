"""
Review service — approval workflow commands.

Spec reference: BACKEND_POSTGRES_PHASE1_HANDOFF Section 11
Commands: submit, approve, reject, unlock.
"""
import logging
from uuid import UUID

from sqlalchemy.orm import Session

from ..repositories.review_repository import ReviewRepository
from ..repositories.treatment_repository import TreatmentRepository
from ..repositories.audit_repository import AuditRepository

logger = logging.getLogger("PrismaFlex.ReviewService")

# Roles allowed to approve, reject, or unlock treatments
DOCTOR_ADMIN_ROLES = frozenset({"doctor", "admin", "Doctor", "Admin", "DOCTOR", "ADMIN"})


class ReviewService:
    """
    Command service for approval workflow state transitions.

    Policy enforcement:
    - submit: only when DRAFT, not IN_PROGRESS
    - approve: only when PENDING_REVIEW, doctor/admin role
    - reject: only when PENDING_REVIEW, doctor/admin role
    - unlock: only when APPROVED, doctor/admin role
    """

    def __init__(self, session: Session):
        self.session = session
        self.review_repo = ReviewRepository(session)
        self.treatment_repo = TreatmentRepository(session)
        self.audit_repo = AuditRepository(session)

    # Roles NOT allowed to submit (per MVP Permission Matrix)
    NURSE_ADMIN_ROLES = frozenset({"nurse", "admin", "Nurse", "Admin", "NURSE", "ADMIN"})

    def submit_review(
        self, treatment_id: UUID, operator_name: str, operator_role: str = None,
    ) -> dict:
        # MVP Policy: Doctor Submit = Deny. Only Nurse/Admin allowed.
        if operator_role and operator_role in DOCTOR_ADMIN_ROLES and operator_role.lower() != 'admin':
            return {"status": "error", "message": "Doctor is not allowed to submit for review. Only Nurse can submit."}

        treatment = self.treatment_repo.get_by_id(treatment_id)
        if not treatment:
            return {"status": "not_found"}

        if treatment.outcome == "IN_PROGRESS":
            return {"status": "error", "message": "Cannot submit while treatment is recording"}

        state = self.review_repo.ensure_exists(treatment_id)
        if state.approval_status == "PENDING_REVIEW":
            return {"status": "error", "message": "Already submitted for review"}
        if state.approval_status == "APPROVED":
            return {"status": "error", "message": "Already approved"}

        self.review_repo.submit(treatment_id, operator_name)
        self.audit_repo.log(
            treatment_id=treatment_id, row_code="*",
            action="submit_review", operator_name=operator_name,
            operator_role=operator_role,
        )
        logger.info(f"Treatment {treatment_id} submitted for review by {operator_name}")
        return {"status": "submitted", "approval_status": "PENDING_REVIEW"}

    def approve(
        self, treatment_id: UUID, operator_name: str, operator_role: str = None,
    ) -> dict:
        # Gate-4: Role enforcement — only doctors/admins can approve
        if not operator_role or operator_role not in DOCTOR_ADMIN_ROLES:
            return {"status": "error", "message": f"Role '{operator_role}' is not authorized to approve. Requires doctor or admin."}

        state = self.review_repo.ensure_exists(treatment_id)
        if state.approval_status != "PENDING_REVIEW":
            return {"status": "error", "message": f"Cannot approve from state '{state.approval_status}'. Must be PENDING_REVIEW."}

        self.review_repo.approve(treatment_id, operator_name)
        self.audit_repo.log(
            treatment_id=treatment_id, row_code="*",
            action="approve", operator_name=operator_name,
            operator_role=operator_role,
        )
        logger.info(f"Treatment {treatment_id} approved by {operator_name}")
        return {"status": "approved", "approval_status": "APPROVED"}

    def reject(
        self, treatment_id: UUID, operator_name: str,
        reason: str = "", operator_role: str = None,
    ) -> dict:
        # Gate-4: Role enforcement — only doctors/admins can reject
        if not operator_role or operator_role not in DOCTOR_ADMIN_ROLES:
            return {"status": "error", "message": f"Role '{operator_role}' is not authorized to reject. Requires doctor or admin."}

        state = self.review_repo.ensure_exists(treatment_id)
        if state.approval_status != "PENDING_REVIEW":
            return {"status": "error", "message": f"Cannot reject from state '{state.approval_status}'. Must be PENDING_REVIEW."}

        self.review_repo.reject(treatment_id, operator_name, reason)
        self.audit_repo.log(
            treatment_id=treatment_id, row_code="*",
            action="reject", operator_name=operator_name,
            operator_role=operator_role, reason=reason,
        )
        logger.info(f"Treatment {treatment_id} rejected by {operator_name}: {reason}")
        # MVP Policy: Reject → DRAFT
        return {"status": "rejected", "approval_status": "DRAFT"}

    def unlock(
        self, treatment_id: UUID, operator_name: str, operator_role: str = None,
    ) -> dict:
        # Gate-4: Role enforcement — only doctors/admins can unlock
        if not operator_role or operator_role not in DOCTOR_ADMIN_ROLES:
            return {"status": "error", "message": f"Role '{operator_role}' is not authorized to unlock. Requires doctor or admin."}

        state = self.review_repo.ensure_exists(treatment_id)
        if state.approval_status != "APPROVED":
            return {"status": "error", "message": "Only approved treatments can be unlocked"}

        self.review_repo.unlock(treatment_id, operator_name)
        self.audit_repo.log(
            treatment_id=treatment_id, row_code="*",
            action="unlock", operator_name=operator_name,
            operator_role=operator_role,
        )
        logger.info(f"Treatment {treatment_id} unlocked by {operator_name}")
        return {"status": "unlocked", "approval_status": "DRAFT"}
