"""
Journal query service — read-only queries for treatment detail and review.

Spec reference: BACKEND_POSTGRES_PHASE1_HANDOFF Section 11
"""
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..repositories.journal_repository import JournalRepository
from ..repositories.treatment_repository import TreatmentRepository
from ..repositories.notes_repository import NotesRepository
from ..models.snapshot_originals import SnapshotOriginal
from ..models.treatment_review_state import TreatmentReviewState


class JournalQueryService:
    """
    Read-only query service for treatment detail, timeline, and review compare.
    """

    def __init__(self, session: Session):
        self.session = session
        self.journal_repo = JournalRepository(session)
        self.treatment_repo = TreatmentRepository(session)
        self.notes_repo = NotesRepository(session)

    def get_treatment_detail(self, treatment_id: UUID) -> dict | None:
        """
        Full treatment detail: master + journal rows + review state + notes.

        Does NOT return raw packets (per architecture spec Section 12.2).
        """
        treatment = self.treatment_repo.get_by_id(treatment_id)
        if not treatment:
            return None

        journal_rows = self.journal_repo.get_by_treatment(treatment_id)
        review = self.session.get(TreatmentReviewState, treatment_id)
        notes = self.notes_repo.get_by_treatment(treatment_id)

        return {
            "treatment": treatment,
            "journal_rows": journal_rows,
            "review_state": review,
            "notes": notes,
            "journal_row_count": len(journal_rows),
            "note_count": len(notes),
        }

    def get_review_compare(self, treatment_id: UUID) -> dict | None:
        """
        Fetch current journal rows + frozen originals for review comparison.
        Both ordered by snapshot_time.
        """
        journal_rows = self.journal_repo.get_by_treatment(treatment_id)

        stmt = (
            select(SnapshotOriginal)
            .where(SnapshotOriginal.treatment_id == treatment_id)
            .order_by(SnapshotOriginal.snapshot_time.asc())
        )
        originals = list(self.session.scalars(stmt).all())

        return {
            "current_rows": journal_rows,
            "originals": originals,
        }
