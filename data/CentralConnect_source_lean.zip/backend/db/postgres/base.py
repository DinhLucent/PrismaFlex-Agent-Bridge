"""
SQLAlchemy declarative base for the PrismaFlex treatment data platform.

All models inherit from Base. This module is the single import point
for the metadata object used by Alembic migrations.
"""
from sqlalchemy.orm import DeclarativeBase, MappedAsDataclass


class Base(DeclarativeBase):
    """
    Declarative base for all PrismaFlex PostgreSQL models.

    Convention notes (ADR-2, ADR-5):
    - Wide-row relational model for journals
    - Strong FK/composite indexing from day one
    - No EAV or per-cell schema
    """
    pass
