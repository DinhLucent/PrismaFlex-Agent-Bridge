"""
Journal repository — data access for treatment_journal_rows.

ADR-2: Wide-row model. ADR rule: snapshot_time is IMMUTABLE.
"""
from uuid import UUID
from typing import Optional
from sqlalchemy.orm import Session
from sqlalchemy import select, update

from ..models.treatment_journal_rows import TreatmentJournalRow


# Fields that nurses can edit on existing stable rows (SPEC §11.1)
NURSE_EDITABLE_FIELDS = frozenset({
    "heparin_bolus", "heparin_rate", "duosol_count", "prismasol_count",
    "filter_type", "kali", "notes", "solution_type",
    "calcium_comp", "citrate_dose",  # TASK-127: Citrate mode fields per SPEC §11.1
})

# Fields that must NOT be edited manually (machine-reported telemetry)
PROTECTED_FIELDS = frozenset({
    "qb", "qd", "qs", "qpbp", "pa", "pv", "pbe", "tmp",
    "uf_total", "uf_hourly", "snapshot_time",
})


class JournalRepository:
    """Data access for treatment_journal_rows."""

    def __init__(self, session: Session):
        self.session = session

    def get_by_treatment(
        self, treatment_id: UUID, include_deleted: bool = False
    ) -> list[TreatmentJournalRow]:
        """Get journal rows ordered by snapshot_time (clinical chronology)."""
        stmt = (
            select(TreatmentJournalRow)
            .where(TreatmentJournalRow.treatment_id == treatment_id)
        )
        if not include_deleted:
            stmt = stmt.where(TreatmentJournalRow.is_deleted == False)
        stmt = stmt.order_by(TreatmentJournalRow.snapshot_time.asc())
        return list(self.session.scalars(stmt).all())

    def get_row(
        self, treatment_id: UUID, row_code: str
    ) -> Optional[TreatmentJournalRow]:
        """Get a single journal row by business key."""
        stmt = (
            select(TreatmentJournalRow)
            .where(
                TreatmentJournalRow.treatment_id == treatment_id,
                TreatmentJournalRow.row_code == row_code,
            )
        )
        return self.session.scalars(stmt).first()

    def update_values(
        self,
        treatment_id: UUID,
        row_code: str,
        fields: dict,
        operator: str,
        expected_version: int | None = None,
    ) -> Optional[TreatmentJournalRow]:
        """
        Update editable fields on an existing journal row.

        Enforces:
        - Row must exist
        - Only NURSE_EDITABLE_FIELDS allowed
        - snapshot_time is never mutated
        - Optimistic concurrency via version check
        """
        row = self.get_row(treatment_id, row_code)
        if not row:
            return None
        if row.is_deleted:
            return None

        # Optimistic concurrency
        if expected_version is not None and row.version != expected_version:
            raise ValueError(
                f"Version conflict: expected {expected_version}, got {row.version}"
            )

        # Apply only allowed fields
        changed = {}
        for k, v in fields.items():
            if k in NURSE_EDITABLE_FIELDS:
                old_val = getattr(row, k)
                setattr(row, k, v)
                changed[k] = {"old": old_val, "new": v}

        if changed:
            row.updated_by = operator
            row.version += 1
            self.session.flush()

        return row

    def create(self, row: TreatmentJournalRow) -> TreatmentJournalRow:
        self.session.add(row)
        self.session.flush()
        return row
