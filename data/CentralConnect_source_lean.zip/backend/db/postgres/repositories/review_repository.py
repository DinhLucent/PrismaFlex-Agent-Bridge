"""
Review repository — approval workflow state management.
"""
from uuid import UUID
from typing import Optional
from datetime import datetime, timezone, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..models.treatment_review_state import TreatmentReviewState

_LOCAL_TZ = timezone(timedelta(hours=7))


class ReviewRepository:
    """Data access for treatment_review_state."""

    def __init__(self, session: Session):
        self.session = session

    def get_by_treatment(self, treatment_id: UUID) -> Optional[TreatmentReviewState]:
        return self.session.get(TreatmentReviewState, treatment_id)

    def ensure_exists(self, treatment_id: UUID) -> TreatmentReviewState:
        """Get or create a review state record (defaults to DRAFT)."""
        state = self.get_by_treatment(treatment_id)
        if not state:
            state = TreatmentReviewState(treatment_id=treatment_id)
            self.session.add(state)
            self.session.flush()
        return state

    def submit(self, treatment_id: UUID, operator: str) -> TreatmentReviewState:
        state = self.ensure_exists(treatment_id)
        state.approval_status = "PENDING_REVIEW"
        state.submitted_at = datetime.now(_LOCAL_TZ)
        state.submitted_by = operator
        self.session.flush()
        return state

    def approve(self, treatment_id: UUID, operator: str) -> TreatmentReviewState:
        state = self.ensure_exists(treatment_id)
        state.approval_status = "APPROVED"
        state.approved_at = datetime.now(_LOCAL_TZ)
        state.approved_by = operator
        self.session.flush()
        return state

    def reject(
        self, treatment_id: UUID, operator: str, reason: str = ""
    ) -> TreatmentReviewState:
        state = self.ensure_exists(treatment_id)
        # MVP Policy: Reject → DRAFT (nurse edits and re-submits)
        state.approval_status = "DRAFT"
        state.rejected_at = datetime.now(_LOCAL_TZ)
        state.rejected_by = operator
        state.reject_reason = reason or None
        self.session.flush()
        return state

    def unlock(self, treatment_id: UUID, operator: str) -> TreatmentReviewState:
        state = self.ensure_exists(treatment_id)
        state.approval_status = "DRAFT"
        state.unlocked_at = datetime.now(_LOCAL_TZ)
        state.unlocked_by = operator
        self.session.flush()
        return state
