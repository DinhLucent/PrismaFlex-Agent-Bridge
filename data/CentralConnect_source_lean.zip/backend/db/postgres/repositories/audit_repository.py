"""
Audit repository — append-only snapshot mutation audit trail.
"""
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..models.snapshot_audit_log import SnapshotAuditLog


class AuditRepository:
    """Data access for snapshot_audit_log (append-only)."""

    def __init__(self, session: Session):
        self.session = session

    def log(
        self,
        treatment_id: UUID,
        row_code: str,
        action: str,
        operator_name: str,
        operator_role: str = None,
        field_name: str = None,
        old_value=None,
        new_value=None,
        reason: str = None,
    ) -> SnapshotAuditLog:
        entry = SnapshotAuditLog(
            treatment_id=treatment_id,
            row_code=row_code,
            action=action,
            field_name=field_name,
            old_value=old_value,
            new_value=new_value,
            operator_name=operator_name,
            operator_role=operator_role,
            reason=reason,
        )
        self.session.add(entry)
        self.session.flush()
        return entry

    def log_multi(
        self,
        treatment_id: UUID,
        row_code: str,
        action: str,
        operator_name: str,
        changes: dict[str, dict],
        operator_role: str = None,
    ) -> list[SnapshotAuditLog]:
        """Log multiple field changes in one call."""
        entries = []
        for field, vals in changes.items():
            entries.append(self.log(
                treatment_id=treatment_id,
                row_code=row_code,
                action=action,
                operator_name=operator_name,
                operator_role=operator_role,
                field_name=field,
                old_value=vals.get("old"),
                new_value=vals.get("new"),
            ))
        return entries

    def get_by_treatment(self, treatment_id: UUID, limit: int = 100) -> list[SnapshotAuditLog]:
        stmt = (
            select(SnapshotAuditLog)
            .where(SnapshotAuditLog.treatment_id == treatment_id)
            .order_by(SnapshotAuditLog.created_at.desc())
            .limit(limit)
        )
        return list(self.session.scalars(stmt).all())
