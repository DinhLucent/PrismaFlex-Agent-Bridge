"""
Raw manifest repository — metadata for raw telemetry storage.

Gate-2 fix: Standardized to use chunk_index (not chunk_seq),
and aligned all column references with the current SQLAlchemy model.
"""
from uuid import UUID
from typing import Optional
from sqlalchemy.orm import Session
from sqlalchemy import select, update

from ..models.raw_packet_manifest import RawPacketManifest


class RawManifestRepository:
    """Data access for raw_packet_manifest (metadata only per ADR-3)."""

    def __init__(self, session: Session):
        self.session = session

    def get_by_treatment(self, treatment_id: UUID) -> list[RawPacketManifest]:
        """Get all chunks for a treatment, ordered by chunk_index."""
        stmt = (
            select(RawPacketManifest)
            .where(RawPacketManifest.treatment_id == treatment_id)
            .order_by(RawPacketManifest.chunk_index.asc())
        )
        return list(self.session.scalars(stmt).all())

    def get_by_status(self, treatment_id: UUID, status: str) -> list[RawPacketManifest]:
        """Get chunks filtered by status (ACTIVE, CLOSED, ARCHIVED)."""
        stmt = (
            select(RawPacketManifest)
            .where(
                RawPacketManifest.treatment_id == treatment_id,
                RawPacketManifest.status == status,
            )
            .order_by(RawPacketManifest.chunk_index.asc())
        )
        return list(self.session.scalars(stmt).all())

    def get_closed_chunks(self) -> list[RawPacketManifest]:
        """Get all CLOSED chunks across all treatments (for Parquet worker)."""
        stmt = (
            select(RawPacketManifest)
            .where(RawPacketManifest.status == "CLOSED")
            .order_by(RawPacketManifest.created_at.asc())
        )
        return list(self.session.scalars(stmt).all())

    def add_chunk(self, manifest: RawPacketManifest) -> RawPacketManifest:
        self.session.add(manifest)
        self.session.flush()
        return manifest

    def update_status(self, manifest_id: int, new_status: str, **kwargs) -> None:
        """Update chunk status and optional tracking fields."""
        values = {"status": new_status, **kwargs}
        self.session.execute(
            update(RawPacketManifest)
            .where(RawPacketManifest.id == manifest_id)
            .values(**values)
        )
        self.session.flush()
