"""
Projection repository — fast list/history projection table.
"""
from uuid import UUID
from typing import Optional
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..models.treatment_list_projection import TreatmentListProjection


class ProjectionRepository:
    """Data access for treatment_list_projection."""

    def __init__(self, session: Session):
        self.session = session

    def get(self, treatment_id: UUID) -> Optional[TreatmentListProjection]:
        return self.session.get(TreatmentListProjection, treatment_id)

    def upsert(self, treatment_id: UUID, **fields) -> TreatmentListProjection:
        proj = self.get(treatment_id)
        if not proj:
            proj = TreatmentListProjection(id=treatment_id, **fields)
            self.session.add(proj)
        else:
            for k, v in fields.items():
                if hasattr(proj, k):
                    setattr(proj, k, v)
        self.session.flush()
        return proj

    def list_treatments(
        self,
        limit: int = 20,
        offset: int = 0,
        outcome: str = None,
        approval_status: str = None,
        patient_id: str = None,
    ) -> list[TreatmentListProjection]:
        stmt = select(TreatmentListProjection)
        if outcome:
            stmt = stmt.where(TreatmentListProjection.outcome == outcome)
        if approval_status:
            stmt = stmt.where(TreatmentListProjection.approval_status == approval_status)
        if patient_id:
            stmt = stmt.where(TreatmentListProjection.patient_id == patient_id)
        stmt = stmt.order_by(TreatmentListProjection.start_time.desc())
        stmt = stmt.offset(offset).limit(limit)
        return list(self.session.scalars(stmt).all())
