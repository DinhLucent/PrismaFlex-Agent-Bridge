"""
Notes repository — append-only clinical notes.
"""
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..models.treatment_notes import TreatmentNote


class NotesRepository:
    """Data access for treatment_notes (append-only)."""

    def __init__(self, session: Session):
        self.session = session

    def get_by_treatment(self, treatment_id: UUID) -> list[TreatmentNote]:
        stmt = (
            select(TreatmentNote)
            .where(TreatmentNote.treatment_id == treatment_id)
            .order_by(TreatmentNote.created_at.asc())
        )
        return list(self.session.scalars(stmt).all())

    def add(
        self, treatment_id: UUID, content: str,
        author_name: str, author_role: str = None,
    ) -> TreatmentNote:
        note = TreatmentNote(
            treatment_id=treatment_id,
            content=content,
            author_name=author_name,
            author_role=author_role,
        )
        self.session.add(note)
        self.session.flush()
        return note
