"""
Treatment repository — CRUD for treatment master records.
"""
from uuid import UUID
from typing import Optional
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..models.treatments import Treatment


class TreatmentRepository:
    """Data access for the treatments table."""

    def __init__(self, session: Session):
        self.session = session

    def get_by_id(self, treatment_id: UUID) -> Optional[Treatment]:
        return self.session.get(Treatment, treatment_id)

    def get_by_device(self, device_id: str, limit: int = 20) -> list[Treatment]:
        stmt = (
            select(Treatment)
            .where(Treatment.device_id == device_id)
            .order_by(Treatment.start_time.desc())
            .limit(limit)
        )
        return list(self.session.scalars(stmt).all())

    def create(self, treatment: Treatment) -> Treatment:
        self.session.add(treatment)
        self.session.flush()
        return treatment

    def update_outcome(self, treatment_id: UUID, outcome: str) -> None:
        t = self.get_by_id(treatment_id)
        if t:
            t.outcome = outcome
            t.version += 1
            self.session.flush()

    def update_patient_context(
        self, treatment_id: UUID, **fields
    ) -> Optional[Treatment]:
        t = self.get_by_id(treatment_id)
        if not t:
            return None
        allowed = {
            "patient_name", "patient_id", "clinical_notes",
            "start_time_override", "end_time_override",
        }
        for k, v in fields.items():
            if k in allowed:
                setattr(t, k, v)
        t.version += 1
        self.session.flush()
        return t
