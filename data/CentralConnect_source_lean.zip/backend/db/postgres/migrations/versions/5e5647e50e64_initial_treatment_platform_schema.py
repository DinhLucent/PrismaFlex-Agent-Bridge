"""initial_treatment_platform_schema

Revision ID: 5e5647e50e64
Revises: 
Create Date: 2026-04-03 23:16:55.648551

Creates the PostgreSQL foundation schema for the PrismaFlex treatment
data platform per TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC Section 9.

Tables created (11):
  - treatments
  - treatment_phases
  - treatment_status_events
  - treatment_journal_rows
  - treatment_config
  - snapshot_originals
  - treatment_review_state
  - treatment_notes
  - snapshot_audit_log
  - treatment_list_projection
  - raw_packet_manifest
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = '5e5647e50e64'
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Create all treatment platform tables."""

    # ── 1. treatments (master record) ──
    op.create_table(
        'treatments',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('device_id', sa.String(), nullable=False),
        sa.Column('patient_id', sa.String(), nullable=True),
        sa.Column('patient_name', sa.String(), nullable=True),
        sa.Column('therapy_type_id', sa.Integer(), nullable=True),
        sa.Column('anticoag_type_id', sa.Integer(), nullable=True),
        sa.Column('start_time', sa.DateTime(timezone=True), nullable=False),
        sa.Column('first_run_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('end_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('last_seen_time', sa.DateTime(timezone=True), nullable=False),
        sa.Column('outcome', sa.String(), nullable=False, server_default='IN_PROGRESS'),
        sa.Column('fsm_state', sa.String(), nullable=False, server_default='IDLE'),
        sa.Column('close_reason', sa.Text(), nullable=True),
        sa.Column('total_run_seconds', sa.Integer(), nullable=True),
        sa.Column('total_paused_seconds', sa.Integer(), nullable=True),
        sa.Column('total_phases', sa.Integer(), nullable=True),
        sa.Column('total_packets', sa.BigInteger(), nullable=True),
        sa.Column('is_valid', sa.Boolean(), nullable=True),
        sa.Column('had_interruption', sa.Boolean(), nullable=True),
        sa.Column('had_program_restart', sa.Boolean(), nullable=True),
        sa.Column('sw_version', sa.String(), nullable=True),
        sa.Column('start_time_override', sa.DateTime(timezone=True), nullable=True),
        sa.Column('end_time_override', sa.DateTime(timezone=True), nullable=True),
        sa.Column('clinical_notes', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('version', sa.Integer(), nullable=False, server_default='1'),
        sa.CheckConstraint(
            "outcome IN ('IN_PROGRESS','COMPLETED','INTERRUPTED','ARCHIVED','INVALID')",
            name='ck_treatments_outcome',
        ),
    )
    op.create_index('ix_treatments_device_start', 'treatments', ['device_id', sa.text('start_time DESC')])
    op.create_index('ix_treatments_patient_start', 'treatments', ['patient_id', sa.text('start_time DESC')])
    op.create_index('ix_treatments_outcome_start', 'treatments', ['outcome', sa.text('start_time DESC')])

    # ── 2. treatment_phases ──
    op.create_table(
        'treatment_phases',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('treatment_id', postgresql.UUID(as_uuid=True),
                  sa.ForeignKey('treatments.id', ondelete='CASCADE'), nullable=False),
        sa.Column('phase_number', sa.Integer(), nullable=False),
        sa.Column('phase_type', sa.String(), nullable=False),
        sa.Column('start_time', sa.DateTime(timezone=True), nullable=False),
        sa.Column('end_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_phases_treatment_number', 'treatment_phases', ['treatment_id', 'phase_number'])

    # ── 3. treatment_status_events ──
    op.create_table(
        'treatment_status_events',
        sa.Column('id', sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column('treatment_id', postgresql.UUID(as_uuid=True),
                  sa.ForeignKey('treatments.id', ondelete='CASCADE'), nullable=False),
        sa.Column('device_id', sa.String(), nullable=False),
        sa.Column('event_time', sa.DateTime(timezone=True), nullable=False),
        sa.Column('therapy_status_id', sa.Integer(), nullable=True),
        sa.Column('fsm_state', sa.String(), nullable=False),
        sa.Column('patient_id', sa.String(), nullable=True),
        sa.Column('event_code', sa.String(), nullable=False),
        sa.Column('note', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_status_events_treatment_time', 'treatment_status_events',
                    ['treatment_id', sa.text('event_time ASC')])
    op.create_index('ix_status_events_device_time', 'treatment_status_events',
                    ['device_id', sa.text('event_time DESC')])
    op.create_index('ix_status_events_code_time', 'treatment_status_events',
                    ['event_code', sa.text('event_time DESC')])

    # ── 4. treatment_journal_rows (most critical table) ──
    op.create_table(
        'treatment_journal_rows',
        sa.Column('id', sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column('treatment_id', postgresql.UUID(as_uuid=True),
                  sa.ForeignKey('treatments.id', ondelete='CASCADE'), nullable=False),
        sa.Column('device_id', sa.String(), nullable=False),
        sa.Column('row_code', sa.String(), nullable=False),
        sa.Column('row_kind', sa.String(), nullable=False),
        sa.Column('snapshot_time', sa.DateTime(timezone=True), nullable=False),
        sa.Column('stable_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('source', sa.String(), nullable=False, server_default='AUTO'),
        sa.Column('is_deleted', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('deleted_by', sa.String(), nullable=True),
        # Telemetry columns
        sa.Column('qb', sa.Numeric(10, 2), nullable=True),
        sa.Column('qs', sa.Numeric(10, 2), nullable=True),
        sa.Column('qd', sa.Numeric(10, 2), nullable=True),
        sa.Column('qpbp', sa.Numeric(10, 2), nullable=True),
        sa.Column('pa', sa.Numeric(10, 2), nullable=True),
        sa.Column('pv', sa.Numeric(10, 2), nullable=True),
        sa.Column('pbe', sa.Numeric(10, 2), nullable=True),
        sa.Column('tmp', sa.Numeric(10, 2), nullable=True),
        sa.Column('uf_total', sa.Numeric(12, 2), nullable=True),
        sa.Column('uf_hourly', sa.Numeric(12, 2), nullable=True),
        sa.Column('effluent_flow', sa.Numeric(12, 2), nullable=True),
        sa.Column('run_time_sec', sa.Integer(), nullable=True),
        sa.Column('blood_vol', sa.Numeric(12, 2), nullable=True),
        sa.Column('heparin_rate', sa.Numeric(12, 2), nullable=True),
        sa.Column('pt_weight', sa.Numeric(12, 2), nullable=True),
        sa.Column('uf_rate_target', sa.Numeric(12, 2), nullable=True),
        sa.Column('citrate_dose', sa.Numeric(12, 2), nullable=True),
        sa.Column('citrate_conc', sa.Numeric(12, 2), nullable=True),
        sa.Column('citrate_load', sa.Numeric(12, 2), nullable=True),
        sa.Column('calcium_comp', sa.Numeric(12, 2), nullable=True),
        sa.Column('calcium_rate', sa.Numeric(12, 2), nullable=True),
        sa.Column('anticoag_type_id', sa.Integer(), nullable=True),
        # Manual-editable columns
        sa.Column('heparin_bolus', sa.Text(), nullable=True),
        sa.Column('solution_type', sa.Text(), nullable=True),
        sa.Column('duosol_count', sa.Numeric(12, 2), nullable=True),
        sa.Column('prismasol_count', sa.Numeric(12, 2), nullable=True),
        sa.Column('filter_type', sa.Text(), nullable=True),
        sa.Column('kali', sa.Numeric(12, 2), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
        # Audit
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('created_by', sa.String(), nullable=True),
        sa.Column('updated_by', sa.String(), nullable=True),
        sa.Column('version', sa.Integer(), nullable=False, server_default='1'),
        sa.UniqueConstraint('treatment_id', 'row_code', name='uq_journal_rows_treatment_row_code'),
        sa.CheckConstraint("row_kind IN ('HOUR','ORDER_CHANGE')", name='ck_journal_rows_row_kind'),
        sa.CheckConstraint("source IN ('AUTO','MANUAL','MERGED','RESTORED')", name='ck_journal_rows_source'),
    )
    op.create_index('ix_journal_rows_treatment_snapshot', 'treatment_journal_rows',
                    ['treatment_id', sa.text('snapshot_time ASC')])
    op.create_index('ix_journal_rows_treatment_kind_snapshot', 'treatment_journal_rows',
                    ['treatment_id', 'row_kind', sa.text('snapshot_time ASC')])
    # Partial index for non-deleted rows
    op.execute("""
        CREATE INDEX ix_journal_rows_treatment_snapshot_active
        ON treatment_journal_rows (treatment_id, snapshot_time ASC)
        WHERE is_deleted = FALSE
    """)

    # ── 5. treatment_config ──
    op.create_table(
        'treatment_config',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('treatment_id', postgresql.UUID(as_uuid=True),
                  sa.ForeignKey('treatments.id', ondelete='CASCADE'), nullable=False, unique=True),
        sa.Column('therapy_type_id', sa.Integer(), nullable=True),
        sa.Column('anticoag_type_id', sa.Integer(), nullable=True),
        sa.Column('config_json', postgresql.JSONB(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_treatment_config_treatment', 'treatment_config', ['treatment_id'])

    # ── 6. snapshot_originals ──
    op.create_table(
        'snapshot_originals',
        sa.Column('id', sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column('treatment_id', postgresql.UUID(as_uuid=True),
                  sa.ForeignKey('treatments.id', ondelete='CASCADE'), nullable=False),
        sa.Column('row_code', sa.String(), nullable=False),
        sa.Column('snapshot_time', sa.DateTime(timezone=True), nullable=False),
        sa.Column('snapshot_json', postgresql.JSONB(), nullable=False),
        sa.Column('frozen_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('frozen_by', sa.String(), nullable=True),
        sa.UniqueConstraint('treatment_id', 'row_code', name='uq_snapshot_originals_treatment_row'),
    )
    op.create_index('ix_snapshot_originals_treatment_time', 'snapshot_originals',
                    ['treatment_id', sa.text('snapshot_time ASC')])

    # ── 7. treatment_review_state ──
    op.create_table(
        'treatment_review_state',
        sa.Column('treatment_id', postgresql.UUID(as_uuid=True),
                  sa.ForeignKey('treatments.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('approval_status', sa.String(), nullable=False, server_default='DRAFT'),
        sa.Column('submitted_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('submitted_by', sa.String(), nullable=True),
        sa.Column('approved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('approved_by', sa.String(), nullable=True),
        sa.Column('rejected_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('rejected_by', sa.String(), nullable=True),
        sa.Column('reject_reason', sa.Text(), nullable=True),
        sa.Column('unlocked_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('unlocked_by', sa.String(), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint(
            "approval_status IN ('DRAFT','PENDING_REVIEW','APPROVED','REJECTED')",
            name='ck_review_state_status',
        ),
    )
    op.create_index('ix_review_state_status_updated', 'treatment_review_state',
                    ['approval_status', sa.text('updated_at DESC')])

    # ── 8. treatment_notes ──
    op.create_table(
        'treatment_notes',
        sa.Column('id', sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column('treatment_id', postgresql.UUID(as_uuid=True),
                  sa.ForeignKey('treatments.id', ondelete='CASCADE'), nullable=False),
        sa.Column('author_name', sa.String(), nullable=False),
        sa.Column('author_role', sa.String(), nullable=True),
        sa.Column('content', sa.Text(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_notes_treatment_created', 'treatment_notes',
                    ['treatment_id', sa.text('created_at ASC')])

    # ── 9. snapshot_audit_log ──
    op.create_table(
        'snapshot_audit_log',
        sa.Column('id', sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column('treatment_id', postgresql.UUID(as_uuid=True),
                  sa.ForeignKey('treatments.id', ondelete='CASCADE'), nullable=False),
        sa.Column('row_code', sa.String(), nullable=False),
        sa.Column('action', sa.String(), nullable=False),
        sa.Column('field_name', sa.String(), nullable=True),
        sa.Column('old_value', postgresql.JSONB(), nullable=True),
        sa.Column('new_value', postgresql.JSONB(), nullable=True),
        sa.Column('operator_name', sa.String(), nullable=False),
        sa.Column('operator_role', sa.String(), nullable=True),
        sa.Column('reason', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_audit_log_treatment_created', 'snapshot_audit_log',
                    ['treatment_id', sa.text('created_at DESC')])
    op.create_index('ix_audit_log_treatment_row_created', 'snapshot_audit_log',
                    ['treatment_id', 'row_code', sa.text('created_at DESC')])
    op.create_index('ix_audit_log_operator_created', 'snapshot_audit_log',
                    ['operator_name', sa.text('created_at DESC')])

    # ── 10. treatment_list_projection ──
    op.create_table(
        'treatment_list_projection',
        sa.Column('treatment_id', postgresql.UUID(as_uuid=True),
                  sa.ForeignKey('treatments.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('device_id', sa.String(), nullable=False),
        sa.Column('patient_id', sa.String(), nullable=True),
        sa.Column('patient_name', sa.String(), nullable=True),
        sa.Column('therapy_type_id', sa.Integer(), nullable=True),
        sa.Column('start_time', sa.DateTime(timezone=True), nullable=False),
        sa.Column('end_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('outcome', sa.String(), nullable=False, server_default='IN_PROGRESS'),
        sa.Column('approval_status', sa.String(), nullable=False, server_default='DRAFT'),
        sa.Column('total_run_seconds', sa.Integer(), nullable=True),
        sa.Column('total_phases', sa.Integer(), nullable=True),
        sa.Column('total_packets', sa.BigInteger(), nullable=True),
        sa.Column('journal_row_count', sa.Integer(), nullable=True),
        sa.Column('note_count', sa.Integer(), nullable=True),
        sa.Column('is_valid', sa.Boolean(), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_projection_outcome_start', 'treatment_list_projection',
                    ['outcome', sa.text('start_time DESC')])
    op.create_index('ix_projection_approval_start', 'treatment_list_projection',
                    ['approval_status', sa.text('start_time DESC')])
    op.create_index('ix_projection_patient_start', 'treatment_list_projection',
                    ['patient_id', sa.text('start_time DESC')])

    # ── 11. raw_packet_manifest ──
    op.create_table(
        'raw_packet_manifest',
        sa.Column('id', sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column('treatment_id', postgresql.UUID(as_uuid=True),
                  sa.ForeignKey('treatments.id', ondelete='CASCADE'), nullable=False),
        sa.Column('storage_kind', sa.String(), nullable=False),
        sa.Column('chunk_seq', sa.Integer(), nullable=False),
        sa.Column('packet_time_min', sa.DateTime(timezone=True), nullable=True),
        sa.Column('packet_time_max', sa.DateTime(timezone=True), nullable=True),
        sa.Column('packet_count', sa.BigInteger(), nullable=False),
        sa.Column('byte_count', sa.BigInteger(), nullable=True),
        sa.Column('content_ref', sa.Text(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index('ix_raw_manifest_treatment_seq', 'raw_packet_manifest',
                    ['treatment_id', 'chunk_seq'])
    op.create_index('ix_raw_manifest_treatment_time', 'raw_packet_manifest',
                    ['treatment_id', 'packet_time_min', 'packet_time_max'])


def downgrade() -> None:
    """Drop all treatment platform tables in reverse dependency order."""
    op.drop_table('raw_packet_manifest')
    op.drop_table('treatment_list_projection')
    op.drop_table('snapshot_audit_log')
    op.drop_table('treatment_notes')
    op.drop_table('treatment_review_state')
    op.drop_table('snapshot_originals')
    op.drop_table('treatment_config')
    op.drop_table('treatment_journal_rows')
    op.drop_table('treatment_status_events')
    op.drop_table('treatment_phases')
    op.drop_table('treatments')
