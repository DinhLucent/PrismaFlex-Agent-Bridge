"""add hour_slot and source to journal rows

Revision ID: abc4bc110e7c
Revises: 432bfeef892d
Create Date: 2026-04-05 22:04:57.528817

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'abc4bc110e7c'
down_revision: Union[str, Sequence[str], None] = '432bfeef892d'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # 1. Add columns
    op.add_column('treatment_journal_rows', sa.Column('hour_slot', sa.Integer(), nullable=True))
    op.add_column('treatment_journal_rows', sa.Column('source_new', sa.String(length=20), server_default='LIVE', nullable=False))

    # 2. Backfill hour_slot from row_code (Hxx)
    op.execute("""
        UPDATE treatment_journal_rows
        SET hour_slot = CAST(SUBSTRING(row_code FROM 2) AS INTEGER)
        WHERE row_code ~ '^H\d{2,}$';
    """)

    # 3. Migrate source values
    op.execute("""
        UPDATE treatment_journal_rows
        SET source_new = CASE 
            WHEN source = 'AUTO' THEN 'LIVE'
            WHEN source = 'MERGED' THEN 'LIVE'
            WHEN source = 'RESTORED' THEN 'RECOVERY'
            ELSE 'MANUAL'
        END;
    """)

    # 4. Swap source columns
    op.drop_column('treatment_journal_rows', 'source')
    op.alter_column('treatment_journal_rows', 'source_new', new_column_name='source')

    # 5. Add Constraints & Indexes
    # Drop old uniqueness constraint if it exists (might be named differently in different environments)
    # The model had: UniqueConstraint("treatment_id", "row_code", name="uq_journal_rows_treatment_row_code")
    # But Spec §5.2 says we keep it during transition.
    
    # New Deterministic hourly uniqueness (partial index)
    op.create_index(
        'uix_journal_hour_slot',
        'treatment_journal_rows',
        ['treatment_id', 'hour_slot'],
        unique=True,
        postgresql_where=sa.text("row_kind = 'HOUR' AND hour_slot IS NOT NULL")
    )

    # OC uniqueness index
    op.create_index(
        'uix_journal_oc_code',
        'treatment_journal_rows',
        ['treatment_id', 'row_code'],
        unique=True,
        postgresql_where=sa.text("row_kind = 'ORDER_CHANGE'")
    )

    # 6. Add Check Constraint for Source
    op.create_check_constraint(
        'ck_journal_rows_source',
        'treatment_journal_rows',
        "source IN ('LIVE', 'BACKFILL', 'MANUAL', 'RECOVERY')"
    )


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_constraint('ck_journal_rows_source', 'treatment_journal_rows')
    op.drop_index('uix_journal_oc_code', 'treatment_journal_rows')
    op.drop_index('uix_journal_hour_slot', 'treatment_journal_rows')
    
    op.add_column('treatment_journal_rows', sa.Column('source_old', sa.String(), server_default='AUTO', nullable=False))
    op.execute("""
        UPDATE treatment_journal_rows
        SET source_old = CASE 
            WHEN source = 'LIVE' THEN 'AUTO'
            WHEN source = 'RECOVERY' THEN 'RESTORED'
            ELSE 'MANUAL'
        END;
    """)
    op.drop_column('treatment_journal_rows', 'source')
    op.alter_column('treatment_journal_rows', 'source_old', new_column_name='source')
    op.drop_column('treatment_journal_rows', 'hour_slot')
