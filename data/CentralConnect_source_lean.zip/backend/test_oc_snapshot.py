import os
import sys
import asyncio
from datetime import datetime, timezone, timedelta

# Add current directory to path so we can import services
sys.path.append(os.path.dirname(__file__))

from services.treatment.treatment_database import TreatmentDatabase
from services.event_service import EventService
from services.treatment.treatment_snapshot_service import TreatmentSnapshotService

async def test_oc_snapshot():
    print("🚀 Starting OC Snapshot Test Case...")
    
    # 1. Setup (Using a temporary test database)
    test_db_path = "test_oc_snapshots.db"
    if os.path.exists(test_db_path):
        os.remove(test_db_path)
    
    db = TreatmentDatabase(test_db_path)
    
    # Mock methods that EventService expects (from TrendDatabase)
    db.get_last_patient_id = lambda device_id: None
    db.insert_events = lambda device_id, timestamp, changes: None
    db.update_patient_session = lambda device_id, patient_id: None
    db.purge_device_history = lambda device_id: None
    
    event_svc = EventService(db)
    snapshot_svc = TreatmentSnapshotService(db)
    
    device_id = "TEST_DEVICE_01"
    treatment_id = "TREAT_20260312_001"
    timestamp = datetime.now(timezone(timedelta(hours=7))).isoformat()
    
    # Mock header and body
    header = {"patient_id": "PT_123"}
    
    def get_body(qb_val):
        return {
            "parameters": [
                {"id": 17, "value": qb_val, "value_text": str(qb_val)}, # QB
                {"id": 21, "value": 1500, "value_text": "1500"},         # QD
                {"id": 1, "value": -120, "value_text": "-120"},         # PA
            ]
        }

    print(f"1️⃣ Sending initial packet (QB = 150)...")
    body1 = get_body(150)
    
    # Simulate the logic in main.py
    # track_parameter_changes establishes the baseline
    event_svc.track_parameter_changes(device_id, timestamp, header, body1)
    # process_packet captures the state for H-snapshots
    snapshot_svc.process_packet(device_id, timestamp, treatment_id, header, body1)
    
    print(f"2️⃣ Sending change packet (QB = 200)...")
    body2 = get_body(200)
    
    # Simulate main.py wiring
    changes = event_svc.track_parameter_changes(device_id, timestamp, header, body2)
    snapshot_svc.process_packet(device_id, timestamp, treatment_id, header, body2)
    
    # Check for order changes
    order_pids = {17, 21, 18, 19, 22, 24}
    order_changes = [(pid, old, new) for pid, old, new in changes if pid in order_pids]
    
    if order_changes:
        print(f"✨ Order change detected: {order_changes}")
        snapshot_svc.save_order_change_snapshot(device_id, timestamp, order_changes)
    else:
        print("❌ Failed: No order change detected!")
        return

    # 3. Verification
    print("🔍 Checking Database...")
    snapshots = db.fetch_all("SELECT hour_label, qb, reason FROM treatment_hourly_snapshots WHERE treatment_id = ?", (treatment_id,))
    
    found_oc = False
    for s in snapshots:
        print(f"   - Label: {s['hour_label']}, QB: {s['qb']}, Reason: {s['reason']}")
        if s['hour_label'] == 'OC_01' and 'qb: 150' in s['reason'].lower():
            found_oc = True
            
    if found_oc:
        print("\n✅ SUCCESS: OC Snapshot created correctly with reason!")
    else:
        print("\n❌ FAILED: OC Snapshot not found or incorrect.")

    # Cleanup
    db._conn.close()
    # os.remove(test_db_path)

if __name__ == "__main__":
    asyncio.run(test_oc_snapshot())
