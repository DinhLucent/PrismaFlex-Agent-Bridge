import os
import sys
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace


sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from services.treatment.postgres_treatment_db import PostgresTreatmentDB  # noqa: E402


LOCAL_TZ = timezone(timedelta(hours=7))


class StableRowPolicyTests(unittest.TestCase):
    def setUp(self):
        # Bypass DB init; this test only exercises the pure policy helper.
        self.db = PostgresTreatmentDB.__new__(PostgresTreatmentDB)
        self.now = datetime(2026, 4, 18, 22, 30, 0, tzinfo=LOCAL_TZ)

    def _row(self, **kwargs):
        defaults = {
            "row_code": "H00",
            "row_kind": "HOUR",
            "stable_at": None,
            "snapshot_time": self.now - timedelta(minutes=10),
        }
        defaults.update(kwargs)
        return SimpleNamespace(**defaults)

    def test_h00_becomes_stable_after_freeze_window(self):
        row = self._row(
            row_code="H00",
            snapshot_time=self.now - timedelta(seconds=61),
        )
        self.assertTrue(self.db._row_should_be_stable(row, self.now))

    def test_h00_stays_unstable_inside_freeze_window(self):
        row = self._row(
            row_code="H00",
            snapshot_time=self.now - timedelta(seconds=30),
        )
        self.assertFalse(self.db._row_should_be_stable(row, self.now))

    def test_h01_is_stable_as_soon_as_it_exists(self):
        row = self._row(
            row_code="H01",
            snapshot_time=self.now,
        )
        self.assertTrue(self.db._row_should_be_stable(row, self.now))

    def test_order_change_rows_are_stable_immediately(self):
        row = self._row(
            row_code="OC_01",
            row_kind="ORDER_CHANGE",
            snapshot_time=self.now,
        )
        self.assertTrue(self.db._row_should_be_stable(row, self.now))


if __name__ == "__main__":
    unittest.main()
