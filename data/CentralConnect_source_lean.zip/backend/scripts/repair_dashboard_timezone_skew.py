#!/usr/bin/env python3
"""
Repair dashboard runtime rows in trends.db that were written +7h in the future.

Safe scope:
- pressure_trends.timestamp
- parameter_events.timestamp
- alarm_history.start_time / end_time

Does NOT touch PostgreSQL treatment history.
"""

from __future__ import annotations

import argparse
import shutil
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DB_PATH = ROOT / "backend" / "trends.db"
BACKUP_DIR = ROOT / "backend" / "backups"
LOCAL_TZ = timezone(timedelta(hours=7))
LEGACY_UTC_SHIFT = timedelta(hours=7)
FUTURE_SKEW_TOLERANCE = timedelta(minutes=2)


def backup_db(db_path: Path) -> Path | None:
    if not db_path.exists():
        return None

    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"trends_before_timezone_repair_{stamp}.db"
    shutil.copy2(db_path, backup_path)
    return backup_path


def parse_db_timestamp(raw_value: str | None) -> datetime | None:
    if raw_value is None:
        return None

    text = str(raw_value).strip()
    if not text:
        return None

    if text.endswith("Z"):
        text = text[:-1] + "+00:00"

    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None

    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=LOCAL_TZ)
    return parsed.astimezone(LOCAL_TZ)


def shifted_if_future(raw_value: str | None, now_local: datetime) -> str | None:
    parsed = parse_db_timestamp(raw_value)
    if parsed is None:
        return None
    if parsed <= now_local + FUTURE_SKEW_TOLERANCE:
        return None

    shifted = parsed - LEGACY_UTC_SHIFT
    if shifted <= now_local + FUTURE_SKEW_TOLERANCE:
        return shifted.isoformat()
    return None


def count_future_rows(conn: sqlite3.Connection, device_id: str | None) -> dict[str, int]:
    now_local = datetime.now(LOCAL_TZ)
    result = {
        "pressure_trends": 0,
        "parameter_events": 0,
        "alarm_history_start": 0,
        "alarm_history_end": 0,
    }

    where = " WHERE device_id = ?" if device_id else ""
    params = (device_id,) if device_id else ()

    for _, raw_ts in conn.execute(f"SELECT rowid, timestamp FROM pressure_trends{where}", params):
        if shifted_if_future(raw_ts, now_local):
            result["pressure_trends"] += 1

    for _, raw_ts in conn.execute(f"SELECT rowid, timestamp FROM parameter_events{where}", params):
        if shifted_if_future(raw_ts, now_local):
            result["parameter_events"] += 1

    for _, start_time, end_time in conn.execute(f"SELECT rowid, start_time, end_time FROM alarm_history{where}", params):
        if shifted_if_future(start_time, now_local):
            result["alarm_history_start"] += 1
        if shifted_if_future(end_time, now_local):
            result["alarm_history_end"] += 1

    return result


def apply_repair(conn: sqlite3.Connection, device_id: str | None) -> dict[str, int]:
    now_local = datetime.now(LOCAL_TZ)
    counts = {
        "pressure_trends": 0,
        "parameter_events": 0,
        "alarm_history_start": 0,
        "alarm_history_end": 0,
    }

    where = " WHERE device_id = ?" if device_id else ""
    params = (device_id,) if device_id else ()

    for rowid, raw_ts in conn.execute(f"SELECT rowid, timestamp FROM pressure_trends{where}", params).fetchall():
        shifted = shifted_if_future(raw_ts, now_local)
        if shifted:
            conn.execute("UPDATE pressure_trends SET timestamp = ? WHERE rowid = ?", (shifted, rowid))
            counts["pressure_trends"] += 1

    for rowid, raw_ts in conn.execute(f"SELECT rowid, timestamp FROM parameter_events{where}", params).fetchall():
        shifted = shifted_if_future(raw_ts, now_local)
        if shifted:
            conn.execute("UPDATE parameter_events SET timestamp = ? WHERE rowid = ?", (shifted, rowid))
            counts["parameter_events"] += 1

    for rowid, start_time, end_time in conn.execute(f"SELECT rowid, start_time, end_time FROM alarm_history{where}", params).fetchall():
        shifted_start = shifted_if_future(start_time, now_local)
        shifted_end = shifted_if_future(end_time, now_local)
        if shifted_start:
            conn.execute("UPDATE alarm_history SET start_time = ? WHERE rowid = ?", (shifted_start, rowid))
            counts["alarm_history_start"] += 1
        if shifted_end:
            conn.execute("UPDATE alarm_history SET end_time = ? WHERE rowid = ?", (shifted_end, rowid))
            counts["alarm_history_end"] += 1

    conn.commit()
    return counts


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Repair +7h dashboard runtime skew inside backend/trends.db")
    scope = parser.add_mutually_exclusive_group(required=True)
    scope.add_argument("--device-id", help="Repair one device only, e.g. PF_004")
    scope.add_argument("--all", action="store_true", help="Repair all devices")
    parser.add_argument("--db-path", help="Optional absolute path to trends.db")
    parser.add_argument("--apply", action="store_true", help="Apply updates. Without this flag the script only previews.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    db_path = Path(args.db_path).expanduser() if args.db_path else DEFAULT_DB_PATH

    print("=" * 80)
    print("REPAIR DASHBOARD TIMEZONE SKEW")
    print("=" * 80)
    print(f"DB: {db_path}")

    if not db_path.exists():
        print("Trend DB not found. Nothing to repair.")
        return 0

    device_id = args.device_id.strip() if args.device_id else None
    scope_label = device_id or "ALL DEVICES"
    print(f"Scope: {scope_label}")

    conn = sqlite3.connect(db_path)
    try:
        before = count_future_rows(conn, device_id)

        print("\nROWS THAT WILL SHIFT -7H")
        print("=" * 80)
        for table, count in before.items():
            print(f"{table:<20} {count}")

        if not args.apply:
            print("\nPreview only. Re-run with --apply to execute.")
            return 0

        backup_path = backup_db(db_path)
        repaired = apply_repair(conn, device_id)

        print("\nREPAIR COMPLETED")
        print("=" * 80)
        if backup_path:
            print(f"Backup: {backup_path}")
        for table, count in repaired.items():
            print(f"{table:<20} {count}")

        print("\nNEXT")
        print("=" * 80)
        print("1. Restart backend")
        print("2. Hard refresh frontend or clear site data")
        print("3. Resume LIVE ingest")
        print("4. Verify detail chart no longer points 7 hours into the future")
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
