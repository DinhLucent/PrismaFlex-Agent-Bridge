import os
import sys
import json
sys.path.append(os.path.join(os.getcwd(), "backend"))

from sqlalchemy import create_engine, text

def run_checks():
    engine = create_engine("postgresql://prismaflex:prismaflex@localhost:5432/prismaflex")
    output = []
    
    with engine.connect() as conn:
        output.append("=== PROJECTION VERIFICATION ===")
        q1 = """
        SELECT device_id, patient_id, outcome, approval_status, journal_row_count
        FROM treatment_list_projection
        WHERE device_id LIKE 'DEV_%'
        ORDER BY start_time;
        """
        rows = conn.execute(text(q1)).mappings().all()
        for r in rows:
            output.append(str(dict(r)))
            
        output.append("\n=== MANIFEST VERIFICATION ===")
        q2 = """
        SELECT device_id, COUNT(DISTINCT m.treatment_id) as tx_count, SUM(packet_count) as pkts
        FROM raw_packet_manifest m
        JOIN treatments t ON t.id = m.treatment_id
        WHERE device_id LIKE 'DEV_%'
        GROUP BY device_id
        ORDER BY device_id;
        """
        rows2 = conn.execute(text(q2)).mappings().all()
        for r in rows2:
            output.append(str(dict(r)))
            
        output.append("\n=== CHRONOLOGY VERIFICATION (B4 - Live OC_XX insertion) ===")
        q3 = """
        SELECT t.device_id, j.row_code, j.row_kind, j.snapshot_time
        FROM treatment_journal_rows j
        JOIN treatments t ON t.id = j.treatment_id
        WHERE t.device_id = 'DEV_B4'
        ORDER BY j.snapshot_time ASC, j.row_code ASC;
        """
        rows3 = conn.execute(text(q3)).mappings().all()
        for r in rows3:
            output.append(str(dict(r)))

        output.append("\n=== PATIENT BOUNDARY (A4 - Patient Change) ===")
        q4 = """
        SELECT id, patient_id, start_time, end_time, outcome 
        FROM treatments 
        WHERE device_id = 'DEV_A4'
        ORDER BY start_time ASC;
        """
        rows4 = conn.execute(text(q4)).mappings().all()
        for r in rows4:
            output.append(str(dict(r)))

    with open("backend/scripts/matrix_output.txt", "w") as f:
        f.write("\n".join(output))
    print("Done")

if __name__ == "__main__":
    run_checks()
