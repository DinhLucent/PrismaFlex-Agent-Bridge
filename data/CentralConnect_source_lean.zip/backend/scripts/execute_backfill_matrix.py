import requests
import time
from datetime import datetime, timezone, timedelta

API_URL = "http://localhost:8000/api/v1/telemetry"

def send_packet(device_id, patient_id, therapy_status, run_time, mock_time=None, params=None):
    ts = mock_time if mock_time else datetime.now(timezone.utc).isoformat()
    
    # 461 = RUN_TIME
    parameters = [{"id": 461, "value": run_time, "type": "Actual"}] if run_time is not None else []
    if params:
        for k, v in params.items():
            parameters.append({"id": k, "value": v, "type": "Actual"})

    payload = {
        "meta": {
            "device_id": device_id,
            "timestamp": ts  # This dictatates whether it's backfill vs live in some logic, but the header timestamp is the clinical one
        },
        "header": {
            "machine_id": 999,
            "patient_id": patient_id,
            "therapy_type_id": 1,
            "therapy_status_id": therapy_status,
            "timestamp": ts
        },
        "body": {
            "parameters": parameters
        }
    }
    
    try:
        resp = requests.post(API_URL, json=payload)
        return resp.status_code, resp.json()
    except Exception as e:
        print(f"Error: {e}")
        return 500, None

def run_group_a():
    print("=== GROUP A: BACKFILL ===")
    
    # A1
    print("Test A1: Backfill 1 treatment, no handoff")
    t1 = datetime.now(timezone.utc) - timedelta(days=1)
    send_packet("DEV_A1", "PT_A1", 5, 100, (t1).isoformat())
    send_packet("DEV_A1", "PT_A1", 5, 105, (t1 + timedelta(minutes=5)).isoformat())
    send_packet("DEV_A1", "PT_A1", 5, 110, (t1 + timedelta(minutes=10)).isoformat())

    # A2
    print("Test A2: END -> same patient -> RUN_TIME > 0")
    t2 = datetime.now(timezone.utc) - timedelta(days=1)
    send_packet("DEV_A2", "PT_A2", 5, 100, (t2).isoformat())
    send_packet("DEV_A2", "PT_A2", 8, 120, (t2 + timedelta(minutes=20)).isoformat()) # END
    send_packet("DEV_A2", "PT_A2", 5, 121, (t2 + timedelta(minutes=25)).isoformat()) # RUN > 0

    # A3
    print("Test A3: END -> same patient -> RUN_TIME = 0")
    t3 = datetime.now(timezone.utc) - timedelta(days=1)
    send_packet("DEV_A3", "PT_A3", 5, 100, (t3).isoformat())
    send_packet("DEV_A3", "PT_A3", 8, 120, (t3 + timedelta(minutes=20)).isoformat()) # END
    send_packet("DEV_A3", "PT_A3", 5, 0, (t3 + timedelta(minutes=25)).isoformat()) # RUN = 0 (New Treatment!)

    # A4
    print("Test A4: Patient change")
    t4 = datetime.now(timezone.utc) - timedelta(days=1)
    send_packet("DEV_A4", "PT_A4_1", 5, 100, (t4).isoformat())
    send_packet("DEV_A4", "PT_A4_2", 5, 10, (t4 + timedelta(minutes=20)).isoformat()) # New Treatment!

def run_group_b():
    print("\n=== GROUP B: HANDOFF TO LIVE ===")
    
    # B1
    print("Test B1: Backfill -> Live Same Patient -> RUN_TIME > 0")
    t_backfill = datetime.now(timezone.utc) - timedelta(hours=1)
    send_packet("DEV_B1", "PT_B1", 5, 50, (t_backfill).isoformat())
    send_packet("DEV_B1", "PT_B1", 5, 60, (t_backfill + timedelta(minutes=10)).isoformat())
    time.sleep(1) # wait a moment
    print("  -> Sending Live...")
    send_packet("DEV_B1", "PT_B1", 5, 120, None) # Live packet

    # B2
    print("Test B2: Backfill -> Live Same Patient -> RUN_TIME = 0")
    send_packet("DEV_B2", "PT_B2", 5, 50, (t_backfill).isoformat())
    send_packet("DEV_B2", "PT_B2", 5, 60, (t_backfill + timedelta(minutes=10)).isoformat())
    time.sleep(1)
    print("  -> Sending Live...")
    send_packet("DEV_B2", "PT_B2", 5, 0, None) # Live packet

    # B3
    print("Test B3: Backfill -> Live Patient Change")
    send_packet("DEV_B3", "PT_B3_1", 5, 50, (t_backfill).isoformat())
    send_packet("DEV_B3", "PT_B3_1", 5, 60, (t_backfill + timedelta(minutes=10)).isoformat())
    time.sleep(1)
    print("  -> Sending Live...")
    send_packet("DEV_B3", "PT_B3_2", 5, 10, None) # Live packet

    # B4
    print("Test B4: Backfill -> Live Same -> OC_XX")
    send_packet("DEV_B4", "PT_B4", 5, 50, (t_backfill).isoformat(), {17: 100})
    time.sleep(1)
    print("  -> Sending Live...")
    send_packet("DEV_B4", "PT_B4", 5, 120, None, {17: 100})
    print("  -> Sending Live with Change (OC_XX)...")
    send_packet("DEV_B4", "PT_B4", 5, 125, None, {17: 150}) # Changed Qb from 100 to 150

if __name__ == "__main__":
    run_group_a()
    run_group_b()
    print("\nMatrix injection complete. Please verify database and UI.")
