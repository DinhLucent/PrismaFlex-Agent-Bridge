"""
QA Automated Test Suite - Phe Duyet Dieu Tri (Treatment Approval)
Tests: Submit, Approve, Reject, Unlock, Permission gates
"""
import requests
import sqlalchemy as sa
import json

API = "http://127.0.0.1:8000"
engine = sa.create_engine('postgresql://prismaflex:prismaflex@localhost:5432/prismaflex')
results = []

def log(tc_id, name, passed, detail=""):
    status = "PASS" if passed else ("FAIL" if passed is False else "SKIP")
    results.append({"id": tc_id, "name": name, "passed": passed, "detail": detail})
    print(f"  [{status}] {tc_id} | {name}" + (f" -- {detail}" if detail else ""))

print("=" * 70)
print("QA TEST SUITE - Phe Duyet Dieu Tri (Approval Workflow)")
print("=" * 70)

h_nurse = {"X-User-Role": "nurse", "X-Operator-Name": "QA_Nurse", "Content-Type": "application/json"}
h_doctor = {"X-User-Role": "doctor", "X-Operator-Name": "QA_Doctor", "Content-Type": "application/json"}

# === SETUP: Find test treatments ===
with engine.connect() as c:
    # Find a COMPLETED treatment with DRAFT status for testing
    completed = c.execute(sa.text(
        "SELECT t.id, t.patient_id, t.outcome, "
        "COALESCE(p.approval_status, 'DRAFT') as approval_status "
        "FROM treatments t "
        "LEFT JOIN treatment_list_projection p ON t.id = p.id "
        "WHERE t.outcome = 'COMPLETED' "
        "ORDER BY t.start_time DESC LIMIT 5"
    )).fetchall()

    # Find an IN_PROGRESS treatment
    in_progress = c.execute(sa.text(
        "SELECT t.id, t.patient_id, t.outcome "
        "FROM treatments t "
        "WHERE t.outcome = 'IN_PROGRESS' "
        "ORDER BY t.start_time DESC LIMIT 1"
    )).fetchone()

    # Find current pending count
    pending = c.execute(sa.text(
        "SELECT COUNT(*) FROM treatment_list_projection WHERE approval_status = 'PENDING_REVIEW'"
    )).fetchone()

print(f"\nCompleted treatments found: {len(completed)}")
for ct in completed:
    print(f"  - {ct[1]} ({str(ct[0])[:8]}) -- outcome={ct[2]}, approval={ct[3]}")
if in_progress:
    print(f"IN_PROGRESS: {in_progress[1]} ({str(in_progress[0])[:8]})")
print(f"Pending review count: {pending[0]}")
print("-" * 70)

# === 1. PENDING COUNT API ===
print("\n[1] PENDING COUNT API")
r = requests.get(f"{API}/api/v1/treatments/pending-count")
if r.ok:
    data = r.json()
    count = data.get('count', data.get('pending_count', -1))
    log("1.1", "GET /pending-count returns valid count", count >= 0, f"count={count}")
else:
    log("1.1", "GET /pending-count returns valid count", False, f"status={r.status_code}")

# === 2. APPROVAL LIST API ===
print("\n[2] APPROVAL LIST")
r = requests.get(f"{API}/api/v1/treatments?approval_status=PENDING_REVIEW&limit=5")
if r.ok:
    items = r.json().get('items', [])
    log("2.1", "Filter by PENDING_REVIEW works", True, f"count={len(items)}")
else:
    # Try alternative endpoint
    r2 = requests.get(f"{API}/api/v1/treatments?limit=50")
    if r2.ok:
        all_items = r2.json().get('items', [])
        pending_items = [i for i in all_items if i.get('approval_status') == 'PENDING_REVIEW']
        log("2.1", "Filter pending treatments", True, f"total={len(all_items)}, pending={len(pending_items)}")
    else:
        log("2.1", "Filter pending treatments", False, f"status={r2.status_code}")

# === 3. SUBMIT FOR REVIEW (Nurse workflow) ===
print("\n[3] SUBMIT FOR REVIEW")

# 3.1 Block submit on IN_PROGRESS treatment
if in_progress:
    ip_id = str(in_progress[0])
    r = requests.post(f"{API}/api/v1/treatments/{ip_id}/submit", headers=h_nurse)
    log("3.1", "Block submit on IN_PROGRESS", r.status_code == 409, f"status={r.status_code}")
else:
    log("3.1", "Block submit on IN_PROGRESS", None, "No IN_PROGRESS treatment -- SKIP")

# 3.2 Find a DRAFT COMPLETED treatment to submit
draft_completed = None
for ct in completed:
    if ct[3] == 'DRAFT':
        draft_completed = ct
        break

if draft_completed:
    dc_id = str(draft_completed[0])
    r = requests.post(f"{API}/api/v1/treatments/{dc_id}/submit", headers=h_nurse)
    log("3.2", "Nurse submits COMPLETED/DRAFT treatment", r.status_code == 200 and r.json().get('approval_status') == 'PENDING_REVIEW',
        f"status={r.status_code}, resp={r.json() if r.ok else r.text[:100]}")

    # 3.3 Double submit should be blocked
    if r.status_code == 200:
        r2 = requests.post(f"{API}/api/v1/treatments/{dc_id}/submit", headers=h_nurse)
        log("3.3", "Block double submit", r2.status_code == 409, f"status={r2.status_code}")

        # === 4. REJECT (Doctor sends back) ===
        print("\n[4] REJECT")
        r = requests.post(f"{API}/api/v1/treatments/{dc_id}/reject",
                          headers=h_doctor, json={"reason": "QA test rejection"})
        log("4.1", "Doctor rejects treatment", r.status_code == 200 and r.json().get('approval_status') == 'DRAFT',
            f"status={r.status_code}, resp={r.json() if r.ok else r.text[:100]}")

        # 4.2 After rejection, nurse can re-submit
        if r.status_code == 200:
            r = requests.post(f"{API}/api/v1/treatments/{dc_id}/submit", headers=h_nurse)
            log("4.2", "Nurse re-submits after reject", r.status_code == 200,
                f"status={r.status_code}")

            # === 5. APPROVE (Doctor approves) ===
            print("\n[5] APPROVE")
            r = requests.post(f"{API}/api/v1/treatments/{dc_id}/approve", headers=h_doctor)
            log("5.1", "Doctor approves treatment", r.status_code == 200 and r.json().get('approval_status') == 'APPROVED',
                f"status={r.status_code}, resp={r.json() if r.ok else r.text[:100]}")

            # 5.2 Double approve should be blocked
            if r.status_code == 200:
                r2 = requests.post(f"{API}/api/v1/treatments/{dc_id}/approve", headers=h_doctor)
                log("5.2", "Block double approve", r2.status_code == 409, f"status={r2.status_code}")

                # 5.3 Nurse cannot edit APPROVED treatment
                r3 = requests.put(f"{API}/api/v1/treatments/{dc_id}/snapshots/H00",
                                  headers=h_nurse, json={"qb": 100})
                log("5.3", "Nurse blocked from editing APPROVED", r3.status_code == 403,
                    f"status={r3.status_code}")

                # 5.4 Cannot delete APPROVED treatment
                r4 = requests.delete(f"{API}/api/v1/treatments/{dc_id}", headers=h_doctor)
                log("5.4", "Block delete APPROVED treatment", r4.status_code == 403,
                    f"status={r4.status_code}")

                # === 6. UNLOCK ===
                print("\n[6] UNLOCK")
                # 6.1 Nurse cannot unlock
                r = requests.post(f"{API}/api/v1/treatments/{dc_id}/unlock", headers=h_nurse)
                log("6.1", "Nurse blocked from unlock", r.status_code == 403,
                    f"status={r.status_code}")

                # 6.2 Doctor can unlock
                r = requests.post(f"{API}/api/v1/treatments/{dc_id}/unlock", headers=h_doctor)
                log("6.2", "Doctor unlocks approved treatment", r.status_code == 200,
                    f"status={r.status_code}, resp={r.json() if r.ok else r.text[:100]}")
            else:
                log("5.2", "Block double approve", None, "SKIP - approve failed")
                log("5.3", "Nurse blocked from editing APPROVED", None, "SKIP")
                log("5.4", "Block delete APPROVED treatment", None, "SKIP")
                log("6.1", "Nurse blocked from unlock", None, "SKIP")
                log("6.2", "Doctor unlocks", None, "SKIP")
        else:
            for tc in ["4.2", "5.1", "5.2", "5.3", "5.4", "6.1", "6.2"]:
                log(tc, "Skipped due to reject failure", None, "SKIP")
    else:
        for tc in ["3.3", "4.1", "4.2", "5.1", "5.2", "5.3", "5.4", "6.1", "6.2"]:
            log(tc, "Skipped due to submit failure", None, "SKIP")
else:
    log("3.2", "No DRAFT/COMPLETED treatment", None, "SKIP - no suitable treatment")

# === 7. PERMISSION GATES ===
print("\n[7] PERMISSION GATES")

# 7.1 No operator name should fail
r = requests.post(f"{API}/api/v1/treatments/{str(completed[0][0])}/approve",
                  headers={"X-User-Role": "doctor", "Content-Type": "application/json"})
log("7.1", "Block approve without operator name", r.status_code == 400, f"status={r.status_code}")

# 7.2 Nurse cannot approve
if draft_completed:
    dc_id = str(draft_completed[0])
    r = requests.post(f"{API}/api/v1/treatments/{dc_id}/approve", headers=h_nurse)
    log("7.2", "Nurse blocked from approving", r.status_code == 403, f"status={r.status_code}")
else:
    log("7.2", "Nurse blocked from approving", None, "SKIP")

# === SUMMARY ===
print("\n" + "=" * 70)
passed = sum(1 for r in results if r['passed'] is True)
failed = sum(1 for r in results if r['passed'] is False)
skipped = sum(1 for r in results if r['passed'] is None)
total = len(results)
print(f"TOTAL: {total} | PASS: {passed} | FAIL: {failed} | SKIP: {skipped}")

if failed:
    print("\nFAILED:")
    for r in results:
        if r['passed'] is False:
            print(f"  X {r['id']}: {r['name']} -- {r['detail']}")
else:
    print("\nALL TESTS PASSED!")
