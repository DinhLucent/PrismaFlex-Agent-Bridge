import requests
import time
import os
import sys
from datetime import datetime, timezone, timedelta

API_URL = "http://localhost:8000/api/v1/telemetry"

def send_packet(device_id, status_id, alarms=[], params=[]):
    ts = datetime.now(timezone.utc).isoformat()
    # build body
    body_params = []
    # TMP = 442, Filter = 441, Effluent = 445, Return = 440
    # Add dummy parameters for vitals
    # Access=1, Filter=2, Effluent=3, Return=4, TMP=6, QB=17
    default_params = [
        {"id": 1, "value": -50, "type": "Actual"}, 
        {"id": 4, "value": 150, "type": "Actual"}, 
        {"id": 2, "value": 200, "type": "Actual"}, 
        {"id": 3, "value": 100, "type": "Actual"}, 
        {"id": 461, "value": 3600, "type": "Actual"},
        {"id": 17, "value": 210, "type": "Actual"}
    ]
    for p in default_params:
        if not any(x["id"] == p["id"] for x in params):
            body_params.append(p)
            
    body_params.extend(params)
    
    payload = {
        "meta": {"device_id": device_id, "timestamp": ts},
        "header": {
            "machine_id": 999,
            "patient_id": f"PT_{device_id}",
            "therapy_type_id": 1,
            "therapy_status_id": status_id,
            "timestamp": ts
        },
        "body": {
            "parameters": body_params,
            "alarms": alarms
        }
    }
    try:
        requests.post(API_URL, json=payload, timeout=2)
    except Exception:
        pass

def run():
    print("Dashboard Simulator starting...")
    # Send once for DEV_OFFline so it ages out (will be 45s offline soon)
    send_packet("DEV_OFFLINE", 5)
    
    count = 0
    try:
        while True:
            # DEV_CRIT: Air in blood (severity 1 usually, or status 11=MALFUNCTION)
            send_packet("DEV_CRIT", 11, params=[{"id": 65, "value": 1, "type": "Alarm"}]) 
            
            # DEV_WARN: severity 2/3 (status 7=WARNING)
            send_packet("DEV_WARN", 7, params=[{"id": 1, "value": 1, "type": "Alarm"}])
            
            # DEV_RUN: Clean running
            send_packet("DEV_RUN", 5, params=[{"id": 6, "value": 55, "type": "Actual"}]) # valid TMP
            
            # DEV_NO_TMP: Test TMP Fallback (No TMP param passed)
            # Extracted fallback logic: ((Filter + Effluent) / 2) - Return
            # ((200 + 100)/2) - 150 = 150 - 150 = 0
            send_packet("DEV_NO_TMP", 5)
            
            # DEV_EVENT: changing parameter to test 5 min merge
            val = 200 + count
            send_packet("DEV_EVENT", 5, params=[{"id": 17, "value": val, "type": "Actual"}]) # QB changing
            
            count += 1
            print(f"Tick {count} sent.")
            time.sleep(5) # send every 5 seconds
    except KeyboardInterrupt:
        print("Stopped.")

if __name__ == "__main__":
    run()
