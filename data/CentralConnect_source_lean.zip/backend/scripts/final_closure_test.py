import os, sys, asyncio
from datetime import datetime, timezone, timedelta

sys.path.append(os.path.join(os.getcwd(), "backend"))
from sqlalchemy import create_engine, text
from db.postgres.session import get_session_factory
from services.treatment.postgres_treatment_db import PostgresTreatmentDB
from services.treatment.raw_streamer import RawDataStreamer
from services.treatment.treatment_recorder import TreatmentRecorderService

class MockStreamer(RawDataStreamer):
    async def stream_packet(self, device_id, treatment_id, packet_data): pass
    async def compress_treatment_file(self, device_id, treatment_id): pass

async def run_tests():
    db = PostgresTreatmentDB()
    recorder = TreatmentRecorderService(db, MockStreamer())

    def send_pkt(device_id, patient_id, therapy_status, run_time, time_str):
        b = {"parameters": [{"id": 461, "value": run_time, "type": "Actual"}]} if run_time is not None else {"parameters": []}
        h = {"machine_id": 999, "patient_id": patient_id, "therapy_type_id": 1, "therapy_status_id": therapy_status, "timestamp": time_str}
        return time_str, h, b, {"timestamp": time_str}

    t1 = (datetime.now(timezone.utc) - timedelta(minutes=60)).isoformat()
    t2 = datetime.now(timezone.utc).isoformat()

    print("=== TC-1: Close by END packet ===")
    t1_1 = send_pkt("DEV_TC1B", "PT_TC1B", 5, 100, t1)
    await recorder.process_packet("DEV_TC1B", *t1_1, is_live=True)
    t1_2 = send_pkt("DEV_TC1B", "PT_TC1B", 8, 120, t2)
    await recorder.process_packet("DEV_TC1B", *t1_2, is_live=True)

    print("=== TC-2: Patient Change ===")
    t2_1 = send_pkt("DEV_TC2B", "PT_TC2_OLD", 5, 100, t1)
    await recorder.process_packet("DEV_TC2B", *t2_1, is_live=True)
    t2_2 = send_pkt("DEV_TC2B", "PT_TC2_NEW", 5, 10, t2)
    await recorder.process_packet("DEV_TC2B", *t2_2, is_live=True)

    print("=== TC-3: RUN_TIME Reset ===")
    t3_1 = send_pkt("DEV_TC3B", "PT_TC3", 5, 150, t1)
    await recorder.process_packet("DEV_TC3B", *t3_1, is_live=True)
    t3_2 = send_pkt("DEV_TC3B", "PT_TC3", 5, 0, t2)
    await recorder.process_packet("DEV_TC3B", *t3_2, is_live=True)

    print("=== TC-7: Late Packet after END ===")
    t7_1 = send_pkt("DEV_TC7", "PT_TC7", 5, 100, t1) # RUN
    await recorder.process_packet("DEV_TC7", *t7_1, is_live=True)
    t7_2 = send_pkt("DEV_TC7", "PT_TC7", 8, 120, t2) # END
    await recorder.process_packet("DEV_TC7", *t7_2, is_live=True)
    # Late packet from 30 mins ago
    t7_late = (datetime.now(timezone.utc) - timedelta(minutes=30)).isoformat()
    t7_3 = send_pkt("DEV_TC7", "PT_TC7", 5, 110, t7_late)
    await recorder.process_packet("DEV_TC7", *t7_3, is_live=True)

    engine = create_engine("postgresql://prismaflex:prismaflex@localhost:5432/prismaflex")
    print("\n--- DATABASE RESULTS ---")
    with engine.connect() as conn:
        for i in [1, 2, 3, 7]:
            dev = f"DEV_TC{i}B" if i != 7 else "DEV_TC7"
            res = conn.execute(text(f"SELECT patient_id, outcome, close_reason FROM treatments WHERE device_id = '{dev}' ORDER BY start_time ASC;")).mappings().all()
            for r in res: 
                print(f"{dev} => {r['patient_id']} | {r['outcome']} | {r['close_reason']}")

if __name__ == "__main__":
    asyncio.run(run_tests())
