from db.postgres.session import get_session
from db.postgres.models.treatment_list_projection import TreatmentListProjection
from db.postgres.models.treatment_notes import TreatmentNote
from sqlalchemy import select, func, update

def sync_note_counts():
    with get_session() as s:
        print("--- Fetching note counts from treatment_notes table ---")
        counts = s.execute(
            select(TreatmentNote.treatment_id, func.count(TreatmentNote.id))
            .group_by(TreatmentNote.treatment_id)
        ).all()
        
        updated = 0
        for tid, count in counts:
            res = s.execute(
                update(TreatmentListProjection)
                .where(TreatmentListProjection.id == tid)
                .values(note_count=count)
            )
            if res.rowcount > 0:
                print(f"Updated Treatment {tid} with count {count}")
                updated += 1
        
        s.commit()
        print(f"--- Finished. Updated {updated} projections. ---")

if __name__ == "__main__":
    sync_note_counts()
