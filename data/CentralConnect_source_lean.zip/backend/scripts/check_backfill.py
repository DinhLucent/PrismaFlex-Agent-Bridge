import os
import sys
import sqlite3
from collections import defaultdict

def main():
    db_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "prismaflex_treatment.db"))
    if not os.path.exists(db_path):
        print(f"Database not found at {db_path}")
        return

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # Get the latest treatment
    c.execute("SELECT * FROM treatments ORDER BY created_at DESC LIMIT 1")
    t = c.fetchone()
    
    if not t:
        print("No treatments found in DB.")
        return
        
    print("=" * 60)
    print(f"LATEST TREATMENT")
    print(f"Treatment ID : {t['id']}")
    print(f"Device ID    : {t['device_id']}")
    print(f"Patient ID   : {t['patient_id']}")
    print(f"Status       : {t['fsm_state']} / {t['outcome']}")
    print(f"Packets      : {t['total_packets']}")
    print(f"Duration     : {t['total_run_seconds']}s")
    print("=" * 60)
    
    # Get snapshots
    c.execute("""
        SELECT row_code, row_kind, hour_slot, snapshot_time, source
        FROM treatment_journal_rows 
        WHERE treatment_id = ? AND is_deleted = 0
        ORDER BY snapshot_time ASC
    """, (t['id'],))
    
    rows = c.fetchall()
    
    print(f"SNAPSHOTS ({len(rows)} total):")
    print(f"{'CODE':<8} | {'KIND':<15} | {'SLOT':<5} | {'SOURCE':<10} | {'TIME'}")
    print("-" * 60)
    
    for r in rows:
        print(f"{r['row_code']:<8} | {r['row_kind']:<15} | {str(r['hour_slot']):<5} | {r['source']:<10} | {r['snapshot_time']}")
        
    print("=" * 60)

    # Check indices
    c.execute("PRAGMA index_list('treatment_journal_rows')")
    indices = [i['name'] for i in c.fetchall()]
    print(f"Indices present: {indices}")

    conn.close()

if __name__ == "__main__":
    main()
