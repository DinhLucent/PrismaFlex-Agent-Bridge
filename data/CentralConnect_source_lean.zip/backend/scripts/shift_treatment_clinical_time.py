"""
Shift one treatment's clinical timestamps by a fixed number of hours.

Use this only for historical repair after a timezone decode bug.

Default workflow:
  1. Preview target treatment and the calculated shift.
  2. Re-run with --apply after the treatment is CLOSED.
"""

from __future__ import annotations

import argparse
from textwrap import dedent

import sqlalchemy as sa


DEFAULT_DSN = "postgresql://prismaflex:prismaflex@127.0.0.1:5432/prismaflex"

SHIFT_TARGETS = [
    ("treatments", "id", [
        "start_time",
        "first_run_time",
        "end_time",
        "last_seen_time",
        "start_time_override",
        "end_time_override",
        "last_packet_time",
    ]),
    ("treatment_list_projection", "id", [
        "start_time",
        "end_time",
    ]),
    ("treatment_status_events", "treatment_id", [
        "event_time",
    ]),
    ("treatment_journal_rows", "treatment_id", [
        "snapshot_time",
        "stable_at",
        "deleted_at",
    ]),
    ("treatment_phases", "treatment_id", [
        "start_time",
        "end_time",
    ]),
    ("treatment_projection_checkpoint", "treatment_id", [
        "slot_anchor_time",
        "last_oc_time",
    ]),
    ("raw_packet_manifest", "treatment_id", [
        "first_timestamp",
        "last_timestamp",
    ]),
]


def _build_update_sql(table: str, where_col: str, columns: list[str]) -> sa.TextClause:
    sets = [
        f"{col} = CASE WHEN {col} IS NULL THEN NULL ELSE {col} + (:hours * INTERVAL '1 hour') END"
        for col in columns
    ]
    sql = f"UPDATE {table} SET {', '.join(sets)} WHERE {where_col} = :treatment_id"
    return sa.text(sql)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Shift one treatment's clinical timestamps by a fixed hour delta."
    )
    parser.add_argument("--dsn", default=DEFAULT_DSN, help="PostgreSQL DSN")
    parser.add_argument("--treatment-id", required=True, help="Treatment UUID")
    parser.add_argument(
        "--hours",
        type=int,
        default=-7,
        help="Hour delta to apply. Use -7 to repair the UTC/+7 decode bug.",
    )
    parser.add_argument("--apply", action="store_true", help="Actually perform updates")
    args = parser.parse_args()

    engine = sa.create_engine(args.dsn)
    tid = args.treatment_id

    with engine.begin() as conn:
        treatment = conn.execute(
            sa.text(
                """
                SELECT id, patient_id, device_id, start_time, end_time, outcome, total_packets
                FROM treatments
                WHERE id = :treatment_id
                """
            ),
            {"treatment_id": tid},
        ).mappings().first()

        if not treatment:
            print("Treatment not found.")
            return 1

        print("=" * 80)
        print("TARGET TREATMENT")
        print("=" * 80)
        for key in ["id", "patient_id", "device_id", "start_time", "end_time", "outcome", "total_packets"]:
            print(f"{key:12}: {treatment.get(key)}")
        print()
        print(f"Planned shift: {args.hours} hour(s)")
        print()

        counts = {}
        for table, where_col, _columns in SHIFT_TARGETS:
            counts[table] = conn.execute(
                sa.text(f"SELECT COUNT(*) FROM {table} WHERE {where_col} = :treatment_id"),
                {"treatment_id": tid},
            ).scalar_one()

        print("AFFECTED ROW COUNTS")
        print("=" * 80)
        for table, count in counts.items():
            print(f"{table:30} {count}")

        if not args.apply:
            print()
            print("Preview only. Re-run with --apply after confirming the treatment is closed.")
            return 0

        if treatment["outcome"] == "IN_PROGRESS":
            print()
            print("Abort: treatment is still IN_PROGRESS. Wait until it is closed.")
            return 2

        print()
        print("APPLYING SHIFT...")
        for table, where_col, columns in SHIFT_TARGETS:
            conn.execute(_build_update_sql(table, where_col, columns), {
                "treatment_id": tid,
                "hours": args.hours,
            })
            print(f"updated {table}")

        refreshed = conn.execute(
            sa.text(
                """
                SELECT id, patient_id, device_id, start_time, end_time, outcome
                FROM treatments
                WHERE id = :treatment_id
                """
            ),
            {"treatment_id": tid},
        ).mappings().first()

        print()
        print("=" * 80)
        print("UPDATED TREATMENT")
        print("=" * 80)
        for key in ["id", "patient_id", "device_id", "start_time", "end_time", "outcome"]:
            print(f"{key:12}: {refreshed.get(key)}")

    print()
    print(dedent("""
        Done.

        Recommended follow-up:
          1. Query /api/v1/treatments/{id}
          2. Open Treatment Journal in frontend
          3. Verify H00/H01 and duration line up with the corrected date
    """).strip())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
