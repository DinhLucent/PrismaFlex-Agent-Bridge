import os
import sys

sys.path.append(os.path.join(os.getcwd(), "backend"))
from sqlalchemy import create_engine, text

def check():
    engine = create_engine("postgresql://prismaflex:prismaflex@localhost:5432/prismaflex")
    output = []
    with engine.connect() as conn:
        for i in range(1, 5):
            dev = f"DEV_TC{i}"
            res = conn.execute(text(f"SELECT patient_id, outcome, close_reason FROM treatments WHERE device_id = '{dev}' ORDER BY start_time ASC;")).mappings().all()
            output.append(f"\n--- {dev} ---")
            for r in res:
                output.append(str(dict(r)))
                
    with open("backend/scripts/closure_results.txt", "w") as f:
        f.write("\n".join(output))

if __name__ == "__main__":
    check()
