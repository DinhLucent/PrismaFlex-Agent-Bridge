import sqlalchemy as sa
import json
from datetime import datetime

class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super(DateTimeEncoder, self).default(obj)

engine = sa.create_engine('postgresql://prismaflex:prismaflex@localhost:5432/prismaflex')
with engine.connect() as c:
    res = c.execute(sa.text("SELECT id, start_time FROM treatments WHERE id::text LIKE '91c52b04%' LIMIT 1")).fetchall()
    if not res:
        print("Not found")
    else:
        tid = res[0][0]
        st = res[0][1]
        
        rows = c.execute(sa.text("SELECT row_code, stable_at FROM treatment_journal_rows WHERE treatment_id = :tid ORDER BY row_code"), {"tid": str(tid)}).fetchall()
        out = [{"row_code": r[0], "stable_at": r[1]} for r in rows]
        
        with open('debug_rows.json', 'w') as f:
            json.dump({"treatment": str(tid), "start_time": st, "rows": out}, f, cls=DateTimeEncoder, indent=2)
        print("Dumped to debug_rows.json")
