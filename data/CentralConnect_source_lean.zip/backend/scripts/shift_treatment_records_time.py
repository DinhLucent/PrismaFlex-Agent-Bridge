#!/usr/bin/env python3
"""
Shift clinical time inside backend/treatment_records.db for one or more treatments.

Safe scope:
- treatments.start_time / first_run_time / end_time / last_seen_time
- treatment_phases.start_time / end_time
- treatment_status_log.timestamp
- treatment_hourly_snapshots.snapshot_time
- snapshot_originals.snapshot_time
- treatment_index.start_time / end_time

Does NOT touch:
- created_at / updated_at / frozen_at system audit timestamps
- trends.db dashboard runtime rows
"""

from __future__ import annotations

import argparse
import shutil
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DB_PATH = ROOT / "backend" / "services" / "treatment_records.db"
BACKUP_DIR = ROOT / "backend" / "backups"
LOCAL_TZ = timezone(timedelta(hours=7))


TIME_COLUMNS = (
    ("treatments", "id", ("start_time", "first_run_time", "end_time", "last_seen_time")),
    ("treatment_phases", "treatment_id", ("start_time", "end_time")),
    ("treatment_status_log", "treatment_id", ("timestamp",)),
    ("treatment_hourly_snapshots", "treatment_id", ("snapshot_time",)),
    ("snapshot_originals", "treatment_id", ("snapshot_time",)),
    ("treatment_index", "id", ("start_time", "end_time")),
)


def backup_db(db_path: Path) -> Path | None:
    if not db_path.exists():
        return None

    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"treatment_records_before_shift_{stamp}.db"
    shutil.copy2(db_path, backup_path)
    return backup_path


def parse_db_timestamp(raw_value: str | None) -> datetime | None:
    if raw_value is None:
        return None

    text = str(raw_value).strip()
    if not text:
        return None

    if text.endswith("Z"):
        text = text[:-1] + "+00:00"

    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=LOCAL_TZ)
    return parsed.astimezone(LOCAL_TZ)


def shift_timestamp(raw_value: str | None, delta: timedelta) -> str | None:
    parsed = parse_db_timestamp(raw_value)
    if parsed is None:
        return None
    return (parsed + delta).isoformat()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Shift treatment clinical time inside treatment_records.db")
    parser.add_argument(
        "--treatment-id",
        action="append",
        dest="treatment_ids",
        required=True,
        help="Treatment id to shift. Repeat the flag for multiple active treatments.",
    )
    parser.add_argument(
        "--hours",
        type=int,
        required=True,
        help="Hour delta to apply, e.g. -7",
    )
    parser.add_argument("--db-path", help="Optional absolute path to treatment_records.db")
    parser.add_argument("--apply", action="store_true", help="Apply updates. Without this flag the script only previews.")
    return parser.parse_args()


def fetch_treatment_summary(conn: sqlite3.Connection, treatment_id: str) -> sqlite3.Row | None:
    row = conn.execute(
        """
        SELECT
            id,
            device_id,
            patient_id,
            start_time,
            end_time,
            last_seen_time,
            outcome,
            total_packets,
            'treatments' AS source_table
        FROM treatments
        WHERE id = ?
        """,
        (treatment_id,),
    ).fetchone()

    if row:
        return row

    return conn.execute(
        """
        SELECT
            id,
            device_id,
            patient_id,
            start_time,
            end_time,
            NULL AS last_seen_time,
            outcome,
            total_packets,
            'treatment_index' AS source_table
        FROM treatment_index
        WHERE id = ?
        """,
        (treatment_id,),
    ).fetchone()


def count_rows(conn: sqlite3.Connection, treatment_ids: list[str]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for table, key_col, _ in TIME_COLUMNS:
        placeholders = ",".join("?" for _ in treatment_ids)
        row = conn.execute(
            f"SELECT COUNT(*) FROM {table} WHERE {key_col} IN ({placeholders})",
            tuple(treatment_ids),
        ).fetchone()
        counts[table] = int(row[0] if row else 0)
    return counts


def apply_shift(conn: sqlite3.Connection, treatment_ids: list[str], delta: timedelta) -> dict[str, int]:
    counts: dict[str, int] = {}

    for table, key_col, columns in TIME_COLUMNS:
        updated_rows = 0
        placeholders = ",".join("?" for _ in treatment_ids)
        rows = conn.execute(
            f"SELECT rowid, {', '.join(columns)} FROM {table} WHERE {key_col} IN ({placeholders})",
            tuple(treatment_ids),
        ).fetchall()

        for row in rows:
            assignments: list[str] = []
            params: list[object] = []

            for column in columns:
                shifted = shift_timestamp(row[column], delta)
                if shifted is not None:
                    assignments.append(f"{column} = ?")
                    params.append(shifted)

            if assignments:
                params.append(row["rowid"])
                conn.execute(
                    f"UPDATE {table} SET {', '.join(assignments)} WHERE rowid = ?",
                    tuple(params),
                )
                updated_rows += 1

        counts[table] = updated_rows

    conn.commit()
    return counts


def main() -> int:
    args = parse_args()
    db_path = Path(args.db_path).expanduser() if args.db_path else DEFAULT_DB_PATH
    treatment_ids = [str(tid).strip() for tid in args.treatment_ids if str(tid).strip()]
    delta = timedelta(hours=args.hours)

    print("=" * 80)
    print("SHIFT TREATMENT RECORDS TIME")
    print("=" * 80)
    print(f"DB: {db_path}")
    print(f"Hours: {args.hours:+d}")

    if not db_path.exists():
        print("Treatment DB not found.")
        return 1

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    try:
        print("\nTARGET TREATMENTS")
        print("=" * 80)
        for treatment_id in treatment_ids:
            row = fetch_treatment_summary(conn, treatment_id)
            if not row:
                print(f"{treatment_id}: NOT FOUND")
                continue
            print(f"source     : {row['source_table']}")
            print(f"id         : {row['id']}")
            print(f"device_id  : {row['device_id']}")
            print(f"patient_id : {row['patient_id']}")
            print(f"start_time : {row['start_time']}")
            print(f"end_time   : {row['end_time']}")
            print(f"last_seen  : {row['last_seen_time']}")
            print(f"outcome    : {row['outcome']}")
            print(f"packets    : {row['total_packets']}")
            print("-" * 80)

        before = count_rows(conn, treatment_ids)
        print("\nAFFECTED ROW COUNTS")
        print("=" * 80)
        for table, count in before.items():
            print(f"{table:<28} {count}")

        if not args.apply:
            print("\nPreview only. Re-run with --apply to execute.")
            return 0

        backup_path = backup_db(db_path)
        shifted = apply_shift(conn, treatment_ids, delta)

        print("\nSHIFT COMPLETED")
        print("=" * 80)
        if backup_path:
            print(f"Backup: {backup_path}")
        for table, count in shifted.items():
            print(f"{table:<28} {count}")

        print("\nUPDATED TREATMENTS")
        print("=" * 80)
        for treatment_id in treatment_ids:
            row = fetch_treatment_summary(conn, treatment_id)
            if not row:
                continue
            print(f"source     : {row['source_table']}")
            print(f"id         : {row['id']}")
            print(f"device_id  : {row['device_id']}")
            print(f"patient_id : {row['patient_id']}")
            print(f"start_time : {row['start_time']}")
            print(f"end_time   : {row['end_time']}")
            print(f"last_seen  : {row['last_seen_time']}")
            print(f"outcome    : {row['outcome']}")
            print("-" * 80)

        print("\nNEXT")
        print("=" * 80)
        print("1. Repair trends.db for the same device(s)")
        print("2. Restart backend")
        print("3. Resume LIVE only")
        print("4. Verify new packets append after the repaired timestamps")
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
