import sqlalchemy as sa
e=sa.create_engine('postgresql://prismaflex:prismaflex@localhost:5432/prismaflex')
c=e.connect()
rows=c.execute(sa.text("SELECT id FROM treatments WHERE patient_id='PT_DEV_EVENT' AND outcome='IN_PROGRESS' ORDER BY start_time DESC LIMIT 1")).fetchall()
if rows:
    tid=rows[0][0]
    print('Treatment:', tid)
    r=c.execute(sa.text('SELECT row_code, stable_at FROM treatment_journal_rows WHERE treatment_id=:tid ORDER BY snapshot_time DESC LIMIT 15'), {'tid': str(tid)}).fetchall()
    for x in r:
        d = dict(x._mapping)
        print(f"Row: {d['row_code']}, stable_at: {d['stable_at']}")
else:
    print("No IN_PROGRESS treatment found for PT_DEV_EVENT")
c.close()
