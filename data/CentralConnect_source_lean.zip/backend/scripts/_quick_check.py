"""Quick DB check — avoids PowerShell escaping issues."""
import sqlalchemy as sa

e = sa.create_engine("postgresql://prismaflex:prismaflex@localhost:5432/prismaflex")
c = e.connect()

# 1. Count
print("=== COUNTS ===")
print("treatments:", c.execute(sa.text("SELECT count(*) FROM treatments")).scalar())
print("journal_rows:", c.execute(sa.text("SELECT count(*) FROM treatment_journal_rows WHERE is_deleted=false")).scalar())

# 2. Source/kind distribution
print("\n=== SOURCE x KIND ===")
rows = c.execute(sa.text(
    "SELECT source, row_kind, count(*) as cnt "
    "FROM treatment_journal_rows WHERE is_deleted=false "
    "GROUP BY source, row_kind ORDER BY source, row_kind"
)).fetchall()
for r in rows:
    print(f"  {r[0]:10s} {r[1]:15s} {r[2]}")

# 3. Latest treatment journal details
print("\n=== LATEST TREATMENT ===")
t = c.execute(sa.text(
    "SELECT id, device_id, patient_id, fsm_state, total_packets, start_time "
    "FROM treatments ORDER BY created_at DESC LIMIT 1"
)).fetchone()
if t:
    print(f"  id={t[0]}, device={t[1]}, patient={t[2]}, state={t[3]}, pkts={t[4]}")
    jrows = c.execute(sa.text(
        "SELECT row_code, row_kind, hour_slot, source, snapshot_time "
        "FROM treatment_journal_rows "
        "WHERE treatment_id = :tid AND is_deleted=false "
        "ORDER BY snapshot_time ASC"
    ), {"tid": t[0]}).fetchall()
    print(f"  journal rows: {len(jrows)}")
    for j in jrows:
        print(f"    {j[0]:8s} {j[1]:15s} slot={str(j[2] or ''):5s} src={j[3]:10s} t={j[4]}")

    # 4. hour_slot NULL check for HOUR rows
    null_slots = c.execute(sa.text(
        "SELECT count(*) FROM treatment_journal_rows "
        "WHERE row_kind='HOUR' AND hour_slot IS NULL AND is_deleted=false"
    )).scalar()
    print(f"\n=== NULL hour_slot on HOUR rows: {null_slots} ===")

    # 5. row_code vs hour_slot mismatch
    mismatched = c.execute(sa.text(
        "SELECT count(*) FROM treatment_journal_rows "
        "WHERE row_kind='HOUR' AND hour_slot IS NOT NULL "
        "AND row_code != 'H' || LPAD(hour_slot::text, 2, '0') "
        "AND is_deleted=false"
    )).scalar()
    print(f"=== row_code/hour_slot MISMATCH: {mismatched} ===")
else:
    print("  (no treatments)")

c.close()
print("\nDone.")
