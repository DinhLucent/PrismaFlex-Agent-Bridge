#!/usr/bin/env python3
"""
Clear dashboard runtime state stored in backend/trends.db.

Safe scope:
- pressure_trends
- parameter_events
- alarm_history
- device_sessions

Does NOT touch PostgreSQL treatment history.
"""

from __future__ import annotations

import argparse
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DB_PATH = ROOT / "backend" / "trends.db"
BACKUP_DIR = ROOT / "backend" / "backups"
TABLES = (
    "pressure_trends",
    "parameter_events",
    "alarm_history",
    "device_sessions",
)


def backup_db(db_path: Path) -> Path | None:
    if not db_path.exists():
        return None

    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"trends_before_clear_{stamp}.db"
    shutil.copy2(db_path, backup_path)
    return backup_path


def count_rows(conn: sqlite3.Connection, device_id: str | None) -> dict[str, int]:
    result: dict[str, int] = {}
    for table in TABLES:
        where = ""
        params: tuple[object, ...] = ()
        if device_id:
            if table == "device_sessions":
                where = " WHERE device_id = ?"
            else:
                where = " WHERE device_id = ?"
            params = (device_id,)
        row = conn.execute(f"SELECT COUNT(*) FROM {table}{where}").fetchone()
        result[table] = int(row[0] if row else 0)
    return result


def clear_rows(conn: sqlite3.Connection, device_id: str | None) -> None:
    for table in TABLES:
        if device_id:
            conn.execute(f"DELETE FROM {table} WHERE device_id = ?", (device_id,))
        else:
            conn.execute(f"DELETE FROM {table}")
    conn.commit()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Clear dashboard runtime state from backend/trends.db")
    scope = parser.add_mutually_exclusive_group(required=True)
    scope.add_argument("--device-id", help="Clear runtime state for one device only, e.g. PF_003")
    scope.add_argument("--all", action="store_true", help="Clear runtime state for all devices")
    parser.add_argument("--db-path", help="Optional absolute path to trends.db")
    parser.add_argument("--apply", action="store_true", help="Apply deletion. Without this flag the script only previews.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    db_path = Path(args.db_path).expanduser() if args.db_path else DEFAULT_DB_PATH

    print("=" * 80)
    print("CLEAR DASHBOARD RUNTIME STATE")
    print("=" * 80)
    print(f"DB: {db_path}")

    if not db_path.exists():
        print("Trend DB not found. Nothing to clear.")
        return 0

    device_id = args.device_id.strip() if args.device_id else None
    scope_label = device_id or "ALL DEVICES"
    print(f"Scope: {scope_label}")

    conn = sqlite3.connect(db_path)
    try:
        before = count_rows(conn, device_id)

        print("\nROWS TO DELETE")
        print("=" * 80)
        for table, count in before.items():
            print(f"{table:<20} {count}")

        if not args.apply:
            print("\nPreview only. Re-run with --apply to execute.")
            return 0

        backup_path = backup_db(db_path)
        clear_rows(conn, device_id)
        after = count_rows(conn, device_id)

        print("\nDELETION COMPLETED")
        print("=" * 80)
        if backup_path:
            print(f"Backup: {backup_path}")
        for table, count in after.items():
            print(f"{table:<20} {count}")

        print("\nNEXT")
        print("=" * 80)
        print("1. Restart backend")
        print("2. Hard refresh frontend or clear site data")
        print("3. Resume LIVE ingest")
        print("4. Verify chart starts fresh")
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
