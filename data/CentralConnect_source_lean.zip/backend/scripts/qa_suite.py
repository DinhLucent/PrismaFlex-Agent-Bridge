"""
QA Automated Test Suite - Treatment Journal Fixes (v2)
"""
import requests
import sqlalchemy as sa
import subprocess

API = "http://127.0.0.1:8000"
engine = sa.create_engine('postgresql://prismaflex:prismaflex@localhost:5432/prismaflex')
results = []

def log(tc_id, name, passed, detail=""):
    status = "PASS" if passed else ("FAIL" if passed is False else "SKIP")
    results.append({"id": tc_id, "name": name, "passed": passed, "detail": detail})
    print(f"  [{status}] {tc_id} | {name}" + (f" -- {detail}" if detail else ""))

print("=" * 70)
print("QA AUTOMATED TEST SUITE - Treatment Journal Fixes (v2)")
print("=" * 70)

# Setup: Find PT_DEV_EVENT IN_PROGRESS treatment
with engine.connect() as c:
    row = c.execute(sa.text(
        "SELECT id, patient_id, outcome FROM treatments "
        "WHERE patient_id = 'PT_DEV_EVENT' AND outcome = 'IN_PROGRESS' "
        "ORDER BY start_time DESC LIMIT 1"
    )).fetchone()

if not row:
    print("No PT_DEV_EVENT IN_PROGRESS treatment found")
    exit(1)

tid = str(row[0])
print(f"\nTarget: {row[1]} ({tid[:8]}...) -- {row[2]}")
print("-" * 70)

# === 1. COT MOC ===
print("\n[1] COT MOC (Milestone)")
with engine.connect() as c:
    proj = c.execute(sa.text(
        "SELECT journal_row_count FROM treatment_list_projection WHERE id = :tid"
    ), {"tid": tid}).fetchone()
    if proj:
        count = proj[0]
        log("1.1", "Cot moc has numeric value", count is not None and count > 0, f"value={count}")
    else:
        log("1.1", "Cot moc has numeric value", False, "Projection not found")

# === 2. KHANG DONG ===
print("\n[2] KHANG DONG (Anticoagulant)")
with engine.connect() as c:
    anticoag = c.execute(sa.text(
        "SELECT anticoag_type FROM treatment_list_projection WHERE id = :tid"
    ), {"tid": tid}).fetchone()
    val = anticoag[0] if anticoag else None
    log("2.1", "Khang dong has value for PT_DEV_EVENT", val is not None, f"value='{val}'")

    mappings = c.execute(sa.text(
        "SELECT anticoag_type, COUNT(*) FROM treatment_list_projection "
        "WHERE anticoag_type IS NOT NULL GROUP BY anticoag_type"
    )).fetchall()
    valid_values = {'None', 'Heparin', 'Citrate'}
    all_valid = all(m[0] in valid_values for m in mappings)
    log("2.2", "Mapping only contains None/Heparin/Citrate", all_valid,
        str([f"{m[0]}={m[1]}" for m in mappings]))

# === 3. STABLE-ROW PARTIAL LOCK ===
print("\n[3] STABLE-ROW PARTIAL LOCK")

h_nurse = {"X-User-Role": "nurse", "X-Operator-Name": "QA_Tester", "Content-Type": "application/json"}
h_doctor = {"X-User-Role": "doctor", "X-Operator-Name": "QA_Doctor", "Content-Type": "application/json"}

# 3.1.1 Edit H00 (stable row) as nurse
r = requests.put(f"{API}/api/v1/treatments/{tid}/snapshots/H00",
                  headers=h_nurse, json={"hep_bolus": 15})
log("3.1.1", "Edit H00 (stable) nurse", r.status_code == 200, f"status={r.status_code}")

# 3.1.2 Edit OC_01 (stable row) as nurse
r = requests.put(f"{API}/api/v1/treatments/{tid}/snapshots/OC_01",
                  headers=h_nurse, json={"qb": 200})
log("3.1.2", "Edit OC_01 (stable) nurse", r.status_code == 200, f"status={r.status_code}")

# 3.1.5 Edit OC_05 as doctor
r = requests.put(f"{API}/api/v1/treatments/{tid}/snapshots/OC_05",
                  headers=h_doctor, json={"qb": 210})
log("3.1.5", "Edit OC_05 (stable) doctor", r.status_code == 200, f"status={r.status_code}")

# 3.2.1 Find the active row
with engine.connect() as c:
    last_row = c.execute(sa.text(
        "SELECT row_code, stable_at FROM treatment_journal_rows "
        "WHERE treatment_id = :tid AND is_deleted = false "
        "ORDER BY snapshot_time DESC LIMIT 1"
    ), {"tid": tid}).fetchone()

if last_row:
    lc = last_row[0]
    ls = last_row[1]
    print(f"  [INFO] Last row: {lc}, stable_at: {ls}")
    if ls is None:
        r = requests.put(f"{API}/api/v1/treatments/{tid}/snapshots/{lc}",
                          headers=h_nurse, json={"qb": 999})
        log("3.2.1", f"Block active row ({lc})", r.status_code == 500, f"status={r.status_code}")
    else:
        log("3.2.1", f"Active row ({lc}) is stable (telemetry stopped)", True, "OK")

# 3.3 Approval gate
print("\n[3.3] Lock gates")
with engine.connect() as c:
    approved = c.execute(sa.text(
        "SELECT id FROM treatment_list_projection WHERE approval_status = 'APPROVED' LIMIT 1"
    )).fetchone()

if approved:
    atid = str(approved[0])
    r = requests.put(f"{API}/api/v1/treatments/{atid}/snapshots/H00",
                      headers=h_nurse, json={"qb": 100})
    log("3.3.1", "Block edit APPROVED treatment", r.status_code in (403, 409), f"status={r.status_code}")
else:
    log("3.3.1", "Block edit APPROVED treatment", None, "No APPROVED treatment -- SKIP")

# 3.4 Clinical Notes always allowed
r = requests.put(f"{API}/api/v1/treatments/{tid}/snapshots/H00",
                  headers=h_nurse, json={"clinical_notes": "QA test note"})
log("3.4.1", "Clinical notes always editable", r.status_code == 200, f"status={r.status_code}")

# === 4. BANNER ===
print("\n[4] BANNER (API level)")
r = requests.get(f"{API}/api/v1/treatments/{tid}")
if r.ok:
    data = r.json()
    outcome = data.get('outcome', '')
    log("4.1", "Treatment outcome is IN_PROGRESS", outcome == "IN_PROGRESS", f"outcome={outcome}")
else:
    log("4.1", "Treatment outcome is IN_PROGRESS", False, f"status={r.status_code}")

# === 5. COMPRESSION ERROR ===
print("\n[5] COMPRESSION ERROR")
result = subprocess.run(
    ["python", "-c", "from services.treatment.raw_streamer import RawDataStreamer; print(hasattr(RawDataStreamer, 'compress_treatment_file'))"],
    capture_output=True, text=True,
    cwd=r"d:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\backend"
)
has_method = result.stdout.strip() == "True"
log("5.1", "RawDataStreamer has NO compress_treatment_file", not has_method, f"hasattr={result.stdout.strip()}")

with open(r"d:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\backend\services\treatment\treatment_recorder.py", "r", encoding="utf-8") as f:
    content = f.read()
has_call = "compress_treatment_file" in content
log("5.2", "treatment_recorder has NO compress calls", not has_call, f"found={has_call}")

# === 6. REGRESSION ===
print("\n[6] REGRESSION")

r = requests.get(f"{API}/api/v1/treatments?limit=5")
items = r.json().get('items', []) if r.ok else []
log("6.1", "GET /treatments list", r.ok and len(items) > 0, f"count={len(items)}")

r = requests.get(f"{API}/api/v1/treatments/{tid}/snapshots")
snaps = r.json() if r.ok else []
log("6.2", "GET /snapshots returns data", r.ok and len(snaps) > 0, f"rows={len(snaps)}")

r = requests.get(f"{API}/api/v1/treatments?outcome=IN_PROGRESS&limit=5")
log("6.5", "Filter by outcome works", r.ok, f"status={r.status_code}")

# === SUMMARY ===
print("\n" + "=" * 70)
passed = sum(1 for r in results if r['passed'] is True)
failed = sum(1 for r in results if r['passed'] is False)
skipped = sum(1 for r in results if r['passed'] is None)
total = len(results)
print(f"TOTAL: {total} | PASS: {passed} | FAIL: {failed} | SKIP: {skipped}")

if failed:
    print("\nFAILED:")
    for r in results:
        if r['passed'] is False:
            print(f"  X {r['id']}: {r['name']} -- {r['detail']}")
else:
    print("\nALL TESTS PASSED!")
