"""Cleanup: fix stale anticoag_type='None' entries (from old wrong mapping) and re-run correct backfill"""
import sqlalchemy as sa

ENGINE = sa.create_engine("postgresql://prismaflex:prismaflex@localhost:5432/prismaflex")
ANTICOAG_MAP = {0: "None", 1: "Heparin", 2: "Citrate", 3: "Citrate"}

def main():
    with ENGINE.connect() as c:
        # 1. Clear all previous wrong anticoag mappings
        r = c.execute(sa.text("UPDATE treatment_list_projection SET anticoag_type = NULL, anticoag_type_id = NULL WHERE anticoag_type IS NOT NULL"))
        c.commit()
        print(f"Cleared {r.rowcount} old anticoag entries")

        # 2. Re-apply correct mapping from journal rows
        rows = c.execute(sa.text("""
            SELECT DISTINCT ON (treatment_id) 
                treatment_id, anticoag_type_id
            FROM treatment_journal_rows
            WHERE anticoag_type_id IS NOT NULL
            ORDER BY treatment_id, snapshot_time DESC
        """)).fetchall()

        updated = 0
        for r in rows:
            tid = r.treatment_id
            acid = r.anticoag_type_id
            aname = ANTICOAG_MAP.get(acid, f"Unknown({acid})")

            c.execute(
                sa.text("UPDATE treatment_list_projection SET anticoag_type_id = :acid, anticoag_type = :aname WHERE id = :tid"),
                {"acid": acid, "aname": aname, "tid": tid}
            )
            updated += 1

        c.commit()
        print(f"Backfilled anticoag_type for {updated} treatments")

        # 3. Verify
        check = c.execute(sa.text(
            "SELECT patient_id, anticoag_type, anticoag_type_id FROM treatment_list_projection WHERE anticoag_type IS NOT NULL ORDER BY start_time DESC LIMIT 15"
        )).fetchall()
        for r in check:
            print(dict(r._mapping))

if __name__ == "__main__":
    main()
