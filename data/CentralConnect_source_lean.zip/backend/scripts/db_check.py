"""
QA Validation Script — Sprint 7 Step 05 (PostgreSQL)

Checks:
  1. All journal rows have valid `source` and `row_kind`
  2. HOUR rows have non-null `hour_slot` matching row_code
  3. H-labels are sequential (H00, H01, H02 …) with no gaps
  4. OC-labels are sequential per treatment
  5. `snapshot_time` is monotonically increasing per treatment
  6. No orphan journal rows (FK to treatments)
  7. Summary of treatments with row counts

Usage:
  python backend/scripts/db_check.py
"""

import sqlalchemy as sa
from datetime import datetime

DB_URL = "postgresql://prismaflex:prismaflex@localhost:5432/prismaflex"

engine = sa.create_engine(DB_URL)


def run():
    with engine.connect() as conn:
        # ──────────────────────────────────────────────
        # 1. Treatment overview
        # ──────────────────────────────────────────────
        treatments = conn.execute(sa.text("""
            SELECT t.id, t.device_id, t.patient_id, t.fsm_state,
                   t.total_packets, t.start_time, t.created_at,
                   COUNT(j.id) as row_count
            FROM treatments t
            LEFT JOIN treatment_journal_rows j
              ON j.treatment_id = t.id AND j.is_deleted = false
            GROUP BY t.id
            ORDER BY t.created_at DESC
            LIMIT 20
        """)).fetchall()

        print("=" * 100)
        print("TREATMENTS (last 20)")
        print(f"{'ID':>38} | {'DEVICE':<18} | {'STATE':<7} | {'PKTS':<6} | {'ROWS':<5} | START_TIME")
        print("-" * 100)
        for t in treatments:
            tid = str(t.id)[:36]
            print(f"{tid:>38} | {t.device_id:<18} | {t.fsm_state:<7} | {str(t.total_packets):<6} | {str(t.row_count):<5} | {t.start_time}")
        print(f"\nTotal treatments shown: {len(treatments)}")

        # ──────────────────────────────────────────────
        # 2. Journal rows for latest treatment
        # ──────────────────────────────────────────────
        if not treatments:
            print("\nNo treatments found.")
            return

        latest = treatments[0]
        rows = conn.execute(sa.text("""
            SELECT row_code, row_kind, hour_slot, source, snapshot_time, stable_at
            FROM treatment_journal_rows
            WHERE treatment_id = :tid AND is_deleted = false
            ORDER BY snapshot_time ASC
        """), {"tid": latest.id}).fetchall()

        print(f"\n{'=' * 80}")
        print(f"JOURNAL ROWS for latest treatment: {latest.id}")
        print(f"{'CODE':<8} | {'KIND':<15} | {'SLOT':<5} | {'SOURCE':<10} | {'STABLE':<6} | SNAPSHOT_TIME")
        print("-" * 80)
        for r in rows:
            stable = "YES" if r.stable_at else "NO"
            print(f"{r.row_code:<8} | {r.row_kind:<15} | {str(r.hour_slot or ''):<5} | {r.source:<10} | {stable:<6} | {r.snapshot_time}")

        # ──────────────────────────────────────────────
        # 3. Validation checks
        # ──────────────────────────────────────────────
        print(f"\n{'=' * 80}")
        print("VALIDATION CHECKS")
        print("-" * 80)
        errors = []

        # Check 3a: Invalid source values
        bad_source = conn.execute(sa.text("""
            SELECT COUNT(*) as cnt FROM treatment_journal_rows
            WHERE source NOT IN ('LIVE','BACKFILL','MANUAL','RECOVERY')
        """)).scalar()
        _check(errors, bad_source == 0, f"Invalid source values: {bad_source} rows")

        # Check 3b: Invalid row_kind values
        bad_kind = conn.execute(sa.text("""
            SELECT COUNT(*) as cnt FROM treatment_journal_rows
            WHERE row_kind NOT IN ('HOUR','ORDER_CHANGE')
        """)).scalar()
        _check(errors, bad_kind == 0, f"Invalid row_kind values: {bad_kind} rows")

        # Check 3c: HOUR rows should have hour_slot matching row_code
        mismatched = conn.execute(sa.text("""
            SELECT COUNT(*) as cnt FROM treatment_journal_rows
            WHERE row_kind = 'HOUR'
              AND hour_slot IS NOT NULL
              AND row_code != 'H' || LPAD(hour_slot::text, 2, '0')
        """)).scalar()
        _check(errors, mismatched == 0, f"hour_slot/row_code mismatch: {mismatched} rows")

        # Check 3d: HOUR rows with NULL hour_slot
        null_slot = conn.execute(sa.text("""
            SELECT COUNT(*) as cnt FROM treatment_journal_rows
            WHERE row_kind = 'HOUR' AND hour_slot IS NULL
        """)).scalar()
        _check(errors, null_slot == 0, f"HOUR rows with NULL hour_slot: {null_slot} rows")

        # Check 3e: Orphan journal rows (no parent treatment)
        orphans = conn.execute(sa.text("""
            SELECT COUNT(*) as cnt FROM treatment_journal_rows j
            LEFT JOIN treatments t ON t.id = j.treatment_id
            WHERE t.id IS NULL
        """)).scalar()
        _check(errors, orphans == 0, f"Orphan journal rows (no treatment): {orphans}")

        # Check 3f: Source distribution
        dist = conn.execute(sa.text("""
            SELECT source, row_kind, COUNT(*) as cnt
            FROM treatment_journal_rows
            WHERE is_deleted = false
            GROUP BY source, row_kind
            ORDER BY source, row_kind
        """)).fetchall()
        print(f"\n  Source distribution:")
        for d in dist:
            print(f"    {d.source:<10} {d.row_kind:<15} {d.cnt} rows")

        # Check 3g: H-sequence gaps per treatment (latest)
        h_rows = [r for r in rows if r.row_kind == "HOUR"]
        if h_rows:
            slots = sorted([r.hour_slot for r in h_rows if r.hour_slot is not None])
            if slots:
                expected = list(range(slots[0], slots[-1] + 1))
                missing = set(expected) - set(slots)
                _check(errors, len(missing) == 0,
                       f"H-sequence gaps in latest treatment: missing slots {sorted(missing)}")
            else:
                _check(errors, False, "All HOUR rows have NULL hour_slot in latest treatment")

        # Summary
        print(f"\n{'=' * 80}")
        if errors:
            print(f"⚠ {len(errors)} ISSUE(S) FOUND:")
            for e in errors:
                print(f"  ✗ {e}")
        else:
            print("✓ ALL CHECKS PASSED")
        print("=" * 80)


def _check(errors: list, condition: bool, msg: str):
    if condition:
        print(f"  ✓ {msg.split(':')[0]}: OK")
    else:
        errors.append(msg)
        print(f"  ✗ {msg}")


if __name__ == "__main__":
    run()
