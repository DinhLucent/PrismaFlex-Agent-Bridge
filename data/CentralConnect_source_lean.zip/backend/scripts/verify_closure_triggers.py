import os
import sys
import asyncio
from datetime import datetime, timezone, timedelta

sys.path.append(os.path.join(os.getcwd(), "backend"))
from sqlalchemy import create_engine, text
from db.postgres.session import get_session_factory
from services.treatment.postgres_treatment_db import PostgresTreatmentDB
from services.treatment.raw_streamer import RawDataStreamer
from services.treatment.treatment_recorder import TreatmentRecorderService

class MockStreamer(RawDataStreamer):
    async def stream_packet(self, device_id, treatment_id, packet_data):
        pass # Mock streaming
    async def compress_treatment_file(self, device_id, treatment_id):
        pass

async def run_tests():
    engine = create_engine("postgresql://prismaflex:prismaflex@localhost:5432/prismaflex")
    db = PostgresTreatmentDB()
    recorder = TreatmentRecorderService(db, MockStreamer())

    def send_pkt(device_id, patient_id, therapy_status, run_time, time_str=None):
        ts = time_str if time_str else datetime.now(timezone.utc).isoformat()
        b = {"parameters": [{"id": 461, "value": run_time, "type": "Actual"}]} if run_time is not None else {"parameters": []}
        h = {"machine_id": 999, "patient_id": patient_id, "therapy_type_id": 1, "therapy_status_id": therapy_status, "timestamp": ts}
        return ts, h, b, {"timestamp": ts}

    # TC-1: Close by END packet
    print("=== TC-1: Close by END packet ===")
    ts1, h1, b1, m1 = send_pkt("DEV_TC1", "PT_TC1", 5, 100)
    await recorder.process_packet("DEV_TC1", ts1, h1, b1, m1, is_live=True)
    
    ts2, h2, b2, m2 = send_pkt("DEV_TC1", "PT_TC1", 8, 120)
    await recorder.process_packet("DEV_TC1", ts2, h2, b2, m2, is_live=True)

    # TC-2: Patient Change
    print("=== TC-2: Patient Change ===")
    ts1, h1, b1, m1 = send_pkt("DEV_TC2", "PT_TC2_OLD", 5, 100)
    await recorder.process_packet("DEV_TC2", ts1, h1, b1, m1, is_live=True)
    
    ts2, h2, b2, m2 = send_pkt("DEV_TC2", "PT_TC2_NEW", 5, 10)
    await recorder.process_packet("DEV_TC2", ts2, h2, b2, m2, is_live=True)

    # TC-3: Run_Time Reset
    print("=== TC-3: RUN_TIME Reset ===")
    ts1, h1, b1, m1 = send_pkt("DEV_TC3", "PT_TC3", 5, 150)
    await recorder.process_packet("DEV_TC3", ts1, h1, b1, m1, is_live=True)
    
    ts2, h2, b2, m2 = send_pkt("DEV_TC3", "PT_TC3", 5, 0)
    await recorder.process_packet("DEV_TC3", ts2, h2, b2, m2, is_live=True)

    # TC-4: Timeout
    print("=== TC-4: Timeout ===")
    ts1, h1, b1, m1 = send_pkt("DEV_TC4", "PT_TC4", 5, 100)
    await recorder.process_packet("DEV_TC4", ts1, h1, b1, m1, is_live=True)
    
    with engine.connect() as conn:
        conn.execute(text("UPDATE treatments SET created_at = NOW() - INTERVAL '25 hours', updated_at = NOW() - INTERVAL '25 hours' WHERE device_id = 'DEV_TC4' AND outcome = 'IN_PROGRESS';"))
        conn.commit()
    
    # Manually trigger Sweep
    closed_count = recorder.enforce_auto_close()
    print(f"Force-aged DEV_TC4 by 25 hours. Sweep executed. Auto-closed: {closed_count}")

if __name__ == "__main__":
    asyncio.run(run_tests())
