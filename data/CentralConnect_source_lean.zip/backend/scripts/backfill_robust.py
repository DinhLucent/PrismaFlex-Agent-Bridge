import sys
import os

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), "backend"))

from db.postgres.session import get_session_factory
from sqlalchemy import text

def backfill():
    factory = get_session_factory()
    session = factory()
    try:
        print("Starting ROBUST backfill for treatment_list_projection...")
        
        # 1. Update therapy_type (Mapping IDs to Strings)
        therapy_map = {
            1: "CVVH",
            2: "CVVHD",
            3: "CVVHDF",
            4: "SCUF",
            5: "TPE",
            6: "HEMOPERFUSION"
        }
        
        for tid, name in therapy_map.items():
            sql = f"UPDATE treatment_list_projection SET therapy_type = '{name}' WHERE therapy_type_id = {tid}"
            session.execute(text(sql))
            
        # 2. Update anticoag_type (Mapping IDs to Strings)
        anticoag_map = {
            1: "None",
            2: "Citrate",
            3: "Heparin"
        }
        
        for aid, name in anticoag_map.items():
            sql = f"UPDATE treatment_list_projection SET anticoag_type = '{name}' WHERE anticoag_type_id = {aid}"
            session.execute(text(sql))

        # 3. Fallback for those with null names but have IDs from the master table
        sql_sync = """
        UPDATE treatment_list_projection p
        SET 
            therapy_type_id = t.therapy_type_id,
            anticoag_type_id = t.anticoag_type_id
        FROM treatments t
        WHERE p.id = t.id AND (p.therapy_type_id IS NULL OR p.anticoag_type_id IS NULL)
        """
        session.execute(text(sql_sync))
        
        # Re-run mappings after sync
        for tid, name in therapy_map.items():
            sql = f"UPDATE treatment_list_projection SET therapy_type = '{name}' WHERE therapy_type_id = {tid} AND therapy_type IS NULL"
            session.execute(text(sql))
            
        for aid, name in anticoag_map.items():
            sql = f"UPDATE treatment_list_projection SET anticoag_type = '{name}' WHERE anticoag_type_id = {aid} AND anticoag_type IS NULL"
            session.execute(text(sql))

        session.commit()
        print("Backfill execution finished.")
        
        # Verification
        print("\n--- VERIFICATION (Latest 5) ---")
        sql_check = "SELECT patient_id, therapy_type, anticoag_type FROM treatment_list_projection ORDER BY start_time DESC LIMIT 5"
        res = session.execute(text(sql_check)).fetchall()
        for r in res:
            print(f"Patient: {r[0]} | Mode: {r[1]} | Anticoag: {r[2]}")

    except Exception as e:
        session.rollback()
        print(f"Error: {e}")
    finally:
        session.close()

if __name__ == "__main__":
    backfill()
