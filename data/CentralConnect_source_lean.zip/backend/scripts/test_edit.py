import requests

# Find treatment ID for PT_DEV_EVENT
import sqlalchemy as sa
e=sa.create_engine('postgresql://prismaflex:prismaflex@localhost:5432/prismaflex')
c=e.connect()
rows=c.execute(sa.text("SELECT id FROM treatments WHERE patient_id='PT_DEV_EVENT' ORDER BY start_time DESC LIMIT 1")).fetchall()
tid = str(rows[0][0])
c.close()

print(f"Testing edit on {tid} hour OC_17")
url = f"http://127.0.0.1:8000/api/v1/treatments/{tid}/snapshots/OC_17"
headers = {"X-User-Role": "nurse", "X-Operator-Name": "Test Nurse"}
data = {"qb": 150}

resp = requests.put(url, headers=headers, json=data)
print("Status:", resp.status_code)
print("Response:", resp.json())
