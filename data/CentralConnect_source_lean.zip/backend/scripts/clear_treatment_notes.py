"""
Administrative utility to clear treatment notes safely.

Supports:
- clearing notes for one treatment
- clearing notes for all treatments
- dry-run preview before deleting

Also clears legacy `treatments.clinical_notes` and refreshes
`treatment_list_projection.note_count` for affected treatments.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from uuid import UUID

from sqlalchemy import delete, func, or_, select, update


BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from db.postgres.models.treatment_notes import TreatmentNote
from db.postgres.models.treatments import Treatment
from db.postgres.session import get_session
from db.postgres.services.projection_service import ProjectionService


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Clear append-only treatment notes and sync projections."
    )
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument(
        "--treatment-id",
        help="Clear notes for a single treatment UUID.",
    )
    target.add_argument(
        "--all",
        action="store_true",
        help="Clear notes for all treatments.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview affected rows without deleting anything.",
    )
    parser.add_argument(
        "--yes",
        action="store_true",
        help="Actually perform deletion. Required unless --dry-run is used.",
    )
    return parser.parse_args()


def _resolve_target_ids(args: argparse.Namespace) -> list[UUID]:
    with get_session() as session:
        if args.treatment_id:
            try:
                treatment_id = UUID(args.treatment_id)
            except ValueError as exc:
                raise SystemExit(f"Invalid UUID: {args.treatment_id}") from exc

            treatment = session.get(Treatment, treatment_id)
            if not treatment:
                raise SystemExit(f"Treatment not found: {treatment_id}")
            return [treatment_id]

        rows = session.execute(
            select(Treatment.id)
            .where(
                or_(
                    Treatment.clinical_notes.is_not(None),
                    select(TreatmentNote.id)
                    .where(TreatmentNote.treatment_id == Treatment.id)
                    .exists(),
                )
            )
            .order_by(Treatment.start_time.desc())
        ).all()
        return [row[0] for row in rows]


def _collect_summary(target_ids: list[UUID]) -> tuple[int, int]:
    with get_session() as session:
        note_count = session.scalar(
            select(func.count(TreatmentNote.id)).where(
                TreatmentNote.treatment_id.in_(target_ids)
            )
        ) or 0
        summary_count = session.scalar(
            select(func.count(Treatment.id)).where(
                Treatment.id.in_(target_ids),
                Treatment.clinical_notes.is_not(None),
            )
        ) or 0
        return int(note_count), int(summary_count)


def _run_clear(target_ids: list[UUID]) -> tuple[int, int]:
    with get_session() as session:
        note_delete_result = session.execute(
            delete(TreatmentNote).where(TreatmentNote.treatment_id.in_(target_ids))
        )
        summary_clear_result = session.execute(
            update(Treatment)
            .where(Treatment.id.in_(target_ids))
            .values(clinical_notes=None)
        )

        projection_service = ProjectionService(session)
        for treatment_id in target_ids:
            projection_service.refresh(treatment_id)

        return int(note_delete_result.rowcount or 0), int(summary_clear_result.rowcount or 0)


def main() -> int:
    args = _parse_args()
    if not args.dry_run and not args.yes:
        print("Refusing to delete without --yes. Use --dry-run first to preview.")
        return 2

    target_ids = _resolve_target_ids(args)
    if not target_ids:
        print("No treatments matched. Nothing to do.")
        return 0

    note_count, summary_count = _collect_summary(target_ids)

    mode = "ALL treatments" if args.all else f"treatment {target_ids[0]}"
    print(f"Target: {mode}")
    print(f"Affected treatments: {len(target_ids)}")
    print(f"Notes to delete: {note_count}")
    print(f"Legacy summaries to clear: {summary_count}")

    if args.dry_run:
        print("Dry-run complete. No changes were made.")
        return 0

    deleted_notes, cleared_summaries = _run_clear(target_ids)
    print("Clear complete.")
    print(f"Deleted notes: {deleted_notes}")
    print(f"Cleared clinical_notes fields: {cleared_summaries}")
    print("Projection refresh complete.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
