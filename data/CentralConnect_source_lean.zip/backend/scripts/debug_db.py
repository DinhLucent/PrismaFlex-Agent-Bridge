import sys
import os

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), "backend"))

from services.treatment.postgres_treatment_db import PostgresTreatmentDB
from sqlalchemy import text

def inspect():
    db = PostgresTreatmentDB()
    session = db._session()
    try:
        print("--- Table: treatments (Master) ---")
        sql_t = "SELECT id, patient_id, therapy_type_id, anticoag_type_id FROM treatments ORDER BY start_time DESC LIMIT 10"
        res_t = session.execute(text(sql_t)).fetchall()
        for r in res_t:
            print(r._mapping)

        print("\n--- Table: treatment_list_projection (Dashboard) ---")
        sql_p = "SELECT id, therapy_type_id, anticoag_type_id, therapy_type, anticoag_type FROM treatment_list_projection ORDER BY start_time DESC LIMIT 10"
        res_p = session.execute(text(sql_p)).fetchall()
        for r in res_p:
            print(r._mapping)
            
    except Exception as e:
        print(f"Error: {e}")
    finally:
        session.close()

if __name__ == "__main__":
    inspect()
