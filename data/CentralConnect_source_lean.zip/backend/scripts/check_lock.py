import sqlalchemy as sa

engine = sa.create_engine('postgresql://prismaflex:prismaflex@localhost:5432/prismaflex')
with engine.connect() as c:
    # Find treatment by UUID prefix
    res = c.execute(sa.text("SELECT id FROM treatments WHERE id::text LIKE '91c52b04%' LIMIT 1")).fetchall()
    if not res:
        print("Treatment not found")
    else:
        tid = res[0][0]
        print(f"Found treatment: {tid}")
        
        # Check rows OC_16 and OC_17
        rows = c.execute(sa.text("SELECT row_code, stable_at FROM treatment_journal_rows WHERE treatment_id = :tid AND row_code IN ('OC_16', 'OC_17')"), {"tid": str(tid)}).fetchall()
        for r in rows:
            print(dict(r._mapping))
