import sqlalchemy
from sqlalchemy import text

# The user's root postgres URL discovered from .env
ROOT_URL = "postgresql+psycopg2://postgres:7b7f7247f90d4420835428352734976c@localhost:5432/postgres"

def setup():
    engine = sqlalchemy.create_engine(ROOT_URL, isolation_level="AUTOCOMMIT")
    with engine.connect() as conn:
        try:
            # Check if role exists
            res = conn.execute(text("SELECT 1 FROM pg_roles WHERE rolname='prismaflex'")).fetchone()
            if not res:
                print("Creating role prismaflex...")
                conn.execute(text("CREATE ROLE prismaflex WITH LOGIN PASSWORD 'prismaflex' SUPERUSER"))
            else:
                print("Role prismaflex already exists, updating password and permissions...")
                conn.execute(text("ALTER ROLE prismaflex WITH LOGIN PASSWORD 'prismaflex' SUPERUSER"))
            
            # Check if database exists
            res = conn.execute(text("SELECT 1 FROM pg_database WHERE datname='prismaflex'")).fetchone()
            if not res:
                print("Creating database prismaflex...")
                conn.execute(text("CREATE DATABASE prismaflex OWNER prismaflex"))
            else:
                print("Database prismaflex already exists.")
                
            print("Database setup complete.")
        except Exception as e:
            print(f"Error during setup: {e}")

if __name__ == '__main__':
    setup()
