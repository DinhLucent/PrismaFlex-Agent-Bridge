"""
Clear all treatment data for QA replay.
Truncates: journal_rows, phases, notes, config, review_state,
           status_events, snapshot_originals, audit_log,
           raw_packet_manifest, treatment_list_projection, treatments.
"""
import sqlalchemy as sa

e = sa.create_engine("postgresql://prismaflex:prismaflex@localhost:5432/prismaflex")

TABLES = [
    "treatment_journal_rows",
    "treatment_phases",
    "treatment_notes",
    "treatment_config",
    "treatment_review_state",
    "treatment_status_events",
    "snapshot_originals",
    "snapshot_audit_log",
    "raw_packet_manifest",
    "treatment_list_projection",
    "treatments",
]

with e.begin() as conn:
    for t in TABLES:
        try:
            conn.execute(sa.text(f"TRUNCATE TABLE {t} CASCADE"))
            print(f"  TRUNCATED {t}")
        except Exception as ex:
            print(f"  SKIP {t}: {ex}")

print("\nAll treatment data cleared. Ready for 50K replay.")
