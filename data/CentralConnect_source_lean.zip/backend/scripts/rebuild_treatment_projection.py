"""
Rebuild treatment_list_projection from treatments + journal rows + notes.

Safe default:
- upsert only
- does not touch treatments/journal data

Usage:
    python backend/scripts/rebuild_treatment_projection.py
    python backend/scripts/rebuild_treatment_projection.py --reset
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

from sqlalchemy import select, delete, func

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from db.postgres.session import get_session
from db.postgres.models.treatments import Treatment
from db.postgres.models.treatment_list_projection import TreatmentListProjection
from db.postgres.models.treatment_journal_rows import TreatmentJournalRow
from db.postgres.models.treatment_notes import TreatmentNote
from db.postgres.models.treatment_review_state import TreatmentReviewState
from db.postgres.services.projection_service import ProjectionService


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reset", action="store_true", help="Delete all projection rows before rebuild")
    args = parser.parse_args()

    with get_session() as session:
        if args.reset:
            deleted = session.execute(delete(TreatmentListProjection)).rowcount or 0
            print(f"Deleted projection rows: {deleted}")

        treatment_ids = list(
            session.scalars(select(Treatment.id).order_by(Treatment.start_time.asc())).all()
        )
        print(f"Treatments found: {len(treatment_ids)}")

        svc = ProjectionService(session)
        for idx, treatment_id in enumerate(treatment_ids, start=1):
            svc.refresh(treatment_id)
            if idx % 100 == 0:
                session.flush()
                print(f"Rebuilt: {idx}")

        session.flush()

        treat_count = session.scalar(select(func.count()).select_from(Treatment)) or 0
        proj_count = session.scalar(select(func.count()).select_from(TreatmentListProjection)) or 0
        journal_count = session.scalar(select(func.count()).select_from(TreatmentJournalRow)) or 0
        note_count = session.scalar(select(func.count()).select_from(TreatmentNote)) or 0
        review_count = session.scalar(select(func.count()).select_from(TreatmentReviewState)) or 0

        print(f"Treatments            : {treat_count}")
        print(f"Projection rows       : {proj_count}")
        print(f"Journal rows          : {journal_count}")
        print(f"Notes                 : {note_count}")
        print(f"Review states         : {review_count}")
        print("Projection rebuild completed.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
