
import requests
import sqlalchemy as sa
from uuid import UUID

# Configuration
API_BASE = "http://localhost:8000/api/v1"
TREATMENT_ID = "c59cda46-1f20-4604-b029-439f0b81325b"
DB_URL = "postgresql://prismaflex:prismaflex@localhost:5432/prismaflex"

def verify():
    print(f"--- Verifying Treatment Journal for ID: {TREATMENT_ID} ---")
    
    # 1. Fetch initial state
    engine = sa.create_engine(DB_URL)
    with engine.connect() as conn:
        proj = conn.execute(sa.text("SELECT note_count FROM treatment_list_projection WHERE id = :tid"), {"tid": TREATMENT_ID}).fetchone()
        initial_note_count = proj[0] if proj else 0
        print(f"Initial note_count in projection: {initial_note_count}")

    # 2. Add a new clinical note via API
    print("Adding a clinical note...")
    note_content = "Re-verification test note at " + str(sa.func.now())
    headers = {
        "X-Operator-Name": "Antigravity Re-Verifier",
        "X-User-Role": "nurse",
        "Content-Type": "application/json"
    }
    payload = {"content": note_content}
    
    response = requests.post(f"{API_BASE}/treatments/{TREATMENT_ID}/notes/log", headers=headers, json=payload)
    
    if response.status_code != 200:
        print(f"FAILED to add note via API: {response.status_code} {response.text}")
        return

    note_data = response.json()
    print(f"SUCCESS: Note added with ID {note_data.get('id')}")

    # 3. Verify Database Persistence
    print("Verifying persistence in PostgreSQL...")
    with engine.connect() as conn:
        # Check treatment_notes table
        note_row = conn.execute(sa.text("SELECT content, created_at FROM treatment_notes WHERE treatment_id = :tid ORDER BY created_at DESC LIMIT 1"), {"tid": TREATMENT_ID}).fetchone()
        if note_row and note_row[0] == note_content:
            print(f"✓ Note persisted in treatment_notes. Timestamp: {note_row[1]}")
        else:
            print("✗ Note NOT found in treatment_notes or content mismatch")

        # Check treatments table summary
        t_row = conn.execute(sa.text("SELECT clinical_notes FROM treatments WHERE id = :tid"), {"tid": TREATMENT_ID}).fetchone()
        if t_row and "[NURSE]" in t_row[0]:
            print(f"✓ Treatment summary updated: {t_row[0]}")
        else:
            print(f"✗ Treatment summary NOT updated. Value: {t_row[0]}")

        # Check projection update
        proj_row = conn.execute(sa.text("SELECT note_count FROM treatment_list_projection WHERE id = :tid"), {"tid": TREATMENT_ID}).fetchone()
        if proj_row and proj_row[0] == initial_note_count + 1:
            print(f"✓ note_count incremented in projection: {proj_row[0]}")
        else:
            print(f"✗ note_count NOT incremented. Current: {proj_row[0] if proj_row else 'None'}")

    # 4. Verify visual indicator / Audit Trail API
    print("Verifying Audit Trail API...")
    trail_res = requests.get(f"{API_BASE}/treatments/{TREATMENT_ID}/audit-trail")
    if trail_res.status_code == 200:
        events = trail_res.json().get("events", [])
        latest_event = events[0] if events else None
        if latest_event and latest_event.get("category") == "clinical_note":
            print(f"✓ Latest audit event is clinical_note: {latest_event.get('description')}")
        else:
            print(f"✗ Latest audit event mismatch or not found: {latest_event}")
    else:
        print(f"✗ Audit trail API error: {trail_res.status_code}")

if __name__ == "__main__":
    verify()
