import requests
import time
import json
from datetime import datetime, timezone

# Configuration
API_URL = "http://localhost:8000/api/v1/telemetry"
DEVICE_ID = "PF_999"

def send_update(qb_value):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Updating Blood Flow (QB) to: {qb_value}")
    
    payload = {
        "meta": {
            "device_id": DEVICE_ID,
            "timestamp": datetime.now(timezone.utc).isoformat()
        },
        "s_header": {
            "machine_id": 999,
            "patient_id": "SIM_COLOR_TEST",
            "therapy_status_id": 5, # RUNNING
            "therapy_type_id": 3,
            "sw_version": "SIM-V1.0",
            "timestamp": datetime.now(timezone.utc).isoformat()
        },
        "s_body": {
            "parameters": [
                {"id": 17, "value": qb_value, "type": "Actual"}, # Blood Flow
                {"id": 26, "value": 75.5, "type": "Actual"}, # Weight
            ]
        }
    }
    
    try:
        requests.post(API_URL, json=payload)
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    # 1. Set initial value
    send_update(200)
    print("Initial value set to 200. Please open the detail page for PRISMAFLEX_999.")
    time.sleep(5)
    
    # 2. Change value (This should trigger 'was: 200')
    send_update(250)
    print("Value changed to 250. You should see 'was: 200' on the UI.")
    print("Now you can try navigating back to Dashboard and returning to this page.")
    print("The 'was: 200' label should PERSIST.")
