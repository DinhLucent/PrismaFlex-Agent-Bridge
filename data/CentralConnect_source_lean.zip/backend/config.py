"""
Configuration settings for PrismaFlex Backend
"""
from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    """Application settings"""
    
    # Application
    APP_NAME: str = "PrismaFlex Central Station API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False  # Override via .env: DEBUG=true
    
    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # CORS
    CORS_ORIGINS: List[str] = ["*"]
    CORS_CREDENTIALS: bool = False
    CORS_METHODS: List[str] = ["*"]
    CORS_HEADERS: List[str] = ["*"]
    
    # Data Quality
    REALTIME_THRESHOLD_SECONDS: int = 25
    
    # WebSocket
    WS_HEARTBEAT_INTERVAL: int = 30  # seconds
    WS_MAX_CONNECTIONS: int = 100
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # PostgreSQL — override via .env: POSTGRES_URL=postgresql+psycopg2://user:pass@host:5432/db
    POSTGRES_URL: str = "postgresql+psycopg2://prismaflex:prismaflex@localhost:5432/prismaflex"
    
    class Config:
        env_file = ".env"
        case_sensitive = True
        extra = "ignore"


# Global settings instance
settings = Settings()
