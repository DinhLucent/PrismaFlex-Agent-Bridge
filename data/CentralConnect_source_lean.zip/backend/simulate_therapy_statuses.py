import requests
import time
import json
from datetime import datetime, timezone

# Configuration
API_URL = "http://localhost:8000/api/v1/telemetry"
DEVICE_ID = "PF_999"  # Simulator Device
PATIENT_ID = "SIM_COLOR_TEST"

THERAPY_STATUS_MAP = {
    0: "IDLE",
    1: "CUSTOM",
    2: "PRIME",
    3: "PRIME TEST",
    4: "WAITING",
    5: "RUNNING",
    6: "CHANGE BAGS",
    7: "STOPPED",
    8: "END",
    9: "RETURN",
    10: "RECIRC",
    11: "RECIRC PRIME",
    12: "RECIRC TEST",
    13: "RECIRC WAIT",
    14: "CALIBRATION",
    15: "SW LOADING"
}

def send_status(status_id):
    status_name = THERAPY_STATUS_MAP.get(status_id, "UNKNOWN")
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Sending Status ID: {status_id} ({status_name})")
    
    payload = {
        "meta": {
            "device_id": DEVICE_ID,
            "timestamp": datetime.now(timezone.utc).isoformat()
        },
        "s_header": {
            "machine_id": 999,
            "patient_id": PATIENT_ID,
            "therapy_status_id": status_id,
            "therapy_type_id": 3, # CVVHDF
            "sw_version": "SIM-V1.0",
            "timestamp": datetime.now(timezone.utc).isoformat()
        },
        "s_body": {
            "parameters": [
                {"id": 17, "value": 200, "type": "Actual"}, # Blood Flow
                {"id": 26, "value": 75.5, "type": "Actual"}, # Weight
            ]
        }
    }
    
    try:
        response = requests.post(API_URL, json=payload)
        if response.status_code == 200:
            print(f"  Successfully updated to {status_name}")
        else:
            print(f"  Error: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"  Failed to connect: {e}")

def run_simulation():
    print(f"Starting Therapy Status Color Simulation for Device {DEVICE_ID}...")
    print("Each status will display for 5 seconds.\n")
    
    try:
        for status_id in range(16):
            send_status(status_id)
            time.sleep(5)
            
        print("\nSimulation completed successfully!")
    except KeyboardInterrupt:
        print("\nSimulation stopped by user.")

if __name__ == "__main__":
    run_simulation()
