"""
Command-Driven Treatment API Router (PostgreSQL)
=================================================
ADR-6: Clinical API is command-driven, not CRUD-driven.

These endpoints coexist with the legacy treatment_router.py.
Frontend will gradually switch to these once parity is validated.

All commands go through services → repositories → PostgreSQL.
"""
import logging
import uuid as _uuid
from datetime import datetime
from decimal import Decimal
from uuid import UUID

from fastapi import APIRouter, HTTPException, Body, Depends, Request
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any

from db.postgres.session import get_session
from db.postgres.services.journal_command_service import JournalCommandService
from db.postgres.services.journal_query_service import JournalQueryService
from db.postgres.services.review_service import ReviewService
from db.postgres.services.projection_service import ProjectionService

logger = logging.getLogger("PrismaFlex.CommandAPI")

router = APIRouter(prefix="/api/v2/treatments", tags=["treatments-v2-commands"])


# ── RBAC Helper ─────────────────────────────────────────────────

def _require_role(request: Request, allowed: list) -> str:
    """Check X-User-Role header against allowed roles. Returns role."""
    role = (request.headers.get('X-User-Role') or 'nurse').lower()
    if role not in allowed:
        raise HTTPException(
            status_code=403,
            detail=f"Role '{role}' not authorized. Required: {allowed}")
    return role


# ── Request Models ──────────────────────────────────────────────

class EditSnapshotCommand(BaseModel):
    """Command: edit existing snapshot values."""
    row_code: str = Field(..., description="e.g. H00, H01, OC_01")
    fields: Dict[str, Any] = Field(..., description="Field name → new value")
    operator_name: str = Field(..., min_length=2, max_length=60)
    operator_role: Optional[str] = None
    expected_version: Optional[int] = None


class RestoreSnapshotCommand(BaseModel):
    """Command: restore a row to machine-original values."""
    row_code: str
    operator_name: str = Field(..., min_length=2, max_length=60)
    operator_role: Optional[str] = None


class ReviewCommand(BaseModel):
    """Command: submit, approve, reject, or unlock."""
    operator_name: str = Field(..., min_length=2, max_length=60)
    operator_role: Optional[str] = None
    reason: Optional[str] = None


class AddNoteCommand(BaseModel):
    """Command: append a clinical note."""
    content: str = Field(..., min_length=1)
    operator_name: str = Field(..., min_length=2, max_length=60)
    operator_role: Optional[str] = None


# ── Journal Commands ────────────────────────────────────────────

@router.post("/{treatment_id}/edit-snapshot")
def edit_snapshot_values(treatment_id: str, cmd: EditSnapshotCommand, request: Request):
    """Edit allowed manual fields on an existing journal row."""
    _require_role(request, ['nurse', 'doctor', 'admin'])
    try:
        tid = UUID(treatment_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID")

    with get_session() as session:
        svc = JournalCommandService(session)
        result = svc.edit_existing_snapshot_values(
            treatment_id=tid,
            row_code=cmd.row_code,
            fields=cmd.fields,
            operator_name=cmd.operator_name,
            operator_role=cmd.operator_role,
            expected_version=cmd.expected_version,
        )
    if result["status"] == "not_found":
        raise HTTPException(status_code=404, detail=result["message"])
    return result


@router.post("/{treatment_id}/restore-snapshot")
def restore_snapshot(treatment_id: str, cmd: RestoreSnapshotCommand, request: Request):
    """Restore a journal row to its frozen machine-original values."""
    _require_role(request, ['nurse', 'doctor', 'admin'])
    try:
        tid = UUID(treatment_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID")

    with get_session() as session:
        svc = JournalCommandService(session)
        result = svc.restore_existing_snapshot(
            treatment_id=tid,
            row_code=cmd.row_code,
            operator_name=cmd.operator_name,
            operator_role=cmd.operator_role,
        )
    if result["status"] == "not_found":
        raise HTTPException(status_code=404, detail=result["message"])
    return result


# ── Review Commands ─────────────────────────────────────────────

@router.post("/{treatment_id}/submit-review")
def submit_for_review(treatment_id: str, cmd: ReviewCommand, request: Request):
    """Nurse submits a treatment for doctor review."""
    _require_role(request, ['nurse', 'admin'])
    try:
        tid = UUID(treatment_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID")

    with get_session() as session:
        svc = ReviewService(session)
        result = svc.submit_review(
            treatment_id=tid,
            operator_name=cmd.operator_name,
            operator_role=cmd.operator_role,
        )
        if result["status"] == "submitted":
            ProjectionService(session).refresh(tid)
    if result["status"] == "not_found":
        raise HTTPException(status_code=404, detail="Treatment not found")
    if result["status"] == "error":
        raise HTTPException(status_code=409, detail=result["message"])
    return result


@router.post("/{treatment_id}/approve")
def approve_treatment(treatment_id: str, cmd: ReviewCommand, request: Request):
    """Doctor approves a treatment."""
    _require_role(request, ['doctor', 'admin'])
    try:
        tid = UUID(treatment_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID")

    with get_session() as session:
        svc = ReviewService(session)
        result = svc.approve(
            treatment_id=tid,
            operator_name=cmd.operator_name,
            operator_role=cmd.operator_role,
        )
        if result["status"] == "approved":
            ProjectionService(session).refresh(tid)
    if result["status"] == "error":
        raise HTTPException(status_code=409, detail=result["message"])
    return result


@router.post("/{treatment_id}/reject")
def reject_treatment(treatment_id: str, cmd: ReviewCommand, request: Request):
    """Doctor rejects a treatment."""
    _require_role(request, ['doctor', 'admin'])
    try:
        tid = UUID(treatment_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID")

    with get_session() as session:
        svc = ReviewService(session)
        result = svc.reject(
            treatment_id=tid,
            operator_name=cmd.operator_name,
            reason=cmd.reason or "",
            operator_role=cmd.operator_role,
        )
        if result["status"] == "rejected":
            ProjectionService(session).refresh(tid)
    if result["status"] == "error":
        raise HTTPException(status_code=409, detail=result["message"])
    return result


@router.post("/{treatment_id}/unlock")
def unlock_treatment(treatment_id: str, cmd: ReviewCommand, request: Request):
    """Doctor unlocks an approved treatment."""
    _require_role(request, ['doctor', 'admin'])
    try:
        tid = UUID(treatment_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID")

    with get_session() as session:
        svc = ReviewService(session)
        result = svc.unlock(
            treatment_id=tid,
            operator_name=cmd.operator_name,
            operator_role=cmd.operator_role,
        )
        if result["status"] == "unlocked":
            ProjectionService(session).refresh(tid)
    if result["status"] == "error":
        raise HTTPException(status_code=409, detail=result["message"])
    return result


# ── Notes Commands ──────────────────────────────────────────────

@router.post("/{treatment_id}/add-note")
def add_clinical_note(treatment_id: str, cmd: AddNoteCommand, request: Request):
    """Append a clinical note (immutable after creation)."""
    _require_role(request, ['nurse', 'doctor', 'admin'])
    try:
        tid = UUID(treatment_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID")

    with get_session() as session:
        from db.postgres.repositories.notes_repository import NotesRepository
        from db.postgres.models.treatments import Treatment

        repo = NotesRepository(session)
        note = repo.add(
            treatment_id=tid,
            content=cmd.content,
            author_name=cmd.operator_name,
            author_role=cmd.operator_role,
        )
        summary = f"[{(cmd.operator_role or 'nurse').upper()}] {cmd.content[:100]}"
        if len(cmd.content) > 100:
            summary += "..."
        treatment = session.get(Treatment, tid)
        if treatment:
            treatment.clinical_notes = summary
        ProjectionService(session).refresh(tid)
    return {"status": "created", "note_id": note.id}


# ── Query Endpoints (read-only) ────────────────────────────────

def _serialize_model(obj) -> dict | None:
    """Convert a SQLAlchemy model instance to a JSON-safe dict."""
    if obj is None:
        return None
    if isinstance(obj, dict):
        return {k: _serialize_value(v) for k, v in obj.items()}
    d = {}
    for col in obj.__table__.columns:
        d[col.name] = _serialize_value(getattr(obj, col.name))
    return d


def _serialize_value(val):
    """Convert a single value to a JSON-safe type."""
    if val is None:
        return None
    if isinstance(val, datetime):
        return val.isoformat()
    if isinstance(val, _uuid.UUID):
        return str(val)
    if isinstance(val, Decimal):
        return float(val)
    if isinstance(val, bytes):
        return val.decode("utf-8", errors="replace")
    return val


@router.get("/{treatment_id}/detail")
def get_treatment_detail(treatment_id: str):
    """Full treatment detail (master + journal + review + notes)."""
    try:
        tid = UUID(treatment_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID")

    with get_session() as session:
        svc = JournalQueryService(session)
        result = svc.get_treatment_detail(tid)
    if not result:
        raise HTTPException(status_code=404, detail="Treatment not found")

    return {
        "status": "ok",
        "data": {
            "treatment": _serialize_model(result.get("treatment")),
            "journal_rows": [_serialize_model(r) for r in (result.get("journal_rows") or [])],
            "review_state": _serialize_model(result.get("review_state")),
            "notes": [_serialize_model(n) for n in (result.get("notes") or [])],
            "journal_row_count": result.get("journal_row_count", 0),
            "note_count": result.get("note_count", 0),
        },
    }


@router.get("/{treatment_id}/review-compare")
def get_review_compare(treatment_id: str):
    """Current vs original rows for review comparison."""
    try:
        tid = UUID(treatment_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID")

    with get_session() as session:
        svc = JournalQueryService(session)
        result = svc.get_review_compare(tid)
    if not result:
        raise HTTPException(status_code=404, detail="Treatment not found")

    return {
        "status": "ok",
        "data": {
            "current_rows": [_serialize_model(r) for r in (result.get("current_rows") or [])],
            "originals": [_serialize_model(r) for r in (result.get("originals") or [])],
        },
    }
