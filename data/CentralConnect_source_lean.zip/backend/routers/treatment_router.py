"""
Treatment API Router
=====================
All treatment-related endpoints extracted from main.py.
Uses app.state for service access (treat_db, streamer, recorder, snapshot_svc).
"""

from fastapi import APIRouter, Request, HTTPException, Body
from fastapi.responses import JSONResponse, FileResponse, Response
from typing import Dict, Any
from datetime import datetime, timezone, timedelta
from uuid import UUID
import asyncio
import os
import logging
import re
from urllib.parse import unquote

from sqlalchemy import select

from db.postgres.session import get_session
from db.postgres.repositories.audit_repository import AuditRepository
from db.postgres.repositories.notes_repository import NotesRepository

logger = logging.getLogger("PrismaFlexBackend")
audit_logger = logging.getLogger("AuditTrail")

router = APIRouter(prefix="/api/v1/treatments", tags=["treatments"])


# ─── RBAC Helper ───────────────────────────────────────────────────

def require_role(request: Request, allowed: list):
    """Lightweight RBAC: read X-User-Role header and check against allowed roles."""
    role = request.headers.get('X-User-Role', 'nurse').lower()
    logger.info(f"🔐 [RBAC] Request {request.method} {request.url.path} - Role: '{role}' (Allowed: {allowed})")
    if role not in allowed:
        audit_logger.warning(f"🚫 [SECURITY] ACCESS DENIED: Role '{role}' attempted {request.method} {request.url.path} (Required: {allowed})")
        logger.warning(f"🚫 [RBAC] ACCESS DENIED: Role '{role}' not in {allowed}")
        raise HTTPException(status_code=403, detail=f"Role '{role}' not authorized for this action")


def require_operator_name(request: Request) -> str:
    """Require an operator identity for manual journal mutations."""
    raw_operator = request.headers.get('X-Operator-Name') or ''
    operator = re.sub(r'\s+', ' ', unquote(raw_operator).strip())
    if len(operator) < 2:
        raise HTTPException(
            status_code=400,
            detail="Operator name required in X-Operator-Name header",
        )
    return operator[:60]


# ─── List & Detail ─────────────────────────────────────────────────

@router.get("/")
async def get_treatments(
    request: Request,
    limit: int = 20,
    offset: int = 0,
    outcome: str = None,
    patient: str = None,
    device: str = None,
    start_time: str = None,
    end_time: str = None,
    approval_status: str = None
):
    """Paginated treatment history with advanced filtering."""
    try:
        treat_db = request.app.state.treat_db
        total = await asyncio.to_thread(treat_db.get_index_count, 
                                       outcome, patient, device, start_time, end_time,
                                       approval_status)
        items = await asyncio.to_thread(treat_db.get_index_list,
                                        limit, offset, outcome, patient, device, start_time, end_time,
                                        approval_status)
        return {"total": total, "items": items}
    except Exception as e:
        logger.error(f"Error fetching treatments: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/pending-count")
async def get_pending_count(request: Request):
    """Quick count for Sidebar badge. Must be defined BEFORE /{id} route."""
    try:
        count = await asyncio.to_thread(request.app.state.treat_db.get_pending_review_count)
        return {"count": count}
    except Exception as e:
        logger.error(f"Pending count error: {e}")
        return {"count": 0}


@router.get("/{id}")
async def get_treatment_detail(id: str, request: Request):
    """Full treatment report including snapshots and setup."""
    try:
        report = await asyncio.to_thread(request.app.state.treat_db.get_full_report, id)
        if not report:
            raise HTTPException(status_code=404, detail="Treatment not found")
        return report
    except HTTPException: raise
    except Exception as e:
        logger.error(f"Error fetching treatment {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─── Patient Info ──────────────────────────────────────────────────

@router.put("/{id}/patient")
async def update_patient_info(id: str, request: Request, data: Dict[str, Any] = Body(...)):
    """Update patient demographic and clinical setup info for a treatment."""
    try:
        treat_db = request.app.state.treat_db
        allowed_fields = [
            "patient_name", "patient_yob", "patient_gender", 
            "patient_weight", "bed_number", "admission_number", "diagnosis",
            "start_time_override", "end_time_override"
        ]
        
        # Filter data to only allowed fields
        update_data = {k: v for k, v in data.items() if k in allowed_fields}

        # Clinical Lock: Block edits on APPROVED treatments
        idx = await asyncio.to_thread(treat_db.fetch_one,
            "SELECT approval_status FROM treatment_index WHERE id = ?", (id,))
        if idx and idx['approval_status'] == 'APPROVED':
            raise HTTPException(status_code=403, detail="Treatment is approved and locked. Doctor must unlock first.")
        
        if update_data:
            await asyncio.to_thread(treat_db.update_treatment, id, **update_data)
            
            treatment = await asyncio.to_thread(treat_db.get_treatment_by_id, id)
            if treatment:
                await asyncio.to_thread(
                    treat_db.upsert_index, 
                    id, 
                    device_id=treatment['device_id'], 
                    **update_data
                )
        return {"status": "updated"}
    except Exception as e:
        logger.error(f"Error updating patient info {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─── Snapshots ─────────────────────────────────────────────────────

@router.put("/{id}/snapshots/{hourLabel}")
async def update_snapshot(id: str, hourLabel: str, request: Request, data: Dict[str, Any] = Body(...)):
    """Manual entry update for a specific hourly snapshot."""
    try:
        treat_db = request.app.state.treat_db
        operator = require_operator_name(request)
        role = request.headers.get('X-User-Role', 'nurse').lower()
        idx = await asyncio.to_thread(treat_db.fetch_one,
            "SELECT approval_status FROM treatment_index WHERE id = ?", (id,))
        if idx and idx['approval_status'] == 'APPROVED':
            raise HTTPException(status_code=403, detail="Treatment is approved and locked. Doctor must unlock first.")

        data['updated_by'] = operator
        await asyncio.to_thread(treat_db.update_snapshot_manual, id, hourLabel, data, operator, role)
        return {"status": "updated"}
    except HTTPException: raise
    except Exception as e:
        logger.error(f"Error updating snapshot {id}/{hourLabel}: {e}")
        if "ACTIVE_ROW_LOCKED" in str(e):
            raise HTTPException(status_code=409, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{id}/snapshots/{hourLabel}")
async def delete_snapshot(id: str, hourLabel: str, request: Request):
    """Delete a specific hourly snapshot."""
    require_role(request, ['doctor', 'admin'])
    try:
        treat_db = request.app.state.treat_db
        idx = await asyncio.to_thread(treat_db.fetch_one,
            "SELECT approval_status FROM treatment_index WHERE id = ?", (id,))
        if idx and idx['approval_status'] == 'APPROVED':
            raise HTTPException(status_code=403, detail="Treatment is approved and locked.")

        await asyncio.to_thread(treat_db.delete_snapshot, id, hourLabel)
        return {"status": "deleted"}
    except HTTPException: raise
    except Exception as e:
        logger.error(f"Error deleting snapshot {id}/{hourLabel}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{id}/snapshots-bulk")
async def bulk_update_snapshots(id: str, request: Request, data: Dict[str, Any] = Body(...)):
    """Bulk update all snapshots for a treatment (e.g. Apply to All)."""
    try:
        treat_db = request.app.state.treat_db
        idx = await asyncio.to_thread(treat_db.fetch_one,
            "SELECT approval_status FROM treatment_index WHERE id = ?", (id,))
        if idx and idx['approval_status'] == 'APPROVED':
            raise HTTPException(status_code=403, detail="Treatment is locked.")

        await asyncio.to_thread(treat_db.update_snapshots_bulk, id, data)
        return {"status": "updated"}
    except Exception as e:
        logger.error(f"Bulk update error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{id}/snapshots/manual")
async def add_manual_snapshot(id: str, request: Request):
    """Insert a manual hourly snapshot to fill telemetry gaps.
    Auto-calculates snapshot_time from treatment start_time + hour_num * 3600s.
    """
    require_role(request, ['nurse', 'admin'])
    try:
        treat_db = request.app.state.treat_db
        body = await request.json()
        hour_label = body.get("hour_label")  # e.g. "H05"
        
        if not hour_label:
            raise HTTPException(status_code=400, detail="hour_label is required")
        
        # Normalize: "H5" → "H05", "h03" → "H03"
        hour_label = hour_label.upper().strip()
        hour_num = int(hour_label.replace("H", ""))
        hour_label = f"H{hour_num:02d}"
            
        treatment = await asyncio.to_thread(treat_db.get_treatment_by_id, id)
        if not treatment:
            raise HTTPException(status_code=404, detail="Treatment not found")
            
        # Check approval status in index
        idx = await asyncio.to_thread(treat_db.fetch_one, 
            "SELECT approval_status FROM treatment_index WHERE id = ?", (id,))
        if idx and idx['approval_status'] == 'APPROVED':
            raise HTTPException(status_code=403, detail="Cannot edit an approved treatment")

        # Auto-calculate snapshot_time = start_time + hour_num * 1h
        from dateutil.parser import parse as dt_parse
        start_dt = dt_parse(treatment['start_time'])
        snapshot_dt = start_dt + timedelta(hours=hour_num)
        snapshot_time = snapshot_dt.isoformat()

        await asyncio.to_thread(
            treat_db.upsert_snapshot,
            treatment_id=id,
            device_id=treatment['device_id'],
            hour_label=hour_label,
            snapshot_time=snapshot_time,
            manual_data={'source': 'MANUAL'}
        )
        await asyncio.to_thread(treat_db.log_approval_event, id, 'MANUAL_INSERT', f'Inserted hour {hour_label} manually')
        role = request.headers.get('X-User-Role', 'nurse').lower()
        audit_logger.info(f"💉 Manual snapshot {hour_label} added for treatment {id[:8]} by {role}")
        logger.info(f"💉 Manual snapshot {hour_label} added for treatment {id[:8]}")
        return {"status": "success", "hour_label": hour_label}
    except HTTPException: raise
    except Exception as e:
        if "UNIQUE constraint failed" in str(e):
            raise HTTPException(status_code=409, detail="Hour label already exists")
        logger.error(f"Manual snapshot error {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─── Clinical Notes ────────────────────────────────────────────────

@router.put("/{id}/notes")
async def update_clinical_notes(id: str, request: Request, data: Dict[str, Any] = Body(...)):
    """Update doctor's clinical notes for a treatment session."""
    try:
        treat_db = request.app.state.treat_db
        notes = data.get('clinical_notes', '').strip()
        
        # Clinical notes are part of the treatment master record in PostgreSQL.
        await asyncio.to_thread(treat_db.execute,
            "UPDATE treatments SET clinical_notes = ? WHERE id = ?", (notes or None, id))
        
        role = request.headers.get('X-User-Role', 'nurse').lower()
        audit_logger.info(f"📝 Clinical notes updated for treatment {id[:8]} by {role}")
        return {"status": "updated"}
    except Exception as e:
        logger.error(f"Notes update error {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{id}/notes/log")
async def get_clinical_note_log(id: str):
    """Retrieve append-only note log from PostgreSQL."""
    try:
        tid = UUID(id)
        with get_session() as session:
            repo = NotesRepository(session)
            notes = repo.get_by_treatment(tid)
            
            # Simple serialization to match Frontend NoteEntry interface
            return {
                "notes": [
                    {
                        "id": n.id,
                        "content": n.content,
                        "author": n.author_name,
                        "author_name": n.author_name,
                        "author_role": n.author_role,
                        "created_at": n.created_at.isoformat()
                    } for n in notes
                ]
            }
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID format")
    except Exception as e:
        logger.error(f"Error fetching notes for {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{id}/notes/log")
async def add_clinical_note(id: str, request: Request, data: Dict[str, Any] = Body(...)):
    """Append a new note to the clinical log in PostgreSQL."""
    try:
        tid = UUID(id)
        content = data.get('content', '').strip()
        if not content:
            raise HTTPException(status_code=400, detail="Note content cannot be empty")
            
        operator_name = request.headers.get('X-Operator-Name', 'Unknown')
        # Frontend provides URL-encoded operator name
        from urllib.parse import unquote
        operator_name = unquote(operator_name)
        operator_role = request.headers.get('X-User-Role', 'nurse')
        summary = f"[{operator_role.upper()}] {content[:100]}"
        if len(content) > 100:
            summary += "..."

        with get_session() as session:
            from db.postgres.models.treatments import Treatment
            from db.postgres.services.projection_service import ProjectionService

            repo = NotesRepository(session)
            note = repo.add(
                treatment_id=tid,
                content=content,
                author_name=operator_name,
                author_role=operator_role
            )

            treatment = session.get(Treatment, tid)
            if treatment:
                treatment.clinical_notes = summary

            ProjectionService(session).refresh(tid)
            logger.info(f"Clinical note log updated for treatment {id[:8]}")

            return {
                "id": note.id,
                "content": note.content,
                "author": note.author_name,
                "author_name": note.author_name,
                "created_at": note.created_at.isoformat()
            }
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID format")
    except Exception as e:
        logger.error(f"Error adding note for {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─── Export ────────────────────────────────────────────────────────

def _iso(value):
    return value.isoformat() if hasattr(value, "isoformat") else value


def _label(value: str) -> str:
    return (value or "SYSTEM").replace("_", " ").strip().title()


def _audit_description(entry) -> str:
    parts = []
    if entry.row_code and entry.row_code != "*":
        parts.append(f"Row {entry.row_code}")
    if entry.field_name:
        parts.append(f"{entry.field_name}: {entry.old_value} -> {entry.new_value}")
    if entry.reason:
        parts.append(f"Reason: {entry.reason}")
    return " | ".join(parts) or _label(entry.action)


@router.get("/{id}/audit-trail")
async def get_audit_trail(id: str, limit: int = 300):
    """Return Treatment Journal edit history only."""
    try:
        tid = UUID(id)
        safe_limit = max(1, min(int(limit or 300), 500))
        events = []

        with get_session() as session:
            try:
                audit_rows = AuditRepository(session).get_by_treatment(tid, safe_limit)
            except Exception as audit_error:
                logger.warning(f"Audit log read failed for {id}: {audit_error}")
                audit_rows = []

            for entry in audit_rows:
                if not entry.row_code or entry.row_code == "*":
                    continue
                events.append({
                    "id": f"audit-{entry.id}",
                    "source": "audit",
                    "category": "journal_audit",
                    "action": entry.action,
                    "title": _label(entry.action),
                    "description": _audit_description(entry),
                    "operator_name": entry.operator_name,
                    "operator_role": entry.operator_role,
                    "row_code": entry.row_code,
                    "field_name": entry.field_name,
                    "old_value": entry.old_value,
                    "new_value": entry.new_value,
                    "reason": entry.reason,
                    "event_time": _iso(entry.created_at),
                })

        events.sort(key=lambda item: item.get("event_time") or "", reverse=True)
        return {"events": events[:safe_limit]}
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid treatment ID format")
    except Exception as e:
        logger.error(f"Error fetching audit trail for {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{id}/export")
async def export_treatment(id: str, request: Request):
    """Export treatment report as a JSON file."""
    try:
        treat_db = request.app.state.treat_db
        report = await asyncio.to_thread(treat_db.get_full_report, id)
        if not report:
            raise HTTPException(status_code=404, detail="Treatment not found")
        
        filename = f"Report_{report['treatment']['patient_id'] or 'Unknown'}_{id[:8]}.json"
        return JSONResponse(content=report, headers={"Content-Disposition": f"attachment; filename={filename}"})
    except HTTPException: raise
    except Exception as e:
        logger.error(f"Export error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{id}/raw")
async def export_raw_data(id: str, request: Request):
    """Serve the raw forensic JSONL (or GZ) file."""
    streamer = request.app.state.streamer
    treat_db = request.app.state.treat_db
    filepath = streamer.get_raw_filepath(id)
    gz_path = filepath + ".gz"
    
    if os.path.exists(gz_path):
         return FileResponse(path=gz_path, media_type="application/gzip", 
                            filename=f"Forensic_{id[:8]}.raw.jsonl.gz")
                            
    if not os.path.exists(filepath):
        # Fallback to DB if file not found (for legacy data)
        try:
            raw_packets = await asyncio.to_thread(treat_db.get_raw_packets, id)
            if not raw_packets:
                raise HTTPException(status_code=404, detail="Raw data not found")
            
            content = "\n".join([p['packet_json'] for p in raw_packets])
            return Response(content=content, media_type="application/x-jsonlines", 
                            headers={"Content-Disposition": f"attachment; filename=Forensic_{id[:8]}.raw.jsonl"})
        except Exception as e:
            logger.error(f"Raw data fallback error: {e}")
            raise HTTPException(status_code=404, detail="Raw data not found")
            
    return FileResponse(path=filepath, media_type="application/x-jsonlines", 
                        filename=f"Forensic_{id[:8]}.raw.jsonl")


# ─── Approval Workflow ─────────────────────────────────────────────

@router.get("/{id}/originals")
async def get_snapshot_originals(id: str, request: Request):
    """Retrieve frozen original snapshots for compare view."""
    try:
        originals = await asyncio.to_thread(request.app.state.treat_db.get_snapshot_originals, id)
        return {"originals": originals}
    except Exception as e:
        logger.error(f"Get originals error {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{id}/submit")
async def submit_for_review(id: str, request: Request):
    """Nurse submits a treatment for doctor review. Single-send constraint."""
    require_role(request, ['nurse', 'admin'])
    try:
        treat_db = request.app.state.treat_db
        treatment = await asyncio.to_thread(treat_db.fetch_one,
            "SELECT id, approval_status, outcome FROM treatment_index WHERE id = ?", (id,))
        if not treatment:
            raise HTTPException(status_code=404, detail="Treatment not found")
        if treatment['approval_status'] == 'PENDING_REVIEW':
            raise HTTPException(status_code=409, detail="Already submitted for review")
        if treatment['approval_status'] == 'APPROVED':
            raise HTTPException(status_code=409, detail="Already approved")
        # Block submit while still recording
        if treatment.get('outcome') == 'IN_PROGRESS':
            raise HTTPException(status_code=409, detail="Cannot submit a treatment that is still recording. Wait for it to complete.")
        await asyncio.to_thread(treat_db.freeze_snapshots, id)
        await asyncio.to_thread(treat_db.update_approval_status, id, 'PENDING_REVIEW')
        # Clear old rejection reason on re-submit
        await asyncio.to_thread(treat_db.execute,
            "UPDATE treatment_index SET reject_reason = NULL WHERE id = ?", (id,))
        await asyncio.to_thread(treat_db.log_approval_event, id, 'SUBMITTED', 'Nurse submitted for doctor review')
        role = request.headers.get('X-User-Role', 'nurse').lower()
        audit_logger.info(f"📋 Treatment {id[:8]} submitted for review by {role}")
        logger.info(f"📋 Treatment {id[:8]} submitted for review (snapshots frozen)")
        return {"status": "submitted", "approval_status": "PENDING_REVIEW"}
    except HTTPException: raise
    except Exception as e:
        logger.error(f"Submit for review error {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{id}/approve")
async def approve_treatment(id: str, request: Request):
    """Doctor approves a treatment. Locks it permanently."""
    require_role(request, ['doctor', 'admin'])
    try:
        treat_db = request.app.state.treat_db
        treatment = await asyncio.to_thread(treat_db.fetch_one,
            "SELECT id, approval_status FROM treatment_index WHERE id = ?", (id,))
        if not treatment:
            raise HTTPException(status_code=404, detail="Treatment not found")
        if treatment['approval_status'] == 'APPROVED':
            raise HTTPException(status_code=409, detail="Already approved")
        await asyncio.to_thread(treat_db.update_approval_status, id, 'APPROVED')
        await asyncio.to_thread(treat_db.log_approval_event, id, 'APPROVED', 'Doctor approved and locked treatment')
        role = request.headers.get('X-User-Role', 'doctor').lower()
        audit_logger.info(f"✅ Treatment {id[:8]} APPROVED by {role}")
        logger.info(f"✅ Treatment {id[:8]} APPROVED by doctor")
        return {"status": "approved", "approval_status": "APPROVED"}
    except HTTPException: raise
    except Exception as e:
        logger.error(f"Approve error {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{id}/reject")
async def reject_treatment(id: str, request: Request, data: Dict[str, Any] = Body(default={})):
    """Doctor rejects a treatment. Returns it to DRAFT so nurse can re-submit."""
    require_role(request, ['doctor', 'admin'])
    try:
        treat_db = request.app.state.treat_db
        treatment = await asyncio.to_thread(treat_db.fetch_one,
            "SELECT id, approval_status FROM treatment_index WHERE id = ?", (id,))
        if not treatment:
            raise HTTPException(status_code=404, detail="Treatment not found")
        if treatment['approval_status'] == 'APPROVED':
            raise HTTPException(status_code=409, detail="Cannot reject an approved treatment")
        reason = data.get('reason', '').strip()
        await asyncio.to_thread(treat_db.update_approval_status, id, 'DRAFT')
        # Store reject reason
        if reason:
            await asyncio.to_thread(treat_db.execute,
                "UPDATE treatment_index SET reject_reason = ? WHERE id = ?", (reason, id))
        await asyncio.to_thread(treat_db.log_approval_event, id, 'REJECTED', f'Doctor rejected: {reason or "No reason given"}')
        role = request.headers.get('X-User-Role', 'doctor').lower()
        audit_logger.info(f"↩️ Treatment {id[:8]} REJECTED by {role} (Reason: {reason or 'none'})")
        logger.info(f"↩️ Treatment {id[:8]} REJECTED → DRAFT (reason: {reason or 'none'})")
        return {"status": "rejected", "approval_status": "DRAFT"}
    except HTTPException: raise
    except Exception as e:
        logger.error(f"Reject error {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{id}/unlock")
async def unlock_treatment(id: str, request: Request):
    """Doctor unlocks an approved treatment for further editing. Returns to PENDING_REVIEW."""
    require_role(request, ['doctor', 'admin'])
    try:
        treat_db = request.app.state.treat_db
        treatment = await asyncio.to_thread(treat_db.fetch_one,
            "SELECT id, approval_status FROM treatment_index WHERE id = ?", (id,))
        if not treatment:
            raise HTTPException(status_code=404, detail="Treatment not found")
        if treatment['approval_status'] != 'APPROVED':
            raise HTTPException(status_code=409, detail="Only approved treatments can be unlocked")
        await asyncio.to_thread(treat_db.update_approval_status, id, 'PENDING_REVIEW')
        await asyncio.to_thread(treat_db.log_approval_event, id, 'UNLOCKED', 'Doctor unlocked approved treatment for editing')
        role = request.headers.get('X-User-Role', 'doctor').lower()
        audit_logger.info(f"🔓 Treatment {id[:8]} UNLOCKED by {role} → PENDING_REVIEW")
        logger.info(f"🔓 Treatment {id[:8]} UNLOCKED by doctor → PENDING_REVIEW")
        return {"status": "unlocked", "approval_status": "PENDING_REVIEW"}
    except HTTPException: raise
    except Exception as e:
        logger.error(f"Unlock error {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─── Delete ────────────────────────────────────────────────────────

@router.delete("/{id}")
async def delete_treatment(id: str, request: Request):
    """Wipe a treatment record and its raw data file."""
    require_role(request, ['admin'])
    try:
        treat_db = request.app.state.treat_db
        # Get device_id before deleting to clear session caches
        treatment = await asyncio.to_thread(treat_db.get_treatment_by_id, id)
        device_id = treatment.get('device_id') if treatment else None

        # Clinical Lock: Block deletion of APPROVED treatments
        idx = await asyncio.to_thread(treat_db.fetch_one,
            "SELECT approval_status FROM treatment_index WHERE id = ?", (id,))
        if idx and idx['approval_status'] == 'APPROVED':
            raise HTTPException(status_code=403, detail="Cannot delete an approved treatment.")

        # Clear in-memory caches FIRST to stop recording/snapshots
        if device_id:
            request.app.state.recorder.clear_device(device_id)
            request.app.state.snapshot_svc.clear_device(device_id)
            logger.info(f"🗑️ Cleared in-memory state for {device_id} BEFORE treatment deletion")

        # Delete raw files (.jsonl and .gz)
        filepath = request.app.state.streamer.get_raw_filepath(id)
        if os.path.exists(filepath): os.remove(filepath)
        if os.path.exists(filepath + ".gz"): os.remove(filepath + ".gz")
            
        # Delete from DB
        await asyncio.to_thread(treat_db.delete_treatment, id)
        
        audit_logger.info(f"🔥 DELETED treatment {id[:8]} (Patient: {treatment.get('patient_id') if treatment else 'Unknown'}) by admin")
        return {"status": "deleted"}
    except Exception as e:
        logger.error(f"Delete error {id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))
