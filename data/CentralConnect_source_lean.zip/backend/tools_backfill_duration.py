import sqlite3
import json
import logging
import os

# Define paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
HOT_DB_PATH = os.path.join(BASE_DIR, 'services', 'treatment_records.db')

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

def backfill_duration():
    if not os.path.exists(HOT_DB_PATH):
        logging.error(f"Database not found at {HOT_DB_PATH}")
        return

    conn = sqlite3.connect(HOT_DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    try:
        # Get all treatments
        cursor.execute("SELECT id, total_run_seconds FROM treatments")
        treatments = cursor.fetchall()
        
        updates = 0
        for t in treatments:
            t_id = t["id"]
            
            # Find max run_time_sec from snapshots
            cursor.execute('''
                SELECT run_time_sec 
                FROM treatment_hourly_snapshots 
                WHERE treatment_id = ? AND run_time_sec IS NOT NULL AND run_time_sec > 0
                ORDER BY snapshot_time DESC LIMIT 1
            ''', (t_id,))
            
            snapshot = cursor.fetchone()
            if snapshot and snapshot["run_time_sec"]:
                new_duration = snapshot["run_time_sec"]
                old_duration = t["total_run_seconds"]
                
                if new_duration != old_duration:
                    logging.info(f"[{t_id[:8]}] Updating duration: {old_duration} -> {new_duration}")
                    
                    # Update treatments
                    cursor.execute("UPDATE treatments SET total_run_seconds = ? WHERE id = ?", (new_duration, t_id))
                    
                    # Update treatment_index
                    cursor.execute("UPDATE treatment_index SET duration_sec = ? WHERE id = ?", (new_duration, t_id))
                    
                    updates += 1

        conn.commit()
        logging.info(f"✅ Backfill completed: {updates} records updated.")

    except Exception as e:
        logging.error(f"Backfill error: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    backfill_duration()
