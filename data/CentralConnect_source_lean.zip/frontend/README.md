# PrismaFlex Frontend Dashboard

### Setup & Run
1. Install dependencies:
   ```bash
   npm install
   ```

2. Run development server:
   ```bash
   npm run dev
   ```

3. Open http://localhost:3000

### Configuration
- **Connect to Backend:** By default it tries `ws://localhost:8000/ws` for real-time data.
- **Mock Data:** If backend is unavailable, it falls back to mock data (`src/utils/mockData.ts`).
- **Styles:** Uses TailwindCSS.

### Structure
- `app/page.tsx`: Main Dashboard (Device List)
- `app/monitor/[id]/page.tsx`: Detail Monitor View (A, B, C, D sections)
- `app/settings/page.tsx`: Device Management
- `app/providers/WebSocketProvider.tsx`: Global data connection logic

### Technologies
- Next.js 14+ (App Router)
- React
- TailwindCSS
- Recharts (Charts)
- Lucide React (Icons)
