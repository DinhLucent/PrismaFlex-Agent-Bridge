'use client';

import React from 'react';
import { Search, Info, AlertCircle, Settings, LayoutGrid } from 'lucide-react';
import { clsx } from 'clsx';
import { useLanguage } from '../../providers/LanguageProvider';

interface ReferenceItem {
    id: number;
    type: string;
    title: string;
    description: string;
    detail: string;
    category: 'Parameter' | 'Alarm';
}

export default function ReferencePage() {
    const { t } = useLanguage();
    const [query, setQuery] = React.useState('');
    const [category, setCategory] = React.useState<'all' | 'parameters' | 'alarms'>('all');
    const [results, setResults] = React.useState<ReferenceItem[]>([]);
    const [loading, setLoading] = React.useState(false);

    const fetchResults = React.useCallback(async () => {
        setLoading(true);
        try {
            const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
            const res = await fetch(`${apiUrl}/api/v1/reference/search?query=${encodeURIComponent(query)}&category=${category}`);
            if (res.ok) {
                const data = await res.json();
                setResults(data);
            }
        } catch (error) {
            console.error('Search failed:', error);
        } finally {
            setLoading(false);
        }
    }, [query, category]);

    React.useEffect(() => {
        const timer = setTimeout(() => {
            fetchResults();
        }, 300);
        return () => clearTimeout(timer);
    }, [query, category, fetchResults]);

    return (
        <div className="flex flex-col h-screen bg-[var(--background)] transition-colors duration-300 overflow-hidden">
            {/* Header Area */}
            <header className="bg-white dark:bg-[#0f172a] border-b border-slate-200 dark:border-slate-800 px-8 py-6 transition-colors shadow-sm relative z-10">
                <div className="max-w-4xl mx-auto">
                    <div className="flex items-center gap-4 mb-6">
                        <div className="p-3 bg-teal-500/10 rounded-2xl">
                            <Search className="w-8 h-8 text-teal-600 dark:text-teal-400" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tighter uppercase">{t('ref_toolkit')}</h1>
                            <p className="text-sm text-slate-500 font-bold uppercase tracking-widest">{t('ref_subtitle')}</p>
                        </div>
                    </div>

                    {/* Search Bar */}
                    <div className="relative group">
                        <div className="absolute inset-0 bg-teal-500/10 blur-xl opacity-0 group-focus-within:opacity-100 transition-opacity rounded-2xl"></div>
                        <input
                            type="text"
                            placeholder={t('ref_search_placeholder')}
                            className="w-full h-14 bg-slate-50 dark:bg-slate-900/50 border-2 border-slate-200 dark:border-slate-800 rounded-2xl px-14 text-slate-900 dark:text-white font-bold placeholder:text-slate-400 focus:border-teal-500 focus:ring-0 transition-all text-lg shadow-inner relative z-10"
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                        />
                        <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-slate-400 group-focus-within:text-teal-500 transition-colors z-20" />
                    </div>

                    {/* Category Tabs */}
                    <div className="flex gap-2 mt-6">
                        {[
                            { id: 'all', label: t('ref_tab_all') },
                            { id: 'parameters', label: t('ref_tab_params') },
                            { id: 'alarms', label: t('ref_tab_alarms') }
                        ].map((tab) => (
                            <button
                                key={tab.id}
                                onClick={() => setCategory(tab.id as any)}
                                className={clsx(
                                    "px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all",
                                    category === tab.id
                                        ? "bg-teal-600 text-white shadow-lg shadow-teal-500/30 translate-y-[-2px]"
                                        : "bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                                )}
                            >
                                {tab.label}
                            </button>
                        ))}
                    </div>
                </div>
            </header>

            {/* Results Area */}
            <main className="flex-1 overflow-y-auto p-8 bg-slate-50 dark:bg-[#09090b] transition-colors">
                <div className="max-w-4xl mx-auto">
                    {loading ? (
                        <div className="flex flex-col items-center justify-center py-20 animate-pulse">
                            <Settings className="w-12 h-12 text-teal-500 animate-spin-slow mb-4" />
                            <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">{t('ref_loading')}</p>
                        </div>
                    ) : results.length > 0 ? (
                        <div className="grid grid-cols-1 gap-4">
                            {results.map((item) => (
                                <div
                                    key={`${item.category}-${item.id}`}
                                    className="bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-slate-800 rounded-2xl p-6 hover:shadow-xl hover:border-teal-500/30 transition-all group animate-in slide-in-from-bottom-2 duration-300"
                                >
                                    <div className="flex items-start justify-between gap-4">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-2 mb-2">
                                                <span className={clsx(
                                                    "px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-tighter",
                                                    item.category === 'Parameter'
                                                        ? "bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400"
                                                        : "bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400"
                                                )}>
                                                    {item.category === 'Parameter' ? t('ref_tab_params').replace(/s$/, '') : t('ref_tab_alarms').replace(/s$/, '')}
                                                </span>
                                                <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500">ID: #{item.id}</span>
                                            </div>
                                            <h3 className="text-xl font-black text-slate-900 dark:text-white mb-2 group-hover:text-teal-500 transition-colors uppercase tracking-tight">
                                                {item.title}
                                            </h3>
                                            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed font-medium">
                                                {item.description}
                                            </p>
                                        </div>
                                        <div className="shrink-0 text-right">
                                            <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 font-black text-[10px] text-teal-600 dark:text-teal-400 uppercase tracking-widest group-hover:shadow-[0_0_15px_rgba(20,184,166,0.15)] transition-all">
                                                {item.detail}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-20">
                            <div className="inline-flex p-6 bg-slate-100 dark:bg-slate-800 rounded-3xl mb-4">
                                <Info className="w-12 h-12 text-slate-300 dark:text-slate-600" />
                            </div>
                            <h3 className="text-xl font-bold text-slate-400 dark:text-slate-600">{t('ref_no_results')}</h3>
                            <p className="text-sm text-slate-400 dark:text-slate-600 mt-2">{t('ref_search_hint')}</p>
                        </div>
                    )}
                </div>
            </main>

            {/* Footer Stats */}
            <footer className="bg-white dark:bg-[#0f172a] border-t border-slate-200 dark:border-slate-800 px-8 py-3 text-[10px] text-slate-400 font-bold uppercase tracking-widest flex items-center justify-between transition-colors">
                <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1.5"><LayoutGrid className="w-3 h-3 text-teal-500" /> {results.length} {t('lbl_matches')}</span>
                    <span className="flex items-center gap-1.5"><AlertCircle className="w-3 h-3 text-amber-500" /> {t('lbl_source')}</span>
                </div>
                <div className="text-slate-300 dark:text-slate-700">{t('lbl_icu_zone')}</div>
            </footer>
        </div>
    );
}
