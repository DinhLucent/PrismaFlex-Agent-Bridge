import type { Metadata } from 'next';
import { Inter, JetBrains_Mono } from 'next/font/google';
import './../globals.css';
import { Sidebar } from '../components/Sidebar';
import { WebSocketProvider } from '../providers/WebSocketProvider';
import { TrendProvider } from '../providers/TrendProvider';
import { ThemeProvider } from '../providers/ThemeProvider';
import { GlobalErrorBoundary } from '../components/ErrorBoundary';
import { GlobalErrorListener } from '../components/GlobalErrorListener';
import { LanguageProvider } from '../providers/LanguageProvider';
import { RoleProvider } from '../providers/RoleProvider';
import { ToastProvider } from '../providers/ToastProvider';
const fontMain = Inter({ subsets: ['latin', 'vietnamese'] });
const jetbrainsMono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono' });

export const metadata: Metadata = {
  title: 'ICU-B CONNECT | Cho Ray Hospital',
  description: 'Continuous Renal Replacement Therapy (CRRT) Monitoring System',
  icons: {
    icon: '/icon.svg',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${fontMain.className} ${jetbrainsMono.variable} bg-background text-foreground antialiased min-h-screen flex flex-col`}>
        <ThemeProvider>
          <LanguageProvider>
            <RoleProvider>
              <ToastProvider>
                <WebSocketProvider>
                  <TrendProvider>
                    <GlobalErrorBoundary>
                      <GlobalErrorListener />
                      <div className="flex bg-[var(--background)] min-h-screen transition-colors duration-300">
                        <Sidebar />
                        <div className="flex-1 flex flex-col min-w-0 transition-all duration-300">
                          <main className="flex-1 overflow-x-hidden overflow-y-auto w-full p-4 lg:p-6 pb-[env(safe-area-inset-bottom)] scroll-smooth relative z-0">
                            {children}
                          </main>
                        </div>
                      </div>
                    </GlobalErrorBoundary>
                  </TrendProvider>
                </WebSocketProvider>
              </ToastProvider>
            </RoleProvider>
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
