'use client';

import React from 'react';
import { useDeviceData } from '../providers/WebSocketProvider';
import { DeviceCard } from '../components/DeviceCard';
import { THERAPY_TYPE_MAP, THERAPY_STATUS_MAP } from '../utils/constants';
import { clsx } from 'clsx';
import { Wifi, WifiOff, Clock, Activity, ChevronDown, ChevronUp } from 'lucide-react';
import Header from '../components/Header';
import { useLanguage } from '../providers/LanguageProvider';

function SystemClock() {
  const { t } = useLanguage();
  const { serverTime } = useDeviceData();
  const [displayTime, setDisplayTime] = React.useState<Date | null>(null);
  // Store the local performance timestamp when we last received a server update
  const syncRef = React.useRef<{ server: number, local: number } | null>(null);

  React.useEffect(() => {
    if (serverTime) {
      syncRef.current = {
        server: serverTime.getTime(),
        local: performance.now()
      };
    }
  }, [serverTime]);

  React.useEffect(() => {
    const timer = setInterval(() => {
      if (syncRef.current) {
        const elapsed = performance.now() - syncRef.current.local;
        setDisplayTime(new Date(syncRef.current.server + elapsed));
      } else {
        // Fallback to local time if server time hasn't arrived yet
        setDisplayTime(new Date());
      }
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!displayTime) return null;

  return (
    <div className="flex items-center gap-3 px-4 py-2 rounded-xl bg-white/50 dark:bg-slate-900/40 border border-slate-200/50 dark:border-white/5 shadow-sm backdrop-blur-md group transition-all hover:shadow-md hover:border-blue-400/30">
      <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500 group-hover:bg-blue-500 group-hover:text-white transition-all duration-500">
        <Clock className="w-4 h-4" />
      </div>
      <div className="flex flex-col">
        <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500 mb-0.5">{t('lbl_server_time')}</span>
        <span className="text-xl font-black font-[family-name:var(--font-mono)] text-slate-700 dark:text-slate-200 tracking-tighter tabular-nums">
          {displayTime.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
        </span>
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { t } = useLanguage();
  const { devices, isConnected, connectionStatus, deviceEvents } = useDeviceData();
  const [scaleFactor, setScaleFactor] = React.useState(1);
  const [legendOpen, setLegendOpen] = React.useState(false);
  const containerRef = React.useRef<HTMLDivElement>(null);

  const getModeText = (modeId: number) => {
    return THERAPY_TYPE_MAP[modeId] || 'Unknown';
  };

  // World-Class Auto-Scaling Logic
  React.useEffect(() => {
    const handleResize = () => {
      if (!containerRef.current) return;

      // Target reference width for 100% scale (Ideal for 1920px width monitor with Sidebar)
      const referenceWidth = 1600;
      const currentWidth = window.innerWidth - (window.innerWidth >= 768 ? 256 : 0); // Account for sidebar width md:ml-64

      // Calculate scale, but don't let it get smaller than 0.5 or larger than 1.1
      let newScale = currentWidth / referenceWidth;
      newScale = Math.min(Math.max(newScale, 0.5), 1.1);

      setScaleFactor(newScale);
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Sort devices by priority: Critical Alarms > Warnings > Cautions > Running > Offline
  const sortedDevices = React.useMemo(() => {
    return [...devices].sort((a, b) => {
      const getScore = (device: any) => {
        const alarms = device.active_alarms?.filter((al: any) => al.state === 'PRESENT') || [];
        if (alarms.some((al: any) => ['ALARM', 'MALFUNCTION'].includes(al.category))) return 100;
        if (alarms.some((al: any) => al.category === 'WARNING')) return 80;
        if (alarms.some((al: any) => al.category === 'CAUTION')) return 60;
        if (alarms.some((al: any) => al.category === 'ADVISORY')) return 50;
        if (device.status === 'RUNNING') return 40;
        return 0;
      };
      return getScore(b) - getScore(a);
    });
  }, [devices]);

  return (
    <>
      {/* Sticky configuration: stays fixed at the top on scroll with a blurred backdrop */}
      <div className="sticky top-0 z-50 mb-4 lg:mb-6 pt-4 px-4 lg:pt-6 lg:px-6 bg-[var(--background)]/80 backdrop-blur-xl border-b border-black/5 dark:border-white/5 pb-4">
        <Header />
      </div>
      <div
        ref={containerRef}
        className="min-h-screen bg-[var(--background)] p-6 md:p-8 transition-colors duration-300 origin-top-left"
        style={{
          zoom: scaleFactor,
          WebkitZoom: scaleFactor
        } as any}
      >

        <main>
          {/* ═══ SUMMARY BAR ═══ */}
          {sortedDevices.length > 0 && (() => {
            const counts = sortedDevices.reduce((acc, d) => {
              const alarms = d.active_alarms?.filter((a: any) => a.state === 'PRESENT') || [];
              if (alarms.some((a: any) => ['ALARM', 'MALFUNCTION'].includes(a.category))) acc.alarm++;
              else if (alarms.some((a: any) => a.category === 'WARNING')) acc.warning++;
              else if (alarms.some((a: any) => a.category === 'CAUTION')) acc.caution++;
              else if (d.status === 'RUNNING') acc.running++;
              else if (d.status === 'OFFLINE') acc.offline++;
              else acc.idle++;
              return acc;
            }, { running: 0, alarm: 0, warning: 0, caution: 0, offline: 0, idle: 0 });

            const chips = [
              { label: t('status_running'), count: counts.running, color: 'bg-teal-500', text: 'text-teal-500', bg: 'bg-teal-500/10', border: 'border-teal-500/20', pulse: true },
              { label: 'ALARM', count: counts.alarm, color: 'bg-rose-500', text: 'text-rose-500', bg: 'bg-rose-500/10', border: 'border-rose-500/20', pulse: counts.alarm > 0 },
              { label: t('status_warning'), count: counts.warning, color: 'bg-amber-500', text: 'text-amber-500', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
              { label: t('status_caution'), count: counts.caution, color: 'bg-sky-500', text: 'text-sky-500', bg: 'bg-sky-500/10', border: 'border-sky-500/20' },
              { label: t('lbl_offline_card'), count: counts.offline, color: 'bg-slate-400', text: 'text-slate-400', bg: 'bg-slate-500/5', border: 'border-slate-500/10' },
            ].filter(c => c.count > 0);

            return (
              <div className="mb-6 flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-2 mr-2">
                  <Activity className="w-4 h-4 text-teal-500" />
                  <span className="text-xs font-black text-[var(--card-foreground)] uppercase tracking-widest">
                    {sortedDevices.length} {t('lbl_total_devices') || 'DEVICES'}
                  </span>
                </div>
                <div className="w-px h-5 bg-[var(--border)]" />
                {chips.map(chip => (
                  <div
                    key={chip.label}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border ${chip.bg} ${chip.border} transition-all`}
                  >
                    <span className="relative flex h-2 w-2">
                      {chip.pulse && <span className={`absolute h-full w-full rounded-full ${chip.color} opacity-50 animate-ping`} />}
                      <span className={`relative h-2 w-2 rounded-full ${chip.color}`} />
                    </span>
                    <span className={`text-[10px] font-black uppercase tracking-wider ${chip.text}`}>
                      {chip.count} {chip.label}
                    </span>
                  </div>
                ))}
              </div>
            );
          })()}

          {/* ═══ DEVICE GRID or EMPTY STATE ═══ */}
          {sortedDevices.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-72 rounded-2xl bg-slate-50/50 dark:bg-slate-900/20 border border-dashed border-slate-200 dark:border-slate-800 text-slate-400 dark:text-slate-600 transition-colors relative overflow-hidden">
              {/* Animated scanning rings */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-40 h-40 rounded-full border border-teal-500/10 animate-ping" style={{ animationDuration: '3s' }} />
                <div className="absolute w-28 h-28 rounded-full border border-teal-500/15 animate-ping" style={{ animationDuration: '2.5s', animationDelay: '0.5s' }} />
                <div className="absolute w-16 h-16 rounded-full border border-teal-500/20 animate-ping" style={{ animationDuration: '2s', animationDelay: '1s' }} />
              </div>
              {/* Center icon */}
              <div className="relative z-10 p-4 rounded-2xl bg-teal-500/5 border border-teal-500/10 mb-4">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-teal-500/40">
                  <path fillRule="evenodd" clipRule="evenodd" d="M10.977 2.903a1.25 1.25 0 0 1 2.046 0l5.116 7.291A7.497 7.497 0 0 1 12 22a7.497 7.497 0 0 1-6.139-11.806l5.116-7.291Z" fill="currentColor" />
                </svg>
              </div>
              <p className="relative z-10 font-black uppercase tracking-[0.15em] text-sm">{t('dash_no_connections')}</p>
              <p className="relative z-10 text-xs mt-2 opacity-60">{t('dash_no_connections_hint')}</p>
            </div>
          ) : (() => {
            const activeDevices = sortedDevices.filter(d => d.status !== 'OFFLINE');
            const offlineDevices = sortedDevices.filter(d => d.status === 'OFFLINE');

            return (
              <>
                {/* Active devices grid */}
                {activeDevices.length > 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 xl:gap-5">
                    {activeDevices.map((device) => {
                      const modeId = device.data?.s_header?.therapy_type_id;
                      const patientId = device.data?.s_header?.patient_id;
                      let status = device.status;
                      const parameters = device.data?.s_body?.parameters || [];
                      const p_access = parameters.find((p: any) => p.id === 1)?.value;
                      const p_filter = parameters.find((p: any) => p.id === 2)?.value;
                      const p_effluent = parameters.find((p: any) => p.id === 3)?.value;
                      const p_return = parameters.find((p: any) => p.id === 4)?.value;
                      const p_qb = parameters.find((p: any) => p.id === 17)?.value;
                      const p_tmp_raw = parameters.find((p: any) => p.id === 6)?.value;
                      let final_tmp = p_tmp_raw;
                      if (p_filter !== undefined && p_effluent !== undefined && p_return !== undefined) {
                        const calculated = Math.round(((p_filter + p_effluent) / 2) - p_return);
                        if (p_tmp_raw === undefined || p_tmp_raw > 1000 || p_tmp_raw < -1000) final_tmp = calculated;
                      }
                      const vitals = { access: p_access, filter: p_filter, effluent: p_effluent, return: p_return, qb: p_qb, tmp: final_tmp };
                      return (
                        <DeviceCard key={device.id} id={device.id} name={device.name} status={status} lastUpdate={device.lastUpdate}
                          mode={modeId ? getModeText(modeId) : undefined} patientId={patientId}
                          therapyStatusId={device.data?.s_header?.therapy_status_id}
                          activeAlarms={device.active_alarms} events={deviceEvents[device.id]} vitals={vitals}
                        />
                      );
                    })}
                  </div>
                )}

                {/* Offline devices — compact section */}
                {offlineDevices.length > 0 && (
                  <div className="mt-6">
                    <div className="flex items-center gap-2 mb-3">
                      <WifiOff className="w-3.5 h-3.5 text-slate-400" />
                      <span className="text-[10px] font-black text-slate-400 dark:text-slate-600 uppercase tracking-[0.15em]">
                        {offlineDevices.length} {t('lbl_offline_card')}
                      </span>
                      <div className="flex-1 h-px bg-slate-200 dark:bg-slate-800" />
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
                      {offlineDevices.map((device) => (
                        <DeviceCard key={device.id} id={device.id} name={device.name} status={device.status} lastUpdate={device.lastUpdate}
                          activeAlarms={device.active_alarms} events={deviceEvents[device.id]}
                          className="!min-h-[140px]"
                        />
                      ))}
                    </div>
                  </div>
                )}
              </>
            );
          })()}

          {/* STATUS LEGEND — collapsible */}
          {sortedDevices.length > 0 && (
            <div className="mt-8 pt-4 border-t border-slate-200/60 dark:border-slate-800/60">
              <button
                onClick={() => setLegendOpen(v => !v)}
                className="flex items-center gap-2 group cursor-pointer mb-0 hover:opacity-80 transition-opacity"
              >
                <h2 className="text-[10px] font-black text-slate-400 dark:text-slate-600 uppercase tracking-[0.2em]">
                  {t('dash_status_guide')}
                </h2>
                {legendOpen
                  ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
                  : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                }
              </button>

              {legendOpen && (
                <div className="grid grid-cols-3 md:grid-cols-6 gap-2 mt-3 animate-in fade-in slide-in-from-top-1 duration-200">
                  {[
                    { color: 'bg-[#e11d48]', text: 'text-[#e11d48]', label: t('status_malfunction'), pulse: true },
                    { color: 'bg-[#f59e0b]', text: 'text-[#f59e0b]', label: t('status_warning') },
                    { color: 'bg-[#0284c7]', text: 'text-[#0284c7]', label: t('status_caution') },
                    { color: 'bg-[#6366f1]', text: 'text-[#6366f1]', label: t('status_advisory') },
                    { color: 'bg-[#2dd4bf]', text: 'text-[#0d9488] dark:text-[#2dd4bf]', label: t('status_running') },
                    { color: 'bg-slate-300 dark:bg-slate-700', text: 'text-slate-400 dark:text-slate-600', label: t('status_offline_guide') },
                  ].map(item => (
                    <div key={item.label} className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-black/[0.02] dark:bg-white/[0.03]">
                      <div className={`w-2 h-5 rounded-full ${item.color} shrink-0 ${item.pulse ? 'animate-pulse' : ''}`} />
                      <span className={`text-[9px] font-black uppercase tracking-wider ${item.text}`}>{item.label}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </main>
      </div>
    </>
  );
}
