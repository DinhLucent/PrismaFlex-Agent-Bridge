'use client';

import React from 'react';
import { useLanguage } from '../../providers/LanguageProvider';
import { useToast } from '../../providers/ToastProvider';
import { getFilterOptions } from './columns';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

type EnsureOperator = (action: () => void) => void;

export default function EditableCell({
    treatmentId,
    hourLabel,
    field,
    value,
    anticoagId,
    operatorName,
    userRole,
    disabled,
    ensureOperator,
    onSaved,
}: {
    treatmentId: string;
    hourLabel: string;
    field: string;
    value: string | number | null;
    anticoagId?: number;
    operatorName?: string;
    userRole?: string;
    disabled?: boolean;
    ensureOperator?: EnsureOperator;
    onSaved: () => void;
}) {
    const [editing, setEditing] = React.useState(false);
    const [localVal, setLocalVal] = React.useState(value ?? '');
    const { t } = useLanguage();
    const { showToast } = useToast();
    const operatorRef = React.useRef(operatorName);

    React.useEffect(() => {
        operatorRef.current = operatorName;
    }, [operatorName]);

    React.useEffect(() => {
        setLocalVal(value ?? '');
    }, [value]);

    const getStoredOperator = React.useCallback(() => {
        try {
            const stored = sessionStorage.getItem(`treatment_operator::${treatmentId}`);
            return stored ? JSON.parse(stored).name as string | undefined : undefined;
        } catch {
            return undefined;
        }
    }, [treatmentId]);

    const getErrorMessage = React.useCallback((status: number, detail?: string) => {
        if (status === 400) return 'Can nhap ten nguoi thao tac truoc khi chinh sua.';
        if (status === 403) return 'Khong co quyen chinh sua muc nay.';
        if (status === 409) return 'Dong journal dang bi khoa trong luc treatment ghi du lieu.';
        return detail || 'Khong the luu thay doi.';
    }, []);

    const save = async (newVal: string | number) => {
        if (String(newVal) === String(value ?? '')) {
            setEditing(false);
            return;
        }

        const currentOperator = operatorRef.current || getStoredOperator();
        if (!currentOperator && ensureOperator) {
            setEditing(false);
            ensureOperator(() => setEditing(true));
            return;
        }

        try {
            const payload: Record<string, string | number | null> = {};
            if (field === 'kali' || field === 'duosol_count' || field === 'prismasol_count') {
                payload[field] = newVal === '' ? null : Number(newVal);
            } else {
                payload[field] = newVal || null;
            }

            const headers: Record<string, string> = {
                'Content-Type': 'application/json',
            };
            if (currentOperator) headers['X-Operator-Name'] = encodeURIComponent(currentOperator);
            if (userRole) headers['X-User-Role'] = userRole;

            const res = await fetch(`${API}/api/v1/treatments/${treatmentId}/snapshots/${hourLabel}`, {
                method: 'PUT',
                headers,
                body: JSON.stringify(payload),
            });

            if (res.ok) {
                onSaved();
            } else {
                const err = await res.json().catch(() => ({ detail: 'Unknown error' }));
                showToast(getErrorMessage(res.status, err.detail), res.status === 409 ? 'warning' : 'error');
            }
        } catch (e) {
            console.error('Save error:', e);
            showToast('Khong the ket noi toi he thong.', 'error');
        }

        setEditing(false);
    };

    if (disabled) {
        return (
            <span className="w-full h-full px-1 py-0.5 text-center">
                {value !== null && value !== undefined && value !== '' ? (
                    <span className="text-xs font-bold text-[var(--card-foreground)] opacity-60">{String(value)}</span>
                ) : (
                    <span className="text-slate-500/20 text-[10px]">-</span>
                )}
            </span>
        );
    }

    if (!editing) {
        return (
            <button
                onClick={() => (ensureOperator ? ensureOperator(() => setEditing(true)) : setEditing(true))}
                className="w-full h-full px-1 py-0.5 rounded hover:bg-slate-500/10 cursor-pointer transition-colors text-center group"
                title={operatorName ? t('click_to_edit') : t('msg_operator_required')}
            >
                {value !== null && value !== undefined && value !== '' ? (
                    <span className="text-xs font-bold text-[var(--card-foreground)]">{String(value)}</span>
                ) : (
                    <span className="text-slate-500/30 text-[10px] group-hover:text-slate-400/60 transition-colors dark:text-slate-500/50">{t('action_input')}</span>
                )}
            </button>
        );
    }

    if (field === 'kali' || field === 'duosol_count' || field === 'prismasol_count') {
        return (
            <input
                autoFocus
                type="number"
                step={field === 'kali' ? '0.1' : '1'}
                value={String(localVal)}
                onChange={(e) => setLocalVal(e.target.value)}
                onBlur={() => save(localVal as string)}
                onKeyDown={(e) => {
                    if (e.key === 'Enter') save(localVal as string);
                    if (e.key === 'Escape') setEditing(false);
                }}
                className="w-16 bg-slate-500/10 border border-slate-500/30 rounded px-1 py-0.5 text-[10px] text-[var(--card-foreground)] font-bold text-center outline-none focus:ring-1 focus:ring-slate-500/50"
            />
        );
    }

    if (field === 'filter_type') {
        return (
            <select
                autoFocus
                value={String(localVal)}
                onChange={(e) => save(e.target.value)}
                onBlur={() => setEditing(false)}
                className="w-full bg-slate-500/10 border border-slate-500/30 rounded px-1 py-0.5 text-[10px] text-[var(--card-foreground)] font-bold outline-none focus:ring-1 focus:ring-slate-500/50"
            >
                {getFilterOptions(anticoagId === 2 || anticoagId === 3).map(opt => (
                    <option key={opt} value={opt} className="bg-[var(--card)] text-[var(--card-foreground)]">
                        {opt || t('select_option')}
                    </option>
                ))}
            </select>
        );
    }

    return (
        <input
            autoFocus
            type="number"
            step="0.1"
            value={String(localVal)}
            onChange={(e) => setLocalVal(e.target.value)}
            onBlur={() => save(localVal as string)}
            onKeyDown={(e) => {
                if (e.key === 'Enter') save(localVal as string);
                if (e.key === 'Escape') setEditing(false);
            }}
            className="w-16 bg-slate-500/10 border border-slate-500/30 rounded px-1 py-0.5 text-[10px] text-[var(--card-foreground)] font-bold text-center outline-none focus:ring-1 focus:ring-slate-500/50"
        />
    );
}
