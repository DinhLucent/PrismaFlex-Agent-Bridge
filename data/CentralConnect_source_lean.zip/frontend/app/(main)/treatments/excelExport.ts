/**
 * Excel Export Utility for Treatment Journal
 * Generates a professional .xlsx file with 2 sheets:
 *   1. Patient Info — demographics + treatment metadata
 *   2. CRRT Data   — hourly snapshot timeline (H01→Hmax + OC rows)
 */

import * as XLSX from 'xlsx';
import { TreatmentDetail, Snapshot } from './types';
import { getColumns, formatDuration } from './columns';
import { TranslationKeys } from '../../lib/translations';

// ─── Column width auto-fit helper ──────────────────────────────
function autoFitColumns(ws: XLSX.WorkSheet, data: (string | number | null)[][]) {
    const colWidths: number[] = [];
    data.forEach(row => {
        row.forEach((cell, i) => {
            const len = cell !== null && cell !== undefined ? String(cell).length : 0;
            colWidths[i] = Math.max(colWidths[i] || 0, len);
        });
    });
    ws['!cols'] = colWidths.map(w => ({ wch: Math.min(Math.max(w + 2, 8), 30) }));
}

// ─── Format helpers ────────────────────────────────────────────
function fmtDate(iso: string): string {
    if (!iso) return '';
    try {
        return new Date(iso).toLocaleString('vi-VN');
    } catch { return iso; }
}

function fmtVal(v: number | null | undefined, decimals = 0): string {
    if (v === null || v === undefined) return '';
    return decimals > 0 ? v.toFixed(decimals) : Math.round(v).toString();
}

function fmtPressure(v: number | null | undefined): string {
    if (v === null || v === undefined) return '';
    const rounded = Math.round(v);
    return rounded > 0 ? `+${rounded}` : String(rounded);
}

// ─── Main Export Function ──────────────────────────────────────
export function exportTreatmentToExcel(
    detail: TreatmentDetail,
    t: (key: TranslationKeys) => string
) {
    const treatment = detail.treatment;
    const snaps = [...(detail.snapshots || [])].sort(
        (a, b) => new Date(a.snapshot_time).getTime() - new Date(b.snapshot_time).getTime()
    );

    const wb = XLSX.utils.book_new();

    // ═══════════════════════════════════════════════════════════
    // SHEET 1 — Patient Info
    // ═══════════════════════════════════════════════════════════
    const patientRows: (string | number | null)[][] = [
        [t('treatments_title'), ''],
        ['', ''],
        [t('table_patient'), treatment.patient_name || treatment.patient_id || '—'],
        ['ID', treatment.patient_id || '—'],
        [t('label_ba'), treatment.admission_number || '—'],
        [t('table_device'), treatment.device_id || '—'],
        [t('table_therapy'), treatment.therapy_type || '—'],
        [t('lbl_anticoagulant'), treatment.anticoag_type || snaps[0]?.anticoag_type_id === 2 || snaps[0]?.anticoag_type_id === 3 ? 'Citrate' : 'Heparin'],
        ['', ''],
        [t('table_start'), fmtDate(treatment.start_time_override || treatment.start_time)],
        ['End', fmtDate(treatment.end_time_override || treatment.end_time)],
        [t('table_duration'), formatDuration(treatment.duration_sec)],
        ['', ''],
        ['Bed', treatment.bed_number || '—'],
        ['YOB', treatment.patient_yob || '—'],
        ['Gender', treatment.patient_gender || '—'],
        ['Diagnosis', treatment.diagnosis || '—'],
        ['', ''],
        ['Snapshots', snaps.length],
        ['Export Time', new Date().toLocaleString('vi-VN')],
    ];

    const ws1 = XLSX.utils.aoa_to_sheet(patientRows);
    autoFitColumns(ws1, patientRows);
    XLSX.utils.book_append_sheet(wb, ws1, 'Patient Info');

    // ═══════════════════════════════════════════════════════════
    // SHEET 2 — CRRT Timeline Data
    // ═══════════════════════════════════════════════════════════
    const anticoagId = snaps.length > 0 ? snaps[0]?.anticoag_type_id : null;
    const columns = getColumns(anticoagId, t);

    // Header row
    const headerRow = [t('col_hour'), 'Time', 'Source', ...columns.map(c => `${c.label}${c.unit ? ` (${c.unit})` : ''}`)];
    const pressureKeys = new Set(['pa', 'pv', 'pbe', 'tmp']);

    // Build continuous timeline with gap rows
    type DisplayRow = { type: 'data' | 'gap' | 'oc'; snap?: Snapshot; hourNum: number; label: string };
    const displayRows: DisplayRow[] = [];

    if (snaps.length > 0) {
        let expectedHour = 1;
        for (const snap of snaps) {
            if (snap.hour_label.startsWith('H')) {
                const hourNum = parseInt(snap.hour_label.replace('H', ''), 10);
                if (isNaN(hourNum)) continue;
                while (expectedHour < hourNum) {
                    displayRows.push({ type: 'gap', hourNum: expectedHour, label: `H${String(expectedHour).padStart(2, '0')}` });
                    expectedHour++;
                }
                displayRows.push({ type: 'data', snap, hourNum, label: snap.hour_label });
                expectedHour = hourNum + 1;
            } else if (snap.hour_label.startsWith('OC')) {
                displayRows.push({ type: 'oc', snap, hourNum: 0, label: snap.hour_label });
            }
        }
    }

    // Build data rows
    const dataRows: (string | number | null)[][] = [headerRow];
    const decimalKeys = new Set(['citrate_dose', 'calcium_rate', 'citrate_conc', 'citrate_load', 'kali', 'heparin_rate']);

    for (const row of displayRows) {
        if (row.type === 'gap') {
            dataRows.push([row.label, '', 'GAP', ...columns.map(() => '')]);
            continue;
        }

        const snap = row.snap!;
        const time = snap.snapshot_time ? fmtDate(snap.snapshot_time) : '';
        const source = snap.source || '';
        const values = columns.map(c => {
            const val = snap[c.key as keyof Snapshot];
            if (val === null || val === undefined || val === '') return '';
            if (pressureKeys.has(c.key)) return fmtPressure(val as number);
            if (decimalKeys.has(c.key)) return fmtVal(val as number, 1);
            if (typeof val === 'number') return fmtVal(val as number, 0);
            return String(val);
        });

        dataRows.push([row.label, time, source, ...values]);
    }

    const ws2 = XLSX.utils.aoa_to_sheet(dataRows);
    autoFitColumns(ws2, dataRows);

    // Freeze header row
    ws2['!freeze'] = { xSplit: 0, ySplit: 1 };
    // Also use the standard SheetJS freeze panes
    if (!ws2['!freeze']) ws2['!freeze'] = {};
    ws2['!rows'] = [{ hpt: 20 }]; // Header row height

    XLSX.utils.book_append_sheet(wb, ws2, 'CRRT Data');

    // ═══════════════════════════════════════════════════════════
    // Download
    // ═══════════════════════════════════════════════════════════
    const patientName = (treatment.patient_name || treatment.patient_id || 'Unknown').replace(/[^a-z0-9\u00C0-\u024F]/gi, '_');
    const fileName = `CRRT_${patientName}_${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(wb, fileName);
}
