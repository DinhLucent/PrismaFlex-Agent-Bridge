// Treatment Journal — Shared Types
// Extracted from page.tsx for reuse across components

export interface TreatmentIndex {
    id: string;
    device_id: string;
    patient_id: string;
    therapy_type: string;
    start_time: string;
    duration_sec: number;
    outcome: string;
    snapshot_count: number;
    total_packets: number;
    archive_path: string | null;
    close_reason: string | null;
    patient_name?: string | null;
    end_time: string;
    patient_yob?: number | null;
    patient_gender?: string | null;
    patient_weight?: number | null;
    bed_number?: string | null;
    admission_number?: string | null;
    diagnosis?: string | null;
    anticoag_type?: string | null;
    approval_status?: string | null;
    reject_reason?: string | null;
    clinical_notes?: string | null;
    note_count?: number | null;
}

export interface Snapshot {
    hour_label: string;
    snapshot_time: string;
    qb: number | null;
    qs: number | null;
    qd: number | null;
    qpbp: number | null;
    pa: number | null;
    pv: number | null;
    pbe: number | null;
    tmp: number | null;
    uf_total: number | null;
    uf_hourly: number | null;
    effluent_flow: number | null;
    heparin_rate: number | null;
    heparin_bolus: string | null;
    pt_weight: number | null;
    blood_vol: number | null;
    run_time_sec: number | null;
    uf_rate_target: number | null;
    duosol_count: number | null;
    prismasol_count: number | null;
    filter_type: string | null;
    kali: number | null;
    citrate_dose: number | null;
    calcium_comp: number | null;
    calcium_rate: number | null;
    anticoag_type_id: number | null;
    citrate_conc: number | null;
    citrate_load: number | null;
    notes: string | null;
    source: string;
    reason?: string | null;
}

export interface ClinicalNote {
    id: number;
    treatment_id?: string;
    content: string;
    author_name: string;
    created_at: string;
}

export interface ReviewState {
    treatment_id: string;
    approval_status: string;
    reviewer_name?: string | null;
    reviewed_at?: string | null;
    reject_reason?: string | null;
    updated_at?: string;
}

export interface StatusEvent {
    id: number;
    treatment_id: string;
    event_time: string;
    event_code: string;
    note: string | null;
    device_id?: string | null;
}

export interface AuditTrailEntry {
    id: string;
    source: 'note' | 'status' | 'audit';
    category: string;
    action: string;
    title: string;
    description: string;
    event_time: string;
    operator_name?: string | null;
    operator_role?: string | null;
    row_code?: string | null;
    field_name?: string | null;
    old_value?: unknown;
    new_value?: unknown;
    reason?: string | null;
    device_id?: string | null;
}

export interface TreatmentDetail {
    source: string;
    treatment: Record<string, any>;
    config: Record<string, any> | null;
    snapshots: Snapshot[];
    notes?: ClinicalNote[];
    status_log?: StatusEvent[];
    review_state?: ReviewState | null;
}
