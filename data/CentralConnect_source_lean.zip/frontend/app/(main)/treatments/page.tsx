'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
    ClipboardList, Download, ChevronLeft, ChevronRight, Search,
    Activity, CheckCircle2, Clock, Cpu, ChevronDown, ChevronUp,
    X, Maximize2, Minimize2, RefreshCw, Database, Trash2, AlertTriangle, User,
    Fingerprint, Hospital, Cake, Bed, Stethoscope, Hash, UserCog, Printer, Send, ShieldCheck, Lock, Unlock, Plus, Info, FileSpreadsheet, MessageSquare
} from 'lucide-react';
import Header from '../../components/Header';
import PatientInfoModal, { PatientInfo } from '../../components/PatientInfoModal';
import { closeCrrtPrintPreviewStandalone, openCrrtPrintPreviewStandalone } from '../../components/CrrtPrintPreview';
import OperatorCheckInModal, { OperatorBadge } from '../../components/OperatorCheckInModal';
import { useLanguage } from '../../providers/LanguageProvider';
import { useRole } from '../../providers/RoleProvider';
import { useToast } from '../../providers/ToastProvider';
import { useTreatmentOperator } from '../../hooks/useTreatmentOperator';

// ─── Modularized Imports ────────────────────────────────────────
import { TreatmentIndex, TreatmentDetail, AuditTrailEntry } from './types';
import { formatDuration, formatCloseReason, formatDate, formatOutcome } from './columns';
import DetailPanel from './DetailPanel';
import ConfirmDeleteModal from './ConfirmDeleteModal';
import TreatmentNotesModal from './TreatmentNotesModal';
import { exportTreatmentToExcel } from './excelExport';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

function cloneTreatmentDetail(detail: TreatmentDetail): TreatmentDetail {
    if (typeof structuredClone === 'function') {
        return structuredClone(detail);
    }
    return JSON.parse(JSON.stringify(detail)) as TreatmentDetail;
}

// ═══════════════════════════════════════════════════════════════
// MAIN PAGE — Orchestrator
// ═══════════════════════════════════════════════════════════════
export default function TreatmentsPage() {
    const { t, language } = useLanguage();
    const { role } = useRole();
    const { showToast } = useToast();
    const [treatments, setTreatments] = useState<TreatmentIndex[]>([]);
    const [total, setTotal] = useState(0);

    const [page, setPage] = useState(0);
    const [filter, setFilter] = useState<string>('');
    const [patientSearch, setPatientSearch] = useState('');
    const [deviceSearch, setDeviceSearch] = useState('');
    const [dateFrom, setDateFrom] = useState('');
    const [dateTo, setDateTo] = useState('');
    const [selectedId, setSelectedId] = useState<string | null>(null);
    const [isolatedId, setIsolatedId] = useState<string | null>(null);
    const [detail, setDetail] = useState<TreatmentDetail | null>(null);
    const [loading, setLoading] = useState(false);
    const [detailLoading, setDetailLoading] = useState(false);
    const [expanded, setExpanded] = useState(false);
    const [deletingId, setDeletingId] = useState<string | null>(null);
    const [isPatientModalOpen, setIsPatientModalOpen] = useState(false);
    const [submittingId, setSubmittingId] = useState<string | null>(null);
    const [submitConfirmId, setSubmitConfirmId] = useState<string | null>(null);
    const [unlockConfirmId, setUnlockConfirmId] = useState<string | null>(null);
    const [fillingGapHour, setFillingGapHour] = useState<string | null>(null);
    const [noteEditId, setNoteEditId] = useState<string | null>(null);
    const [isHistoryOpen, setIsHistoryOpen] = useState(false);
    const [auditTrail, setAuditTrail] = useState<AuditTrailEntry[] | null>(null);
    const [auditLoading, setAuditLoading] = useState(false);
    const limit = 15;
    const activeTreatmentId = isolatedId || selectedId || null;
    const {
        operator,
        showModal: showOperatorModal,
        ensureOperator,
        confirmOperator,
        cancelModal: cancelOperatorModal,
        clearOperator,
        changeOperator,
    } = useTreatmentOperator(activeTreatmentId, role || 'nurse');

    useEffect(() => {
        return () => {
            closeCrrtPrintPreviewStandalone();
        };
    }, []);

    const fetchList = useCallback(async (isInitial = false) => {
        if (isInitial) setLoading(true);
        try {
            const params = new URLSearchParams({ limit: String(limit), offset: String(page * limit) });
            if (filter) params.set('outcome', filter);
            if (patientSearch) params.set('patient', patientSearch);
            if (deviceSearch) params.set('device', deviceSearch);
            if (dateFrom) params.set('start_time', new Date(dateFrom).toISOString());
            // Make dateTo inclusive of the whole day by adding 23h59m
            if (dateTo) {
                const end = new Date(dateTo);
                end.setHours(23, 59, 59, 999);
                params.set('end_time', end.toISOString());
            }
            const res = await fetch(`${API}/api/v1/treatments?${params}`);
            const data = await res.json();
            setTreatments(data.items || []);
            setTotal(data.total || 0);
        } catch (e) { console.error('List fetch error:', e); }
        if (isInitial) setLoading(false);
    }, [page, filter, patientSearch, deviceSearch, dateFrom, dateTo]);

    useEffect(() => { fetchList(true); }, [fetchList]);

    const fetchDetail = async (id: string) => {
        if (selectedId === id) { setSelectedId(null); setDetail(null); setIsHistoryOpen(false); setAuditTrail(null); return; }
        setSelectedId(id);
        setIsolatedId(null);
        setIsHistoryOpen(false);
        setAuditTrail(null);
        setDetailLoading(true);
        try {
            const res = await fetch(`${API}/api/v1/treatments/${id}`);
            setDetail(await res.json());
        } catch (e) { console.error('Detail fetch error:', e); }
        setDetailLoading(false);
    };

    const openIsolated = async (id: string) => {
        setIsolatedId(id);
        setSelectedId(null);
        setIsHistoryOpen(false);
        setAuditTrail(null);
        setDetailLoading(true);
        try {
            const res = await fetch(`${API}/api/v1/treatments/${id}`);
            setDetail(await res.json());
        } catch (e) { console.error('Isolated fetch error:', e); }
        setDetailLoading(false);
    };

    const refreshDetail = async (id: string) => {
        setDetailLoading(true);
        try {
            const res = await fetch(`${API}/api/v1/treatments/${id}`);
            setDetail(await res.json());
            await new Promise(r => setTimeout(r, 600));
        } catch (e) {
            console.error('Refresh error:', e);
        } finally {
            setDetailLoading(false);
        }
    };

    const loadAuditTrail = async (id: string) => {
        setAuditLoading(true);
        try {
            const res = await fetch(`${API}/api/v1/treatments/${id}/audit-trail?limit=300`);
            if (!res.ok) {
                setAuditTrail(null);
                return;
            }
            const data = await res.json();
            setAuditTrail(Array.isArray(data.events) ? data.events : null);
        } catch (e) {
            console.error('Audit trail fetch error:', e);
            setAuditTrail(null);
        } finally {
            setAuditLoading(false);
        }
    };

    const handleEditPatient = async (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        await openIsolated(id);
        setIsPatientModalOpen(true);
    };

    const handleSavePatientInfo = async (data: Partial<PatientInfo>) => {
        if (!isolatedId) return;
        try {
            const res = await fetch(`${API}/api/v1/treatments/${isolatedId}/patient`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            if (res.ok) {
                refreshDetail(isolatedId);
            } else {
                throw new Error("Failed to save patient info");
            }
        } catch (e) {
            console.error(e);
            throw e;
        }
    };

    const handleExport = (id: string, e?: React.MouseEvent) => {
        e?.stopPropagation();
        window.open(`${API}/api/v1/treatments/${id}/export`, '_blank');
    };

    const handleRawExport = (id: string, e?: React.MouseEvent) => {
        e?.stopPropagation();
        window.open(`${API}/api/v1/treatments/${id}/raw`, '_blank');
    };

    const handleExcelExport = async (id?: string, e?: React.MouseEvent) => {
        e?.stopPropagation();
        // If called from list view, fetch detail on the fly
        if (id) {
            try {
                const res = await fetch(`${API}/api/v1/treatments/${id}`);
                const data = await res.json();
                exportTreatmentToExcel(data, t);
            } catch (err) { console.error('Excel export error:', err); }
            return;
        }
        if (!detail) return;
        exportTreatmentToExcel(detail, t);
    };

    const handleOpenPrintPreview = useCallback(() => {
        if (!detail?.treatment) return;
        openCrrtPrintPreviewStandalone(cloneTreatmentDetail(detail), language);
    }, [detail, language]);

    const handleFillGap = async (hourLabel: string) => {
        if (!isolatedId) return;
        setFillingGapHour(hourLabel);
        try {
            const res = await fetch(`${API}/api/v1/treatments/${isolatedId}/snapshots/manual`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-User-Role': role || 'nurse'
                },
                body: JSON.stringify({ hour_label: hourLabel })
            });
            if (res.ok) {
                showToast(t('msg_snap_added'), 'success');
                refreshDetail(isolatedId);
            } else if (res.status === 409) {
                showToast(t('val_hour_exists'), 'error');
            } else {
                const err = await res.json();
                showToast(err.detail || 'Failed', 'error');
            }
        } catch (e) {
            console.error(e);
            showToast('Network error', 'error');
        } finally {
            setFillingGapHour(null);
        }
    };

    const handleDelete = async (id: string) => {
        try {
            const res = await fetch(`${API}/api/v1/treatments/${id}`, {
                method: 'DELETE',
                headers: {
                    'X-User-Role': 'admin'
                }
            });
            if (res.ok) {
                setDeletingId(null);
                setIsolatedId(null);
                setSelectedId(null);
                setDetail(null);
                setIsHistoryOpen(false);
                setAuditTrail(null);
                fetchList();
            }
        } catch (e) {
            console.error('Delete error:', e);
            alert('Failed to delete treatment. Please try again.');
        }
    };

    const handleNoteOpen = (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        setNoteEditId(id);
    };

    const totalPages = Math.ceil(total / limit);

    return (
        <div className="space-y-4 flex-1 flex flex-col min-h-0 animate-slide-up h-full">
            {/* Conditional Rendering: List or Detail */}
            {!isolatedId ? (
                <>
                    {/* Page Title & Controls - Only shown in List Mode */}
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="p-2.5 bg-teal-500/15 rounded-xl">
                                <ClipboardList className="w-5 h-5 text-teal-400" />
                            </div>
                            <div>
                                <h1 className="text-xl font-black text-[var(--card-foreground)] tracking-tight">{t('treatments_title')}</h1>
                                <p className="text-[10px] text-[var(--muted)] font-bold uppercase tracking-widest">{t('treatments_subtitle')} &middot; {total} {t('treatments_count')}</p>
                            </div>
                        </div>
                        <div className="flex flex-wrap items-center justify-end gap-2 flex-1">
                            {/* Device Search */}
                            <div className="relative">
                                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[var(--muted)]" />
                                <input
                                    type="text"
                                    placeholder={t('search_device')}
                                    value={deviceSearch}
                                    onChange={(e) => { setDeviceSearch(e.target.value); setPage(0); }}
                                    className="pl-8 pr-3 py-1.5 text-xs bg-[var(--background)] border border-[var(--border)] rounded-lg text-[var(--card-foreground)] placeholder:text-[var(--muted)] focus:outline-none focus:border-teal-500/50 w-28"
                                />
                            </div>

                            {/* Patient Search */}
                            <div className="relative">
                                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[var(--muted)]" />
                                <input
                                    type="text"
                                    placeholder={t('search_patient')}
                                    value={patientSearch}
                                    onChange={(e) => { setPatientSearch(e.target.value); setPage(0); }}
                                    className="pl-8 pr-3 py-1.5 text-xs bg-[var(--background)] border border-[var(--border)] rounded-lg text-[var(--card-foreground)] placeholder:text-[var(--muted)] focus:outline-none focus:border-teal-500/50 w-28"
                                />
                            </div>

                            {/* Date Range */}
                            <div className="flex items-center gap-1">
                                <span className="text-[10px] text-[var(--muted)] font-bold uppercase tracking-widest pl-1">{t('date_from')}</span>
                                <input
                                    type="date"
                                    value={dateFrom}
                                    onChange={(e) => { setDateFrom(e.target.value); setPage(0); }}
                                    className="px-2 py-1 text-xs bg-[var(--background)] border border-[var(--border)] rounded-lg text-[var(--card-foreground)] focus:outline-none focus:border-teal-500/50"
                                />
                                <span className="text-[10px] text-[var(--muted)] font-bold uppercase tracking-widest">→</span>
                                <input
                                    type="date"
                                    value={dateTo}
                                    onChange={(e) => { setDateTo(e.target.value); setPage(0); }}
                                    className="px-2 py-1 text-xs bg-[var(--background)] border border-[var(--border)] rounded-lg text-[var(--card-foreground)] focus:outline-none focus:border-teal-500/50"
                                />
                            </div>

                            {/* Filter */}
                            <select
                                value={filter}
                                onChange={(e) => { setFilter(e.target.value); setPage(0); }}
                                className="px-3 py-1.5 text-xs bg-[var(--background)] border border-[var(--border)] rounded-lg text-[var(--card-foreground)] focus:outline-none focus:border-teal-500/50"
                            >
                                <option value="">{t('filter_all')}</option>
                                <option value="IN_PROGRESS">{t('filter_active')}</option>
                                <option value="COMPLETED">{t('filter_done')}</option>
                                <option value="TIMEOUT">TIMEOUT</option>
                            </select>

                            {/* Refresh */}
                            <button
                                onClick={() => fetchList(true)}
                                className="p-1.5 hover:bg-[var(--border)] rounded-lg transition-colors"
                                title={t('btn_sync')}
                            >
                                <RefreshCw className={`w-3.5 h-3.5 text-[var(--muted)] ${loading ? 'animate-spin' : ''}`} />
                            </button>
                        </div>
                    </div>

                    {/* Treatment Table */}
                    <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl overflow-hidden shadow-xl flex-1 flex flex-col min-h-0">
                        <div className="overflow-auto flex-1 min-h-0">
                            <table className="w-full border-collapse text-xs">
                                <thead className="sticky top-0 z-10 bg-[var(--card)] shadow-md">
                                    <tr>
                                        <th className="px-3 py-2 text-left text-[9px] font-black text-[var(--muted)] uppercase tracking-[0.15em] border-b border-[var(--border)]">{t('table_status')}</th>
                                        <th className="px-3 py-2 text-left text-[9px] font-black text-[var(--muted)] uppercase tracking-[0.15em] border-b border-[var(--border)]">{t('table_patient')}</th>
                                        <th className="px-3 py-2 text-left text-[9px] font-black text-[var(--muted)] uppercase tracking-[0.15em] border-b border-[var(--border)]">{t('table_device')}</th>
                                        <th className="px-3 py-2 text-left text-[9px] font-black text-[var(--muted)] uppercase tracking-[0.15em] border-b border-[var(--border)]">{t('table_therapy')}</th>
                                        <th className="px-3 py-2 text-center text-[9px] font-black text-[var(--muted)] uppercase tracking-[0.15em] border-b border-[var(--border)]">{t('lbl_anticoagulant')}</th>
                                        <th className="px-3 py-2 text-left text-[9px] font-black text-[var(--muted)] uppercase tracking-[0.15em] border-b border-[var(--border)]">{t('table_start')}</th>
                                        <th className="px-3 py-2 text-center text-[9px] font-black text-[var(--muted)] uppercase tracking-[0.15em] border-b border-[var(--border)]">{t('table_duration')}</th>
                                        <th className="px-3 py-2 text-center text-[9px] font-black text-[var(--muted)] uppercase tracking-[0.15em] border-b border-[var(--border)]">{t('table_snaps')}</th>
                                        <th className="px-3 py-2 text-center text-[9px] font-black text-[var(--muted)] uppercase tracking-[0.15em] border-b border-[var(--border)]">{t('badge_approved')}</th>
                                        <th className="px-3 py-2 text-center text-[9px] font-black text-[var(--muted)] uppercase tracking-[0.15em] border-b border-[var(--border)]">{t('table_action')}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {loading ? (
                                        <tr><td colSpan={11} className="py-12 text-center text-[var(--muted)] animate-pulse">{t('loading')}</td></tr>
                                    ) : treatments.length === 0 ? (
                                        <tr><td colSpan={11} className="py-12 text-center text-[var(--muted)]">{t('no_data')}</td></tr>
                                    ) : (
                                        treatments.map((treatmentItem) => (
                                            <React.Fragment key={treatmentItem.id}>
                                                <tr
                                                    onClick={() => fetchDetail(treatmentItem.id)}
                                                    className={`cursor-pointer transition-all duration-200 hover:bg-teal-500/[0.04] ${
                                                        selectedId === treatmentItem.id 
                                                            ? 'bg-teal-500/[0.06]' 
                                                            : selectedId 
                                                                ? 'opacity-35' 
                                                                : ''
                                                    }`}
                                                >
                                                    <td className="px-3 py-2.5 border-b border-[var(--border)]/30">
                                                        {treatmentItem.outcome === 'IN_PROGRESS' ? (
                                                            <span className="flex items-center gap-1.5 text-emerald-500 font-bold text-[10px]">
                                                                <span className="relative flex h-2 w-2"><span className="animate-ping absolute h-full w-full rounded-full bg-emerald-400 opacity-75" /><span className="relative h-2 w-2 rounded-full bg-emerald-500" /></span>
                                                                {t('status_recording')}
                                                            </span>
                                                        ) : (
                                                            <span className="text-[10px] text-[var(--muted)] font-bold">{formatCloseReason(treatmentItem.close_reason, t) || formatOutcome(treatmentItem.outcome, t)}</span>
                                                        )}
                                                    </td>
                                                    <td className="px-3 py-2.5 border-b border-[var(--border)]/30">
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-xs font-bold text-[var(--card-foreground)] truncate max-w-[120px]">{treatmentItem.patient_name || treatmentItem.patient_id || '—'}</span>
                                                            {!treatmentItem.patient_name && treatmentItem.outcome !== 'IN_PROGRESS' && (
                                                                <button
                                                                    onClick={(e) => handleEditPatient(treatmentItem.id, e)}
                                                                    className="text-[8px] bg-amber-500/10 text-amber-500 px-1.5 py-0.5 rounded font-bold hover:bg-amber-500/20 transition-colors"
                                                                >
                                                                    ✎ {t('btn_patient')}
                                                                </button>
                                                            )}
                                                        </div>
                                                    </td>
                                                    <td className="px-3 py-2.5 border-b border-[var(--border)]/30 text-xs font-mono text-[var(--muted)]">{treatmentItem.device_id}</td>
                                                    <td className="px-3 py-2.5 border-b border-[var(--border)]/30 text-xs font-bold text-[var(--card-foreground)]">{treatmentItem.therapy_type || '—'}</td>
                                                    <td className="px-3 py-2.5 border-b border-[var(--border)]/30 text-center">
                                                        {treatmentItem.anticoag_type ? (
                                                            <span className={`inline-flex items-center gap-1 text-[9px] font-black px-2.5 py-1 rounded-lg uppercase tracking-wider border ${
                                                                treatmentItem.anticoag_type === 'Citrate' 
                                                                    ? 'bg-cyan-500/8 text-cyan-500 border-cyan-500/20' 
                                                                : treatmentItem.anticoag_type === 'Heparin' 
                                                                    ? 'bg-rose-500/8 text-rose-400 border-rose-500/20' 
                                                                    : 'bg-slate-500/8 text-slate-400 border-slate-500/15'
                                                            }`}>
                                                                <span className={`w-1.5 h-1.5 rounded-full ${
                                                                    treatmentItem.anticoag_type === 'Citrate' ? 'bg-cyan-400' :
                                                                    treatmentItem.anticoag_type === 'Heparin' ? 'bg-rose-400' : 'bg-slate-400'
                                                                }`} />
                                                                {treatmentItem.anticoag_type}
                                                            </span>
                                                        ) : (
                                                            <span className="text-[9px] text-[var(--muted)] opacity-40">—</span>
                                                        )}
                                                    </td>
                                                    <td className="px-3 py-2.5 border-b border-[var(--border)]/30 text-xs text-[var(--muted)]">
                                                        <div>{formatDate(treatmentItem.start_time)}</div>
                                                        <div className="text-[10px] opacity-60">{new Date(treatmentItem.start_time).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}</div>
                                                    </td>
                                                    <td className="px-3 py-2.5 border-b border-[var(--border)]/30 text-center text-xs font-bold text-[var(--card-foreground)]">{formatDuration(treatmentItem.duration_sec)}</td>
                                                    <td className="px-3 py-2.5 border-b border-[var(--border)]/30 text-center text-xs font-mono text-[var(--muted)]">{treatmentItem.snapshot_count}</td>
                                                    <td className="px-3 py-2.5 border-b border-[var(--border)]/30 text-center">
                                                        {treatmentItem.approval_status === 'APPROVED' ? (
                                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-full text-[9px] font-black uppercase">
                                                                <ShieldCheck className="w-3 h-3" />{t('badge_approved')}
                                                            </span>
                                                        ) : treatmentItem.approval_status === 'PENDING_REVIEW' ? (
                                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-indigo-500/10 text-indigo-400 rounded-full text-[9px] font-black uppercase">
                                                                <Clock className="w-3 h-3 animate-pulse" />{t('badge_pending')}
                                                            </span>
                                                        ) : (
                                                            <span className="text-[9px] text-[var(--muted)] opacity-40 uppercase">{t('badge_draft')}</span>
                                                        )}
                                                    </td>
                                                    <td className="px-3 py-2.5 border-b border-[var(--border)]/30 text-center">
                                                        <div className="flex items-center justify-center gap-1">
                                                            <button
                                                                onClick={(e) => { e.stopPropagation(); openIsolated(treatmentItem.id); }}
                                                                className="p-1 hover:bg-teal-500/10 rounded transition-colors text-[var(--muted)] hover:text-teal-400"
                                                                title={t('btn_detail')}
                                                            >
                                                                <Maximize2 className="w-3.5 h-3.5" />
                                                            </button>
                                                            <button
                                                                onClick={(e) => handleExport(treatmentItem.id, e)}
                                                                className="p-1 hover:bg-amber-500/10 rounded transition-colors text-[var(--muted)] hover:text-amber-400"
                                                                title={t('btn_export')}
                                                            >
                                                                <Download className="w-3.5 h-3.5" />
                                                            </button>
                                                            <button
                                                                onClick={(e) => handleExcelExport(treatmentItem.id, e)}
                                                                className="p-1 hover:bg-teal-500/10 rounded transition-colors text-[var(--muted)] hover:text-teal-400"
                                                                title="Export Excel"
                                                            >
                                                                <FileSpreadsheet className="w-3.5 h-3.5" />
                                                            </button>
                                                            <button
                                                                onClick={(e) => handleNoteOpen(treatmentItem.id, e)}
                                                                className={`p-1 rounded transition-colors relative ${
                                                                    ((treatmentItem.note_count || 0) > 0 || !!treatmentItem.clinical_notes)
                                                                        ? 'text-amber-500 hover:bg-amber-500/10'
                                                                        : 'text-[var(--muted)] hover:text-amber-400 hover:bg-amber-500/10'
                                                                }`}
                                                                title={t('btn_notes')}
                                                            >
                                                                <MessageSquare className="w-3.5 h-3.5" />
                                                                {(((treatmentItem.note_count || 0) > 0) || !!treatmentItem.clinical_notes) && (
                                                                    <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-amber-400 rounded-full" />
                                                                )}
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>

                                                {selectedId === treatmentItem.id && (
                                                    <tr>
                                                        <td colSpan={11} className="p-0">
                                                            <div className="max-h-[500px] overflow-auto">
                                                            <DetailPanel
                                                                t={treatmentItem}
                                                                detail={detail}
                                                                loading={detailLoading}
                                                                onExport={() => handleExport(treatmentItem.id)}
                                                                expanded={false}
                                                                onToggleExpand={() => { }}
                                                                onClose={() => { setSelectedId(null); setDetail(null); setIsHistoryOpen(false); setAuditTrail(null); }}
                                                                onRefresh={() => refreshDetail(treatmentItem.id)}
                                                                showNotesHistory={selectedId === treatmentItem.id ? isHistoryOpen : false}
                                                                onHistoryToggle={selectedId === treatmentItem.id ? (open) => {
                                                                    setIsHistoryOpen(open);
                                                                    if (open) loadAuditTrail(treatmentItem.id);
                                                                } : undefined}
                                                                auditTrail={selectedId === treatmentItem.id ? auditTrail : null}
                                                                auditLoading={selectedId === treatmentItem.id ? auditLoading : false}
                                                                operatorName={selectedId === treatmentItem.id ? operator?.name : undefined}
                                                                userRole={role || 'nurse'}
                                                                ensureOperator={ensureOperator}
                                                            />
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )}
                                            </React.Fragment>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>

                        {totalPages > 1 && (
                            <div className="flex items-center justify-between px-3 py-2 border-t border-[var(--border)] bg-[var(--background)]/30">
                                <span className="text-[10px] text-[var(--muted)]">
                                    {page * limit + 1}&ndash;{Math.min((page + 1) * limit, total)} {t('pagination_of')} {total} {t('treatments_count')}
                                </span>
                                <div className="flex items-center gap-1">
                                    <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}
                                        className="p-1 rounded hover:bg-[var(--border)] disabled:opacity-20 transition-colors">
                                        <ChevronLeft className="w-3.5 h-3.5 text-[var(--muted)]" />
                                    </button>
                                    <span className="px-2 text-[10px] font-bold text-[var(--card-foreground)]">
                                        {page + 1}/{totalPages}
                                    </span>
                                    <button onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1}
                                        className="p-1 rounded hover:bg-[var(--border)] disabled:opacity-20 transition-colors">
                                        <ChevronRight className="w-3.5 h-3.5 text-[var(--muted)]" />
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </>
            ) : (
                /* Isolated Detail Mode */
                <div className="flex-1 flex flex-col min-h-0 gap-4 animate-slide-up">
                    <div className="sticky top-0 z-20 bg-[var(--card)]/60 backdrop-blur-xl p-5 rounded-2xl border border-[var(--border)] shadow-2xl relative overflow-hidden group">
                        {/* Decorative Background Accent */}
                        <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/5 -mr-32 -mt-32 rounded-full blur-3xl pointer-events-none" />

                        {/* Lock Banner for APPROVED treatments */}
                        {(() => {
                            const currentItem = treatments.find(x => x.id === isolatedId);
                            return currentItem?.approval_status === 'APPROVED' ? (
                                <div className="relative z-10 mb-4 flex items-center gap-3 px-4 py-3 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl">
                                    <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                                    <span className="text-sm font-bold text-emerald-400">{t('treatment_locked_msg')}</span>
                                </div>
                            ) : null;
                        })()}

                        {/* Rejection Banner with Doctor's Note */}
                        {(() => {
                            const currentItem = treatments.find(x => x.id === isolatedId);
                            return currentItem?.reject_reason && currentItem?.approval_status === 'DRAFT' ? (
                                <div className="relative z-10 mb-4 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-2xl">
                                    <div className="flex items-center gap-3 mb-2">
                                        <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
                                        <span className="text-sm font-bold text-red-400">{t('badge_rejected')}</span>
                                    </div>
                                    <div className="ml-8 text-xs text-[var(--muted)]">
                                        <span className="font-bold text-red-400/80">{t('rejected_note_label')}:</span>{' '}
                                        <span className="italic">{currentItem.reject_reason}</span>
                                    </div>
                                </div>
                            ) : null;
                        })()}

                        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
                            {/* Left Side: Back Button & Patient Identity */}
                            <div className="flex items-center gap-4 min-w-0">
                                <button
                                    onClick={() => { setIsolatedId(null); setDetail(null); setIsHistoryOpen(false); setAuditTrail(null); }}
                                    className="p-2.5 bg-slate-500/10 hover:bg-teal-500/15 text-slate-500 hover:text-teal-500 rounded-xl transition-all active:scale-95 group/back border border-transparent hover:border-teal-500/20 shadow-sm"
                                    title={t('back_to_list')}
                                >
                                    <ChevronLeft className="w-5 h-5 group-hover/back:-translate-x-0.5 transition-transform" />
                                </button>

                                <div className="flex flex-col min-w-0">
                                    <div className="flex items-center gap-3 mb-1">
                                        <h1 className="text-xl font-black text-[var(--card-foreground)] tracking-tight uppercase truncate" title={detail?.treatment?.patient_name || detail?.treatment?.patient_id || 'UNKNOWN PATIENT'}>
                                            {detail?.treatment?.patient_name || detail?.treatment?.patient_id || 'UNKNOWN PATIENT'}
                                        </h1>
                                        {detail?.treatment?.patient_gender && (
                                            <span className="text-[9px] font-black text-[var(--muted)] opacity-60 uppercase bg-slate-500/10 px-1.5 py-0.5 rounded border border-slate-500/10">
                                                {detail.treatment.patient_gender === 'Nam' ? t('label_gender_male') : detail.treatment.patient_gender === 'Nữ' ? t('label_gender_female') : detail.treatment.patient_gender}
                                            </span>
                                        )}
                                    </div>

                                    <div className="flex flex-wrap items-center gap-1.5">
                                        {detail?.treatment?.patient_id && (
                                            <span className="flex items-center gap-1 px-1.5 py-0.5 bg-blue-500/5 border border-blue-500/10 rounded-md text-[9px] font-bold text-blue-500 uppercase tracking-wider" title="Patient ID">
                                                <Fingerprint className="w-3 h-3" />
                                                ID: {detail?.treatment?.patient_id ?? 'N/A'}
                                            </span>
                                        )}
                                        <span className="flex items-center gap-1 px-1.5 py-0.5 bg-teal-500/5 border border-teal-500/10 rounded-md text-[9px] font-bold text-teal-500 uppercase tracking-wider" title="Device ID">
                                            <Activity className="w-3 h-3" />
                                            {detail?.treatment?.device_id}
                                        </span>
                                        <span className="flex items-center gap-1 px-1.5 py-0.5 bg-slate-500/5 border border-slate-500/10 rounded-md text-[9px] font-bold text-[var(--muted)] uppercase tracking-wider" title="Session Hash">
                                            <Hash className="w-3 h-3" />
                                            {isolatedId?.slice(0, 8)}
                                        </span>
                                        {detail?.treatment?.admission_number && (
                                            <span className="flex items-center gap-1 px-1.5 py-0.5 bg-indigo-500/5 border border-indigo-500/10 rounded-md text-[9px] font-bold text-indigo-500 uppercase tracking-wider" title="BA">
                                                <Hospital className="w-3 h-3" />
                                                {t('label_ba')}: {detail?.treatment?.admission_number}
                                            </span>
                                        )}
                                    </div>
                                </div>
                            </div>

                            {/* Right Side: Action Groups */}
                            <div className="flex flex-wrap items-center gap-3">
                                {operator ? (
                                    <OperatorBadge name={operator.name} onClear={clearOperator} onChange={changeOperator} />
                                ) : (
                                    <button
                                        onClick={changeOperator}
                                        className="flex items-center gap-1.5 rounded-xl border border-sky-500/20 bg-sky-500/10 px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-sky-500 transition-all hover:bg-sky-500/20"
                                        title={t('label_operator_entry')}
                                    >
                                        <Info className="w-3.5 h-3.5" />
                                        <span className="hidden xl:inline">{t('label_operator_entry')}</span>
                                    </button>
                                )}

                                {/* Group: Clinical Controls */}
                                <div className="flex items-center bg-[var(--background)]/40 p-1 rounded-xl border border-[var(--border)] gap-0.5 shadow-sm">
                                    <button
                                        onClick={() => setIsPatientModalOpen(true)}
                                        disabled={treatments.find(x => x.id === isolatedId)?.approval_status === 'APPROVED'}
                                        className="flex items-center gap-1.5 px-3 py-2 hover:bg-blue-500/10 text-[10px] font-bold text-blue-500 rounded-lg transition-all uppercase tracking-wider disabled:opacity-30"
                                        title={t('btn_patient')}
                                    >
                                        <UserCog className="w-3.5 h-3.5" />
                                        <span className="hidden xl:inline">{t('btn_patient')}</span>
                                    </button>
                                    <div className="w-px h-5 bg-[var(--border)] opacity-50" />
                                    <button
                                        onClick={() => refreshDetail(isolatedId as string)}
                                        disabled={detailLoading}
                                        className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all text-[10px] uppercase tracking-wider active:scale-95 ${detailLoading
                                            ? 'bg-teal-500/10 text-teal-300'
                                            : 'hover:bg-teal-500/10 text-teal-400 font-bold'
                                            }`}
                                        title={t('btn_sync')}
                                    >
                                        <RefreshCw className={`w-3.5 h-3.5 ${detailLoading ? 'animate-spin' : ''}`} />
                                        <span className="hidden xl:inline">{detailLoading ? t('btn_syncing') : t('btn_sync')}</span>
                                    </button>
                                </div>

                                {/* Group: Document & Data */}
                                <div className="flex items-center bg-[var(--background)]/40 p-1 rounded-xl border border-[var(--border)] gap-0.5 shadow-sm">
                                    <button
                                        onClick={handleOpenPrintPreview}
                                        disabled={!detail?.treatment}
                                        className="flex items-center gap-1.5 px-3 py-2 hover:bg-emerald-500/10 text-[10px] font-bold text-emerald-500 rounded-lg transition-all uppercase tracking-wider"
                                        title={t('btn_print')}
                                    >
                                        <Printer className="w-3.5 h-3.5" />
                                        <span className="hidden xl:inline">{t('btn_print')}</span>
                                    </button>
                                    <div className="w-px h-5 bg-[var(--border)] opacity-50" />
                                    <button
                                        onClick={() => handleExport(isolatedId as string)}
                                        className="flex items-center gap-1.5 px-3 py-2 hover:bg-amber-500/10 text-[10px] font-bold text-amber-500 rounded-lg transition-all uppercase tracking-wider"
                                        title={t('btn_export')}
                                    >
                                        <Download className="w-3.5 h-3.5" />
                                        <span className="hidden xl:inline">{t('btn_export')}</span>
                                    </button>
                                    <div className="w-px h-5 bg-[var(--border)] opacity-50" />
                                    <button
                                        onClick={(e) => handleRawExport(isolatedId as string, e)}
                                        className="flex items-center gap-1.5 px-3 py-2 hover:bg-indigo-500/10 text-[10px] font-bold text-indigo-500 rounded-lg transition-all uppercase tracking-wider"
                                        title={t('btn_raw')}
                                    >
                                        <Database className="w-3.5 h-3.5" />
                                        <span className="hidden xl:inline">{t('btn_raw')}</span>
                                    </button>
                                    <div className="w-px h-5 bg-[var(--border)] opacity-50" />
                                    <button
                                        onClick={() => handleExcelExport()}
                                        className="flex items-center gap-1.5 px-3 py-2 hover:bg-teal-500/10 text-[10px] font-bold text-teal-500 rounded-lg transition-all uppercase tracking-wider"
                                        title="Export Excel"
                                    >
                                        <FileSpreadsheet className="w-3.5 h-3.5" />
                                        <span className="hidden xl:inline">Excel</span>
                                    </button>
                                </div>

                                <div className="flex items-center bg-[var(--background)]/40 p-1 rounded-xl border border-[var(--border)] gap-0.5 shadow-sm">
                                    <button
                                        onClick={() => setNoteEditId(isolatedId as string)}
                                        className="flex items-center gap-1.5 px-3 py-2 hover:bg-amber-500/10 text-[10px] font-bold text-amber-500 rounded-lg transition-all uppercase tracking-wider"
                                        title={t('btn_notes')}
                                    >
                                        <MessageSquare className="w-3.5 h-3.5" />
                                        <span className="hidden xl:inline">{t('btn_notes')}</span>
                                    </button>
                                    <div className="w-px h-5 bg-[var(--border)] opacity-50" />
                                    <button
                                        onClick={() => {
                                            const nextOpen = !isHistoryOpen;
                                            setIsHistoryOpen(nextOpen);
                                            if (nextOpen && isolatedId) loadAuditTrail(isolatedId);
                                        }}
                                        className={`relative flex items-center gap-1.5 rounded-lg px-3 py-2 text-[10px] font-bold uppercase tracking-wider transition-all ${
                                            isHistoryOpen
                                                ? 'bg-amber-500 text-white'
                                                : 'text-amber-500 hover:bg-amber-500/10'
                                        }`}
                                        title={t('lbl_audit_trail')}
                                    >
                                        <Clock className="w-3.5 h-3.5" />
                                        <span className="hidden xl:inline">{t('lbl_audit_trail')}</span>
                                    </button>
                                </div>

                                {/* Decision Actions */}
                                <div className="flex items-center gap-2">
                                    {(() => {
                                        const currentItem = treatments.find(x => x.id === isolatedId);
                                        if (currentItem?.approval_status === 'APPROVED') return null;
                                        return (
                                            <button
                                                onClick={() => setDeletingId(isolatedId as string)}
                                                className="p-2 bg-red-500/5 hover:bg-red-500/10 text-red-500 rounded-lg border border-red-500/20 transition-all hover:scale-105"
                                                title={t('btn_purge')}
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </button>
                                        );
                                    })()}

                                    {(() => {
                                        const currentItem = treatments.find(x => x.id === isolatedId);
                                        const approvalStatus = currentItem?.approval_status || 'DRAFT';
                                        if (approvalStatus === 'APPROVED') {
                                            return (
                                                <div className="flex items-center gap-1.5">
                                                    <div className="flex items-center gap-1.5 px-3 py-2 bg-emerald-500/10 text-emerald-400 rounded-lg border border-emerald-500/20 text-[10px] font-black uppercase tracking-wider cursor-default shadow-sm shadow-emerald-500/5">
                                                        <ShieldCheck className="w-3.5 h-3.5" />
                                                        {t('badge_approved')}
                                                    </div>
                                                    {(role === 'doctor' || role === 'admin') && (
                                                        <button
                                                            onClick={() => setUnlockConfirmId(isolatedId)}
                                                            className="flex items-center gap-1.5 px-3 py-2 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 rounded-lg border border-amber-500/20 text-[10px] font-black uppercase tracking-wider transition-all"
                                                            title={t('btn_unlock')}
                                                        >
                                                            <Unlock className="w-3.5 h-3.5" />
                                                        </button>
                                                    )}
                                                </div>
                                            );
                                        }
                                        if (approvalStatus === 'PENDING_REVIEW') {
                                            return (
                                                <div className="flex items-center gap-1.5 px-3 py-2 bg-indigo-500/10 text-indigo-400 rounded-lg border border-indigo-500/20 text-[10px] font-black uppercase tracking-wider cursor-default shadow-inner">
                                                    <Clock className="w-3.5 h-3.5 animate-pulse" />
                                                    {t('badge_pending')}
                                                </div>
                                            );
                                        }
                                        if (role === 'doctor') return null;
                                        return (
                                            <button
                                                onClick={() => {
                                                    if (currentItem?.outcome === 'IN_PROGRESS') { showToast(t('submit_still_recording'), 'warning'); return; }
                                                    const hasName = currentItem?.patient_name || detail?.treatment?.patient_name;
                                                    if (!hasName) { showToast(t('submit_missing_patient'), 'error'); return; }
                                                    setSubmitConfirmId(isolatedId);
                                                }}
                                                disabled={!!submittingId}
                                                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-all text-[10px] font-black uppercase tracking-wider shadow-md shadow-indigo-600/20 active:scale-95 disabled:opacity-50"
                                            >
                                                <Send className="w-3.5 h-3.5" />
                                                {t('btn_submit_review')}
                                            </button>
                                        );
                                    })()}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-[var(--card)] border border-[var(--border)] rounded-2xl overflow-hidden shadow-2xl flex-1 flex flex-col min-h-0">
                        <DetailPanel
                            t={treatments.find(x => x.id === isolatedId) || {} as any}
                            detail={detail}
                            loading={detailLoading}
                            onExport={() => handleExport(isolatedId as string)}
                            expanded={true}
                            onToggleExpand={() => { }}
                            onClose={() => { setIsolatedId(null); setDetail(null); setIsHistoryOpen(false); setAuditTrail(null); }}
                            onRefresh={() => refreshDetail(isolatedId as string)}
                            onFillGap={(role === 'nurse' || role === 'admin') ? handleFillGap : undefined}
                            fillingGapHour={fillingGapHour}
                            showNotesHistory={isHistoryOpen}
                            onHistoryToggle={(open) => {
                                setIsHistoryOpen(open);
                                if (open && isolatedId) loadAuditTrail(isolatedId);
                            }}
                            auditTrail={auditTrail}
                            auditLoading={auditLoading}
                            operatorName={operator?.name}
                            userRole={role || 'nurse'}
                            ensureOperator={ensureOperator}
                        />
                    </div>
                </div>
            )}

            {/* Global Delete Confirmation Modal */}
            {deletingId && (
                <ConfirmDeleteModal
                    patientId={treatments.find(t => t.id === deletingId)?.patient_id || 'Unknown'}
                    onConfirm={() => handleDelete(deletingId)}
                    onCancel={() => setDeletingId(null)}
                />
            )}

            {/* Patient Info Modal */}
            <PatientInfoModal
                isOpen={isPatientModalOpen}
                onClose={() => setIsPatientModalOpen(false)}
                onSave={handleSavePatientInfo}
                initialData={detail?.treatment || {}}
            />

            <OperatorCheckInModal
                open={showOperatorModal}
                onConfirm={confirmOperator}
                onCancel={cancelOperatorModal}
            />


            {/* Submit for Review Confirmation Modal */}
            {submitConfirmId && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
                    <div className="bg-[var(--card)] border border-[var(--border)] w-full max-w-md rounded-3xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
                        <div className="p-8 border-b border-[var(--border)] bg-indigo-500/5">
                            <div className="flex items-center gap-4 mb-4">
                                <div className="p-3 rounded-2xl bg-indigo-500/20">
                                    <Send className="w-6 h-6 text-indigo-400" />
                                </div>
                                <h2 className="text-xl font-black text-[var(--foreground)]">{t('confirm_submit_title')}</h2>
                            </div>
                            <p className="text-sm text-[var(--muted)] leading-relaxed">{t('confirm_submit_msg')}</p>
                        </div>
                        <div className="p-6 flex gap-3 justify-end">
                            <button
                                onClick={() => setSubmitConfirmId(null)}
                                className="px-5 py-3 rounded-xl border border-[var(--border)] text-[var(--foreground)] font-bold text-sm hover:bg-[var(--background)] transition-all"
                            >
                                {t('btn_cancel')}
                            </button>
                            <button
                                onClick={async () => {
                                    if (!submitConfirmId) return;
                                    setSubmittingId(submitConfirmId);
                                    try {
                                        const res = await fetch(`${API}/api/v1/treatments/${submitConfirmId}/submit`, {
                                            method: 'POST',
                                            headers: { 'X-User-Role': role || 'nurse' },
                                        });
                                        if (res.ok) {
                                            setTreatments(prev => prev.map(item =>
                                                item.id === submitConfirmId ? { ...item, approval_status: 'PENDING_REVIEW' } : item
                                            ));
                                        }
                                    } catch (err) { console.error('Submit failed:', err); }
                                    finally { setSubmittingId(null); setSubmitConfirmId(null); }
                                }}
                                disabled={!!submittingId}
                                className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-500/20 transition-all disabled:opacity-50"
                            >
                                {submittingId ? '...' : t('btn_confirm_submit')}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Unlock Confirmation Modal */}
            {unlockConfirmId && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
                    <div className="bg-[var(--card)] border border-[var(--border)] w-full max-w-md rounded-3xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
                        <div className="p-8 border-b border-[var(--border)] bg-amber-500/5">
                            <div className="flex items-center gap-4 mb-4">
                                <div className="p-3 rounded-2xl bg-amber-500/20">
                                    <Unlock className="w-6 h-6 text-amber-400" />
                                </div>
                                <h2 className="text-xl font-black text-[var(--foreground)]">{t('confirm_unlock_title')}</h2>
                            </div>
                            <p className="text-sm text-[var(--muted)] leading-relaxed">{t('confirm_unlock_msg')}</p>
                        </div>
                        <div className="p-6 flex gap-3 justify-end">
                            <button
                                onClick={() => setUnlockConfirmId(null)}
                                className="px-5 py-3 rounded-xl border border-[var(--border)] text-[var(--foreground)] font-bold text-sm hover:bg-[var(--background)] transition-all"
                            >
                                {t('btn_cancel')}
                            </button>
                            <button
                                onClick={async () => {
                                    if (!unlockConfirmId) return;
                                    try {
                                        const res = await fetch(`${API}/api/v1/treatments/${unlockConfirmId}/unlock`, {
                                            method: 'POST',
                                            headers: { 'X-User-Role': role || 'doctor' },
                                        });
                                        if (res.ok) {
                                            setTreatments(prev => prev.map(item =>
                                                item.id === unlockConfirmId ? { ...item, approval_status: 'PENDING_REVIEW' } : item
                                            ));
                                        }
                                    } catch (err) { console.error('Unlock failed:', err); }
                                    finally { setUnlockConfirmId(null); }
                                }}
                                className="px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-white font-bold text-sm shadow-lg shadow-amber-500/20 transition-all"
                            >
                                {t('btn_unlock')}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Clinical Notes Modal */}
            {noteEditId && (
                <TreatmentNotesModal
                    key={noteEditId}
                    treatmentId={noteEditId}
                    patientName={treatments.find(x => x.id === noteEditId)?.patient_name || treatments.find(x => x.id === noteEditId)?.patient_id || '---'}
                    userRole={role || 'nurse'}
                    onNoteAdded={() => {
                        const targetId = noteEditId;
                        setTreatments(prev => prev.map(item =>
                            item.id === noteEditId
                                ? { ...item, note_count: (item.note_count || 0) + 1 }
                                : item
                        ));
                        if (targetId && (targetId === isolatedId || targetId === selectedId)) {
                            refreshDetail(targetId);
                            if (isHistoryOpen) loadAuditTrail(targetId);
                        }
                    }}
                    onClose={() => setNoteEditId(null)}
                />
            )}
        </div>
    );
}
