'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '../../../providers/LanguageProvider';
import { useRole } from '../../../providers/RoleProvider';
import { ClipboardCheck, Check, X, Trash2, Eye, RefreshCw, AlertTriangle, Clock, User, GitCompare, RotateCcw } from 'lucide-react';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

interface TreatmentItem {
    id: string;
    device_id: string;
    patient_id?: string;
    patient_name?: string;
    therapy_type?: string;
    start_time: string;
    end_time?: string;
    duration_sec: number;
    outcome: string;
    snapshot_count: number;
    approval_status?: string;
    anticoag_type?: string;
    bed_number?: string;
    diagnosis?: string;
}

interface SnapshotRow {
    id: number;
    hour_label: string;
    snapshot_time: string;
    qb?: number;
    qs?: number;
    qd?: number;
    qpbp?: number;
    pa?: number;
    pv?: number;
    pbe?: number;
    tmp?: number;
    uf_total?: number;
    uf_hourly?: number;
    effluent_flow?: number;
    heparin_rate?: number;
    duosol_count?: number;
    prismasol_count?: number;
    filter_type?: string;
    kali?: number;
    notes?: string;
    [key: string]: any;
}

interface DetailData {
    treatment: any;
    config: any;
    snapshots: SnapshotRow[];
    status_log_count: number;
}

export default function ReviewPage() {
    const { t } = useLanguage();
    const { role, isNurse } = useRole();
    const router = useRouter();

    // Nurse redirect guard
    useEffect(() => {
        if (isNurse) router.replace('/treatments');
    }, [isNurse, router]);

    const [treatments, setTreatments] = useState<TreatmentItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedId, setSelectedId] = useState<string | null>(null);
    const [detail, setDetail] = useState<DetailData | null>(null);
    const [detailLoading, setDetailLoading] = useState(false);
    const [confirmModal, setConfirmModal] = useState<{ type: 'approve' | 'reject' | null; id: string | null }>({ type: null, id: null });
    const [actionLoading, setActionLoading] = useState(false);
    const [rejectReason, setRejectReason] = useState('');
    const [deleteConfirm, setDeleteConfirm] = useState<SnapshotRow | null>(null);

    // Compare view
    const [showCompare, setShowCompare] = useState(false);
    const [originals, setOriginals] = useState<Record<string, Record<string, any>>>({});

    const missingHours = useMemo(() => {
        if (!detail?.snapshots || !originals) return [];
        const currentHours = new Set(detail.snapshots.map(s => s.hour_label));
        return Object.keys(originals).filter(h => !currentHours.has(h)).sort();
    }, [detail?.snapshots, originals]);

    // ─── Fetch Pending Treatments ──────────────────────────────────
    const fetchPending = useCallback(async () => {
        try {
            const res = await fetch(`${API}/api/v1/treatments?approval_status=PENDING_REVIEW&limit=100`);
            if (res.ok) {
                const data = await res.json();
                setTreatments(data.items || []);
            }
        } catch (err) {
            console.error('Failed to fetch pending treatments:', err);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { fetchPending(); }, [fetchPending]);

    // ─── Fetch Detail ──────────────────────────────────────────────
    const fetchDetail = async (id: string) => {
        setSelectedId(id);
        setDetailLoading(true);
        try {
            const res = await fetch(`${API}/api/v1/treatments/${id}`);
            if (res.ok) {
                const data = await res.json();
                setDetail(data);
                // Pre-fetch originals for Compare & Restore features
                fetchOriginals(id);
            }
        } catch (err) {
            console.error('Failed to fetch detail:', err);
        } finally {
            setDetailLoading(false);
        }
    };

    const fetchOriginals = async (id: string) => {
        try {
            const res = await fetch(`${API}/api/v1/treatments/${id}/originals`);
            if (res.ok) {
                const data = await res.json();
                const map: Record<string, Record<string, any>> = {};
                for (const orig of (data.originals || [])) {
                    map[orig.hour_label] = orig.data || {};
                }
                setOriginals(map);
            }
        } catch { setOriginals({}); }
    };

    // ─── Actions ───────────────────────────────────────────────────
    const handleApprove = async (id: string) => {
        setActionLoading(true);
        try {
            const res = await fetch(`${API}/api/v1/treatments/${id}/approve`, {
                method: 'POST',
                headers: { 'X-User-Role': role || 'doctor' },
            });
            if (res.ok) {
                setTreatments(prev => prev.filter(t => t.id !== id));
                if (selectedId === id) { setSelectedId(null); setDetail(null); }
                setConfirmModal({ type: null, id: null });
            }
        } catch (err) {
            console.error('Approve failed:', err);
        } finally {
            setActionLoading(false);
        }
    };

    const handleReject = async (id: string) => {
        if (!rejectReason.trim()) return; // require reason
        setActionLoading(true);
        try {
            const res = await fetch(`${API}/api/v1/treatments/${id}/reject`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-User-Role': role || 'doctor' },
                body: JSON.stringify({ reason: rejectReason.trim() }),
            });
            if (res.ok) {
                setTreatments(prev => prev.filter(t => t.id !== id));
                if (selectedId === id) { setSelectedId(null); setDetail(null); }
                setConfirmModal({ type: null, id: null });
                setRejectReason('');
            }
        } catch (err) {
            console.error('Reject failed:', err);
        } finally {
            setActionLoading(false);
        }
    };

    // ─── Format Helpers ────────────────────────────────────────────
    const formatDuration = (sec: number) => {
        if (!sec) return '-';
        const h = Math.floor(sec / 3600);
        const m = Math.floor((sec % 3600) / 60);
        return `${h}h ${m}m`;
    };

    const formatTime = (ts: string) => {
        if (!ts) return '-';
        try {
            const d = new Date(ts);
            return d.toLocaleString('vi-VN', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
        } catch { return ts; }
    };

    // ─── Column definitions — Dynamic based on Anticoagulation ─────
    const BASE_COLS = [
        { key: 'qb', label: 'QB', editable: true },
        { key: 'qd', label: 'QD', editable: true },
        { key: 'qs', label: 'QS', editable: true },
    ];

    const UF_COLS = [
        { key: 'uf_total', label: 'UF (2)', editable: true },
        { key: 'uf_hourly', label: 'UF RATE', editable: true },
    ];

    const PRESSURE_COLS = [
        { key: 'pa', label: 'PA', editable: true },
        { key: 'pv', label: 'PV', editable: true },
        { key: 'pbe', label: 'PBE', editable: true },
        { key: 'tmp', label: 'TMP', editable: true },
    ];

    function getSnapshotColumns(anticoagId: number | null | undefined, t: any) {
        const isCitrate = anticoagId === 2 || anticoagId === 3;

        if (isCitrate) {
            return [
                { key: 'hour_label', label: t('col_hour'), editable: false },
                { key: 'uf_total', label: t('col_uf_total'), editable: true },
                { key: 'uf_hourly', label: t('col_uf_rate'), editable: true },
                { key: 'qb', label: 'QB', editable: true },
                { key: 'qs', label: 'QS', editable: true },
                { key: 'qd', label: 'QD', editable: true },
                { key: 'qpbp', label: t('col_qci'), editable: true },
                ...PRESSURE_COLS,
                { key: 'duosol_count', label: t('col_duosol'), editable: true },
                { key: 'prismasol_count', label: t('col_prismasol'), editable: true },
                { key: 'filter_type', label: t('col_filter'), editable: true },
                { key: 'calcium_comp', label: t('col_calcium_comp'), editable: true },
                { key: 'citrate_dose', label: t('col_citrate_dose'), editable: true },
                { key: 'kali', label: t('col_calcium_rate'), editable: true },
            ];
        }

        return [
            { key: 'hour_label', label: t('col_hour'), editable: false },
            ...BASE_COLS,
            { key: 'qpbp', label: t('col_qpbp'), editable: true },
            ...UF_COLS,
            { key: 'heparin_bolus', label: t('col_heparin_bolus'), editable: true },
            { key: 'heparin_rate', label: t('col_heparin_rate'), editable: true },
            ...PRESSURE_COLS,
            { key: 'duosol_count', label: t('col_duosol'), editable: true },
            { key: 'prismasol_count', label: t('col_prismasol'), editable: true },
            { key: 'filter_type', label: t('col_filter'), editable: true },
            { key: 'kali', label: t('col_kali'), editable: true },
        ];
    }

    // ─── Edit Snapshot Cell ────────────────────────────────────────
    const [editingCell, setEditingCell] = useState<{ snapId: number; key: string } | null>(null);
    const [editValue, setEditValue] = useState('');

    const startEdit = (snapId: number, key: string, currentVal: any) => {
        setEditingCell({ snapId, key });
        setEditValue(currentVal?.toString() || '');
    };

    const saveEdit = async () => {
        if (!editingCell || !detail || !selectedId) return;
        const snap = detail.snapshots.find(s => s.id === editingCell.snapId);
        if (!snap) return;

        const payload: any = {};
        payload[editingCell.key] = editingCell.key === 'filter_type'
            ? editValue
            : editValue === '' ? null : parseFloat(editValue);

        try {
            const res = await fetch(`${API}/api/v1/treatments/${selectedId}/snapshots/${snap.hour_label}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-User-Role': role || 'nurse'
                },
                body: JSON.stringify(payload),
            });
            if (res.ok) {
                // Update local state
                setDetail(prev => {
                    if (!prev) return prev;
                    return {
                        ...prev,
                        snapshots: prev.snapshots.map(s =>
                            s.id === editingCell.snapId
                                ? { ...s, [editingCell.key]: payload[editingCell.key] }
                                : s
                        )
                    };
                });
            }
        } catch (err) {
            console.error('Save edit failed:', err);
        } finally {
            setEditingCell(null);
        }
    };

    const restoreSnapshot = async (snap: SnapshotRow) => {
        if (!selectedId || !originals[snap.hour_label]) return;
        const originalData = originals[snap.hour_label];

        try {
            const res = await fetch(`${API}/api/v1/treatments/${selectedId}/snapshots/${snap.hour_label}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-User-Role': role || 'doctor'
                },
                body: JSON.stringify(originalData),
            });
            if (res.ok) {
                setDetail(prev => {
                    if (!prev) return prev;
                    return {
                        ...prev,
                        snapshots: prev.snapshots.map(s =>
                            s.id === snap.id ? { ...s, ...originalData } : s
                        )
                    };
                });
            }
        } catch (err) {
            console.error('Restore snapshot failed:', err);
        }
    };

    const restoreMissingHours = async () => {
        if (!selectedId || missingHours.length === 0) return;
        setActionLoading(true);
        try {
            for (const hour of missingHours) {
                const originalData = originals[hour];
                await fetch(`${API}/api/v1/treatments/${selectedId}/snapshots/${hour}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-User-Role': role || 'doctor'
                    },
                    body: JSON.stringify(originalData),
                });
            }
            // Refresh detail to see new rows
            await fetchDetail(selectedId);
        } catch (err) {
            console.error('Restore missing hours failed:', err);
        } finally {
            setActionLoading(false);
        }
    };

    // ─── Delete Snapshot Row ───────────────────────────────────────
    const deleteSnapshot = async (snap: SnapshotRow) => {
        if (!selectedId) return;
        setDeleteConfirm(null);

        try {
            const res = await fetch(`${API}/api/v1/treatments/${selectedId}/snapshots/${snap.hour_label}`, {
                method: 'DELETE',
                headers: { 'X-User-Role': role || 'doctor' }
            });
            if (res.ok) {
                setDetail(prev => {
                    if (!prev) return prev;
                    return {
                        ...prev,
                        snapshots: prev.snapshots.filter(s => s.id !== snap.id)
                    };
                });
            }
        } catch (err) {
            console.error('Delete snapshot failed:', err);
        }
    };

    return (
        <div className="min-h-screen bg-[var(--background)] text-[var(--foreground)] p-6">
            {/* Header */}
            <div className="mb-8">
                <div className="flex items-center gap-4 mb-2">
                    <div className="p-3 bg-indigo-500/10 rounded-2xl">
                        <ClipboardCheck className="w-7 h-7 text-indigo-400" />
                    </div>
                    <div>
                        <h1 className="text-2xl font-black tracking-tight text-[var(--foreground)]">{t('review_title')}</h1>
                        <p className="text-sm text-[var(--muted)] font-medium">{t('review_subtitle')}</p>
                    </div>
                    <button
                        onClick={() => { setLoading(true); fetchPending(); }}
                        className="ml-auto p-3 rounded-xl hover:bg-[var(--card)] transition-colors text-[var(--muted)] hover:text-teal-400"
                    >
                        <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
                    </button>
                </div>
            </div>

            {/* Empty State */}
            {!loading && treatments.length === 0 && (
                <div className="flex flex-col items-center justify-center py-24 text-center">
                    <div className="p-6 bg-[var(--card)] rounded-3xl border border-[var(--border)] mb-6">
                        <ClipboardCheck className="w-12 h-12 text-[var(--muted)] opacity-40" />
                    </div>
                    <h3 className="text-lg font-bold text-[var(--foreground)] mb-2">{t('review_empty_title')}</h3>
                    <p className="text-sm text-[var(--muted)] max-w-md">
                        {t('review_empty_desc')}
                    </p>
                </div>
            )}

            {/* Loading */}
            {loading && (
                <div className="flex items-center justify-center py-24">
                    <RefreshCw className="w-8 h-8 text-teal-400 animate-spin" />
                </div>
            )}

            {/* Main Content: List + Detail */}
            {!loading && treatments.length > 0 && (
                <div className="grid grid-cols-1 xl:grid-cols-4 gap-4">
                    {/* Left: Treatment List */}
                    <div className="xl:col-span-1 space-y-3">
                        <p className="text-xs font-bold text-[var(--muted)] uppercase tracking-widest mb-4">
                            {treatments.length} {t('review_pending_count')}
                        </p>
                        {treatments.map(item => (
                            <button
                                key={item.id}
                                onClick={() => fetchDetail(item.id)}
                                className={`w-full text-left p-4 rounded-2xl border transition-all duration-300 group ${selectedId === item.id
                                    ? 'bg-indigo-500/10 border-indigo-500/30 shadow-lg shadow-indigo-500/10'
                                    : 'bg-[var(--card)] border-[var(--border)] hover:border-indigo-500/20 hover:shadow-md'
                                    }`}
                            >
                                <div className="flex items-center justify-between mb-2">
                                    <span className="text-xs font-mono font-bold text-indigo-400">
                                        {item.device_id}
                                    </span>
                                    <span className="px-2 py-0.5 text-[9px] font-black uppercase tracking-wider rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/20">
                                        {t('badge_pending')}
                                    </span>
                                </div>
                                <div className="flex items-center gap-2 mb-1">
                                    <User className="w-3.5 h-3.5 text-[var(--muted)]" />
                                    <span className="text-sm font-semibold text-[var(--foreground)] truncate">
                                        {item.patient_name || item.patient_id || 'N/A'}
                                    </span>
                                </div>
                                <div className="flex items-center gap-4 text-xs text-[var(--muted)]">
                                    <span className="flex items-center gap-1">
                                        <Clock className="w-3 h-3" />
                                        {formatTime(item.start_time)}
                                    </span>
                                    <span>{formatDuration(item.duration_sec)}</span>
                                    <span>{item.snapshot_count} {t('table_snaps')}</span>
                                </div>
                            </button>
                        ))}
                    </div>

                    {/* Right: Detail View */}
                    <div className="xl:col-span-3">
                        {!selectedId && (
                            <div className="flex items-center justify-center h-64 text-[var(--muted)] text-sm">
                                <Eye className="w-5 h-5 mr-2 opacity-40" />
                                {t('review_select_hint')}
                            </div>
                        )}

                        {detailLoading && (
                            <div className="flex items-center justify-center h-64">
                                <RefreshCw className="w-6 h-6 text-teal-400 animate-spin" />
                            </div>
                        )}

                        {selectedId && detail && !detailLoading && (
                            <div className="bg-[var(--card)] rounded-3xl border border-[var(--border)] overflow-hidden">
                                {/* Detail Header */}
                                <div className="p-6 border-b border-[var(--border)] bg-gradient-to-r from-indigo-500/5 to-transparent">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <h2 className="text-lg font-black text-[var(--foreground)]">
                                                {detail.treatment?.patient_name || detail.treatment?.patient_id || 'N/A'}
                                            </h2>
                                            <p className="text-xs text-[var(--muted)] mt-1">
                                                {detail.treatment?.device_id} • {detail.treatment?.therapy_type_name || 'Unknown'} • {detail.snapshots?.length || 0} snapshots
                                            </p>
                                        </div>
                                        <div className="flex gap-2">
                                            {missingHours.length > 0 && (
                                                <button
                                                    onClick={restoreMissingHours}
                                                    disabled={actionLoading}
                                                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-orange-500/10 text-orange-400 hover:bg-orange-500/20 transition-all font-bold text-sm border border-orange-500/20 shadow-lg shadow-orange-500/10 animate-pulse"
                                                    title={`${t('btn_restore_hint')} (${missingHours.length})`}
                                                >
                                                    <RotateCcw className={`w-4 h-4 ${actionLoading ? 'animate-spin' : ''}`} />
                                                    {t('btn_restore_rows')} ({missingHours.length})
                                                </button>
                                            )}
                                            <button
                                                onClick={() => {
                                                    if (!showCompare && selectedId) fetchOriginals(selectedId);
                                                    setShowCompare(!showCompare);
                                                }}
                                                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm border transition-all ${showCompare
                                                    ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
                                                    : 'bg-[var(--card)] text-[var(--muted)] border-[var(--border)] hover:text-cyan-400 hover:border-cyan-500/30'
                                                    }`}
                                            >
                                                <GitCompare className="w-4 h-4" />
                                                {showCompare ? t('btn_compare_hide') : t('btn_compare_show')}
                                            </button>
                                            <button
                                                onClick={() => setConfirmModal({ type: 'reject', id: selectedId })}
                                                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-all font-bold text-sm border border-red-500/20"
                                            >
                                                <X className="w-4 h-4" />
                                                {t('btn_reject')}
                                            </button>
                                            <button
                                                onClick={() => setConfirmModal({ type: 'approve', id: selectedId })}
                                                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 text-white hover:bg-emerald-500 transition-all font-bold text-sm shadow-lg shadow-emerald-500/20"
                                            >
                                                <Check className="w-4 h-4" />
                                                {t('btn_approve')}
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                {/* Snapshot Table */}
                                <div className="overflow-x-auto">
                                    {detail.snapshots && detail.snapshots.length > 0 ? (
                                        <table className="w-full text-sm">
                                            <thead>
                                                <tr className="border-b border-[var(--border)]">
                                                    {getSnapshotColumns(detail.treatment?.anticoag_type_id, t).map(col => (
                                                        <th key={col.key} className="px-1.5 py-3 text-left text-[9px] font-black uppercase tracking-tighter text-[var(--muted)]">
                                                            {col.label}
                                                        </th>
                                                    ))}
                                                    <th className="px-1.5 py-3 w-20"></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {detail.snapshots.map((snap, idx) => {
                                                    const columns = getSnapshotColumns(detail.treatment?.anticoag_type_id, t);
                                                    return (
                                                        <tr key={snap.id} className={`border-b border-[var(--border)]/50 hover:bg-indigo-500/5 transition-colors ${idx % 2 !== 0 ? 'bg-slate-500/[0.03] dark:bg-white/[0.02]' : ''}`}>
                                                            {columns.map(col => {
                                                                const val = snap[col.key];
                                                                const isEditing = editingCell?.snapId === snap.id && editingCell?.key === col.key;
                                                                const originalVal = originals[snap.hour_label]?.[col.key];
                                                                const hasDiff = showCompare && originalVal != null && val != null && String(originalVal) !== String(val);

                                                                return (
                                                                    <td key={col.key} className="px-1 py-2">
                                                                        {isEditing ? (
                                                                            <input
                                                                                autoFocus
                                                                                value={editValue}
                                                                                onChange={e => setEditValue(e.target.value)}
                                                                                onBlur={saveEdit}
                                                                                onKeyDown={e => { if (e.key === 'Enter') saveEdit(); if (e.key === 'Escape') setEditingCell(null); }}
                                                                                className="w-full px-2 py-1 text-sm bg-indigo-500/10 border border-indigo-500/30 rounded-lg text-[var(--foreground)] outline-none focus:ring-2 focus:ring-indigo-500/50"
                                                                            />
                                                                        ) : col.editable ? (
                                                                            <div
                                                                                onClick={() => startEdit(snap.id, col.key, val)}
                                                                                className={`cursor-pointer px-2 py-1 rounded-lg hover:bg-indigo-500/10 transition-all flex flex-col items-center min-w-[50px] ${hasDiff ? 'bg-amber-500/15 ring-1 ring-amber-500/30' : ''}`}
                                                                                title={hasDiff ? `Gốc: ${originalVal}` : t('click_to_edit')}
                                                                            >
                                                                                <span className={`text-sm ${hasDiff ? 'text-amber-300 font-black' : ''}`}>
                                                                                    {val != null ? (typeof val === 'number' ? val.toFixed(1) : val) : <span className="text-[var(--muted)] opacity-40">—</span>}
                                                                                </span>
                                                                                {hasDiff && (
                                                                                    <span className="text-[9px] text-amber-500/60 line-through decoration-amber-500/40 font-bold -mt-0.5">
                                                                                        {typeof originalVal === 'number' ? originalVal.toFixed(1) : originalVal}
                                                                                    </span>
                                                                                )}
                                                                            </div>
                                                                        ) : (
                                                                            <span className="font-bold text-indigo-400">{val || '-'}</span>
                                                                        )}
                                                                    </td>
                                                                );
                                                            })}
                                                            <td className="px-2 py-2 flex items-center gap-1">
                                                                <button
                                                                    onClick={() => restoreSnapshot(snap)}
                                                                    className={`p-1.5 rounded-lg transition-all ${originals[snap.hour_label] ? 'text-cyan-400/40 hover:text-cyan-400 hover:bg-cyan-500/10' : 'opacity-0 cursor-default'}`}
                                                                    title={t('btn_restore_rows')}
                                                                >
                                                                    <RefreshCw className="w-3.5 h-3.5" />
                                                                </button>
                                                                <button
                                                                    onClick={() => setDeleteConfirm(snap)}
                                                                    className="p-1.5 rounded-lg text-red-400/40 hover:text-red-400 hover:bg-red-500/10 transition-all"
                                                                    title={t('btn_confirm_delete')}
                                                                >
                                                                    <Trash2 className="w-3.5 h-3.5" />
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    ) : (
                                        <div className="p-12 text-center text-[var(--muted)] text-sm">
                                            {t('no_snapshots')}
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Confirmation Modal */}
            {confirmModal.type && confirmModal.id && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
                    <div className="bg-[var(--card)] border border-[var(--border)] w-full max-w-md rounded-3xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
                        <div className={`p-8 border-b border-[var(--border)] ${confirmModal.type === 'approve' ? 'bg-emerald-500/5' : 'bg-red-500/5'}`}>
                            <div className="flex items-center gap-4 mb-4">
                                <div className={`p-3 rounded-2xl ${confirmModal.type === 'approve' ? 'bg-emerald-500/20' : 'bg-red-500/20'}`}>
                                    {confirmModal.type === 'approve'
                                        ? <Check className="w-6 h-6 text-emerald-400" />
                                        : <AlertTriangle className="w-6 h-6 text-red-400" />}
                                </div>
                                <h2 className="text-xl font-black text-[var(--foreground)]">
                                    {confirmModal.type === 'approve' ? t('confirm_approve_title') : t('confirm_reject_title')}
                                </h2>
                            </div>
                            <p className="text-sm text-[var(--muted)] leading-relaxed">
                                {confirmModal.type === 'approve' ? t('confirm_approve_msg') : t('confirm_reject_msg')}
                            </p>
                            {confirmModal.type === 'reject' && (
                                <textarea
                                    value={rejectReason}
                                    onChange={e => setRejectReason(e.target.value)}
                                    placeholder={t('reject_reason_placeholder')}
                                    rows={3}
                                    className="mt-4 w-full px-4 py-3 rounded-xl bg-[var(--background)] border border-[var(--border)] text-sm text-[var(--foreground)] placeholder:text-[var(--muted)] resize-none focus:outline-none focus:ring-2 focus:ring-red-500/30"
                                />
                            )}
                        </div>
                        <div className="p-6 flex gap-3 justify-end">
                            <button
                                onClick={() => setConfirmModal({ type: null, id: null })}
                                className="px-5 py-3 rounded-xl border border-[var(--border)] text-[var(--foreground)] font-bold text-sm hover:bg-[var(--background)] transition-all"
                                disabled={actionLoading}
                            >
                                {t('btn_cancel')}
                            </button>
                            <button
                                onClick={() => confirmModal.type === 'approve' ? handleApprove(confirmModal.id!) : handleReject(confirmModal.id!)}
                                disabled={actionLoading || (confirmModal.type === 'reject' && !rejectReason.trim())}
                                className={`px-5 py-3 rounded-xl font-bold text-sm text-white transition-all shadow-lg ${confirmModal.type === 'approve'
                                    ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-500/20'
                                    : 'bg-red-600 hover:bg-red-500 shadow-red-500/20'
                                    } ${actionLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                            >
                                {actionLoading ? '...' : confirmModal.type === 'approve' ? t('btn_approve') : t('btn_reject')}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Delete Confirmation Modal */}
            {deleteConfirm && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
                    <div className="bg-[var(--card)] border border-[var(--border)] w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl p-8">
                        <div className="flex items-center gap-4 mb-4">
                            <div className="p-3 rounded-2xl bg-red-500/20">
                                <Trash2 className="w-6 h-6 text-red-400" />
                            </div>
                            <h2 className="text-xl font-black text-[var(--foreground)]">{t('confirm_delete_row_title')}</h2>
                        </div>
                        <p className="text-sm text-[var(--muted)] leading-relaxed mb-8">
                            {t('confirm_delete_row_msg')} <strong>{deleteConfirm.hour_label}</strong>. {t('review_restore_hint')}
                        </p>
                        <div className="flex gap-3 justify-end">
                            <button
                                onClick={() => setDeleteConfirm(null)}
                                className="px-5 py-3 rounded-xl border border-[var(--border)] text-[var(--foreground)] font-bold text-sm hover:bg-[var(--background)] transition-all"
                            >
                                {t('btn_cancel')}
                            </button>
                            <button
                                onClick={() => deleteSnapshot(deleteConfirm)}
                                className="px-5 py-3 rounded-xl font-bold text-sm text-white bg-red-600 hover:bg-red-500 transition-all shadow-lg shadow-red-500/20"
                            >
                                {t('btn_delete_now')}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
