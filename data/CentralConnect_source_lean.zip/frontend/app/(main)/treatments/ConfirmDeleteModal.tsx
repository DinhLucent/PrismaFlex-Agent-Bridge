'use client';

import { useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { useLanguage } from '../../providers/LanguageProvider';

// ─── Confirm Delete Modal (Password Protected) ──────────────────
export default function ConfirmDeleteModal({ patientId, onConfirm, onCancel }: {
    patientId: string;
    onConfirm: () => void;
    onCancel: () => void;
}) {
    const { t } = useLanguage();
    const [password, setPassword] = useState('');
    const [error, setError] = useState(false);

    const handleConfirm = () => {
        if (password === 'admin') {
            setError(false);
            onConfirm();
        } else {
            setError(true);
        }
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-fade-in">
            <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" onClick={onCancel} />
            <div className="relative w-full max-w-md bg-[var(--card)] border border-red-500/20 rounded-3xl shadow-2xl shadow-red-500/10 overflow-hidden animate-scale-in">
                {/* Header */}
                <div className="bg-gradient-to-r from-red-500/10 to-transparent p-6 pb-4">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-red-500/10 dark:bg-red-500/20 rounded-2xl">
                            <AlertTriangle className="w-6 h-6 text-red-600 dark:text-red-500" />
                        </div>
                        <div>
                            <h3 className="text-lg font-black text-slate-900 dark:text-white tracking-tight">{t('confirm_delete_title')}</h3>
                            <p className="text-[10px] text-red-600 dark:text-red-400 font-bold uppercase tracking-widest mt-0.5">{t('confirm_delete_subtitle')}</p>
                        </div>
                    </div>
                </div>

                {/* Content */}
                <div className="p-6 pt-2 space-y-4">
                    <p className="text-xs text-[var(--muted)] leading-relaxed">
                        {t('confirm_delete_msg')} <span className="text-slate-900 dark:text-white font-bold">{patientId}</span>.
                        {t('confirm_delete_detail')}
                    </p>

                    <div className="bg-red-500/5 border border-red-500/10 rounded-2xl p-4">
                        <p className="text-[10px] text-red-600/80 dark:text-red-400/80 font-medium leading-tight italic">
                            * {t('confirm_delete_warn')}
                        </p>
                    </div>

                    <div className="space-y-2 pt-2">
                        <label className="text-[10px] text-[var(--muted)] font-bold uppercase tracking-widest">{t('password_required')}</label>
                        <input
                            type="password"
                            autoFocus
                            value={password}
                            onChange={(e) => { setPassword(e.target.value); setError(false); }}
                            onKeyDown={(e) => { if (e.key === 'Enter') handleConfirm(); }}
                            placeholder={t('password_placeholder')}
                            className={`w-full px-4 py-2 bg-slate-500/5 border ${error ? 'border-red-500 focus:border-red-500' : 'border-slate-500/30 focus:border-red-500/50'} rounded-xl text-sm text-[var(--card-foreground)] outline-none transition-colors placeholder:text-slate-400 dark:placeholder:text-slate-500`}
                        />
                        {error && <p className="text-[10px] text-red-600 dark:text-red-400 font-bold animate-pulse">{t('password_error')}</p>}
                    </div>
                </div>

                {/* Actions */}
                <div className="p-6 bg-slate-500/5 flex items-center gap-3">
                    <button
                        onClick={onCancel}
                        className="flex-1 px-4 py-2.5 bg-slate-500/10 hover:bg-slate-500/20 text-[11px] font-black text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all uppercase tracking-widest"
                    >
                        {t('btn_cancel')}
                    </button>
                    <button
                        onClick={handleConfirm}
                        className="flex-1 px-4 py-2.5 bg-red-500/10 dark:bg-red-500/20 hover:bg-red-500/20 dark:hover:bg-red-500/30 text-[11px] font-black text-red-600 dark:text-red-500 rounded-xl border border-red-500/20 transition-all uppercase tracking-widest shadow-lg shadow-red-500/5 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                        disabled={!password}
                    >
                        {t('btn_confirm_delete')}
                    </button>
                </div>
            </div>
        </div>
    );
}
