'use client';

import React, { useState, useEffect, useRef } from 'react';
import { MessageSquarePlus, Send, Clock, User, PenLine } from 'lucide-react';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

interface NoteEntry {
    id: number;
    content: string;
    author: string;
    author_name?: string;
    created_at: string;
}

function formatNoteTime(iso: string): string {
    try {
        const d = new Date(iso);
        return d.toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' });
    } catch { return iso; }
}

export default function TreatmentNotesModal({
    treatmentId,
    patientName,
    onNoteAdded,
    onClose,
    userRole = 'nurse',
}: {
    treatmentId: string;
    patientName: string;
    onNoteAdded?: () => void;
    onClose: () => void;
    userRole?: string;
}) {
    const [notes, setNotes] = useState<NoteEntry[]>([]);
    const [loading, setLoading] = useState(true);
    const [newNote, setNewNote] = useState('');
    const [authorName, setAuthorName] = useState('');
    const [saving, setSaving] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);
    const authorRef = useRef<HTMLInputElement>(null);

    // Load last used author from localStorage (persistent across sessions)
    useEffect(() => {
        const saved = localStorage.getItem('notes_author_name');
        if (saved) setAuthorName(saved);
    }, []);

    // Fetch notes on mount
    useEffect(() => {
        setLoading(true);
        setNotes([]);
        fetchNotes();
    }, [treatmentId]);

    const fetchNotes = async () => {
        try {
            const res = await fetch(`${API}/api/v1/treatments/${treatmentId}/notes/log`);
            if (res.ok) {
                const data = await res.json();
                setNotes(data.notes || []);
            }
        } catch (err) {
            console.error('Fetch notes error:', err);
        } finally {
            setLoading(false);
        }
    };

    // Auto-scroll to bottom when notes change
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [notes]);

    const handleSubmit = async () => {
        const trimmedAuthor = authorName.trim();
        const trimmedNote = newNote.trim();
        if (!trimmedNote || !trimmedAuthor || trimmedAuthor.length < 2 || saving) return;

        // Save author name for next time
        localStorage.setItem('notes_author_name', trimmedAuthor);

        setSaving(true);
        try {
            const res = await fetch(`${API}/api/v1/treatments/${treatmentId}/notes/log`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Operator-Name': encodeURIComponent(trimmedAuthor),
                    'X-User-Role': userRole,
                },
                body: JSON.stringify({ content: trimmedNote }),
            });
            if (res.ok) {
                const note = await res.json();
                setNotes(prev => [...prev, note]);
                setNewNote('');
                if (onNoteAdded) onNoteAdded();
            }
        } catch (err) {
            console.error('Add note error:', err);
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200" onClick={onClose}>
            <div className="bg-[var(--card)] border border-[var(--border)] w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col max-h-[80vh]"
                onClick={e => e.stopPropagation()}>
                
                {/* Header */}
                <div className="p-6 border-b border-[var(--border)] bg-amber-500/5">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="p-2.5 rounded-2xl bg-amber-500/20">
                            <MessageSquarePlus className="w-5 h-5 text-amber-500" />
                        </div>
                        <div>
                            <h2 className="text-lg font-black text-[var(--foreground)]">Ghi chú ca điều trị</h2>
                            <p className="text-xs text-[var(--muted)]">{patientName}</p>
                        </div>
                    </div>
                    <p className="text-[10px] text-[var(--muted)] mt-1">
                        Ghi chú không thể xóa hoặc sửa sau khi lưu. Mỗi ghi chú gắn tên người nhập và thời gian.
                    </p>
                </div>

                {/* Notes list */}
                <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 min-h-[200px]">
                    {loading ? (
                        <div className="text-center text-[var(--muted)] text-sm animate-pulse py-8">Đang tải...</div>
                    ) : notes.length === 0 ? (
                        <div className="text-center text-[var(--muted)] text-sm py-8">
                            <MessageSquarePlus className="w-8 h-8 mx-auto mb-2 opacity-30" />
                            Chưa có ghi chú nào
                        </div>
                    ) : (
                        notes.map(note => (
                            <div key={note.id} className="group rounded-xl bg-[var(--background)] border border-[var(--border)]/50 p-3 transition-all hover:border-amber-500/20">
                                {/* Author + Time */}
                                <div className="flex items-center gap-2 mb-1.5">
                                    <User className="w-3 h-3 text-amber-500" />
                                    <span className="text-[11px] font-bold text-amber-600 dark:text-amber-400">
                                        {(() => {
                                            const name = note.author_name || note.author;
                                            try { return decodeURIComponent(name); } catch { return name; }
                                        })()}
                                    </span>
                                    <span className="text-[10px] text-[var(--muted)] ml-auto flex items-center gap-1">
                                        <Clock className="w-2.5 h-2.5" />
                                        {formatNoteTime(note.created_at)}
                                    </span>
                                </div>
                                {/* Content */}
                                <p className="text-sm text-[var(--foreground)] whitespace-pre-wrap leading-relaxed">{note.content}</p>
                            </div>
                        ))
                    )}
                </div>

                {/* Input area — self-contained author name + note content */}
                <div className="p-4 border-t border-[var(--border)] bg-[var(--background)]/50 space-y-3">
                    {/* Author name input */}
                    <div className="flex items-center gap-2">
                        <PenLine className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                        <input
                            ref={authorRef}
                            type="text"
                            value={authorName}
                            onChange={e => setAuthorName(e.target.value)}
                            placeholder="Tên người ghi chú (VD: ĐD Lan, BS Minh)"
                            className="flex-1 px-3 py-2 rounded-lg border border-[var(--border)] bg-[var(--card)] text-xs text-[var(--foreground)] placeholder:text-[var(--muted)] focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500/50"
                        />
                    </div>

                    {/* Note content + submit */}
                    <div className="flex gap-2">
                        <div className="flex-1 relative">
                            <textarea
                                value={newNote}
                                onChange={e => setNewNote(e.target.value)}
                                placeholder="Nhập ghi chú lâm sàng..."
                                className="w-full px-3 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--card)] text-sm text-[var(--foreground)] placeholder:text-[var(--muted)] focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500/50 resize-none"
                                rows={2}
                                onKeyDown={e => {
                                    if (e.key === 'Enter' && !e.shiftKey) {
                                        e.preventDefault();
                                        handleSubmit();
                                    }
                                }}
                            />
                            <div className="text-[9px] text-[var(--muted)] mt-1">
                                Enter để lưu · Shift+Enter để xuống dòng
                            </div>
                        </div>
                        <button
                            onClick={handleSubmit}
                            disabled={!newNote.trim() || !authorName.trim() || authorName.trim().length < 2 || saving}
                            className="self-start px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm shadow-lg shadow-amber-500/20 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                            {saving ? '...' : <Send className="w-4 h-4" />}
                        </button>
                    </div>
                </div>

                {/* Close button */}
                <div className="p-3 border-t border-[var(--border)] flex justify-end">
                    <button
                        onClick={onClose}
                        className="px-5 py-2 rounded-xl border border-[var(--border)] text-[var(--foreground)] font-bold text-sm hover:bg-[var(--background)] transition-all"
                    >
                        Đóng
                    </button>
                </div>
            </div>
        </div>
    );
}
