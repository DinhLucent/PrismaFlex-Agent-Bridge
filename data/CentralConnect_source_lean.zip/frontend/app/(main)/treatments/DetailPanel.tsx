'use client';

import React from 'react';
import { Activity, ClipboardList, Clock, Pencil, Plus, User, X } from 'lucide-react';
import { useLanguage } from '../../providers/LanguageProvider';
import { TreatmentDetail, TreatmentIndex, Snapshot, AuditTrailEntry } from './types';
import { getColumns, getGroupBg, formatTime, fmtVal, MANUAL_EDIT_KEYS } from './columns';
import EditableCell from './EditableCell';

type DetailPanelProps = {
    t: TreatmentIndex;
    detail: TreatmentDetail | null;
    loading: boolean;
    onExport: () => void;
    expanded: boolean;
    onToggleExpand: () => void;
    onClose: () => void;
    onRefresh: () => void;
    onFillGap?: (hourLabel: string) => void;
    fillingGapHour?: string | null;
    showNotesHistory?: boolean;
    onHistoryToggle?: (open: boolean) => void;
    auditTrail?: AuditTrailEntry[] | null;
    auditLoading?: boolean;
    operatorName?: string;
    userRole?: string;
    ensureOperator?: (action: () => void) => void;
};

type DisplayRow =
    | { type: 'data'; snap: Snapshot; hourNum: number }
    | { type: 'gap'; hourNum: number }
    | { type: 'oc'; snap: Snapshot; label: string };

function decodeSafe(value?: string | null) {
    if (!value) return '';
    try {
        return decodeURIComponent(value);
    } catch {
        return value;
    }
}

function formatEventLabel(eventCode?: string | null) {
    return (eventCode || 'SYSTEM').replace(/_/g, ' ');
}

function stringifyAuditValue(value: unknown) {
    if (value === null || value === undefined || value === '') return '--';
    if (typeof value === 'object') {
        try {
            return JSON.stringify(value);
        } catch {
            return String(value);
        }
    }
    return String(value);
}

function fallbackAuditDescription(item: AuditTrailEntry) {
    if (item.description) return item.description;
    if (item.field_name) {
        return `${item.row_code || 'Row'} | ${item.field_name}: ${stringifyAuditValue(item.old_value)} -> ${stringifyAuditValue(item.new_value)}`;
    }
    return formatEventLabel(item.action);
}

export default function DetailPanel({
    t: treatmentIndex,
    detail,
    onClose,
    expanded,
    onToggleExpand,
    onExport,
    loading,
    onRefresh,
    onFillGap,
    fillingGapHour,
    showNotesHistory,
    onHistoryToggle,
    auditTrail,
    auditLoading,
    operatorName,
    userRole,
    ensureOperator,
}: DetailPanelProps) {
    const { t } = useLanguage();

    if (loading) {
        return <div className="animate-pulse p-8 text-center text-sm text-[var(--muted)]">{t('loading')}</div>;
    }
    if (!detail) return null;

    const snaps = [...(detail.snapshots || [])].sort(
        (a, b) => new Date(a.snapshot_time).getTime() - new Date(b.snapshot_time).getTime()
    );

    const displayRows: DisplayRow[] = [];
    if (snaps.length > 0) {
        let expectedHour = 1;
        for (const snap of snaps) {
            if (snap.hour_label.startsWith('H')) {
                const hourNum = parseInt(snap.hour_label.replace('H', ''), 10);
                if (Number.isNaN(hourNum)) continue;

                while (expectedHour < hourNum) {
                    displayRows.push({ type: 'gap', hourNum: expectedHour });
                    expectedHour++;
                }
                displayRows.push({ type: 'data', snap, hourNum });
                expectedHour = hourNum + 1;
            } else if (snap.hour_label.startsWith('OC')) {
                displayRows.push({ type: 'oc', snap, label: snap.hour_label });
            }
        }
    }

    const visibleHistory = [...(auditTrail ?? [])].sort(
        (a, b) => new Date(b.event_time).getTime() - new Date(a.event_time).getTime()
    );

    return (
        <div className="relative flex min-h-0 flex-1 flex-col border-t border-teal-500/30 bg-[radial-gradient(circle_at_50%_0%,rgba(20,184,166,0.05),transparent)] shadow-inner backdrop-blur-sm">
            <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-20">
                <div className="absolute left-1/4 top-0 h-full w-1/2 rounded-full bg-teal-500/5 blur-[120px]" />
            </div>

            <div className="relative z-10 min-h-0 max-h-[calc(100vh-280px)] flex-1 overflow-auto">
                <table className="w-full border-collapse text-xs">
                    <thead className="sticky top-0 z-30 bg-[var(--card)] shadow-md">
                        <tr>
                            <th className="sticky left-0 z-20 w-16 border-b border-r border-[var(--border)] bg-[var(--card)] px-3 py-2 text-left text-[9px] font-black uppercase tracking-[0.15em] text-[var(--muted)]">
                                {t('col_hour')}
                            </th>
                            {getColumns(snaps[0]?.anticoag_type_id, t).map((column, index, all) => {
                                const prevGroup = index > 0 ? all[index - 1].group : '';
                                const showSep = index > 0 && column.group !== prevGroup;
                                const groupBg = getGroupBg(column.group);
                                return (
                                    <th
                                        key={column.key}
                                        className={`min-w-[60px] border-b border-[var(--border)] px-2 py-2 text-center ${showSep ? 'border-l-2 border-l-[var(--border)]' : ''} ${groupBg}`}
                                    >
                                        <div className={`text-[9px] font-black uppercase tracking-wider ${column.color}`}>{column.label}</div>
                                        {column.unit && <div className="mt-0.5 text-[8px] text-[var(--muted)] opacity-30">{column.unit}</div>}
                                    </th>
                                );
                            })}
                        </tr>
                    </thead>
                    <tbody>
                        {displayRows.map((row, rowIdx) => {
                            const isLastRow = rowIdx === displayRows.length - 1;
                            const hourLabel = row.type === 'oc' ? row.label : `H${String(row.hourNum).padStart(2, '0')}`;

                            if (row.type === 'gap') {
                                const cols = snaps.length > 0 ? getColumns(snaps[0]?.anticoag_type_id, t) : getColumns(null, t);
                                const isFilling = fillingGapHour === hourLabel;
                                return (
                                    <tr
                                        key={`gap-${row.hourNum}`}
                                        className="bg-[repeating-linear-gradient(135deg,transparent,transparent_4px,rgba(100,116,139,0.03)_4px,rgba(100,116,139,0.03)_8px)] opacity-60 transition-opacity hover:opacity-100"
                                    >
                                        <td className="sticky left-0 z-10 border-r border-[var(--border)] bg-slate-500/5 px-3 py-1 text-center font-mono shadow-[2px_0_5px_rgba(0,0,0,0.05)] dark:bg-slate-900/20">
                                            <div className="leading-tight text-xs font-black text-[var(--muted)]">{hourLabel}</div>
                                            {onFillGap ? (
                                                <button
                                                    onClick={() => onFillGap(hourLabel)}
                                                    disabled={!!isFilling}
                                                    className="mt-0.5 cursor-pointer rounded bg-sky-500/20 px-1.5 py-0.5 text-[8px] font-bold uppercase leading-tight tracking-wider text-sky-400 transition-all hover:bg-sky-500/40 disabled:opacity-50"
                                                >
                                                    {isFilling ? '...' : t('btn_fill')}
                                                </button>
                                            ) : (
                                                <div className="mt-0.5 text-[8px] font-bold uppercase tracking-wider text-red-400/60">{t('lbl_gap')}</div>
                                            )}
                                        </td>
                                        {cols.map((column) => (
                                            <td key={column.key} className="border-b border-[var(--border)]/10 px-2 py-1 text-center">
                                                <span className="text-[10px] text-slate-600">-</span>
                                            </td>
                                        ))}
                                    </tr>
                                );
                            }

                            const snap = row.snap;

                            return (
                                <tr
                                    key={`${snap.hour_label}-${snap.snapshot_time}`}
                                    className={`group transition-colors duration-100 ${
                                        isLastRow
                                            ? 'bg-teal-500/[0.06]'
                                            : rowIdx % 2 === 0
                                                ? 'bg-transparent'
                                                : 'bg-[var(--background)]/30'
                                    } hover:bg-teal-500/[0.04]`}
                                >
                                    <td
                                        className={`sticky left-0 z-10 border-r border-[var(--border)] px-3 py-1.5 text-center font-mono shadow-[2px_0_5px_rgba(0,0,0,0.05)] ${
                                            row.type === 'oc'
                                                ? 'bg-amber-500/[0.08] text-amber-500 dark:bg-amber-500/[0.12]'
                                                : isLastRow
                                                    ? 'bg-teal-500/[0.08] text-teal-400'
                                                    : 'bg-slate-500/5 text-[var(--card-foreground)] dark:bg-slate-900/40'
                                        } group-hover:bg-teal-500/[0.04]`}
                                    >
                                        <div className="leading-tight text-xs font-black">{hourLabel}</div>
                                        {snap.source === 'MANUAL' ? (
                                            <div className="mt-0.5 rounded bg-amber-500/20 px-1 text-[8px] font-bold leading-tight tracking-tighter text-amber-500">
                                                {t('lbl_manual')}
                                            </div>
                                        ) : (
                                            <div className="mt-0.5 text-[9px] leading-tight text-[var(--muted)] opacity-70">
                                                {formatTime(snap.snapshot_time)}
                                            </div>
                                        )}
                                    </td>

                                    {getColumns(snap.anticoag_type_id, t).map((column, colIdx, all) => {
                                        const prevGroup = colIdx > 0 ? all[colIdx - 1].group : '';
                                        const showSep = colIdx > 0 && column.group !== prevGroup;
                                        const value = snap[column.key as keyof Snapshot];
                                        const isManual = column.group === 'manual';
                                        const isHeparin = column.group === 'heparin';
                                        const isCitrateGroup = column.group === 'citrate';
                                        const groupBg = getGroupBg(column.group);
                                        const isEditable = MANUAL_EDIT_KEYS.has(column.key) || snap.source === 'MANUAL';

                                        return (
                                            <td
                                                key={column.key}
                                                className={`px-2 py-1.5 text-center font-mono ${showSep ? 'border-l-[1px] border-l-[var(--border)]/60' : ''} ${isLastRow ? 'border-b-0' : 'border-b border-[var(--border)]/20'} ${groupBg}`}
                                            >
                                                {isEditable ? (
                                                    <EditableCell
                                                        treatmentId={treatmentIndex?.id ?? ''}
                                                        hourLabel={snap.hour_label}
                                                        field={column.key}
                                                        value={value as string | number | null}
                                                        anticoagId={snap.anticoag_type_id ?? undefined}
                                                        operatorName={operatorName}
                                                        userRole={userRole}
                                                        ensureOperator={ensureOperator}
                                                        onSaved={onRefresh}
                                                    />
                                                ) : value !== null && value !== undefined && value !== '' ? (
                                                    <span
                                                        className={`text-xs font-bold ${
                                                            isManual
                                                                ? 'text-[var(--muted)]'
                                                                : isHeparin
                                                                    ? 'text-amber-600 dark:text-amber-400/90'
                                                                    : isCitrateGroup
                                                                        ? 'text-indigo-600 dark:text-indigo-400/90'
                                                                        : 'text-[var(--card-foreground)]'
                                                        }`}
                                                    >
                                                        {column.key === 'pa' || column.key === 'pv' || column.key === 'pbe' || column.key === 'tmp'
                                                            ? (typeof value === 'number' ? (value > 0 ? `+${Math.round(value)}` : Math.round(value)) : '--')
                                                            : fmtVal(
                                                                value as number,
                                                                column.key === 'citrate_dose' ||
                                                                column.key === 'calcium_rate' ||
                                                                column.key === 'citrate_conc' ||
                                                                column.key === 'citrate_load' ||
                                                                column.key === 'heparin_rate'
                                                                    ? 1
                                                                    : 0
                                                            )}
                                                    </span>
                                                ) : (
                                                    <span className="opacity-15 text-[var(--muted)]">&middot;</span>
                                                )}
                                            </td>
                                        );
                                    })}
                                </tr>
                            );
                        })}
                    </tbody>
                </table>

                {onFillGap && snaps.length > 0 && (
                    <div className="flex justify-center border-t border-dashed border-[var(--border)]/30 py-3">
                        <button
                            onClick={() => {
                                const hourlyRows = displayRows.filter((row): row is Extract<DisplayRow, { type: 'data' | 'gap' }> => row.type === 'data' || row.type === 'gap');
                                const maxHour = hourlyRows.length > 0 ? hourlyRows[hourlyRows.length - 1].hourNum : 0;
                                const nextLabel = `H${String(maxHour + 1).padStart(2, '0')}`;
                                onFillGap(nextLabel);
                            }}
                            disabled={!!fillingGapHour}
                            className="flex items-center gap-1.5 rounded-lg border border-sky-500/20 bg-sky-500/10 px-4 py-1.5 text-[10px] font-bold uppercase tracking-wider text-sky-400 transition-all hover:bg-sky-500/20 disabled:opacity-50"
                        >
                            <Plus className="h-3 w-3" />
                            {t('btn_add_snapshot')}
                        </button>
                    </div>
                )}

                {snaps.length === 0 && (
                    <div className="py-16 text-center">
                        <div className="mb-2 text-[var(--muted)] opacity-20">
                            <ClipboardList className="mx-auto h-12 w-12" />
                        </div>
                        <p className="text-xs font-bold text-[var(--muted)]">{t('no_snapshots')}</p>
                        <p className="mt-1 text-[10px] text-[var(--muted)] opacity-60">{t('telemetry_hint')}</p>
                    </div>
                )}
            </div>

            {expanded && showNotesHistory && (
                <>
                    <div className="absolute inset-0 z-40 bg-black/20 backdrop-blur-sm" onClick={() => onHistoryToggle?.(false)} />

                    <div className="absolute inset-y-0 right-0 z-50 flex w-full max-w-[420px] flex-col border-l border-[var(--border)] bg-[var(--card)] shadow-2xl">
                        <div className="flex items-center justify-between border-b border-[var(--border)] bg-teal-500/[0.03] px-4 py-4">
                            <div className="flex items-center gap-2">
                                <div className="rounded-lg bg-teal-500/20 p-1.5">
                                    <ClipboardList className="h-3.5 w-3.5 text-teal-500" />
                                </div>
                                <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-[var(--foreground)]">
                                    {t('lbl_audit_trail')}
                                </h3>
                            </div>
                            <button
                                onClick={() => onHistoryToggle?.(false)}
                                className="rounded-full p-1.5 text-[var(--muted)] transition-colors hover:bg-[var(--border)]"
                                title={t('btn_close')}
                            >
                                <X className="h-4 w-4" />
                            </button>
                        </div>

                        <div className="flex-1 space-y-6 overflow-y-auto p-4">
                            {auditLoading ? (
                                <div className="flex h-full flex-col items-center justify-center p-8 text-center opacity-40">
                                    <Activity className="mb-2 h-10 w-10 animate-pulse text-[var(--muted)]" />
                                    <div className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">
                                        {t('loading')}
                                    </div>
                                </div>
                            ) : visibleHistory.length === 0 ? (
                                <div className="flex h-full flex-col items-center justify-center p-8 text-center opacity-30">
                                    <Activity className="mb-2 h-10 w-10 text-[var(--muted)]" />
                                    <div className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">
                                        {t('lbl_no_history')}
                                    </div>
                                </div>
                            ) : (
                                visibleHistory.map((item, index) => {
                                    const isNote = item.source === 'note';
                                    const isAudit = item.source === 'audit';
                                    const isEdit = item.action?.toLowerCase().includes('edit') || item.action?.toLowerCase().includes('restore');
                                    const actor = decodeSafe(item.operator_name || '');
                                    const actionLabel = decodeSafe(item.title || formatEventLabel(item.action));
                                    const eventLabel = isAudit && actor ? `${actor} - ${actionLabel}` : actionLabel || 'SYSTEM';
                                    const eventText = decodeSafe(fallbackAuditDescription(item));

                                    return (
                                        <div key={item.id} className="group relative pl-7">
                                            {index !== visibleHistory.length - 1 && (
                                                <div className="absolute bottom-0 left-[9px] top-6 w-px bg-[var(--border)] transition-colors group-hover:bg-teal-500/20" />
                                            )}

                                            <div
                                                className={`absolute left-0 top-1 z-10 flex h-5 w-5 items-center justify-center rounded-full border-2 bg-[var(--card)] shadow-sm ${
                                                    isNote
                                                        ? 'border-amber-500/40 text-amber-500'
                                                        : isAudit || isEdit
                                                            ? 'border-blue-500/40 text-blue-500'
                                                            : 'border-teal-500/40 text-teal-500'
                                                }`}
                                            >
                                                {isNote ? (
                                                    <User className="h-2.5 w-2.5" />
                                                ) : isAudit || isEdit ? (
                                                    <Pencil className="h-2.5 w-2.5" />
                                                ) : (
                                                    <Activity className="h-2.5 w-2.5" />
                                                )}
                                            </div>

                                            <div className="space-y-1.5">
                                                <div className="flex items-center justify-between gap-2">
                                                    <span className={`text-[10px] font-black uppercase tracking-tighter ${isNote ? 'text-amber-600' : 'text-teal-600'}`}>
                                                        {eventLabel}
                                                    </span>
                                                    <span className="flex items-center gap-1 font-mono text-[9px] text-[var(--muted)] opacity-70">
                                                        <Clock className="h-2.5 w-2.5" />
                                                        {new Date(item.event_time).toLocaleString('vi-VN', {
                                                            hour: '2-digit',
                                                            minute: '2-digit',
                                                            day: '2-digit',
                                                            month: '2-digit',
                                                        })}
                                                    </span>
                                                </div>

                                                <div
                                                    className={`whitespace-pre-wrap rounded-xl border p-3 text-[11px] leading-relaxed shadow-sm transition-all ${
                                                        isNote
                                                            ? 'border-amber-500/20 bg-amber-500/5 text-[var(--foreground)] group-hover:border-amber-500/40'
                                                            : isAudit
                                                                ? 'border-blue-500/10 bg-blue-500/5 text-[var(--muted)] group-hover:border-blue-500/30'
                                                            : 'border-teal-500/10 bg-teal-500/5 text-[var(--muted)] group-hover:border-teal-500/30'
                                                    }`}
                                                >
                                                    {eventText}
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })
                            )}
                        </div>

                        <div className="border-t border-[var(--border)] bg-slate-500/5 p-4">
                            <p className="text-[9px] italic leading-normal text-[var(--muted)] opacity-60">
                                {t('lbl_history_hint')}
                            </p>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
}
