// Treatment Journal — Column Definitions & Helpers
// Extracted from page.tsx for reuse in DetailPanel and other components

import { TranslationKeys } from '../../lib/translations';

// ─── Formatters ─────────────────────────────────────────────────

export function formatDuration(sec: number): string {
    if (sec === undefined || sec === null) return '\u2014';
    if (sec <= 0) return '0m';
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export function formatCloseReason(reason: string | null | undefined, t: (key: TranslationKeys) => string): string | null {
    if (!reason) return null;
    if (reason.startsWith('AUTO_TIMEOUT')) return `\u23f0 ${t('status_timeout')}`;
    if (reason === 'END received') return `\u2705 ${t('status_normal_end')}`;
    if (reason.startsWith('Patient changed')) return `\ud83d\udd04 ${t('status_patient_changed')}`;
    return reason;
}

export function formatOutcome(outcome: string | null | undefined, t: (key: TranslationKeys) => string): string {
    if (!outcome) return '\u2014';
    if (outcome === 'IN_PROGRESS') return t('status_recording');
    if (outcome === 'COMPLETED') return t('status_done');
    if (outcome === 'TIMEOUT') return t('status_timeout');
    return outcome;
}

export function formatTime(iso: string): string {
    if (!iso) return '\u2014';
    try {
        return new Date(iso).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
    } catch { return iso.slice(11, 16); }
}

export function formatDate(iso: string): string {
    if (!iso) return '';
    try {
        return new Date(iso).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' });
    } catch { return iso.slice(5, 10); }
}

export function fmtVal(v: number | null | undefined, decimals = 0): string {
    if (v === null || v === undefined) return '';
    return decimals > 0 ? v.toFixed(decimals) : Math.round(v).toString();
}

// ─── Column Definitions — Dynamic based on Anticoagulation ──────

export interface ColumnDef {
    key: string;
    label: string;
    unit: string;
    group: string;
    color: string;
}

const BASE_COLS: ColumnDef[] = [
    { key: 'qb', label: 'QB', unit: 'ml/min', group: 'flow', color: 'text-emerald-600 dark:text-emerald-400' },
    { key: 'qd', label: 'QD', unit: 'ml/hr', group: 'flow', color: 'text-emerald-600 dark:text-emerald-400' },
    { key: 'qs', label: 'QS', unit: 'ml/hr', group: 'flow', color: 'text-emerald-600 dark:text-emerald-400' },
];

const UF_COLS: ColumnDef[] = [
    { key: 'uf_total', label: 'UF (2)', unit: 'ml', group: 'uf', color: 'text-cyan-600 dark:text-cyan-400' },
    { key: 'uf_hourly', label: 'UF RATE', unit: 'ml/hr', group: 'uf', color: 'text-cyan-600 dark:text-cyan-400' },
];

const PRESSURE_COLS: ColumnDef[] = [
    { key: 'pa', label: 'PA', unit: 'mmHg', group: 'pressure', color: 'text-rose-500 dark:text-rose-400' },
    { key: 'pv', label: 'PV', unit: 'mmHg', group: 'pressure', color: 'text-rose-500 dark:text-rose-400' },
    { key: 'pbe', label: 'PBE', unit: 'mmHg', group: 'pressure', color: 'text-rose-500 dark:text-rose-400' },
    { key: 'tmp', label: 'TMP', unit: 'mmHg', group: 'pressure', color: 'text-rose-500 dark:text-rose-400' },
];

export function getColumns(anticoagId: number | null | undefined, t: (key: TranslationKeys) => string): ColumnDef[] {
    const isCitrate = anticoagId === 2 || anticoagId === 3;

    if (isCitrate) {
        return [
            { key: 'uf_total', label: t('col_uf_total'), unit: 'ml', group: 'uf', color: 'text-cyan-600 dark:text-cyan-400' },
            { key: 'uf_hourly', label: t('col_uf_rate'), unit: 'ml/hr', group: 'uf', color: 'text-cyan-600 dark:text-cyan-400' },
            { key: 'qb', label: 'QB', unit: 'ml/min', group: 'flow', color: 'text-emerald-600 dark:text-emerald-400' },
            { key: 'qs', label: 'QS', unit: 'ml/hr', group: 'flow', color: 'text-emerald-600 dark:text-emerald-400' },
            { key: 'qd', label: 'QD', unit: 'ml/hr', group: 'flow', color: 'text-emerald-600 dark:text-emerald-400' },
            { key: 'qpbp', label: t('col_qci'), unit: 'ml/hr', group: 'flow', color: 'text-emerald-600 dark:text-emerald-400' },
            ...PRESSURE_COLS.map(c => ({ ...c, label: (t as any)(c.key) || c.label })),
            { key: 'duosol_count', label: t('col_duosol'), unit: '', group: 'manual', color: 'text-amber-600 dark:text-amber-400' },
            { key: 'prismasol_count', label: t('col_prismasol'), unit: '', group: 'manual', color: 'text-amber-600 dark:text-amber-400' },
            { key: 'filter_type', label: t('col_filter'), unit: '', group: 'manual', color: 'text-amber-600 dark:text-amber-400' },
            { key: 'calcium_comp', label: t('col_calcium_comp'), unit: '%', group: 'citrate', color: 'text-indigo-600 dark:text-indigo-400' },
            { key: 'citrate_dose', label: t('col_citrate_dose'), unit: 'mmol/L', group: 'citrate', color: 'text-indigo-600 dark:text-indigo-400' },
            { key: 'kali', label: 'Canci', unit: 'mmol/L', group: 'manual', color: 'text-amber-600 dark:text-amber-400' },
        ];
    }

    return [
        ...BASE_COLS.map(c => ({ ...c, label: (t as any)(c.key) || c.label })),
        { key: 'qpbp', label: t('col_qpbp'), unit: 'ml/hr', group: 'flow', color: 'text-emerald-600 dark:text-emerald-400' },
        ...UF_COLS.map(c => ({ ...c, label: (t as any)(c.key) || c.label })),
        { key: 'heparin_bolus', label: t('col_heparin_bolus'), unit: '', group: 'heparin', color: 'text-amber-600 dark:text-amber-400' },
        { key: 'heparin_rate', label: t('col_heparin_rate'), unit: 'ml/hr', group: 'heparin', color: 'text-amber-600 dark:text-amber-400' },
        ...PRESSURE_COLS.map(c => ({ ...c, label: (t as any)(c.key) || c.label })),
        { key: 'duosol_count', label: t('col_duosol'), unit: '', group: 'manual', color: 'text-amber-600 dark:text-amber-400' },
        { key: 'prismasol_count', label: t('col_prismasol'), unit: '', group: 'manual', color: 'text-amber-600 dark:text-amber-400' },
        { key: 'filter_type', label: t('col_filter'), unit: '', group: 'manual', color: 'text-amber-600 dark:text-amber-400' },
        { key: 'kali', label: t('col_kali'), unit: 'mEq/L', group: 'manual', color: 'text-amber-600 dark:text-amber-400' },
    ];
}

export const getGroupBg = (group: string) => {
    switch (group) {
        case 'flow': return 'bg-emerald-500/[0.03]';
        case 'uf': return 'bg-cyan-500/[0.03]';
        case 'pressure': return 'bg-rose-500/[0.03]';
        case 'manual':
        case 'heparin': return 'bg-amber-500/[0.03]';
        case 'citrate': return 'bg-indigo-500/[0.03]';
        default: return '';
    }
};

// ─── Dropdown options ───────────────────────────────────────────

export function getSolutionOptions(isCitrate: boolean) {
    if (isCitrate) return ['', 'CITRATE', 'PRISMOCAL', 'PRISMASOL', 'DUOSOL'];
    return ['', 'DUOSOL', 'PRISMASOL'];
}

export function getFilterOptions(isCitrate: boolean) {
    if (isCitrate) return ['', 'OXIRIS', 'Kit M100', 'DÂY CANCI'];
    return ['', 'OXIRIS', 'Kit M100'];
}

// Manual-editable column keys
export const MANUAL_EDIT_KEYS = new Set(['duosol_count', 'prismasol_count', 'filter_type', 'kali', 'heparin_bolus']);
