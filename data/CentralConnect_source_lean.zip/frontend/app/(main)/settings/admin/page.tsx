'use client';

import React from 'react';
import { Shield, Lock, Save, ArrowLeft, Cpu, Database, Settings, Activity, Zap } from 'lucide-react';
import { useLanguage } from '../../../providers/LanguageProvider';
import { useRole } from '../../../providers/RoleProvider';
import { useTheme } from '../../../providers/ThemeProvider';
import Link from 'next/link';

export default function AdminSettingsPage() {
    const { t } = useLanguage();
    const { isAdmin, doctorPin, adminPin, setPins } = useRole();
    const { theme } = useTheme();

    const [localDoctorPin, setLocalDoctorPin] = React.useState(doctorPin);
    const [localAdminPin, setLocalAdminPin] = React.useState(adminPin);
    const [isSaved, setIsSaved] = React.useState(false);

    if (!isAdmin) {
        return (
            <div className="flex flex-col items-center justify-center min-h-screen bg-[var(--background)] p-6 text-center">
                <div className="relative mb-8">
                    <div className="absolute inset-0 bg-red-500/20 blur-3xl rounded-full"></div>
                    <Shield className="w-24 h-24 text-red-500 animate-pulse relative z-10" />
                </div>
                <h2 className="text-3xl font-black text-[var(--foreground)] uppercase tracking-widest mb-4">ACCESS DENIED</h2>
                <p className="text-[var(--muted)] max-w-sm mb-8 font-medium">This terminal is restricted to administrative personnel only. Unauthorized access attempt logged.</p>
                <Link href="/">
                    <button className="px-8 py-3 bg-[var(--foreground)] text-[var(--background)] font-black uppercase tracking-widest rounded-full hover:bg-teal-400 hover:text-white transition-all transform hover:scale-110 active:scale-95 shadow-xl shadow-black/10 dark:shadow-white/10">
                        {t('btn_back') || 'Go Back'}
                    </button>
                </Link>
            </div>
        );
    }

    const handleSave = () => {
        setPins(localDoctorPin, localAdminPin);
        setIsSaved(true);
        setTimeout(() => setIsSaved(false), 3000);
    };

    return (
        <div className="min-h-screen bg-[var(--background)] text-[var(--foreground)] relative overflow-hidden font-sans selection:bg-teal-500/30 transition-colors duration-500">
            {/* 💎 Background Decorative Elements - Subtle in light mode, vibrant in dark */}
            <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-teal-500/[0.05] dark:bg-teal-500/10 rounded-full blur-[120px] animate-pulse"></div>
            <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-500/[0.05] dark:bg-indigo-500/10 rounded-full blur-[120px] animate-pulse delay-700"></div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.01] dark:opacity-[0.03] pointer-events-none"></div>

            <div className="relative z-10 p-6 md:p-16 max-w-7xl mx-auto space-y-12 animate-in fade-in zoom-in-95 duration-1000">

                {/* 🏷️ Header Section */}
                <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-[var(--sidebar-border)]">
                    <div className="space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="flex -space-x-2">
                                <div className="w-3 h-3 rounded-full bg-teal-400 shadow-[0_0_10px_rgba(45,212,191,0.5)]"></div>
                                <div className="w-3 h-3 rounded-full bg-indigo-500 opacity-50 shadow-[0_0_10px_rgba(99,102,241,0.5)]"></div>
                            </div>
                            <span className="text-[10px] font-black text-teal-600 dark:text-teal-400 uppercase tracking-[0.4em]">SYSTEM_V3.CORE_AUTH</span>
                        </div>
                        <h1 className="text-5xl md:text-7xl font-black tracking-tighter leading-none bg-gradient-to-r from-[var(--foreground)] via-[var(--foreground)] to-[var(--muted)] bg-clip-text text-transparent">
                            {t('admin_config_title')}
                        </h1>
                        <p className="text-[var(--muted)] text-lg md:text-xl font-medium max-w-2xl leading-relaxed">
                            {t('admin_config_desc')}
                        </p>
                    </div>

                    <Link href="/">
                        <button className="group flex items-center gap-3 px-6 py-4 bg-[var(--sidebar-nav-hover)] hover:bg-[var(--foreground)] text-[var(--foreground)] hover:text-[var(--background)] rounded-2xl border border-[var(--sidebar-border)] transition-all duration-500 font-black uppercase text-xs tracking-widest shadow-lg hover:shadow-black/10 dark:hover:shadow-white/10">
                            <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
                            EXIT PANEL
                        </button>
                    </Link>
                </header>

                <main className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

                    {/* 🛡️ Secure Access Control Panel */}
                    <div className="lg:col-span-12 xl:col-span-8">
                        <div className="bg-[var(--card)] backdrop-blur-3xl border border-[var(--sidebar-border)] rounded-[3rem] p-8 md:p-12 shadow-2xl relative overflow-hidden group transition-colors duration-500">
                            <div className="absolute top-0 right-0 p-12 opacity-[0.02] dark:opacity-[0.03] group-hover:opacity-[0.05] group-hover:scale-110 transition-all duration-1000 group-hover:rotate-12">
                                <Shield className="w-64 h-64 text-[var(--foreground)]" />
                            </div>

                            <div className="relative z-10 flex flex-col md:flex-row gap-12">
                                <div className="w-full md:w-1/3 flex flex-col justify-between">
                                    <div className="space-y-6">
                                        <div className="w-16 h-16 bg-gradient-to-br from-teal-400 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl shadow-teal-500/20">
                                            <Lock className="w-8 h-8 text-white" />
                                        </div>
                                        <h2 className="text-3xl font-black uppercase tracking-tight leading-tight text-[var(--foreground)]">
                                            PIN Management
                                        </h2>
                                        <p className="text-[var(--muted)] text-sm leading-relaxed">
                                            Update clinical access codes periodically to maintain security integrity. Use unique 4-6 digit numeric codes.
                                        </p>
                                    </div>

                                    <div className="mt-12 p-6 bg-teal-500/[0.03] dark:bg-teal-500/5 rounded-3xl border border-teal-500/10 space-y-3 transition-colors">
                                        <div className="flex items-center gap-3 text-teal-600 dark:text-teal-400">
                                            <Activity className="w-4 h-4" />
                                            <span className="text-[10px] font-black uppercase tracking-widest">Live Status</span>
                                        </div>
                                        <p className="text-xs text-[var(--muted)] font-medium">Session token active and encrypted. All changes are logged for audit compliance.</p>
                                    </div>
                                </div>

                                <div className="flex-1 space-y-10">
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                                        <div className="space-y-4">
                                            <label className="flex items-center gap-2 text-[10px] font-black text-[var(--muted)] uppercase tracking-[0.3em] ml-2">
                                                <Zap className="w-3 h-3 text-teal-500" />
                                                {t('lbl_update_doctor_pin')}
                                            </label>
                                            <div className="relative group/input">
                                                <div className="absolute -inset-1 bg-gradient-to-r from-teal-500 to-indigo-500 rounded-3xl blur opacity-0 group-focus-within/input:opacity-10 transition-all"></div>
                                                <input
                                                    type="text"
                                                    value={localDoctorPin}
                                                    onChange={(e) => setLocalDoctorPin(e.target.value)}
                                                    className="relative w-full bg-[var(--background)] border border-[var(--sidebar-border)] rounded-3xl px-8 py-6 text-2xl font-mono font-black text-teal-600 dark:text-teal-400 outline-none focus:border-teal-500/50 transition-all placeholder:opacity-10"
                                                    placeholder="0000"
                                                />
                                            </div>
                                        </div>

                                        <div className="space-y-4">
                                            <label className="flex items-center gap-2 text-[10px] font-black text-[var(--muted)] uppercase tracking-[0.3em] ml-2">
                                                <Zap className="w-3 h-3 text-amber-500" />
                                                {t('lbl_update_admin_pin')}
                                            </label>
                                            <div className="relative group/input">
                                                <div className="absolute -inset-1 bg-gradient-to-r from-amber-500 to-orange-500 rounded-3xl blur opacity-0 group-focus-within/input:opacity-10 transition-all"></div>
                                                <input
                                                    type="text"
                                                    value={localAdminPin}
                                                    onChange={(e) => setLocalAdminPin(e.target.value)}
                                                    className="relative w-full bg-[var(--background)] border border-[var(--sidebar-border)] rounded-3xl px-8 py-6 text-2xl font-mono font-black text-amber-600 dark:text-amber-500 outline-none focus:border-amber-500/50 transition-all placeholder:opacity-10"
                                                    placeholder="0000"
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <button
                                        onClick={handleSave}
                                        disabled={isSaved}
                                        className={`w-full py-8 rounded-[2rem] font-black uppercase tracking-[0.5em] transition-all duration-700 flex items-center justify-center gap-4 relative overflow-hidden text-sm shadow-xl ${isSaved
                                            ? 'bg-emerald-500 text-white shadow-emerald-500/20'
                                            : 'bg-[var(--foreground)] text-[var(--background)] hover:bg-teal-500 hover:text-white hover:shadow-teal-500/30 active:scale-[0.98]'
                                            }`}
                                    >
                                        <div className={isSaved ? "flex items-center gap-3" : "flex items-center gap-3 group-hover:animate-pulse"}>
                                            {isSaved ? <Save className="w-5 h-5 animate-bounce" /> : <Settings className="w-5 h-5 group-hover:rotate-180 transition-transform duration-1000" />}
                                            {isSaved ? t('config_saved_msg') : t('btn_save_config')}
                                        </div>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* 🦾 Modules Stats / Side Column */}
                    <div className="lg:col-span-12 xl:col-span-4 space-y-8">
                        <section className="bg-[var(--card)] backdrop-blur-3xl border border-[var(--sidebar-border)] rounded-[2.5rem] p-10 relative overflow-hidden group transition-colors duration-500 shadow-xl">
                            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent opacity-20"></div>

                            <div className="flex items-center gap-4 mb-8">
                                <div className="p-3 bg-indigo-500/10 rounded-2xl">
                                    <Cpu className="w-6 h-6 text-indigo-500 dark:text-indigo-400" />
                                </div>
                                <h3 className="text-lg font-black uppercase tracking-tight italic text-[var(--foreground)]">System Architecture</h3>
                            </div>

                            <div className="space-y-6">
                                <div className="flex items-center justify-between group/stat">
                                    <span className="text-sm font-bold text-[var(--muted)] group-hover/stat:text-[var(--foreground)] transition-colors">UI Engine</span>
                                    <span className="px-3 py-1 bg-[var(--background)] rounded-full text-[10px] font-black text-indigo-600 dark:text-indigo-400 border border-[var(--sidebar-border)] uppercase tracking-widest">Next.js 16</span>
                                </div>
                                <div className="flex items-center justify-between group/stat">
                                    <span className="text-sm font-bold text-[var(--muted)] group-hover/stat:text-[var(--foreground)] transition-colors">Logic Core</span>
                                    <span className="px-3 py-1 bg-[var(--background)] rounded-full text-[10px] font-black text-teal-600 dark:text-teal-400 border border-[var(--sidebar-border)] uppercase tracking-widest">Python 3.12</span>
                                </div>
                                <div className="flex items-center justify-between group/stat">
                                    <span className="text-sm font-bold text-[var(--muted)] group-hover/stat:text-[var(--foreground)] transition-colors">Persistence</span>
                                    <span className="px-3 py-1 bg-[var(--background)] rounded-full text-[10px] font-black text-amber-600 dark:text-amber-500 border border-[var(--sidebar-border)] uppercase tracking-widest flex items-center gap-2">
                                        <Database className="w-3 h-3" />
                                        SQLite 3
                                    </span>
                                </div>

                                <div className="pt-6 border-t border-[var(--sidebar-border)]">
                                    <div className="flex items-center gap-2 mb-4 text-[10px] font-black text-[var(--muted)] uppercase tracking-widest">
                                        <Zap className="w-3 h-3 text-indigo-500" />
                                        Upcoming Modules
                                    </div>
                                    <div className="grid grid-cols-2 gap-3">
                                        {['Auditing', 'Grouping', 'Thresholds', 'Webhooks'].map(m => (
                                            <div key={m} className="px-4 py-3 bg-[var(--background)] border border-[var(--sidebar-border)] rounded-xl text-[10px] font-bold text-[var(--muted)] cursor-not-allowed hover:bg-[var(--sidebar-nav-hover)] transition-colors uppercase tracking-widest">
                                                {m}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </section>

                        <div className="p-10 bg-gradient-to-br from-teal-500/10 to-indigo-500/5 dark:from-teal-500/20 dark:to-indigo-500/10 border border-teal-500/10 rounded-[2.5rem] relative group cursor-pointer overflow-hidden transition-all duration-500 shadow-lg">
                            <div className="absolute inset-0 bg-white dark:bg-black opacity-0 group-hover:opacity-[0.02] transition-opacity"></div>
                            <h4 className="text-xs font-black uppercase tracking-[0.3em] text-teal-600 dark:text-teal-400 mb-2">Need Assistance?</h4>
                            <p className="text-[var(--muted)] text-xs font-medium leading-relaxed">System documentation is available in the /docs directory. For critical security failures, contact Cho Ray IT Department.</p>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
