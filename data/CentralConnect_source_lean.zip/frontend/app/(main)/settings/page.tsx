'use client';

import React, { useState } from 'react';
import { Plus, Trash2, Edit2, Copy, Monitor, PlayCircle, StopCircle, RefreshCw, Eye } from 'lucide-react';
import { MOCK_DEVICES } from '../../utils/mockData';
import { clsx } from 'clsx';
import Link from 'next/link';

export default function SettingsPage() {
    const [devices, setDevices] = useState(MOCK_DEVICES);

    const handleCopyEndpoint = (id: string) => {
        // In real app, copy to clipboard
        const url = `http://localhost:8000/api/v1/telemetry/${id}`;
        navigator.clipboard.writeText(url);
        alert(`Copied endpoint for ${id}: ${url}`);
    };

    const startDevice = (id: string) => {
        // Simulate "Linking" or "Activating" the stream
        alert(`Activating stream for ${id}`);
    }

    const stopDevice = (id: string) => {
        alert(`Deactivating stream for ${id}`);
    }


    return (
        <div className="p-6 md:p-10 max-w-6xl mx-auto space-y-8">
            <header>
                <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight mb-2">Device Management</h1>
                <p className="text-slate-500">Configure devices and Mirth Connect integration endpoints.</p>
            </header>

            {/* Integration Guide Card */}
            <section className="bg-blue-50 border border-blue-100 rounded-xl p-6 shadow-sm">
                <h2 className="font-bold text-blue-900 text-lg mb-2 flex items-center gap-2">
                    <RefreshCw className="w-5 h-5" />
                    Integration Setup (Mirth Connect)
                </h2>
                <p className="text-blue-800/80 mb-4 text-sm">
                    Configure Mirth Connect to send JSON data to the following central endpoint.
                    Alternatively, use device-specific endpoints if configured.
                </p>
                <div className="flex items-center gap-2 bg-white border border-blue-200 rounded-lg p-3">
                    <code className="flex-1 font-mono text-sm text-slate-700">http://localhost:8000/api/v1/telemetry</code>
                    <button
                        onClick={() => { navigator.clipboard.writeText('http://localhost:8000/api/v1/telemetry'); alert('Copied!') }}
                        className="p-2 hover:bg-slate-100 rounded-md text-slate-500 transition-colors"
                        title="Copy URL"
                    >
                        <Copy className="w-4 h-4" />
                    </button>
                </div>
            </section>

            {/* Device List */}
            <section className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-slate-50/50">
                    <h2 className="font-bold text-slate-700 flex items-center gap-2">
                        <Monitor className="w-5 h-5" /> Registered Devices
                    </h2>
                    <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors text-sm shadow-sm shadow-blue-500/20">
                        <Plus className="w-4 h-4" /> Add New Device
                    </button>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead>
                            <tr className="border-b border-slate-100 bg-slate-50 text-slate-500">
                                <th className="px-6 py-4 font-medium">Device Name</th>
                                <th className="px-6 py-4 font-medium">Device ID</th>
                                <th className="px-6 py-4 font-medium">IP Address</th>
                                <th className="px-6 py-4 font-medium">Status</th>
                                <th className="px-6 py-4 font-medium">Last Seen</th>
                                <th className="px-6 py-4 font-medium text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                            {devices.map((device) => (
                                <tr key={device.id} className="hover:bg-slate-50/80 transition-colors group">
                                    <td className="px-6 py-4 font-medium text-slate-900">{device.name}</td>
                                    <td className="px-6 py-4 font-mono text-slate-600">{device.id}</td>
                                    <td className="px-6 py-4 font-mono text-slate-500">{device.ip}</td>
                                    <td className="px-6 py-4">
                                        <span className={clsx(
                                            "px-2.5 py-0.5 rounded-full text-xs font-bold border",
                                            device.status === 'RUNNING' && "bg-green-100 text-green-700 border-green-200",
                                            device.status === 'ALARM' && "bg-red-100 text-red-700 border-red-200 animate-pulse",
                                            (device.status === 'STOPPED' || device.status === 'OFFLINE') && "bg-slate-100 text-slate-600 border-slate-200",
                                            device.status === 'UNKNOWN' && "bg-yellow-100 text-yellow-700 border-yellow-200",
                                        )}>
                                            {device.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-slate-500">
                                        {new Date(device.lastUpdate).toLocaleString('en-GB', { hour12: false })}
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <Link href={`/monitor/${device.id}`} title="View Monitor">
                                                <button className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                                                    <Eye className="w-4 h-4" />
                                                </button>
                                            </Link>
                                            <button
                                                onClick={() => handleCopyEndpoint(device.id)}
                                                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                                                title="Copy Device Endpoint"
                                            >
                                                <Copy className="w-4 h-4" />
                                            </button>
                                            <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                                                <Edit2 className="w-4 h-4" />
                                            </button>
                                            <button className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                                                <Trash2 className="w-4 h-4" />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    );
}
