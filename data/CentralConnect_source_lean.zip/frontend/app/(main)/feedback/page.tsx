'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Send, MessageSquare, User, Clock, CheckCircle2, ChevronLeft, Trash2, Lock, Unlock } from 'lucide-react';
import { clsx } from 'clsx';
import { useLanguage } from '../../providers/LanguageProvider';

interface Feedback {
    id: string;
    user: string;
    content: string;
    timestamp: string;
    status: 'received' | 'reviewed' | 'implemented';
}

export default function FeedbackPage() {
    const { t } = useLanguage();
    const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
    const [newComment, setNewComment] = useState('');
    const [userName, setUserName] = useState('');
    const [isAdmin, setIsAdmin] = useState(false);
    const [showPasswordInput, setShowPasswordInput] = useState(false);
    const [tempPassword, setTempPassword] = useState('');

    const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

    // Load from Backend API
    const fetchFeedbacks = async () => {
        try {
            const res = await fetch(`${API_BASE}/api/v1/feedback`);
            if (res.ok) {
                const data = await res.json();
                setFeedbacks(data);
            }
        } catch (e) {
            console.error('Failed to fetch feedback:', e);
        }
    };

    useEffect(() => {
        fetchFeedbacks();
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newComment.trim()) return;

        const entry = {
            id: Date.now().toString(),
            user: userName.trim() || t('fb_anon'),
            content: newComment.trim(),
            timestamp: new Date().toLocaleString('en-GB', { hour12: false }),
            status: 'received'
        };

        try {
            const res = await fetch(`${API_BASE}/api/v1/feedback`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(entry)
            });
            if (res.ok) {
                setNewComment('');
                fetchFeedbacks(); // Refresh list
            }
        } catch (e) {
            console.error('Failed to submit feedback:', e);
            alert(t('fb_err_submit'));
        }
    };

    const handleDelete = async (id: string) => {
        if (!isAdmin) return;
        if (confirm(t('fb_confirm_delete'))) {
            try {
                const res = await fetch(`${API_BASE}/api/v1/feedback/${id}`, {
                    method: 'DELETE',
                    headers: { 'X-User-Role': 'admin' }
                });
                if (res.ok) {
                    fetchFeedbacks(); // Refresh list
                }
            } catch (e) {
                console.error('Failed to delete feedback:', e);
            }
        }
    };

    const handleToggleStatus = async (fb: Feedback) => {
        if (!isAdmin) return;

        const statusCycle: Feedback['status'][] = ['received', 'reviewed', 'implemented'];
        const currentIndex = statusCycle.indexOf(fb.status);
        const nextStatus = statusCycle[(currentIndex + 1) % statusCycle.length];

        try {
            const res = await fetch(`${API_BASE}/api/v1/feedback/${fb.id}/status`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'X-User-Role': 'admin'
                },
                body: JSON.stringify({ status: nextStatus })
            });
            if (res.ok) {
                fetchFeedbacks(); // Refresh list
            }
        } catch (e) {
            console.error('Failed to update status:', e);
        }
    };

    const handleAdminLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (tempPassword === 'ICU-B') {
            setIsAdmin(true);
            setShowPasswordInput(false);
            setTempPassword('');
        } else {
            alert(t('fb_err_wrong_pass'));
        }
    };

    return (
        <div className="min-h-screen bg-[var(--background)] p-6 md:p-10 transition-all duration-300">
            <header className="mb-10 flex items-center justify-between">
                <div>
                    <div className="flex items-center gap-2 mb-2">
                        <Link href="/" className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors text-slate-500">
                            <ChevronLeft className="w-5 h-5" />
                        </Link>
                        <span className="text-[10px] font-bold text-teal-600 dark:text-teal-400 uppercase tracking-[0.2em]">{t('fb_portal')}</span>
                    </div>
                    <h1 className="text-3xl font-black text-slate-800 dark:text-slate-100 tracking-tight flex items-center gap-3 uppercase">
                        {t('fb_title')}
                    </h1>
                    <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">{t('fb_desc')}</p>
                </div>

                <div className="flex items-center gap-2">
                    {isAdmin ? (
                        <div className="flex items-center gap-2 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 px-3 py-1.5 rounded-full border border-emerald-100 dark:border-emerald-900/20 text-[10px] font-black uppercase tracking-widest animate-in fade-in duration-300">
                            <Unlock className="w-3 h-3" />
                            {t('fb_admin_enabled')}
                            <button
                                onClick={() => setIsAdmin(false)}
                                className="ml-1 text-emerald-800 dark:text-emerald-200 hover:underline"
                            >
                                {t('fb_admin_lock')}
                            </button>
                        </div>
                    ) : (
                        <button
                            onClick={() => setShowPasswordInput(!showPasswordInput)}
                            className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors text-slate-400 dark:text-slate-500 flex items-center gap-2 group"
                            title={t('fb_admin_login')}
                        >
                            <span className="text-[10px] font-bold opacity-0 group-hover:opacity-100 transition-opacity">{t('fb_admin_only')}</span>
                            <Lock className="w-4 h-4" />
                        </button>
                    )}
                </div>
            </header>

            {showPasswordInput && (
                <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                    <div className="bg-white dark:bg-[#0f172a] rounded-3xl p-8 shadow-2xl border border-slate-100 dark:border-slate-800 w-full max-w-sm animate-in zoom-in-95 duration-200">
                        <div className="flex flex-col items-center mb-6">
                            <div className="w-12 h-12 bg-teal-50 dark:bg-teal-900/20 rounded-full flex items-center justify-center text-teal-600 dark:text-teal-400 mb-4">
                                <Lock className="w-6 h-6" />
                            </div>
                            <h2 className="text-xl font-black text-slate-800 dark:text-slate-100 uppercase tracking-tight">{t('fb_admin_auth')}</h2>
                            <p className="text-slate-500 text-xs mt-1">{t('fb_admin_auth_desc')}</p>
                        </div>
                        <form onSubmit={handleAdminLogin} className="space-y-4">
                            <input
                                autoFocus
                                type="password"
                                value={tempPassword}
                                onChange={(e) => setTempPassword(e.target.value)}
                                placeholder={t('fb_admin_pass_ph')}
                                className="w-full bg-slate-50 dark:bg-slate-900 border-none rounded-2xl py-4 px-6 text-sm text-center font-bold tracking-[0.5em] text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-teal-500 transition-all outline-none"
                            />
                            <div className="flex gap-2">
                                <button
                                    type="button"
                                    onClick={() => { setShowPasswordInput(false); setTempPassword(''); }}
                                    className="flex-1 py-3 px-4 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-bold rounded-2xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
                                >
                                    {t('fb_btn_cancel')}
                                </button>
                                <button
                                    type="submit"
                                    className="flex-1 py-3 px-4 bg-teal-600 text-white font-bold rounded-2xl hover:bg-teal-500 transition-all shadow-lg shadow-teal-900/20"
                                >
                                    {t('fb_btn_unlock')}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Submit Feedback Form */}
                <div className="lg:col-span-1">
                    <div className="bg-white dark:bg-[#0f172a] rounded-3xl shadow-xl shadow-slate-200/50 dark:shadow-black/20 border border-slate-100 dark:border-slate-800 overflow-hidden sticky top-8">
                        <div className="p-6 bg-gradient-to-br from-teal-600 to-teal-800 text-white">
                            <h2 className="font-bold text-lg flex items-center gap-2">
                                <Send className="w-5 h-5" />
                                {t('fb_share_thoughts')}
                            </h2>
                            <p className="text-teal-100/70 text-xs mt-1">{t('fb_share_desc')}</p>
                        </div>
                        <form onSubmit={handleSubmit} className="p-6 space-y-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5 ml-1">{t('fb_name_role')}</label>
                                <div className="relative">
                                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                    <input
                                        type="text"
                                        value={userName}
                                        onChange={(e) => setUserName(e.target.value)}
                                        placeholder={t('fb_name_placeholder')}
                                        className="w-full bg-slate-50 dark:bg-slate-900 border-none rounded-2xl py-3 pl-10 pr-4 text-sm text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-teal-500 transition-all outline-none"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5 ml-1">{t('fb_content')}</label>
                                <textarea
                                    required
                                    value={newComment}
                                    onChange={(e) => setNewComment(e.target.value)}
                                    rows={4}
                                    placeholder={t('fb_content_placeholder')}
                                    className="w-full bg-slate-50 dark:bg-slate-900 border-none rounded-2xl p-4 text-sm text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-teal-500 transition-all outline-none resize-none"
                                />
                            </div>
                            <button
                                type="submit"
                                className="w-full bg-slate-900 dark:bg-teal-600 text-white font-bold py-4 rounded-2xl hover:bg-slate-800 dark:hover:bg-teal-500 transition-all shadow-lg dark:shadow-teal-900/40 active:scale-[0.98]"
                            >
                                {t('fb_submit')}
                            </button>
                        </form>
                    </div>
                </div>

                {/* Feedback List */}
                <div className="lg:col-span-2 space-y-4">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="font-black text-slate-800 dark:text-slate-200 uppercase tracking-wider text-sm flex items-center gap-2">
                            <MessageSquare className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                            {t('fb_recent')} ({feedbacks.length})
                        </h3>
                    </div>

                    {feedbacks.length === 0 ? (
                        <div className="bg-white dark:bg-[#0f172a] rounded-3xl p-12 border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center">
                            <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-full mb-4">
                                <MessageSquare className="w-8 h-8 text-slate-300 dark:text-slate-600" />
                            </div>
                            <h4 className="font-bold text-slate-400 dark:text-slate-500">{t('fb_empty_title')}</h4>
                            <p className="text-slate-400 dark:text-slate-600 text-sm mt-1">{t('fb_empty_desc')}</p>
                        </div>
                    ) : (
                        feedbacks.map((fb) => (
                            <div key={fb.id} className="group bg-white dark:bg-[#0f172a] rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 hover:shadow-md transition-all relative overflow-hidden">
                                <div className="flex justify-between items-start mb-4">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 bg-teal-50 dark:bg-teal-900/20 rounded-full flex items-center justify-center text-teal-600 dark:text-teal-400 font-bold">
                                            {fb.user?.charAt(0).toUpperCase() || '?'}
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-slate-800 dark:text-slate-200 text-sm">{fb.user}</h4>
                                            <div className="flex items-center gap-2 text-[10px] text-slate-400 dark:text-slate-500 font-medium">
                                                <Clock className="w-3 h-3" />
                                                {fb.timestamp}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <button
                                            onClick={() => handleToggleStatus(fb)}
                                            disabled={!isAdmin}
                                            className={clsx(
                                                "px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider transition-all",
                                                isAdmin && "hover:scale-105 active:scale-95",
                                                !isAdmin && "cursor-default",
                                                fb.status === 'received' && "bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400",
                                                fb.status === 'reviewed' && "bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400",
                                                fb.status === 'implemented' && "bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400",
                                            )}
                                            title={isAdmin ? "Click to cycle status" : "Status of contribution"}
                                        >
                                            {fb.status === 'received' && t('fb_status_received')}
                                            {fb.status === 'reviewed' && t('fb_status_reviewed')}
                                            {fb.status === 'implemented' && t('fb_status_implemented')}
                                        </button>
                                        {isAdmin && (
                                            <button
                                                onClick={() => handleDelete(fb.id)}
                                                className="p-1.5 text-slate-300 hover:text-red-500 dark:text-slate-700 dark:hover:text-red-400 transition-colors"
                                                title="Delete feedback"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </button>
                                        )}
                                    </div>
                                </div>
                                <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed bg-slate-50/50 dark:bg-black/20 p-4 rounded-2xl italic">
                                    &quot;{fb.content}&quot;
                                </p>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
}
