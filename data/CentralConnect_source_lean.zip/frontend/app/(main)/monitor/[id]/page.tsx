'use client';

import React from 'react';
import Link from 'next/link';
import { CRRT_PARAMETER_MAP, SECTION_KEYS, SECTION_KEYS_ADVANCED } from '../../../utils/crrtMap';
import { PressureChart } from '../../../components/PressureChart';
import { StandardPressureChart } from '../../../components/StandardPressureChart';
import { useDeviceData } from '../../../providers/WebSocketProvider';
import { useTrend } from '../../../providers/TrendProvider';
import { useTheme } from '../../../providers/ThemeProvider';
import { clsx } from 'clsx';
import { THERAPY_STATUS_MAP, THERAPY_STATUS_COLORS, THERAPY_TYPE_MAP } from '../../../utils/constants';
import { normalizeRecentEventTimestampMs } from '../../../utils/clinicalTime';
import { useLanguage } from '../../../providers/LanguageProvider';

export default function MonitorDetailPage({ params }: { params: Promise<{ id: string }> }) {
    const resolvedParams = React.use(params);
    const deviceId = resolvedParams.id;
    const { t } = useLanguage();

    const { getDevice, isConnected } = useDeviceData();
    const { theme } = useTheme();
    const currentDevice = getDevice(deviceId);
    const trendData = useTrend(deviceId);
    const [scaleFactor, setScaleFactor] = React.useState(1);
    const containerRef = React.useRef<HTMLDivElement>(null);

    // World-Class Auto-Scaling Logic (Synced with Dashboard)
    React.useEffect(() => {
        const handleResize = () => {
            if (!containerRef.current) return;
            const referenceWidth = 1600;
            // No sidebar on detail page, but we want to maintain similar density
            const currentWidth = window.innerWidth;
            let newScale = currentWidth / referenceWidth;
            newScale = Math.min(Math.max(newScale, 0.6), 1.1);
            setScaleFactor(newScale);
        };

        handleResize();
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const historyData = trendData;
    const setHistoryData = React.useCallback((_next: any) => { }, []);
    const dbLoaded = true;

    /*
    Legacy localStorage hydration kept chart history only while this detail page was active.
    Historical trends now hydrate from backend pressure_trends on mount instead.
    React.useEffect(() => {
        if (typeof window !== 'undefined') {
            // v3.7.2 Migration: Clear stale cache with +7h timezone corruption
            const cacheVersion = localStorage.getItem('trend_cache_version');
            if (cacheVersion !== '3.7.2') {
                // Wipe ALL device history caches (they contain wrong timestamps)
                Object.keys(localStorage).forEach(key => {
                    if (key.startsWith('history_')) localStorage.removeItem(key);
                });
                localStorage.setItem('trend_cache_version', '3.7.2');
                console.log('🔄 v3.7.2: Cleared stale trend cache (timezone fix)');
            }

            const savedRaw = localStorage.getItem(`history_${deviceId}`);
            if (savedRaw) {
                try {
                    const saved = JSON.parse(savedRaw);
                    const currentPid = currentDevice?.data?.s_header?.patient_id || currentDevice?.data?.header?.patient_id;

                    // SESSION VALIDATION: If simulated patient changed while we were away, wipe the local cache!
                    if (saved.patient_id && currentPid && String(saved.patient_id).trim() !== String(currentPid).trim()) {
                        console.warn(`🚨 Persistence Mismatch: Local history is for '${saved.patient_id}', but simulation says '${currentPid}'. Wiping cached trends.`);
                        localStorage.removeItem(`history_${deviceId}`);
                    } else {
                        setHistoryData(saved);
                    }
                } catch (e) {
                    console.error('Failed to parse saved history:', e);
                }
            }
        }
    }, [deviceId, currentDevice?.data?.s_header?.patient_id]);
    */

    // --- NEW PATIENT DETECTION (DEBOUNCED) ---
    const patientIdRef = React.useRef<string | null>(null);
    const initialLoadDoneRef = React.useRef(false); // NEW REF: To prevent wipe on first setup
    const patientChangeCandidateRef = React.useRef<{ id: string, count: number } | null>(null); // DEBOUNCE REF

    React.useEffect(() => {
        let currentPid = currentDevice?.data?.s_header?.patient_id || currentDevice?.data?.header?.patient_id;

        if (currentPid) {
            const pidStr = String(currentPid).trim();
            const upperPid = pidStr.toUpperCase();

            // IGNORE non-clinical strings during session start (matches backend logic)
            if (!pidStr || upperPid === "N/A" || upperPid === "NONE" || upperPid === "NULL" || pidStr === "---") {
                return;
            }

            // First time load - just capture the ID, do not clear data
            if (patientIdRef.current === null) {
                console.log(`📡 Detail Page: Initial Patient ID Captured: '${pidStr}'`);
                patientIdRef.current = pidStr;
                // Defer the protection activation slightly to let hydration settle
                setTimeout(() => { initialLoadDoneRef.current = true; }, 1500);
            }
            // Anomalous Patient Change Detected! (Past initial load phase)
            else if (initialLoadDoneRef.current && patientIdRef.current !== pidStr) {
                const candidate = patientChangeCandidateRef.current;

                if (candidate && candidate.id === pidStr) {
                    patientChangeCandidateRef.current = { id: pidStr, count: candidate.count + 1 };
                    console.log(`⚠️ Patient Change Candidate '${pidStr}' hit ${candidate.count + 1}/3 for Frontend Wipe`);

                    // 3 Consecutive Hits -> Official Patient Change -> Wipe Data
                    if (patientChangeCandidateRef.current.count >= 3) {
                        console.warn(`🚨 Patient Changed: ${patientIdRef.current} -> ${pidStr}. Clearing local history!`);
                        setAlarmHistory([]); // CRITICAL: Clear historical alarms too!
                        setLastChangedParams({});
                        previousValuesRef.current = {};

                        // Update Refs
                        patientIdRef.current = pidStr;
                        patientChangeCandidateRef.current = null; // Clear debounce candidate
                    }
                } else {
                    // Start tracking a new potential patient change
                    patientChangeCandidateRef.current = { id: pidStr, count: 1 };
                    console.log(`⚠️ New Patient Change Candidate '${pidStr}' detected (1/3) vs active '${patientIdRef.current}'`);
                }
            }
            // Normal: Patient ID matches again. Reset any ongoing debounce suspicion.
            else if (initialLoadDoneRef.current && patientIdRef.current === pidStr && patientChangeCandidateRef.current !== null) {
                console.log(`✅ False alarm patient change resolved back to '${patientIdRef.current}'.`);
                patientChangeCandidateRef.current = null;
            }
        }
    }, [currentDevice?.data?.s_header?.patient_id, currentDevice?.data?.header?.patient_id, deviceId]);

    const [expandedChart, setExpandedChartState] = React.useState<'access' | 'filter' | 'effluent' | 'return' | 'tmp' | null>(null);
    const [isTransitioning, startTransition] = React.useTransition();

    const setExpandedChart = React.useCallback((val: 'access' | 'filter' | 'effluent' | 'return' | 'tmp' | null) => {
        startTransition(() => {
            setExpandedChartState(val);
        });
    }, []);

    // ─── Threshold Settings (per-machine, localStorage only) ───
    const [showThresholdSettings, setShowThresholdSettings] = React.useState(false);
    const [tmpThreshold, setTmpThreshold] = React.useState(() => {
        if (typeof window !== 'undefined') {
            const saved = localStorage.getItem(`threshold_tmp_${deviceId}`);
            return saved ? Number(saved) : 300;
        }
        return 300;
    });
    const [dpThreshold, setDpThreshold] = React.useState(() => {
        if (typeof window !== 'undefined') {
            const saved = localStorage.getItem(`threshold_dp_${deviceId}`);
            return saved ? Number(saved) : 150;
        }
        return 150;
    });

    const updateThreshold = React.useCallback((type: 'tmp' | 'dp', value: number) => {
        const clamped = Math.max(0, Math.min(999, value));
        if (type === 'tmp') {
            setTmpThreshold(clamped);
            localStorage.setItem(`threshold_tmp_${deviceId}`, String(clamped));
        } else {
            setDpThreshold(clamped);
            localStorage.setItem(`threshold_dp_${deviceId}`, String(clamped));
        }
    }, [deviceId]);

    // Track previous values and timestamps for change detection
    const previousValuesRef = React.useRef<Record<string, string>>({});
    const [lastChangedParams, setLastChangedParams] = React.useState<Record<string, { value: string, timestamp: number }>>({});

    // Alarm History State
    const [alarmHistory, setAlarmHistory] = React.useState<any[]>([]);
    const [showAlarmLog, setShowAlarmLog] = React.useState(true);

    // Advanced Drawer State (Idea 3: Side Panel)
    const [activeDrawer, setActiveDrawer] = React.useState<'A' | 'B' | 'C' | null>(null);

    const CHANGE_PERSIST_MS = 3600000; // Keep 'was' label for 1 hour

    // Polling for Alarm History (Every 30s)
    React.useEffect(() => {
        const fetchAlarms = async () => {
            try {
                const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
                const res = await fetch(`${apiUrl}/api/v1/devices/${deviceId}/alarm_history`);
                if (res.ok) {
                    const data = await res.json();
                    setAlarmHistory(data);
                }
            } catch (e) {
                console.error("Alarm history error:", e);
            }
        };

        fetchAlarms(); // Initial load
        const interval = setInterval(fetchAlarms, 30000);
        return () => clearInterval(interval);
    }, [deviceId]);    // --- DATA AGING LOGIC (Clinical Safety) ---
    const [now, setNow] = React.useState(Date.now());
    React.useEffect(() => {
        const interval = setInterval(() => setNow(Date.now()), 1000);
        return () => clearInterval(interval);
    }, []);

    const lastUpdateTime = currentDevice?.lastUpdate ? new Date(currentDevice.lastUpdate).getTime() : 0;
    const secondsSinceUpdate = Math.max(0, (now - lastUpdateTime) / 1000);

    const isStale = secondsSinceUpdate > 25; // Dim values after 25s
    const isOffline = secondsSinceUpdate > 45 || !isConnected; // Hide values after 45s

    const getParamValue = (key: string) => {
        if (!currentDevice?.data) return '--';
        if (isOffline) return '---'; // Clinical Placeholder for missing data

        const config = CRRT_PARAMETER_MAP[key];
        if (!config) return '--';

        let rawValue;
        if (config.source === 'header') {
            const header = currentDevice.data.s_header || {};
            if (config.key === 'therapy_type_id') {
                rawValue =
                    header.therapy_type_id_name ||
                    (typeof header.therapy_type_id === 'number' ? THERAPY_TYPE_MAP[header.therapy_type_id] : undefined) ||
                    header[config.key] ||
                    '--';
            } else if (config.key === 'therapy_status_id') {
                rawValue =
                    header.therapy_status_id_name ||
                    (typeof header.therapy_status_id === 'number' ? THERAPY_STATUS_MAP[header.therapy_status_id] : undefined) ||
                    header[config.key] ||
                    '--';
            } else {
                rawValue = header[`${config.key}_name`] || header[`${config.key}_id_name`] || header[config.key] || '--';
            }
        } else {
            const bodyParams = currentDevice.data.s_body?.parameters || [];
            if (Array.isArray(bodyParams)) {
                const param = bodyParams.find((p: any) => p.id === config.key);
                if (!param) return '--';

                // If there's a custom mapping, use the numeric value as key
                if (config.mapping && param.value !== undefined && config.mapping[param.value] !== undefined) {
                    return config.mapping[param.value];
                }

                rawValue = param.value_text || param.value?.toString() || '--';
            } else {
                return '--';
            }
        }

        // Format datetime if specified
        if (config.format === 'datetime' && rawValue !== '--') {
            try {
                // PrismaFlex machine timestamps are local time (GMT+7) mislabeled as "UTC"
                // Strip the fake UTC suffix so Date() treats it as local time
                const cleanedTs = typeof rawValue === 'string' ? rawValue.replace(/ UTC$/, '') : rawValue;
                const date = new Date(cleanedTs);
                return date.toLocaleString('en-GB', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: false
                });
            } catch (e) {
                return rawValue;
            }
        }

        // Format duration (seconds to HH:MM:SS)
        if (config.format === 'duration' && rawValue !== '--') {
            try {
                const totalSeconds = parseInt(rawValue);
                const hours = Math.floor(totalSeconds / 3600);
                const minutes = Math.floor((totalSeconds % 3600) / 60);
                const seconds = totalSeconds % 60;
                return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            } catch (e) {
                return rawValue;
            }
        }

        // Apply precision and decimal separator if needed
        if (config.precision !== undefined && rawValue !== '--') {
            try {
                let num = parseFloat(rawValue);
                if (!isNaN(num)) {
                    // Apply scaling if defined (e.g., 0.01 to convert 2766 to 27.66)
                    if (config.scale !== undefined) {
                        num = num * config.scale;
                    }

                    let formatted = num.toFixed(config.precision);
                    if (config.decimalSeparator === ',') {
                        formatted = formatted.replace('.', ',');
                    }
                    return formatted;
                }
            } catch (e) {
                return rawValue;
            }
        }

        // Create a shorter version of known long strings
        if (typeof rawValue === 'string') {
            if (rawValue.includes('Systemic (e.g. Heparin')) return 'Systemic (Heparin)';
            if (rawValue.includes('Cit/Cal (Citrate/Calcium, External')) return 'Cit/Cal (External)';
            if (rawValue.includes('Cit/Cal (Citrate/Calcium, Prismaflex')) return 'Cit/Cal (Pump)';
            if (rawValue.includes('None (No Anticoagulation)')) return 'None';
            if (rawValue === 'Not Use') return 'Not Used';
            if (rawValue === 'Use') return 'Used';
        }

        return rawValue;
    };



    // Fetch events only for parameter change tracking.
    React.useEffect(() => {
        const fetchEvents = async () => {
            try {
                const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

                // Fetch "Was" Events (Audit Trail) — still needed for parameter change tracking
                const resEvents = await fetch(`${apiUrl}/api/v1/devices/${deviceId}/events`);
                if (resEvents.ok) {
                    const events = await resEvents.json();
                    if (Array.isArray(events)) {
                        const newChanges: Record<string, { value: string, timestamp: number }> = {};
                        events.forEach((evt: any) => {
                            const nowMs = Date.now();
                            const time = normalizeRecentEventTimestampMs(evt.timestamp, nowMs);
                            const ageMs = nowMs - time;
                            if (ageMs >= 0 && ageMs < CHANGE_PERSIST_MS) {
                                const key = Object.keys(CRRT_PARAMETER_MAP).find(k =>
                                    CRRT_PARAMETER_MAP[k].key.toString() === evt.param_id.toString()
                                );
                                if (key) {
                                    newChanges[key] = { value: evt.old_value, timestamp: time };
                                }
                            }
                        });
                        setLastChangedParams(prev => ({ ...prev, ...newChanges }));
                    }
                }

                // Activate patient change protection
                initialLoadDoneRef.current = true;
            } catch (e) {
                console.error("Failed to fetch events:", e);
            }
        };

        fetchEvents();
    }, [deviceId]);

    const activePatientId = React.useMemo(() => {
        const rawValue = currentDevice?.data?.s_header?.patient_id || currentDevice?.data?.header?.patient_id;
        return rawValue ? String(rawValue).trim() : null;
    }, [currentDevice?.data?.s_header?.patient_id, currentDevice?.data?.header?.patient_id]);

    React.useEffect(() => {
        trendData.loadHistory();
    }, [deviceId, activePatientId]);

    React.useEffect(() => {
        // Non-blocking Live Append (Like version 3.0.3 but with better merging)
        if (!dbLoaded || !currentDevice?.data?.s_body?.parameters) return;

        const params = currentDevice.data.s_body.parameters;
        let timestamp = new Date().toLocaleTimeString('en-GB', { hour12: false });
        let ts_ms = Date.now();
        try {
            const dataTime = currentDevice.data.s_header?.timestamp || currentDevice.data.meta?.timestamp;
            if (dataTime) {
                // Strip fake "UTC" suffix — PrismaFlex timestamps are already local time
                const cleanedTs = typeof dataTime === 'string' ? dataTime.replace(/ UTC$/, '') : dataTime;
                const date = new Date(cleanedTs);
                ts_ms = date.getTime();
                timestamp = date.toLocaleTimeString('en-GB', {
                    hour12: false,
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit'
                });
            }
        } catch (e) {
            console.warn("Failed to parse machine timestamp for chart:", e);
        }

        const access = params.find((p: any) => p.id === 1)?.value || 0;
        const filter = params.find((p: any) => p.id === 2)?.value || 0;
        const effluent = params.find((p: any) => p.id === 3)?.value || 0;
        const returnP = params.find((p: any) => p.id === 4)?.value || 0;
        const tmp = params.find((p: any) => p.id === 6)?.value || 0;
        const deltaP = params.find((p: any) => p.id === 7)?.value || 0;

        setHistoryData((prev: typeof historyData) => {
            // Ensure lists exist
            const pAccess = prev.access || [];
            const pFilter = prev.filter || [];
            const pEffluent = prev.effluent || [];
            const pReturn = prev.return || [];
            const pTmp = prev.tmp || [];

            // Numeric deduplication: If we already have this exact millisecond, skip!
            if (pAccess.length > 0 && pAccess[pAccess.length - 1]._ts === ts_ms) {
                return prev;
            }

            const currentPid = currentDevice.data?.s_header?.patient_id || currentDevice.data?.header?.patient_id;
            const pidStr = currentPid ? String(currentPid).trim() : null;

            const next = {
                patient_id: pidStr,
                access: [...pAccess.slice(-999), { time: timestamp, value: access, _ts: ts_ms }],
                filter: [...pFilter.slice(-999), { time: timestamp, value: filter, _ts: ts_ms }],
                effluent: [...pEffluent.slice(-999), { time: timestamp, value: effluent, _ts: ts_ms }],
                return: [...pReturn.slice(-999), { time: timestamp, value: returnP, _ts: ts_ms }],
                tmp: [...pTmp.slice(-999), { time: timestamp, value: tmp, _ts: ts_ms }],
                delta_p: [...(prev.delta_p || []).slice(-999), { time: timestamp, value: deltaP, _ts: ts_ms }]
            };

            return next;
        });
    }, [currentDevice?.data?.s_body?.parameters, deviceId, dbLoaded]);

    // Track all parameter changes in one useEffect
    React.useEffect(() => {
        if (!currentDevice?.data) return;

        const currentValues: Record<string, string> = {};
        let hasNewChange = false;

        // Collect all current parameter values
        Object.keys(CRRT_PARAMETER_MAP).forEach(key => {
            const config = CRRT_PARAMETER_MAP[key];
            const value = getParamValue(key);
            if (value !== '--') {
                currentValues[key] = value;

                // If value changed from previous known value, AND tracking is enabled
                const prevVal = previousValuesRef.current[key];
                if (config.trackChanges && prevVal !== undefined && prevVal !== value) {
                    setLastChangedParams(prev => ({
                        ...prev,
                        [key]: { value: prevVal, timestamp: Date.now() }
                    }));
                }
            }
        });

        // Periodic cleanup of expired changes
        const now = Date.now();
        setLastChangedParams(prev => {
            const next = { ...prev };
            let changed = false;
            Object.keys(next).forEach(key => {
                if (now - next[key].timestamp > CHANGE_PERSIST_MS) {
                    delete next[key];
                    changed = true;
                }
            });
            return changed ? next : prev;
        });

        // Update ref for next comparison
        previousValuesRef.current = currentValues;
    }, [currentDevice?.data?.s_body?.parameters, currentDevice?.data?.s_header]);

    if (!currentDevice) {
        return (
            <div className="min-h-screen bg-[var(--background)] flex items-center justify-center">
                <div className="text-center">
                    <h2 className="text-2xl font-bold text-slate-700 dark:text-slate-300 mb-2">Device Not Found</h2>
                    <p className="text-slate-500 dark:text-slate-400 mb-4">Device ID: {deviceId}</p>
                    <Link href="/" className="text-blue-600 dark:text-blue-400 hover:underline">← Back to Dashboard</Link>
                </div>
            </div>
        );
    }

    return (
        <div
            ref={containerRef}
            className="flex flex-col h-screen bg-[var(--background)] transition-colors duration-300 origin-top-left"
            style={{
                zoom: scaleFactor,
                WebkitZoom: scaleFactor
            } as any}
        >
            {/* Global Connection Warning */}
            {!isConnected && (
                <div className="bg-red-600 text-white text-[10px] py-1 px-4 text-center font-bold animate-pulse flex items-center justify-center gap-2">
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    {t('monitor_offline_warning')}
                </div>
            )}

            {/* Device Offline Warning */}
            {currentDevice.status === 'OFFLINE' && isConnected && (
                <div className="bg-amber-500 text-white text-[10px] py-1 px-4 text-center font-bold flex items-center justify-center gap-2">
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    {t('monitor_sync_delayed')}
                </div>
            )}

            {/* Ultra Compact Top Bar */}
            <header className="bg-white dark:bg-[#0f172a] border-b border-slate-200 dark:border-slate-800 px-3 py-1.5 flex items-center justify-between shadow-sm transition-colors duration-300 z-30">
                <div className="flex items-center gap-3">
                    <Link href="/" className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors group">
                        <svg className="w-3.5 h-3.5 text-slate-600 dark:text-slate-400 group-hover:text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
                        </svg>
                    </Link>
                    <div className="flex items-center gap-2">
                        <div>
                            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 uppercase leading-tight">PRISMAFLEX_{deviceId.replace('PF_', '')}</h2>
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-4">
                    <div className={clsx(
                        "px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all duration-300 shadow-sm text-white",
                        currentDevice.data?.s_header?.therapy_status_id !== undefined
                            ? THERAPY_STATUS_COLORS[currentDevice.data.s_header.therapy_status_id] || "bg-slate-500"
                            : (currentDevice.status === 'OFFLINE' ? "bg-amber-500" : "bg-slate-500")
                    )}>
                        <div className="w-1 h-1 rounded-full bg-white animate-pulse"></div>
                        {currentDevice.data?.s_header?.therapy_status_id !== undefined
                            ? THERAPY_STATUS_MAP[currentDevice.data.s_header.therapy_status_id] || currentDevice.status
                            : currentDevice.status === 'OFFLINE' ? t('lbl_offline_card') : currentDevice.status
                        }
                    </div>
                    <div className="text-[9px] text-slate-500 dark:text-slate-400 flex flex-col items-end">
                        <span className="text-[7px] font-bold text-slate-400 dark:text-slate-500 uppercase leading-none mb-0.5">{t('lbl_last_transmission')}</span>
                        <span className={clsx(
                            "font-bold font-[family-name:var(--font-mono)]",
                            currentDevice.status === 'OFFLINE' ? "text-amber-600 dark:text-amber-400" : "text-slate-900 dark:text-slate-200"
                        )}>
                            {new Date(currentDevice.lastUpdate).toLocaleTimeString('en-GB', { hour12: false })}
                        </span>
                    </div>
                </div>
            </header>


            {/* Active Alarms Section */}
            {currentDevice.active_alarms && currentDevice.active_alarms.length > 0 && (
                <div className="mx-2 mt-2 space-y-1">
                    {currentDevice.active_alarms.map((alarm) => {
                        const isOverridden = alarm.state === 'OVERRIDDEN';

                        // Style based on Category & Priority
                        let bgClass = "bg-slate-700";
                        let ringClass = "ring-0";
                        let animateClass = "animate-pulse";

                        if (['ALARM', 'MALFUNCTION'].includes(alarm.category)) {
                            bgClass = isOverridden ? "bg-red-900/50" : "bg-red-600";
                        } else if (alarm.category === 'WARNING') {
                            bgClass = isOverridden ? "bg-amber-900/50" : "bg-amber-500";
                        } else if (alarm.category === 'CAUTION') {
                            bgClass = "bg-blue-500";
                        } else if (alarm.category === 'ADVISORY') {
                            bgClass = "bg-slate-400";
                        }

                        if (isOverridden) animateClass = ""; // No pulse for hidden alarms

                        return (
                            <div key={`${alarm.id}-${alarm.state}`} className={clsx(
                                "text-white p-2.5 rounded-lg shadow-md flex items-start gap-3 transition-opacity",
                                bgClass,
                                animateClass,
                                isOverridden && "opacity-70 border border-white/20"
                            )}>
                                <svg className="w-5 h-5 mt-0.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    {isOverridden ? (
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.643-9.943-6.442a5.04 5.04 0 01.623-4.512l1.353 1.353m1.411 1.411A10.16 10.16 0 0112 11c1.267 0 2.466.233 3.567.657m0 0a10.16 10.16 0 013.31 1.942m-1.411-1.411L17.875 14.175m5.068 5.068A10.035 10.035 0 0112 21a10.035 10.035 0 01-10.943-5.825L1 15l1.057-1.175m1.411-1.411L3.875 12.025" />
                                    ) : (
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                    )}
                                </svg>
                                <div className="flex-1 min-w-0">
                                    <div className="flex justify-between items-start">
                                        <h3 className="font-black text-[12px] uppercase tracking-wider truncate">
                                            {alarm.title}
                                            {isOverridden && <span className="ml-2 text-[10px] font-medium bg-black/30 px-1.5 py-0.5 rounded italic">{t('lbl_overridden')}</span>}
                                        </h3>
                                        <span className="text-[10px] font-bold opacity-60 ml-2 shrink-0">{t(`status_${alarm.category.toLowerCase()}` as any) || alarm.category}</span>
                                    </div>
                                    <p className="text-[11px] opacity-90 leading-tight mt-0.5 line-clamp-2">{alarm.description}</p>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}

            {/* Dashboard Layout Container */}
            <div className={clsx(
                "flex-1 flex flex-col min-h-0 bg-slate-50/50 dark:bg-slate-950/20 transition-all duration-700 ease-in-out",
                activeDrawer ? "scale-[0.97] opacity-60 grayscale-[0.3] pointer-events-none origin-left blur-[2px]" : "scale-100 opacity-100 grayscale-0"
            )}>

                <main className={clsx(
                    "flex-1 p-2 space-y-2 overflow-y-auto no-scrollbar transition-opacity duration-300",
                    (currentDevice.status === 'OFFLINE' || !isConnected) && "opacity-60 saturate-50 grayscale-[0.2]"
                )}>
                    {/* Prescription / Flows - Ultra Compact */}
                    <section>
                        <div className="flex items-center gap-1.5 mb-1 group">
                            <div className="w-0.5 h-3 bg-blue-500 rounded-full"></div>
                            <h3 className="text-[10px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">{t('lbl_therapy_rx')}</h3>
                            <button
                                onClick={() => setActiveDrawer('B')}
                                className="ml-auto text-[9px] px-2.5 py-0.5 rounded-full font-bold transition-all duration-300 border flex items-center gap-1 shadow-sm hover:scale-[1.03] active:scale-95 uppercase tracking-wide bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-900/30 hover:border-blue-300 hover:shadow-blue-500/20">
                                <span>{t('lbl_more')}</span>
                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" /></svg>
                            </button>
                        </div>
                        <div key={activeDrawer === 'B' ? 'advanced' : 'basic'} className="grid grid-cols-9 gap-1.5 relative min-h-[50px] animate-in fade-in slide-in-from-bottom-2 duration-300">
                            {SECTION_KEYS.B.slice(0, 9).map(key => {
                                const config = CRRT_PARAMETER_MAP[key];
                                if (!config) return null;
                                const value = getParamValue(key);
                                const changeInfo = lastChangedParams[key];
                                const hasChanged = config.trackChanges && !!changeInfo && String(changeInfo.value) !== String(value);

                                return (
                                    <div key={key} className={clsx(
                                        "shadow-sm rounded p-1.5 border transition-all duration-200 relative hover:shadow-[0_0_10px_rgba(59,130,246,0.3)] hover:border-blue-400/50",
                                        hasChanged
                                            ? "border-amber-400 dark:border-amber-600 shadow-[0_0_10px_rgba(251,191,36,0.2)] bg-white dark:bg-slate-800"
                                            : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                                    )}>
                                        <div className="flex items-start justify-between gap-1">
                                            <div className="flex-1">
                                                <div className="text-[8px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-0.5">{(t as any)(config.name) || config.name}</div>
                                                <div className={clsx(
                                                    "text-base font-bold transition-all duration-200 font-[family-name:var(--font-mono)]",
                                                    hasChanged ? "text-amber-700 dark:text-amber-400" : "text-slate-900 dark:text-slate-100",
                                                    isStale && "opacity-40",
                                                    isOffline && "text-slate-400"
                                                )}>
                                                    {(t as any)(value) || value}
                                                    {isStale && !isOffline && <span className="ml-1 text-[8px] opacity-60 animate-pulse italic">STALE</span>}
                                                </div>
                                                {config.unit && <div className="text-[9px] text-blue-600 dark:text-blue-400 font-semibold">{config.unit}</div>}
                                            </div>
                                            {hasChanged && (
                                                <div className="absolute top-1 right-1 flex flex-col items-end animate-audit-glow audit-shimmer-container px-1 rounded-sm border border-amber-200/50 dark:border-amber-700/30 z-10">
                                                    <span className="text-[7px] font-black text-amber-600 dark:text-amber-400 uppercase leading-none mt-1">{t('lbl_was')}</span>
                                                    <span className="text-[10px] font-black text-amber-950 dark:text-white leading-none mb-1 font-[family-name:var(--font-mono)]">{(t as any)(changeInfo.value) || changeInfo.value}</span>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </section>

                    {/* Machine Info - Ultra Compact */}
                    <section>
                        <div className="flex items-center gap-1.5 mb-1 group">
                            <div className="w-0.5 h-3 bg-teal-500 rounded-full"></div>
                            <h3 className="text-[10px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">{t('lbl_system_telemetry')}</h3>
                            <button
                                onClick={() => setActiveDrawer('A')}
                                className="ml-auto text-[9px] px-2.5 py-0.5 rounded-full font-bold transition-all duration-300 border flex items-center gap-1 shadow-sm hover:scale-[1.03] active:scale-95 uppercase tracking-wide bg-white dark:bg-slate-800 text-teal-600 dark:text-teal-400 border-teal-200 dark:border-teal-800 hover:bg-teal-50 dark:hover:bg-teal-900/30 hover:border-teal-300 hover:shadow-teal-500/20">
                                <span>{t('lbl_more')}</span>
                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" /></svg>
                            </button>
                        </div>
                        <div className="bg-white dark:bg-slate-800 shadow-sm rounded p-2 border border-slate-200 dark:border-slate-700 transition-colors duration-300 relative min-h-[50px]">
                            <div className="grid grid-cols-4 gap-2">
                                {SECTION_KEYS.A.map(key => {
                                    const config = CRRT_PARAMETER_MAP[key];
                                    if (!config) return null;
                                    const value = getParamValue(key);
                                    const changeInfo = lastChangedParams[key];
                                    const hasChanged = config.trackChanges && !!changeInfo && String(changeInfo.value) !== String(value);
                                    const isTherapyStatus = key === 'header_therapy_status_id';
                                    const therapyStatusId = currentDevice.data?.s_header?.therapy_status_id;

                                    // Specific color for Therapy Status if available
                                    const statusColor = (isTherapyStatus && therapyStatusId !== undefined)
                                        ? THERAPY_STATUS_COLORS[therapyStatusId] || "bg-slate-500"
                                        : null;

                                    return (
                                        <div key={key} className={clsx(
                                            "border-l-2 pl-1.5 transition-all duration-200 relative hover:shadow-[0_0_10px_rgba(45,212,191,0.3)] hover:bg-teal-50/50 dark:hover:bg-teal-900/20",
                                            hasChanged
                                                ? "border-amber-400 bg-amber-50/30 dark:bg-amber-900/10"
                                                : (statusColor ? statusColor.replace('bg-', 'border-') : "border-teal-400")
                                        )}>
                                            <div className="flex items-start justify-between gap-1">
                                                <div className="flex-1">
                                                    <div className="text-[8px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-0.5">{(t as any)(config.name) || config.name}</div>
                                                    {isTherapyStatus && therapyStatusId !== undefined && !isOffline ? (
                                                        <div className="mt-0.5">
                                                            <span className={clsx(
                                                                "px-1.5 py-0.5 rounded text-[10px] font-black text-white shadow-sm uppercase tracking-wider inline-block transition-all duration-500",
                                                                statusColor || "bg-slate-500",
                                                                isStale && "opacity-40 grayscale-[0.5]"
                                                            )}>
                                                                {THERAPY_STATUS_MAP[therapyStatusId] || value}
                                                            </span>
                                                        </div>
                                                    ) : (
                                                        <div className={clsx(
                                                            "text-xs font-bold transition-all duration-200 font-[family-name:var(--font-mono)]",
                                                            hasChanged ? "text-amber-700 dark:text-amber-400" : "text-slate-900 dark:text-slate-100",
                                                            isStale && "opacity-40",
                                                            isOffline && "text-slate-400"
                                                        )}>
                                                            {value}
                                                            {isStale && !isOffline && <span className="ml-1 text-[7px] opacity-40 animate-pulse italic">STALE</span>}
                                                        </div>
                                                    )}
                                                    {config.unit && <div className="text-[9px] text-teal-600 dark:text-teal-400 font-semibold">{config.unit}</div>}
                                                </div>
                                                {hasChanged && (
                                                    <div className="absolute top-1 right-1 flex flex-col items-end animate-audit-glow audit-shimmer-container px-1 rounded-sm border border-amber-200/50 dark:border-amber-700/30 z-10">
                                                        <span className="text-[7px] font-black text-amber-600 dark:text-amber-400 uppercase leading-none mt-1">{t('lbl_was')}</span>
                                                        <span className="text-[10px] font-black text-amber-950 dark:text-white leading-none mb-1 font-[family-name:var(--font-mono)]">{changeInfo.value}</span>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </section>


                    {/* Pressures & Trends - LARGE CHARTS */}
                    <section className="flex-1">
                        <div className="flex items-center gap-1.5 mb-1">
                            <div className="w-0.5 h-3 bg-purple-500 rounded-full"></div>
                            <h3 className="text-[10px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">{t('lbl_hemodynamic_trends')}</h3>
                            <div className="ml-auto flex gap-2 items-center">
                                {/* Threshold Settings Toggle */}
                                {expandedChart === 'tmp' && (
                                    <button
                                        onClick={() => setShowThresholdSettings(!showThresholdSettings)}
                                        className={clsx(
                                            "text-[10px] px-2 py-0.5 rounded font-bold transition-all duration-200 border flex items-center gap-1 shadow-sm",
                                            showThresholdSettings
                                                ? "bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 border-red-200 dark:border-red-800"
                                                : "bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700"
                                        )}
                                    >
                                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                        </svg>
                                        {showThresholdSettings ? t('btn_threshold_close') : t('btn_threshold_toggle')}
                                    </button>
                                )}
                                {!expandedChart && (
                                    <button
                                        onClick={() => setExpandedChart('tmp')}
                                        className="text-[10px] bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400 hover:bg-purple-200 dark:hover:bg-purple-900/50 border border-purple-200 dark:border-purple-800 px-2 py-0.5 rounded font-bold transition-colors shadow-sm flex items-center gap-1 group"
                                    >
                                        <svg className="w-3 h-3 group-hover:scale-110 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
                                        </svg>
                                        TMP + ΔP
                                    </button>
                                )}
                                {expandedChart && (
                                    <button
                                        onClick={() => { setExpandedChart(null); setShowThresholdSettings(false); }}
                                        className="text-[10px] bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 px-2 py-0.5 rounded font-semibold text-slate-600 dark:text-slate-400 transition-colors shadow-sm"
                                    >
                                        {t('btn_show_all')}
                                    </button>
                                )}
                            </div>
                        </div>

                        {/* ─── Threshold Settings Panel (Premium Inline) ─── */}
                        {showThresholdSettings && expandedChart === 'tmp' && (
                            <div className="mb-1 p-1.5 rounded-xl border backdrop-blur-md bg-white/80 dark:bg-slate-900/80 border-slate-200 dark:border-slate-700 shadow-lg transition-all duration-200">
                                <div className="flex items-center justify-between gap-6 px-1">
                                    <div className="flex items-center gap-6">
                                        {/* TMP Threshold */}
                                        <div className="flex items-center gap-2">
                                            <div className="flex items-center gap-1">
                                                <div className="w-1.5 h-3 bg-purple-500 rounded-full"></div>
                                                <span className="text-[10px] font-black text-purple-600 dark:text-purple-400 tracking-wide">TMP</span>
                                            </div>
                                            <div className="flex items-center bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-600 overflow-hidden">
                                                <button
                                                    onClick={() => updateThreshold('tmp', tmpThreshold - 10)}
                                                    className="px-2 py-0.5 text-[11px] font-black text-slate-500 hover:bg-purple-100 dark:hover:bg-purple-900/30 hover:text-purple-600 transition-colors"
                                                >−</button>
                                                <input
                                                    type="number"
                                                    value={tmpThreshold}
                                                    onChange={(e) => updateThreshold('tmp', Number(e.target.value))}
                                                    className="w-12 text-center text-[12px] font-black font-[family-name:var(--font-mono)] text-purple-700 dark:text-purple-300 bg-transparent border-x border-slate-200 dark:border-slate-600 py-0.5 outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                                />
                                                <button
                                                    onClick={() => updateThreshold('tmp', tmpThreshold + 10)}
                                                    className="px-2 py-0.5 text-[11px] font-black text-slate-500 hover:bg-purple-100 dark:hover:bg-purple-900/30 hover:text-purple-600 transition-colors"
                                                >+</button>
                                            </div>
                                            <span className="text-[9px] text-slate-400 font-bold">mmHg</span>
                                        </div>

                                        {/* Divider */}
                                        <div className="w-px h-4 bg-slate-200 dark:bg-slate-700"></div>

                                        {/* ΔP Threshold */}
                                        <div className="flex items-center gap-2">
                                            <div className="flex items-center gap-1">
                                                <div className="w-1.5 h-3 bg-amber-500 rounded-full"></div>
                                                <span className="text-[10px] font-black text-amber-600 dark:text-amber-400 tracking-wide">ΔP</span>
                                            </div>
                                            <div className="flex items-center bg-slate-50 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-600 overflow-hidden">
                                                <button
                                                    onClick={() => updateThreshold('dp', dpThreshold - 10)}
                                                    className="px-2 py-0.5 text-[11px] font-black text-slate-500 hover:bg-amber-100 dark:hover:bg-amber-900/30 hover:text-amber-600 transition-colors"
                                                >−</button>
                                                <input
                                                    type="number"
                                                    value={dpThreshold}
                                                    onChange={(e) => updateThreshold('dp', Number(e.target.value))}
                                                    className="w-12 text-center text-[12px] font-black font-[family-name:var(--font-mono)] text-amber-700 dark:text-amber-300 bg-transparent border-x border-slate-200 dark:border-slate-600 py-0.5 outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                                />
                                                <button
                                                    onClick={() => updateThreshold('dp', dpThreshold + 10)}
                                                    className="px-2 py-0.5 text-[11px] font-black text-slate-500 hover:bg-amber-100 dark:hover:bg-amber-900/30 hover:text-amber-600 transition-colors"
                                                >+</button>
                                            </div>
                                            <span className="text-[9px] text-slate-400 font-bold">mmHg</span>
                                        </div>
                                    </div>

                                    <button
                                        onClick={() => { updateThreshold('tmp', 300); updateThreshold('dp', 150); }}
                                        className="text-[9px] px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-600 font-bold transition-colors"
                                    >
                                        {t('btn_threshold_reset')}
                                    </button>
                                </div>
                            </div>
                        )}

                        <div className={clsx(
                            "grid gap-2 transition-[grid-template-columns,height] duration-500 ease-[cubic-bezier(0.4,0,0.2,1)]",
                            expandedChart === 'tmp' ? 'grid-cols-1 h-[400px]' : expandedChart ? 'grid-cols-1 h-64' : 'grid-cols-4 h-48',
                            isTransitioning && "opacity-60 pointer-events-none"
                        )}>
                            {/* DualPressureChart — Conditional rendering to save cycles & avoid warnings */}
                            {expandedChart === 'tmp' && (
                                <div className="flex flex-col gap-3 h-full animate-in slide-in-from-top-4 duration-500">
                                    <div className="flex-1 overflow-hidden rounded-lg">
                                        <StandardPressureChart
                                            data={historyData.tmp}
                                            color="#a855f7"
                                            name="TMP"
                                            unit="mmHg"
                                            limit={tmpThreshold}
                                            windowMode="full"
                                            syncId="detailTmpDp"
                                        />
                                    </div>
                                    <div className="flex-1 overflow-hidden rounded-lg">
                                        <StandardPressureChart
                                            data={historyData.delta_p}
                                            color="#f59e0b"
                                            name="ΔP"
                                            unit="mmHg"
                                            limit={dpThreshold}
                                            windowMode="full"
                                            syncId="detailTmpDp"
                                        />
                                    </div>
                                </div>
                            )}

                            {/* Individual Pressure Charts — Only mount when not in TMP view */}
                            {expandedChart !== 'tmp' && (
                                <>
                                    <div
                                        onClick={() => setExpandedChart(expandedChart === 'access' ? null : 'access')}
                                        className={clsx(
                                            "cursor-pointer transition-transform duration-300 hover:scale-[1.02] hover:shadow-[0_0_15px_rgba(168,85,247,0.6)] rounded-lg",
                                            expandedChart && expandedChart !== 'access' ? 'hidden' : ''
                                        )}
                                    >
                                        <PressureChart data={historyData.access} color="#ef4444" name="Access" unit="mmHg" />
                                    </div>
                                    <div
                                        onClick={() => setExpandedChart(expandedChart === 'filter' ? null : 'filter')}
                                        className={clsx(
                                            "cursor-pointer transition-transform duration-300 hover:scale-[1.02] hover:shadow-[0_0_15px_rgba(168,85,247,0.6)] rounded-lg",
                                            expandedChart && expandedChart !== 'filter' ? 'hidden' : ''
                                        )}
                                    >
                                        <PressureChart data={historyData.filter} color="#f97316" name="Filter" unit="mmHg" />
                                    </div>
                                    <div
                                        onClick={() => setExpandedChart(expandedChart === 'effluent' ? null : 'effluent')}
                                        className={clsx(
                                            "cursor-pointer transition-transform duration-300 hover:scale-[1.02] hover:shadow-[0_0_15px_rgba(168,85,247,0.6)] rounded-lg",
                                            expandedChart && expandedChart !== 'effluent' ? 'hidden' : ''
                                        )}
                                    >
                                        <PressureChart data={historyData.effluent} color="#d97706" name="Effluent" unit="mmHg" />
                                    </div>
                                    <div
                                        onClick={() => setExpandedChart(expandedChart === 'return' ? null : 'return')}
                                        className={clsx(
                                            "cursor-pointer transition-transform duration-300 hover:scale-[1.02] hover:shadow-[0_0_15px_rgba(168,85,247,0.6)] rounded-lg",
                                            expandedChart && expandedChart !== 'return' ? 'hidden' : ''
                                        )}
                                    >
                                        <PressureChart data={historyData.return} color="#3b82f6" name="Return" unit="mmHg" />
                                    </div>
                                </>
                            )}
                        </div>
                    </section>

                    {/* Anticoagulation - Ultra Compact */}
                    <section>
                        <div className="flex items-center gap-1.5 mb-1 group">
                            <div className="w-0.5 h-3 bg-amber-500 rounded-full"></div>
                            <h3 className="text-[10px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">{t('lbl_regional_anticoag')}</h3>
                            <button
                                onClick={() => setActiveDrawer('C')}
                                className="ml-auto text-[9px] px-2.5 py-0.5 rounded-full font-bold transition-all duration-300 border flex items-center gap-1 shadow-sm hover:scale-[1.03] active:scale-95 uppercase tracking-wide bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-500 border-amber-200 dark:border-amber-800 hover:bg-amber-50 dark:hover:bg-amber-900/30 hover:border-amber-300 hover:shadow-amber-500/20">
                                <span>{t('lbl_more')}</span>
                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" /></svg>
                            </button>
                        </div>
                        <div className="grid grid-cols-5 gap-1.5 relative min-h-[50px]">
                            {(() => {
                                const anticoagType = getParamValue('body_409');
                                let anticoagKeys = ['body_409'];
                                if (anticoagType.includes('Heparin')) {
                                    anticoagKeys = ['body_409', 'body_38', 'body_36', 'body_37'];
                                } else if (anticoagType.includes('Cit/Cal') || anticoagType.includes('Citrate')) {
                                    anticoagKeys = ['body_409', 'body_400', 'body_403', 'body_404', 'body_406'];
                                }

                                return anticoagKeys.map(key => {
                                    const config = CRRT_PARAMETER_MAP[key];
                                    if (!config) return null;
                                    const value = getParamValue(key);
                                    const changeInfo = lastChangedParams[key];
                                    const hasChanged = config.trackChanges && !!changeInfo && String(changeInfo.value) !== String(value);

                                    return (
                                        <div key={key} className={clsx(
                                            "bg-white dark:bg-slate-800 shadow-sm rounded p-1.5 border transition-all duration-300 relative hover:scale-[1.05] hover:shadow-[0_0_15px_rgba(245,158,11,0.6)] hover:border-amber-400/50",
                                            hasChanged
                                                ? "border-amber-400 dark:border-amber-600 shadow-[0_0_10px_rgba(251,191,36,0.2)]"
                                                : "border-slate-200 dark:border-slate-700"
                                        )}>
                                            <div className="flex items-start justify-between gap-1">
                                                <div className="flex-1">
                                                    <div className="text-[8px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-0.5">{(t as any)(config.name) || config.name}</div>
                                                    <div className={clsx(
                                                        "text-sm font-bold transition-all duration-500 font-[family-name:var(--font-mono)]",
                                                        hasChanged ? "text-amber-700 dark:text-amber-400" : "text-slate-900 dark:text-slate-100",
                                                        isStale && "opacity-40",
                                                        isOffline && "text-slate-400"
                                                    )}>
                                                        {value}
                                                        {isStale && !isOffline && <span className="ml-1 text-[7px] opacity-40 animate-pulse italic">STALE</span>}
                                                    </div>
                                                    {config.unit && <div className={clsx("text-[9px] font-semibold transition-all duration-500", isStale ? "text-slate-400" : "text-amber-600 dark:text-amber-400")}>{config.unit}</div>}
                                                </div>
                                                {hasChanged && (
                                                    <div className="absolute top-1 right-1 flex flex-col items-end animate-audit-glow audit-shimmer-container px-1 rounded-sm border border-amber-200/50 dark:border-amber-700/30 z-10">
                                                        <span className="text-[7px] font-black text-amber-600 dark:text-amber-400 uppercase leading-none mt-1">was</span>
                                                        <span className="text-[10px] font-black text-amber-950 dark:text-white leading-none mb-1 font-[family-name:var(--font-mono)]">{changeInfo.value}</span>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    );
                                });
                            })()}
                        </div>
                    </section>
                    <section className="pb-4">
                        <div
                            onClick={() => setShowAlarmLog(!showAlarmLog)}
                            className="flex items-center gap-1.5 mb-1 mt-1 cursor-pointer group hover:bg-slate-200/50 dark:hover:bg-slate-800/50 p-1 rounded transition-colors"
                        >
                            <div className="w-0.5 h-3 bg-red-500 rounded-full"></div>
                            <h3 className="text-[10px] font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">{t('lbl_historical_events')}</h3>
                            <div className="flex items-center gap-2 ml-auto">
                                {alarmHistory.length > 0 && (
                                    <span className="text-[8px] bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 px-1.5 py-0.5 rounded-full font-bold border border-red-100 dark:border-red-900/50 transition-colors">
                                        {alarmHistory.filter(a => !a.end_time).length} {t('lbl_active_count')} / {alarmHistory.length} {t('lbl_total_count')}
                                    </span>
                                )}
                                <svg
                                    className={clsx("w-3 h-3 text-slate-400 dark:text-slate-500 transition-transform duration-200", showAlarmLog && "rotate-180")}
                                    fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                >
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>
                        </div>

                        {showAlarmLog && (
                            <div className="bg-white dark:bg-[#0f172a] rounded p-2 border border-slate-200 dark:border-slate-800 h-32 overflow-y-auto animate-in fade-in slide-in-from-top-1 duration-200 transition-colors">
                                <table className="w-full text-left border-collapse">
                                    <thead>
                                        <tr className="text-[9px] text-slate-400 dark:text-slate-500 uppercase border-b border-slate-100 dark:border-slate-800">
                                            <th className="py-1 font-semibold w-10">{t('lbl_th_id')}</th>
                                            <th className="py-1 font-semibold w-24">{t('lbl_th_time')}</th>
                                            <th className="py-1 font-semibold w-20">{t('lbl_th_patient_id')}</th>
                                            <th className="py-1 font-semibold w-20">{t('lbl_th_severity')}</th>
                                            <th className="py-1 font-semibold">{t('lbl_th_alarm_title')}</th>
                                            <th className="py-1 font-semibold w-16">{t('lbl_th_duration')}</th>
                                            <th className="py-1 font-semibold w-16 text-right">{t('lbl_th_status')}</th>
                                        </tr>
                                    </thead>
                                    <tbody className="text-[10px]">
                                        {alarmHistory.map((alarm: any, idx: number) => {
                                            const start = new Date(alarm.start_time);
                                            const end = alarm.end_time ? new Date(alarm.end_time) : null;

                                            // Calculate duration: end - start OR now - start (for active)
                                            // CRITICAL FIX: If device is OFFLINE, freeze the counter at lastUpdate time
                                            const isOffline = currentDevice.status === 'OFFLINE';
                                            const referenceNow = (!end && isOffline) ? new Date(currentDevice.lastUpdate) : new Date();

                                            const durationSec = end
                                                ? Math.floor((end.getTime() - start.getTime()) / 1000)
                                                : Math.floor((referenceNow.getTime() - start.getTime()) / 1000);

                                            const formatDuration = (totalSec: number) => {
                                                if (totalSec < 0) return "0s";
                                                const h = Math.floor(totalSec / 3600);
                                                const m = Math.floor((totalSec % 3600) / 60);
                                                const s = totalSec % 60;

                                                if (h > 0) return `${h}h ${m}m ${s}s`;
                                                if (m > 0) return `${m}m ${s}s`;
                                                return `${s}s`;
                                            };

                                            // Severity Colors - Clinical Standardization
                                            let severColor = "text-slate-700 dark:text-slate-300";
                                            if (alarm.severity === "ALARM" || alarm.severity === "MALFUNCTION")
                                                severColor = "text-red-600 dark:text-red-400 font-bold";
                                            else if (alarm.severity === "WARNING")
                                                severColor = "text-amber-600 dark:text-amber-400 font-bold";
                                            else if (alarm.severity === "CAUTION")
                                                severColor = "text-sky-500 dark:text-sky-400 font-bold";
                                            else if (alarm.severity === "ADVISORY")
                                                severColor = "text-teal-500 dark:text-teal-400 font-bold";

                                            return (
                                                <tr key={idx} className="border-b border-slate-50 dark:border-slate-800 last:border-0 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                                                    <td className="py-1 text-slate-400 font-[family-name:var(--font-mono)] text-[9px]">#{alarm.alarm_id || '--'}</td>
                                                    <td className="py-1 text-slate-500 dark:text-slate-500 font-[family-name:var(--font-mono)]">
                                                        {start.toLocaleTimeString('en-GB', { hour12: false })}
                                                    </td>
                                                    <td className="py-1 text-slate-600 dark:text-slate-400 font-medium">{alarm.patient_id || '--'}</td>
                                                    <td className="py-1">
                                                        <span className={clsx("px-1.5 py-0.5 rounded-[4px] text-[8px] font-black uppercase tracking-tighter border",
                                                            alarm.severity === "ALARM" || alarm.severity === "MALFUNCTION" ? "bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 border-red-100 dark:border-red-900/50" :
                                                                alarm.severity === "WARNING" ? "bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 border-amber-100 dark:border-amber-900/50" :
                                                                    alarm.severity === "CAUTION" ? "bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-400 border-sky-100 dark:border-sky-900/50" :
                                                                        "bg-teal-50 dark:bg-teal-900/20 text-teal-600 dark:text-teal-400 border-teal-100 dark:border-teal-900/50"
                                                        )}>
                                                            {alarm.severity}
                                                        </span>
                                                    </td>
                                                    <td className={clsx("py-1 truncate max-w-[200px]", severColor)} title={alarm.title}>
                                                        {alarm.title}
                                                    </td>

                                                    <td className="py-1 font-[family-name:var(--font-mono)]" >
                                                        {formatDuration(durationSec)}
                                                    </td>
                                                    <td className="py-1 text-right">
                                                        {end ? (
                                                            <span className="text-[8px] bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-1 py-0.5 rounded transition-colors">{t('lbl_status_cleared')}</span>
                                                        ) : (
                                                            <span className="text-[8px] bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 px-1 py-0.5 rounded font-bold animate-pulse transition-colors">{t('lbl_status_active')}</span>
                                                        )}
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                        {alarmHistory.length === 0 && (
                                            <tr>
                                                <td colSpan={7} className="py-4 text-center text-slate-300 italic text-[10px]">
                                                    {t('lbl_no_events')}
                                                </td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </section>
                </main>
            </div>
            {/* Side Panel Drawer (Idea 3) */}
            {
                activeDrawer && (
                    <div
                        className="fixed inset-0 z-50 flex justify-end animate-in fade-in duration-300"
                        onClick={() => setActiveDrawer(null)}
                    >
                        {/* Backdrop Overlay */}
                        <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-[4px]" />

                        {/* Drawer Content */}
                        <div
                            className={clsx(
                                "relative w-[450px] h-full bg-white dark:bg-slate-900 shadow-2xl border-l border-white/20 dark:border-slate-800 flex flex-col animate-in slide-in-from-right duration-500 ease-out",
                                activeDrawer === 'B' ? "ring-2 ring-blue-500/20" : "ring-2 ring-amber-500/20"
                            )}
                            onClick={e => e.stopPropagation()}
                        >
                            {/* Drawer Header */}
                            <div className={clsx(
                                "p-6 flex items-center justify-between border-b border-slate-100 dark:border-slate-800",
                                activeDrawer === 'B' ? "bg-blue-50/50 dark:bg-blue-900/20" :
                                    activeDrawer === 'A' ? "bg-teal-50/50 dark:bg-teal-900/20" : "bg-amber-50/50 dark:bg-amber-900/20"
                            )}>
                                <div>
                                    <h4 className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em] mb-1">{t('lbl_advanced_view')}</h4>
                                    <h2 className="text-xl font-black text-slate-800 dark:text-slate-100 flex items-center gap-2">
                                        <div className={clsx("w-1 h-5 rounded-full",
                                            activeDrawer === 'B' ? "bg-blue-500" :
                                                activeDrawer === 'A' ? "bg-teal-500" : "bg-amber-500")} />
                                        {activeDrawer === 'A' ? t('lbl_system_telemetry') :
                                            activeDrawer === 'B' ? t('lbl_therapy_rx') : t('lbl_regional_anticoag')}
                                    </h2>
                                </div>
                                <button
                                    onClick={() => setActiveDrawer(null)}
                                    className="p-2 rounded-full hover:bg-white/80 dark:hover:bg-slate-800 transition-colors shadow-sm border border-slate-200 dark:border-slate-700"
                                >
                                    <svg className="w-5 h-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>

                            {/* Drawer Body - Scrollable */}
                            <div className="flex-1 overflow-y-auto p-6 space-y-8 no-scrollbar">
                                {/* Parameters Grid */}
                                <div className="space-y-4">
                                    <h5 className="text-[9px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                                        <span className="w-1.5 h-1.5 rounded-full bg-current opacity-40" />
                                        {t('lbl_clinical_parameters')}
                                    </h5>
                                    <div className="grid grid-cols-2 gap-3">
                                        {(activeDrawer === 'A' ? SECTION_KEYS_ADVANCED.A :
                                            activeDrawer === 'B' ? SECTION_KEYS_ADVANCED.B : SECTION_KEYS_ADVANCED.C).map(key => {
                                                const config = CRRT_PARAMETER_MAP[key];
                                                if (!config) return null;
                                                const value = getParamValue(key);
                                                const accentColor = activeDrawer === 'B' ? "text-blue-600 dark:text-blue-400" :
                                                    activeDrawer === 'A' ? "text-teal-600 dark:text-teal-400" : "text-amber-600 dark:text-amber-400";
                                                const borderColor = activeDrawer === 'B' ? "border-blue-500/30" :
                                                    activeDrawer === 'A' ? "border-teal-500/30" : "border-amber-500/30";

                                                return (
                                                    <div key={key} className={clsx(
                                                        "p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm transition-all duration-300 hover:scale-[1.02] hover:shadow-md relative overflow-hidden group",
                                                        activeDrawer === 'B' ? "hover:border-blue-400/50" :
                                                            activeDrawer === 'A' ? "hover:border-teal-400/50" : "hover:border-amber-400/50"
                                                    )}>
                                                        {/* Subtle Left Accent Stripe */}
                                                        <div className={clsx("absolute left-0 top-0 bottom-0 w-1",
                                                            activeDrawer === 'B' ? "bg-blue-500/50" :
                                                                activeDrawer === 'A' ? "bg-teal-500/50" : "bg-amber-500/50")} />

                                                        <div className="text-[10px] font-black text-slate-600 dark:text-slate-300 uppercase tracking-widest mb-2 pl-1 border-b border-slate-50 dark:border-slate-800/50 pb-1">{(t as any)(config.name) || config.name}</div>
                                                        <div className="flex items-baseline gap-1.5 pl-1.5 mt-2">
                                                            <span className={clsx(
                                                                "text-2xl font-black font-[family-name:var(--font-mono)] transition-all duration-500",
                                                                isOffline ? "text-slate-400" : "text-slate-900 dark:text-white",
                                                                isStale && "opacity-40"
                                                            )}>
                                                                {value}
                                                                {isStale && !isOffline && <span className="ml-1 text-[10px] opacity-40 animate-pulse italic">STALE</span>}
                                                            </span>
                                                            {config.unit && <span className={clsx("text-[11px] font-black uppercase tracking-tighter transition-all duration-500", isStale ? "text-slate-400" : accentColor)}>{config.unit}</span>}
                                                        </div>

                                                        {/* Background Decorative Glow (Hover) */}
                                                        <div className={clsx(
                                                            "absolute -right-4 -bottom-4 w-12 h-12 rounded-full blur-2xl transition-opacity duration-300 opacity-0 group-hover:opacity-20",
                                                            activeDrawer === 'B' ? "bg-blue-500" : "bg-amber-500"
                                                        )} />
                                                    </div>
                                                );
                                            })}
                                    </div>
                                </div>
                            </div>

                            {/* Drawer Footer */}
                            <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/40">
                                <button
                                    onClick={() => setActiveDrawer(null)}
                                    className="w-full py-3 bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 dark:hover:bg-slate-600 text-white rounded-xl font-bold transition-all shadow-lg active:scale-95 uppercase tracking-widest text-xs"
                                >
                                    CLOSE
                                </button>
                            </div>
                        </div>
                    </div>
                )}
        </div>
    );
}
