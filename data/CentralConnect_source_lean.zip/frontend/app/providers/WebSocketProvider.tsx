'use client';

import React, { createContext, useContext, useEffect, useState, useRef, useCallback, useMemo } from 'react';
import { DeviceData, WebSocketMessage } from '../types';
import { MOCK_DEVICES } from '../utils/mockData';
import { THERAPY_STATUS_MAP, THERAPY_TYPE_MAP } from '../utils/constants';
import { normalizeRecentEventTimestampMs, toClinicalTimestampMs } from '../utils/clinicalTime';

// ─── Types ────────────────────────────────────────────────────────

interface DeviceEvent {
    paramId: string;
    paramName?: string;
    oldValue: string;
    newValue: string;
    timestamp: number;
}

interface WebSocketContextType {
    devices: DeviceData[];
    isConnected: boolean;
    getDevice: (id: string) => DeviceData | undefined;
    connectionStatus: 'CONNECTED' | 'DISCONNECTED' | 'CONNECTING' | 'ERROR';
    /** Centralized events data: { deviceId: DeviceEvent[] } */
    deviceEvents: Record<string, DeviceEvent[]>;
    /** Latest server time synchronized from the backend */
    serverTime: Date | null;
    /** Whether audio is armed and ready to play */
    isAudioEnabled: boolean;
    /** Function to unlock audio via user interaction */
    enableAudio: () => void;
    /** Permanently remove a device from the local registry */
    forgetDevice: (id: string) => void;
}

const WebSocketContext = createContext<WebSocketContextType | null>(null);

function mergeDefinedFields<T extends Record<string, any>>(base: T | undefined, patch: T | undefined): T {
    const merged = { ...(base || {}) } as Record<string, any>;

    Object.entries(patch || {}).forEach(([key, value]) => {
        if (value !== undefined) {
            merged[key] = value;
        }
    });

    if (merged.therapy_type_id_name == null && typeof merged.therapy_type_id === 'number') {
        merged.therapy_type_id_name = THERAPY_TYPE_MAP[merged.therapy_type_id];
    }

    if (merged.therapy_status_id_name == null && typeof merged.therapy_status_id === 'number') {
        merged.therapy_status_id_name = THERAPY_STATUS_MAP[merged.therapy_status_id];
    }

    return merged as T;
}

// ─── Provider ─────────────────────────────────────────────────────

export function WebSocketProvider({ children }: { children: React.ReactNode }) {
    const [deviceMap, setDeviceMap] = useState<Record<string, DeviceData>>({});
    const [connectionStatus, setConnectionStatus] = useState<'CONNECTED' | 'DISCONNECTED' | 'CONNECTING' | 'ERROR'>('DISCONNECTED');
    const [deviceEvents, setDeviceEvents] = useState<Record<string, DeviceEvent[]>>({});
    const [serverTime, setServerTime] = useState<Date | null>(null);
    const [isAudioEnabled, setIsAudioEnabled] = useState(false);
    const wsRef = useRef<WebSocket | null>(null);
    const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

    // Debounce timer for localStorage writes
    const registrySaveTimer = useRef<NodeJS.Timeout | null>(null);
    const pendingRegistryRef = useRef<Record<string, any>>({});

    // ─── Initialize from localStorage ─────────────────────────────

    useEffect(() => {
        const initialMap: Record<string, DeviceData> = {};
        const savedDevices = localStorage.getItem('known_devices');
        if (savedDevices) {
            try {
                const registry = JSON.parse(savedDevices);
                Object.keys(registry).forEach(id => {
                    initialMap[id] = { ...registry[id], status: 'OFFLINE' };
                });
            } catch (e) {
                console.error('Failed to parse saved devices:', e);
            }
        }
        setDeviceMap(initialMap);
    }, []);

    // ─── Debounced Registry Save ──────────────────────────────────

    const saveRegistryDebounced = useCallback((deviceId: string, data: DeviceData) => {
        pendingRegistryRef.current[deviceId] = {
            id: data.id,
            name: data.name,
            ip: data.ip,
            lastUpdate: data.lastUpdate,
        };

        // Only write to localStorage at most once every 10 seconds
        if (!registrySaveTimer.current) {
            registrySaveTimer.current = setTimeout(() => {
                const saved = localStorage.getItem('known_devices');
                const registry = saved ? JSON.parse(saved) : {};
                const merged = { ...registry, ...pendingRegistryRef.current };
                localStorage.setItem('known_devices', JSON.stringify(merged));
                pendingRegistryRef.current = {};
                registrySaveTimer.current = null;
            }, 10000);
        }
    }, []);

    // Keep a ref of the latest audio enabled state so the WebSocket closure can access it
    const isAudioEnabledRef = useRef(isAudioEnabled);
    useEffect(() => {
        isAudioEnabledRef.current = isAudioEnabled;
    }, [isAudioEnabled]);

    // ─── Audio Arming ──────────────────────────────────────────────

    const enableAudio = useCallback(() => {
        // Prime the audio engine using one of our verified local files
        const silentAudio = new Audio('/audio/beep-warning.wav');
        silentAudio.volume = 0; // Silent priming
        silentAudio.play()
            .then(() => {
                console.log('🔊 Audio System Armed Successfully');
                setIsAudioEnabled(true);
            })
            .catch(e => {
                console.error('❌ Failed to arm audio:', e);
            });
    }, []);

    // ─── Device Cleanup ───────────────────────────────────────────

    const forgetDevice = useCallback((deviceId: string) => {
        setDeviceMap(prev => {
            const newMap = { ...prev };
            delete newMap[deviceId];

            // Immediately update localStorage
            const saved = localStorage.getItem('known_devices');
            if (saved) {
                try {
                    const registry = JSON.parse(saved);
                    delete registry[deviceId];
                    localStorage.setItem('known_devices', JSON.stringify(registry));
                } catch (e) {
                    console.error('Failed to update localStorage during forgetDevice:', e);
                }
            }

            return newMap;
        });
    }, []);

    useEffect(() => {
        const interval = setInterval(() => {
            const now = new Date().getTime();
            setDeviceMap(prev => {
                let hasChanges = false;
                const newMap = { ...prev };

                Object.keys(newMap).forEach(id => {
                    const lastUpdate = new Date(newMap[id].lastUpdate).getTime();
                    if (now - lastUpdate > 45000 && newMap[id].status !== 'OFFLINE') {
                        newMap[id] = { ...newMap[id], status: 'OFFLINE' };
                        hasChanges = true;
                    }
                });

                return hasChanges ? newMap : prev;
            });
        }, 5000);

        return () => clearInterval(interval);
    }, []);

    // ─── Centralized Events Polling (Every 15s) ──────────────────
    // Instead of each DeviceCard polling independently,
    // we batch-fetch events for all online devices here.

    useEffect(() => {
        const fetchAllEvents = async () => {
            // Fetch for ALL known devices (not just online)
            // So Was events survive browser refresh (data is in backend DB)
            const allDevices = Object.values(deviceMap);
            if (allDevices.length === 0) return;

            const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
            const newEvents: Record<string, DeviceEvent[]> = {};

            // Fetch events for all online devices in parallel
            const promises = allDevices.map(async (device) => {
                try {
                    const res = await fetch(`${apiUrl}/api/v1/devices/${device.id}/events`);
                    if (res.ok) {
                        const events = await res.json();
                        if (Array.isArray(events)) {
                            newEvents[device.id] = events.map((evt: any) => ({
                                paramId: evt.param_id,
                                oldValue: evt.old_value,
                                newValue: evt.new_value,
                                timestamp: normalizeRecentEventTimestampMs(evt.timestamp),
                            }));
                        }
                    }
                } catch {
                    // Silent fail for individual device
                }
            });

            await Promise.all(promises);
            setDeviceEvents(prev => ({ ...prev, ...newEvents }));
        };

        fetchAllEvents();
        const interval = setInterval(fetchAllEvents, 15000);
        return () => clearInterval(interval);
    }, [Object.keys(deviceMap).join(',')]);

    // ─── WebSocket Connection ────────────────────────────────────

    useEffect(() => {
        const connect = () => {
            if (wsRef.current?.readyState === WebSocket.OPEN) return;

            setConnectionStatus('CONNECTING');

            try {
                const wsUrl = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8000/ws';
                const ws = new WebSocket(wsUrl);
                wsRef.current = ws;

                ws.onopen = () => {
                    console.log('✅ WebSocket Connected');
                    setConnectionStatus('CONNECTED');
                    ws.send(JSON.stringify({ type: 'PING' }));
                };

                ws.onmessage = (event) => {
                    try {
                        const message: any = JSON.parse(event.data);

                        if (message.type === 'HEARTBEAT') {
                            if (message.server_time) {
                                setServerTime(new Date(message.server_time));
                            }
                        } else if (message.type === 'EVENT_UPDATE') {
                            const { device_id, changes } = message;
                            if (device_id && Array.isArray(changes)) {
                                setDeviceEvents(prev => {
                                    const existing = prev[device_id] || [];
                                    const mappedChanges: DeviceEvent[] = changes.map((c: any) => ({
                                        paramId: String(c.param_id),
                                        oldValue: String(c.old_value),
                                        newValue: String(c.new_value),
                                        timestamp: normalizeRecentEventTimestampMs(c.timestamp),
                                    }));

                                    // Merge and sort (limit to last 20 for memory safety)
                                    const merged = [...existing, ...mappedChanges]
                                        .sort((a, b) => b.timestamp - a.timestamp)
                                        .slice(0, 20);

                                    return { ...prev, [device_id]: merged };
                                });
                            }
                        } else if (message.type === 'TELEMETRY_FAST_UPDATE') {
                            const { payload } = message;
                            if (!payload || !payload.meta) return;

                            const deviceId = payload.meta.device_id;
                            const timestamp = payload.meta.timestamp;

                            setDeviceMap(prev => {
                                const existing = prev[deviceId];
                                if (!existing) return prev;

                                const packetNum = payload.meta.packet_num || 0;
                                const existingPacketNum = existing.packetNum || 0;
                                if (packetNum > 0 && packetNum <= existingPacketNum) return prev;

                                const statusId = payload.s_header?.therapy_status_id;
                                let newStatus = existing.status;
                                if ([1, 2, 3, 4, 5, 10, 11, 12, 13, 14, 15].includes(statusId)) newStatus = 'RUNNING';
                                else if (statusId === 9) newStatus = 'ALARM';
                                else if ([0, 6, 7, 8].includes(statusId)) newStatus = 'STOPPED';

                                const updatedParams = [...(existing.data?.s_body?.parameters || [])];
                                const vitalToPid: Record<string, number> = {
                                    "access_pressure": 1, "filter_pressure": 2, "effluent_pressure": 3, "return_pressure": 4,
                                    "tmp": 6, "blood_flow_qb": 17, "pbp_flow": 22, "dialysate_flow_qd": 21,
                                    "replacement_flow_post": 19, "replacement_flow_pre": 18,
                                    "effluent_rate": 23, "net_uf_rate": 24, "heparin_flow": 38, "effluent_dose": 410
                                };

                                Object.entries(payload.vitals || {}).forEach(([label, value]) => {
                                    const pid = vitalToPid[label];
                                    if (pid) {
                                        const idx = updatedParams.findIndex(p => p.id === pid && p.type === 'Actual');
                                        if (idx !== -1) {
                                            updatedParams[idx] = { ...updatedParams[idx], value: value as number };
                                        } else {
                                            updatedParams.push({ id: pid, type: 'Actual', value: value as number });
                                        }
                                    }
                                });

                                return {
                                    ...prev,
                                    [deviceId]: {
                                        ...existing,
                                        status: newStatus,
                                        // Use BROWSER time for lastUpdate (not packet timestamp which may be
                                        // local time mislabeled as UTC, causing TELEMETRY_UPDATE rejection)
                                        lastUpdate: new Date().toISOString(),
                                        packetNum: payload.meta.packet_num,
                                        data: {
                                            ...existing.data,
                                            s_header: mergeDefinedFields(existing.data?.s_header, payload.s_header),
                                            s_body: { ...(existing.data?.s_body || {}), parameters: updatedParams }
                                        }
                                    }
                                };
                            });
                        } else if (message.type === 'TELEMETRY_UPDATE') {
                            const { payload, quality_status } = message;

                            if (!payload || !payload.meta) {
                                console.warn('Received invalid telemetry payload:', payload);
                                return;
                            }

                            const deviceId = payload.meta.device_id;

                            setDeviceMap(prev => {
                                const existing = prev[deviceId];

                                // Freshness Check
                                if (!quality_status?.server_time) return prev;

                                const newDate = new Date(quality_status.server_time);
                                const newTime = newDate.getTime();
                                setServerTime(newDate); // Update global server time too

                                const oldTime = existing ? new Date(existing.lastUpdate).getTime() : 0;
                                // CRITICAL FIX: Allow full updates to ALWAYS update the state if they come from TELEMETRY_UPDATE,
                                // as they contain the complete parameter set. Only block if the incoming packet is ancient (> 10s).
                                if (existing && (oldTime - newTime) > 10000) return prev;

                                // Determine Status
                                const statusId = payload.s_header?.therapy_status_id ?? payload.header?.therapy_status_id;
                                let newStatus: any = 'UNKNOWN';
                                if ([1, 2, 3, 4, 5, 10, 11, 12, 13, 14, 15].includes(statusId)) newStatus = 'RUNNING';
                                else if (statusId === 9) newStatus = 'ALARM';
                                else if ([0, 6, 7, 8].includes(statusId)) newStatus = 'STOPPED';

                                // Multi-level Alarm Notification
                                const activeAlarms = payload.active_alarms || [];
                                const hasCritical = activeAlarms.some((a: any) => ['ALARM', 'MALFUNCTION'].includes(a.category) && a.state === 'PRESENT');
                                const hasWarning = activeAlarms.some((a: any) => a.category === 'WARNING' && a.state === 'PRESENT');
                                const normalizedHeader = mergeDefinedFields(existing?.data?.s_header, payload.s_header || payload.header);

                                const hadCriticalBefore = existing?.active_alarms?.some((a: any) => ['ALARM', 'MALFUNCTION'].includes(a.category) && a.state === 'PRESENT');
                                const hadWarningBefore = existing?.active_alarms?.some((a: any) => a.category === 'WARNING' && a.state === 'PRESENT');

                                // Sound Logic: Play if new severity level reached
                                if (isAudioEnabledRef.current && hasCritical && !hadCriticalBefore) {
                                    // High-priority urgent beep
                                    console.log('🚨 Triggering CRITICAL audio...');
                                    const audio = new Audio('/audio/beep-critical.wav');
                                    audio.volume = 0.5;
                                    audio.play().then(() => console.log('✅ Critical audio played')).catch(e => console.warn('Critical audio play blocked:', e));
                                } else if (isAudioEnabledRef.current && hasWarning && !hadWarningBefore && !hasCritical) {
                                    // Medium-priority alert ping
                                    console.log('⚠️ Triggering WARNING audio...');
                                    const audio = new Audio('/audio/beep-warning.wav');
                                    audio.volume = 0.4;
                                    audio.play().then(() => console.log('✅ Warning audio played')).catch(e => console.warn('Warning audio play blocked:', e));
                                }

                                const newDeviceData: DeviceData = {
                                    id: deviceId,
                                    name: existing?.name || `Device ${deviceId}`,
                                    ip: 'unknown',
                                    status: newStatus,
                                    lastUpdate: new Date().toISOString(), // Use BROWSER time for the heartbeat/offline check
                                    packetNum: payload.meta.packet_num,
                                    active_alarms: activeAlarms,
                                    data: {
                                        s_header: normalizedHeader,
                                        s_body: payload.s_body || payload.body
                                    },
                                    quality: quality_status
                                };

                                // Debounced save to localStorage
                                saveRegistryDebounced(deviceId, newDeviceData);

                                return { ...prev, [deviceId]: newDeviceData };
                            });
                        }
                    } catch (e) {
                        console.error('WS Message Parse Error:', e);
                    }
                };

                ws.onclose = () => {
                    console.log('❌ WebSocket Disconnected');
                    setConnectionStatus('DISCONNECTED');
                    wsRef.current = null;
                    reconnectTimeoutRef.current = setTimeout(connect, 3000);
                };

                ws.onerror = () => {
                    console.warn('⚠️ WebSocket Error. Check if backend is running.');
                    setConnectionStatus('ERROR');
                    ws.close();
                };

            } catch (e) {
                console.error('WebSocket Connection Setup Failed:', e);
                setConnectionStatus('ERROR');
                reconnectTimeoutRef.current = setTimeout(connect, 5000);
            }
        };

        connect();

        return () => {
            if (wsRef.current) wsRef.current.close();
            if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
        };
    }, []);

    // ─── Context Value ───────────────────────────────────────────

    const devices = useMemo(() => Object.values(deviceMap), [deviceMap]);

    const value: WebSocketContextType = useMemo(() => ({
        devices,
        isConnected: connectionStatus === 'CONNECTED',
        connectionStatus,
        getDevice: (id: string) => deviceMap[id],
        deviceEvents,
        serverTime,
        isAudioEnabled,
        enableAudio,
        forgetDevice,
    }), [devices, connectionStatus, deviceMap, deviceEvents, serverTime, isAudioEnabled, enableAudio, forgetDevice]);

    return (
        <WebSocketContext.Provider value={value}>
            {children}
        </WebSocketContext.Provider>
    );
}

export function useDeviceData() {
    const context = useContext(WebSocketContext);
    if (!context) {
        throw new Error('useDeviceData must be used within a WebSocketProvider');
    }
    return context;
}
