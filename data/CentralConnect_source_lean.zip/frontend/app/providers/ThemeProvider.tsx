'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';

type Theme = 'light' | 'dark';

interface ThemeContextType {
    theme: Theme;
    toggleTheme: (x?: number, y?: number) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
    const [theme, setTheme] = useState<Theme>('light');
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        // Get initial theme from localStorage or system preference
        const savedTheme = localStorage.getItem('theme') as Theme;
        if (savedTheme) {
            setTheme(savedTheme);
        } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
            setTheme('dark');
        }
        setMounted(true);
    }, []);

    useEffect(() => {
        if (!mounted) return;

        // Apply theme to document
        const root = window.document.documentElement;
        if (theme === 'dark') {
            root.classList.add('dark');
        } else {
            root.classList.remove('dark');
        }
        localStorage.setItem('theme', theme);
    }, [theme, mounted]);

    const toggleTheme = (x?: number, y?: number) => {
        const newTheme = theme === 'light' ? 'dark' : 'light';

        // Check if browser supports View Transition API
        if (typeof document !== 'undefined' && (document as any).startViewTransition) {
            const root = document.documentElement;

            // Set coordinates
            if (x !== undefined && y !== undefined) {
                root.style.setProperty('--x', `${x}px`);
                root.style.setProperty('--y', `${y}px`);
            } else {
                root.style.setProperty('--x', '50%');
                root.style.setProperty('--y', '50%');
            }

            // Optimization: Add class to disable other transitions
            root.classList.add('is-transitioning');

            const transition = (document as any).startViewTransition(() => {
                setTheme(newTheme);
            });

            // Cleanup after transition
            transition.finished.finally(() => {
                root.classList.remove('is-transitioning');
            });
        } else {
            setTheme(newTheme);
        }
    };

    return (
        <ThemeContext.Provider value={{ theme, toggleTheme }}>
            {children}
        </ThemeContext.Provider>
    );
}

export function useTheme() {
    const context = useContext(ThemeContext);
    if (context === undefined) {
        throw new Error('useTheme must be used within a ThemeProvider');
    }
    return context;
}
