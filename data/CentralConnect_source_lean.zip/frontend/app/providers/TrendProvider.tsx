'use client';

import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { useDeviceData } from './WebSocketProvider';
import { parseClinicalDate, toClinicalTimestampMs } from '../utils/clinicalTime';

export interface TrendPoint {
    time: string;
    value: number;
    _ts: number;
}

export interface TrendData {
    patient_id: string | null;
    access: TrendPoint[];
    filter: TrendPoint[];
    effluent: TrendPoint[];
    return: TrendPoint[];
    tmp: TrendPoint[];
    delta_p: TrendPoint[];
    is_loading?: boolean;
}

interface TrendContextType {
    getTrend: (deviceId: string) => TrendData;
    loadHistory: (deviceId: string) => Promise<void>;
    forgetTrend: (deviceId: string) => void;
}

type TrendRow = {
    timestamp?: string;
    access?: number;
    filter?: number;
    effluent?: number;
    return?: number;
    tmp?: number;
    delta_p?: number;
};

const EMPTY_TREND: TrendData = {
    patient_id: null,
    access: [],
    filter: [],
    effluent: [],
    return: [],
    tmp: [],
    delta_p: [],
    is_loading: false,
};

const MAX_HISTORY_POINTS = 1000;

const TrendContext = createContext<TrendContextType | null>(null);

function isClinicalPatientId(value: unknown): value is string {
    if (typeof value !== 'string') return false;
    const text = value.trim();
    if (!text) return false;
    const upper = text.toUpperCase();
    return upper !== 'N/A' && upper !== 'NONE' && upper !== 'NULL' && text !== '---';
}

function formatTrendTime(date: Date): string {
    return date.toLocaleTimeString('en-GB', {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
    });
}

function trimPoints(points: TrendPoint[]): TrendPoint[] {
    return points.length > MAX_HISTORY_POINTS ? points.slice(-MAX_HISTORY_POINTS) : points;
}

function buildPoint(value: number, ts: number): TrendPoint {
    const date = new Date(ts);
    return { time: formatTrendTime(date), value, _ts: ts };
}

function mergeSeries(existing: TrendPoint[], incoming: TrendPoint[]): TrendPoint[] {
    const merged = new Map<number, TrendPoint>();

    for (const point of existing) {
        merged.set(point._ts, point);
    }

    for (const point of incoming) {
        merged.set(point._ts, point);
    }

    return Array.from(merged.values())
        .sort((a, b) => a._ts - b._ts)
        .slice(-MAX_HISTORY_POINTS);
}

export function TrendProvider({ children }: { children: React.ReactNode }) {
    const { devices } = useDeviceData();
    const trendMapRef = useRef<Record<string, TrendData>>({});
    const hydratedPatientRef = useRef<Record<string, string | null>>({});
    const [version, setVersion] = useState(0);

    const loadHistory = useCallback(async (deviceId: string) => {
        const current = trendMapRef.current[deviceId] || EMPTY_TREND;
        if (current.is_loading) return;
        const activePatientId = current.patient_id ?? null;

        if (hydratedPatientRef.current[deviceId] === activePatientId && current.access.length > 0) {
            return;
        }

        trendMapRef.current[deviceId] = {
            ...current,
            is_loading: true,
        };
        setVersion((v) => v + 1);

        try {
            const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
            const res = await fetch(`${apiUrl}/api/v1/devices/${deviceId}/trends?limit=${MAX_HISTORY_POINTS}`);

            if (!res.ok) {
                trendMapRef.current[deviceId] = {
                    ...trendMapRef.current[deviceId],
                    is_loading: false,
                };
                return;
            }

            const data = await res.json();
            if (!Array.isArray(data)) {
                trendMapRef.current[deviceId] = {
                    ...trendMapRef.current[deviceId],
                    is_loading: false,
                };
                return;
            }

            const sortedRows = [...(data as TrendRow[])]
                .sort((a, b) => toClinicalTimestampMs(a.timestamp) - toClinicalTimestampMs(b.timestamp))
                .slice(-MAX_HISTORY_POINTS);

            const nextTrend: TrendData = {
                patient_id: activePatientId,
                access: [],
                filter: [],
                effluent: [],
                return: [],
                tmp: [],
                delta_p: [],
                is_loading: false,
            };

            for (const row of sortedRows) {
                const ts = parseClinicalDate(row.timestamp).getTime();
                nextTrend.access.push(buildPoint(Number(row.access ?? 0), ts));
                nextTrend.filter.push(buildPoint(Number(row.filter ?? 0), ts));
                nextTrend.effluent.push(buildPoint(Number(row.effluent ?? 0), ts));
                nextTrend.return.push(buildPoint(Number(row.return ?? 0), ts));
                nextTrend.tmp.push(buildPoint(Number(row.tmp ?? 0), ts));
                nextTrend.delta_p.push(buildPoint(Number(row.delta_p ?? 0), ts));
            }

            const latestLiveTrend = trendMapRef.current[deviceId] || EMPTY_TREND;
            trendMapRef.current[deviceId] = {
                patient_id: latestLiveTrend.patient_id ?? nextTrend.patient_id ?? null,
                access: mergeSeries(latestLiveTrend.access || [], nextTrend.access),
                filter: mergeSeries(latestLiveTrend.filter || [], nextTrend.filter),
                effluent: mergeSeries(latestLiveTrend.effluent || [], nextTrend.effluent),
                return: mergeSeries(latestLiveTrend.return || [], nextTrend.return),
                tmp: mergeSeries(latestLiveTrend.tmp || [], nextTrend.tmp),
                delta_p: mergeSeries(latestLiveTrend.delta_p || [], nextTrend.delta_p),
                is_loading: false,
            };
            hydratedPatientRef.current[deviceId] = trendMapRef.current[deviceId].patient_id ?? activePatientId;
        } catch (error) {
            console.error(`Failed to load trend history for ${deviceId}:`, error);
            trendMapRef.current[deviceId] = {
                ...(trendMapRef.current[deviceId] || EMPTY_TREND),
                is_loading: false,
            };
        } finally {
            setVersion((v) => v + 1);
        }
    }, []);

    useEffect(() => {
        if (!devices.length) return;

        let hasChanges = false;

        for (const device of devices) {
            const deviceId = device.id;
            const params = device.data?.s_body?.parameters;
            if (!Array.isArray(params) || params.length === 0) continue;

            const existing = trendMapRef.current[deviceId] || { ...EMPTY_TREND };

            const patientIdRaw = device.data?.s_header?.patient_id || device.data?.header?.patient_id;
            const nextPatientId = isClinicalPatientId(patientIdRaw) ? patientIdRaw.trim() : null;

            let baseTrend = existing;
            if (nextPatientId && existing.patient_id && existing.patient_id !== nextPatientId) {
                baseTrend = {
                    ...EMPTY_TREND,
                    patient_id: nextPatientId,
                };
                delete hydratedPatientRef.current[deviceId];
                trendMapRef.current[deviceId] = baseTrend;
                hasChanges = true;
            } else if (nextPatientId && existing.patient_id !== nextPatientId) {
                baseTrend = {
                    ...existing,
                    patient_id: nextPatientId,
                };
                delete hydratedPatientRef.current[deviceId];
            }

            const rawTimestamp = device.data?.s_header?.timestamp || device.data?.meta?.timestamp;
            const ts = parseClinicalDate(rawTimestamp).getTime();
            const lastTs = baseTrend.access[baseTrend.access.length - 1]?._ts;
            if (lastTs === ts) continue;

            const getValue = (id: number) => Number(params.find((param: any) => param.id === id)?.value ?? 0);

            trendMapRef.current[deviceId] = {
                ...baseTrend,
                access: trimPoints([...baseTrend.access, buildPoint(getValue(1), ts)]),
                filter: trimPoints([...baseTrend.filter, buildPoint(getValue(2), ts)]),
                effluent: trimPoints([...baseTrend.effluent, buildPoint(getValue(3), ts)]),
                return: trimPoints([...baseTrend.return, buildPoint(getValue(4), ts)]),
                tmp: trimPoints([...baseTrend.tmp, buildPoint(getValue(6), ts)]),
                delta_p: trimPoints([...baseTrend.delta_p, buildPoint(getValue(7), ts)]),
            };
            hasChanges = true;
        }

        if (hasChanges) {
            setVersion((v) => v + 1);
        }
    }, [devices]);

    const getTrend = useCallback((deviceId: string) => {
        void version;
        return trendMapRef.current[deviceId] || EMPTY_TREND;
    }, [version]);

    const forgetTrend = useCallback((deviceId: string) => {
        delete trendMapRef.current[deviceId];
        setVersion((v) => v + 1);
    }, []);

    const contextValue = useMemo(() => ({ getTrend, loadHistory, forgetTrend }), [getTrend, loadHistory, forgetTrend]);

    return (
        <TrendContext.Provider value={contextValue}>
            {children}
        </TrendContext.Provider>
    );
}

export function useTrend(deviceId: string) {
    const context = useContext(TrendContext);
    if (!context) {
        throw new Error('useTrend must be used within a TrendProvider');
    }

    return {
        ...context.getTrend(deviceId),
        loadHistory: () => context.loadHistory(deviceId),
        forgetTrend: () => context.forgetTrend(deviceId),
    };
}
