'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export type UserRole = 'nurse' | 'doctor' | 'admin';

interface RoleContextType {
    role: UserRole;
    setRole: (role: UserRole) => void;
    doctorPin: string;
    adminPin: string;
    setPins: (doctorPin: string, adminPin: string) => void;
    isNurse: boolean;
    isDoctor: boolean;
    isAdmin: boolean;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export function RoleProvider({ children }: { children: React.ReactNode }) {
    const [role, setRoleState] = useState<UserRole>('nurse');
    const [doctorPin, setDoctorPin] = useState<string>('1234');
    const [adminPin, setAdminPin] = useState<string>('9999');

    useEffect(() => {
        const saved = localStorage.getItem('user_role') as UserRole;
        if (saved && ['nurse', 'doctor', 'admin'].includes(saved)) {
            setRoleState(saved);
        }

        const savedDoctorPin = localStorage.getItem('doctor_pin');
        if (savedDoctorPin) setDoctorPin(savedDoctorPin);

        const savedAdminPin = localStorage.getItem('admin_pin');
        if (savedAdminPin) setAdminPin(savedAdminPin);
    }, []);

    const setRole = (r: UserRole) => {
        setRoleState(r);
        localStorage.setItem('user_role', r);
    };

    const setPins = (dPin: string, aPin: string) => {
        setDoctorPin(dPin);
        setAdminPin(aPin);
        localStorage.setItem('doctor_pin', dPin);
        localStorage.setItem('admin_pin', aPin);
    };

    return (
        <RoleContext.Provider value={{
            role,
            setRole,
            doctorPin,
            adminPin,
            setPins,
            isNurse: role === 'nurse',
            isDoctor: role === 'doctor',
            isAdmin: role === 'admin',
        }}>
            {children}
        </RoleContext.Provider>
    );
}

export function useRole() {
    const context = useContext(RoleContext);
    if (context === undefined) {
        throw new Error('useRole must be used within a RoleProvider');
    }
    return context;
}
