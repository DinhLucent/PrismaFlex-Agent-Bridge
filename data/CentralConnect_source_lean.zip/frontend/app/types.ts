export type ParameterConfig = {
  id: string; // The key used in our map, e.g., 'body_17'
  name: string;
  source: 'header' | 'body';
  key: string | number; // The key in the JSON data
  unit?: string;
  format?: 'datetime' | 'duration' | 'number' | 'string';
  group?: 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G';
  precision?: number; // Number of decimal places
  decimalSeparator?: ',' | '.'; // Custom decimal separator
  scale?: number; // Scaling factor (e.g., 0.01 for 2 decimal places in integer data)
  trackChanges?: boolean; // Whether to show previous value when changed
  mapping?: Record<string | number, string>; // Custom label mapping for enums
};

export type DeviceStatus = 'RUNNING' | 'STOPPED' | 'ALARM' | 'UNKNOWN' | 'OFFLINE';

export type MockDevice = {
  id: string;
  name: string;
  ip: string;
  status: DeviceStatus;
  lastUpdate: string;
  packetNum: number;
  data: any; // Raw JSON payload
  active_alarms?: {
    id: number;
    title: string;
    description: string;
    severity: string;
    category: 'ALARM' | 'MALFUNCTION' | 'WARNING' | 'CAUTION' | 'ADVISORY';
    state: 'PRESENT' | 'OVERRIDDEN';
  }[];
};

export const CRRT_SECTIONS = {
  A: { id: 'A', title: 'Start Info' },
  B: { id: 'B', title: 'Prescription' },
  C: { id: 'C', title: 'Anticoagulation' },
  D: { id: 'D', title: 'Pressures' },
};

export interface QualityStatus {
  quality: 'LIVE' | 'DELAYED' | 'UNKNOWN';
  latency_sec: number;
  server_time: string;
}

export interface WebSocketMessage {
  type: 'TELEMETRY_UPDATE' | 'CONNECTION_STATUS' | 'ERROR' | 'HEARTBEAT';
  quality_status: QualityStatus;
  payload: any;
}

export interface DeviceData extends MockDevice {
  quality?: QualityStatus;
}
