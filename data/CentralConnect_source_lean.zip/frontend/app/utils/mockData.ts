import { MockDevice } from '../types';

// Mock data generator for testing UI without backend
const generateTrendData = (base: number, variance: number, count: number) => {
    return Array.from({ length: count }).map((_, i) => ({
        time: new Date(Date.now() - (count - i) * 10000).toISOString(),
        value: base + (Math.random() - 0.5) * variance,
    }));
};

const SAMPLE_JSON_BODY = {
    total_records: 172,
    parameters: [
        { id: 1, value: -40 },  // Access
        { id: 4, value: 129 },  // Return
        { id: 2, value: 235 },  // Filter
        { id: 3, value: 127 },  // Effluent
        { id: 6, value: 61 },   // TMP
        { id: 17, value: 200 }, // Qb
        { id: 22, value: 100 }, // PBP
        { id: 21, value: 1550 },// Qd
        { id: 19, value: 600 }, // Replacement Post
        { id: 18, value: 0 },   // Replacement Pre
        { id: 24, value: 250 }, // UF Rate
        { id: 26, value: 70 },  // Weight
    ]
};

export const MOCK_DEVICES: MockDevice[] = [];

export const MOCK_HISTORY_DATA = {
    'PF_001': {
        access: generateTrendData(-40, 10, 20),
        return: generateTrendData(120, 15, 20),
        filter: generateTrendData(230, 20, 20),
        effluent: generateTrendData(100, 10, 20),
    }
};
