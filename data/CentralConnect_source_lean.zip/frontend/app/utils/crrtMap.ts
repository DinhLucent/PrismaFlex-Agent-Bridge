import { ParameterConfig } from '../types';

export const CRRT_PARAMETER_MAP: Record<string, ParameterConfig> = {
    // A. Start Info / Administrative
    header_patient_id: { id: 'header_patient_id', name: 'param_patient_id', source: 'header', key: 'patient_id', group: 'A' },
    header_machine_id: { id: 'header_machine_id', name: 'param_machine_id', source: 'header', key: 'machine_id', group: 'A' },
    header_sw_version: { id: 'header_sw_version', name: 'param_sw_version', source: 'header', key: 'sw_version', group: 'A' },
    header_therapy_status_id: { id: 'header_therapy_status_id', name: 'param_therapy_status', source: 'header', key: 'therapy_status_id', group: 'A' },
    header_timestamp: { id: 'header_timestamp', name: 'param_machine_time', source: 'header', key: 'timestamp', format: 'datetime', group: 'A' },

    body_26: { id: 'body_26', name: 'param_weight', source: 'body', key: 26, unit: 'kg', group: 'A' },
    body_460: { id: 'body_460', name: 'param_hct_port', source: 'body', key: 460, unit: '%', group: 'A', trackChanges: true },
    body_47: { id: 'body_47', name: 'param_hct_pre', source: 'body', key: 47, unit: '%', group: 'A', trackChanges: true },
    body_411: { id: 'body_411', name: 'param_filter_set', source: 'body', key: 411, group: 'A', trackChanges: true },
    body_59: { id: 'body_59', name: 'param_therapy_time', source: 'body', key: 59, format: 'duration', group: 'A' },
    body_415: { id: 'body_415', name: 'param_filter_time', source: 'body', key: 415, format: 'duration', group: 'A' },
    body_461: { id: 'body_461', name: 'param_treatment_time', source: 'body', key: 461, format: 'duration', group: 'A' },
    body_192: { id: 'body_192', name: 'param_max_gain', source: 'body', key: 192, unit: 'ml', group: 'B', trackChanges: true },
    body_196: { id: 'body_196', name: 'param_excess_fluid', source: 'body', key: 196, unit: 'ml', group: 'B', trackChanges: true },

    // B. Prescription / Flow Rates
    header_therapy_type_id: { id: 'header_therapy_type_id', name: 'param_therapy_mode', source: 'header', key: 'therapy_type_id', group: 'B', trackChanges: true },
    body_17: { id: 'body_17', name: 'param_qb', source: 'body', key: 17, unit: 'ml/min', group: 'B', trackChanges: true },
    body_22: { id: 'body_22', name: 'param_pbp', source: 'body', key: 22, unit: 'ml/h', group: 'B', trackChanges: true },
    body_21: { id: 'body_21', name: 'param_qd', source: 'body', key: 21, unit: 'ml/h', group: 'B', trackChanges: true },
    body_19: { id: 'body_19', name: 'param_replacement_post', source: 'body', key: 19, unit: 'ml/h', group: 'B', trackChanges: true },
    body_18: { id: 'body_18', name: 'param_replacement_pre', source: 'body', key: 18, unit: 'ml/h', group: 'B', trackChanges: true },
    body_23: { id: 'body_23', name: 'param_effluent_rate', source: 'body', key: 23, unit: 'ml/h', group: 'B', trackChanges: true },
    body_24: { id: 'body_24', name: 'param_net_uf', source: 'body', key: 24, unit: 'ml/h', group: 'B', trackChanges: true },

    body_414: { id: 'body_414', name: 'param_post_dilution', source: 'body', key: 414, unit: '%', group: 'B', trackChanges: true },
    body_413: { id: 'body_413', name: 'param_pre_dilution', source: 'body', key: 413, unit: '%', group: 'B', trackChanges: true },
    body_410: { id: 'body_410', name: 'param_effluent_dose', source: 'body', key: 410, unit: 'ml/kg/h', group: 'B', trackChanges: false },
    body_412: { id: 'body_412', name: 'param_filtration_fraction', source: 'body', key: 412, unit: '%', group: 'B', trackChanges: false },
    body_44: { id: 'body_44', name: 'param_ufr', source: 'body', key: 44, unit: '%', group: 'B' },
    body_467: { id: 'body_467', name: 'param_prismalung', source: 'body', key: 467, group: 'B', trackChanges: true, mapping: { 0: 'mapping_not_use', 1: 'mapping_use' } },

    // C. Anticoagulation
    body_409: { id: 'body_409', name: 'param_anticoag_type', source: 'body', key: 409, group: 'C', trackChanges: true },
    body_38: { id: 'body_38', name: 'param_heparin_rate', source: 'body', key: 38, unit: 'ml/hr', group: 'C', trackChanges: true, precision: 1, scale: 0.1 },
    body_36: { id: 'body_36', name: 'param_bolus_vol', source: 'body', key: 36, unit: 'ml', group: 'C', trackChanges: true },
    body_37: { id: 'body_37', name: 'param_bolus_interval', source: 'body', key: 37, unit: 'hr', group: 'C', trackChanges: true },
    body_400: { id: 'body_400', name: 'param_citrate_dose', source: 'body', key: 400, unit: 'mmol/L', group: 'C', trackChanges: true },
    body_403: { id: 'body_403', name: 'param_citrate_load', source: 'body', key: 403, unit: 'mmol/h', group: 'C', trackChanges: true },
    body_404: { id: 'body_404', name: 'param_calcium_rate', source: 'body', key: 404, unit: 'ml/h', group: 'C', trackChanges: true },
    body_406: { id: 'body_406', name: 'param_calcium_comp', source: 'body', key: 406, unit: '%', group: 'C', trackChanges: true },

    // D. Pressures
    body_1: { id: 'body_1', name: 'param_access', source: 'body', key: 1, unit: 'mmHg', group: 'D' },
    body_4: { id: 'body_4', name: 'param_return', source: 'body', key: 4, unit: 'mmHg', group: 'D' },
    body_2: { id: 'body_2', name: 'param_filter', source: 'body', key: 2, unit: 'mmHg', group: 'D' },
    body_3: { id: 'body_3', name: 'param_effluent', source: 'body', key: 3, unit: 'mmHg', group: 'D' },
    body_6: { id: 'body_6', name: 'param_tmp', source: 'body', key: 6, unit: 'mmHg', group: 'D' },
    body_7: { id: 'body_7', name: 'param_delta_p', source: 'body', key: 7, unit: 'mmHg', group: 'D' },

    // E. Advanced Anticoagulation (New)
    body_401: { id: 'body_401', name: 'param_citrate_conc', source: 'body', key: 401, unit: 'mmol/l', group: 'E', trackChanges: true },
    body_402: { id: 'body_402', name: 'param_citric_acid_conc', source: 'body', key: 402, unit: 'mmol/l', group: 'E', trackChanges: true },
    body_405: { id: 'body_405', name: 'param_ca_conc', source: 'body', key: 405, unit: 'mmol/l', group: 'E', trackChanges: true },
    body_408: { id: 'body_408', name: 'param_repl_ca_conc', source: 'body', key: 408, unit: 'mmol/l', group: 'E', trackChanges: true },

    // F. Advanced Telemetry / Filters
    body_60: { id: 'body_60', name: 'param_processed_blood', source: 'body', key: 60, unit: 'L', group: 'F', trackChanges: false },
    body_12: { id: 'body_12', name: 'param_blood_pump_speed', source: 'body', key: 12, unit: 'rpm', group: 'F', trackChanges: false, precision: 2, decimalSeparator: ',', scale: 0.01 },

    // G. Advanced Flows
    body_459: { id: 'body_459', name: 'param_24h_net_fluid', source: 'body', key: 459, unit: 'ml', group: 'G', trackChanges: false },
    body_445: { id: 'body_445', name: 'param_24h_effluent', source: 'body', key: 445, unit: 'ml', group: 'G', trackChanges: false },
    body_463: { id: 'body_463', name: 'param_serial_number', source: 'body', key: 463, group: 'A' },
    body_464: { id: 'body_464', name: 'param_monitor_id', source: 'body', key: 464, group: 'A' },
};

export const SECTION_KEYS = {
    A: ['header_patient_id', 'body_26', 'body_460', 'body_47', 'header_machine_id', 'header_sw_version', 'body_411', 'header_therapy_status_id', 'header_timestamp', 'body_59', 'body_415', 'body_461'],
    B: ['header_therapy_type_id', 'body_467', 'body_17', 'body_22', 'body_21', 'body_19', 'body_18', 'body_23', 'body_24', 'body_414', 'body_413', 'body_410', 'body_412'],
    C: ['body_409', 'body_37', 'body_38', 'body_400', 'body_403'], // Base keys for hydration, will be filtered in UI
    D: ['body_1', 'body_4', 'body_2', 'body_3', 'body_6'],
};

export const SECTION_KEYS_ADVANCED = {
    A: ['body_463', 'body_464'],
    B: ['body_459', 'body_445', 'body_60', 'body_12', 'body_414', 'body_413', 'body_410', 'body_412', 'body_44', 'body_192', 'body_196'],
    C: ['body_36', 'body_401', 'body_402', 'body_404', 'body_405', 'body_406', 'body_408'],
};

