export function parseClinicalDate(rawValue: unknown, fallback: Date = new Date()): Date {
    if (rawValue instanceof Date && !Number.isNaN(rawValue.getTime())) {
        return rawValue;
    }

    if (typeof rawValue === 'number' && Number.isFinite(rawValue)) {
        const millis = rawValue > 1_000_000_000_000 ? rawValue : rawValue * 1000;
        const parsed = new Date(millis);
        return Number.isNaN(parsed.getTime()) ? fallback : parsed;
    }

    if (typeof rawValue === 'string') {
        const text = rawValue.trim();
        if (text) {
            const candidates = [
                text.endsWith(' UTC') ? text.replace(/ UTC$/, '').replace(' ', 'T') : text,
                text.replace(' ', 'T'),
                text,
            ];

            for (const candidate of candidates) {
                const parsed = new Date(candidate);
                if (!Number.isNaN(parsed.getTime())) {
                    return parsed;
                }
            }
        }
    }

    return fallback;
}

export function toClinicalTimestampMs(rawValue: unknown, fallbackMs: number = Date.now()): number {
    return parseClinicalDate(rawValue, new Date(fallbackMs)).getTime();
}

const FUTURE_SKEW_TOLERANCE_MS = 2 * 60 * 1000;
const LEGACY_UTC_SHIFT_MS = 7 * 60 * 60 * 1000;

export function normalizeRecentEventTimestampMs(
    rawValue: unknown,
    fallbackMs: number = Date.now()
): number {
    const parsedMs = toClinicalTimestampMs(rawValue, fallbackMs);

    // Legacy decoded packets can be stored 7 hours ahead because local
    // clinical wall-clock was mislabeled as UTC upstream. If an event lands
    // in the future, shift it back once and keep the corrected value only
    // when it falls back into a sane recent window.
    if (parsedMs > fallbackMs + FUTURE_SKEW_TOLERANCE_MS) {
        const shiftedMs = parsedMs - LEGACY_UTC_SHIFT_MS;
        if (shiftedMs <= fallbackMs + FUTURE_SKEW_TOLERANCE_MS) {
            return shiftedMs;
        }
    }

    return parsedMs;
}
