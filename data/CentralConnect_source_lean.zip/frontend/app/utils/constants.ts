export const THERAPY_STATUS_MAP: Record<number, string> = {
    0: "IDLE",
    1: "CUSTOM",
    2: "PRIME",
    3: "PRIME TEST",
    4: "WAITING",
    5: "RUNNING",
    6: "CHANGE BAGS",
    7: "STOPPED",
    8: "END",
    9: "RETURN",
    10: "RECIRC",
    11: "RECIRC PRIME",
    12: "RECIRC TEST",
    13: "RECIRC WAIT",
    14: "CALIBRATION",
    15: "SW LOADING"
};

export const THERAPY_TYPE_MAP: Record<number, string> = {
    1: "CVVH",
    2: "CVVHD",
    3: "CVVHDF",
    4: "SCUF",
    5: "TPE"
};

export const THERAPY_STATUS_COLORS: Record<number, string> = {
    0: "bg-slate-500",      // IDLE
    1: "bg-indigo-500",     // CUSTOM
    2: "bg-blue-500",       // PRIME
    3: "bg-blue-600",       // PRIME TEST
    4: "bg-amber-400",      // WAITING
    5: "bg-emerald-500",    // RUNNING
    6: "bg-rose-500",       // CHANGE BAGS
    7: "bg-rose-600",       // STOPPED
    8: "bg-slate-600",      // END
    9: "bg-indigo-400",     // RETURN
    10: "bg-cyan-500",      // RECIRC
    11: "bg-cyan-600",      // RECIRC PRIME
    12: "bg-cyan-700",      // RECIRC TEST
    13: "bg-cyan-400",      // RECIRC WAIT
    14: "bg-orange-500",     // CALIBRATION
    15: "bg-purple-500"      // SW LOADING
};
