import type { Metadata } from 'next';
import { Inter, JetBrains_Mono } from 'next/font/google';
import '../globals.css';
import './landing.css';

const fontMain = Inter({ subsets: ['latin', 'vietnamese'] });
const jetbrainsMono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono' });

export const metadata: Metadata = {
    title: 'ICU-B CONNECT | Advanced CRRT Monitoring System',
    description: 'Next-generation real-time monitoring platform for PrismaFlex Continuous Renal Replacement Therapy machines. Built for Cho Ray Hospital ICU Zone B.',
};

export default function LandingLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <html lang="en" className="dark" suppressHydrationWarning>
            <body className={`${fontMain.className} ${jetbrainsMono.variable} antialiased`}>
                {children}
            </body>
        </html>
    );
}
