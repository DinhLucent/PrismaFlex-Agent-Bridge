'use client';

import React from 'react';
import Link from 'next/link';
import { motion, useInView } from 'framer-motion';
import {
    Activity, Bell, BookOpen, BarChart3, ClipboardCheck, Wifi, WifiOff,
    Zap, Server, Monitor, Database, Cpu, ArrowRight, Heart, Droplets, Globe,
    CheckCircle, Lock, PlusCircle
} from 'lucide-react';

/* ═══════════════════════════════════════════════════════════════
   MINI VISUALIZATIONS FOR FEATURES
   ═══════════════════════════════════════════════════════════════ */
function MiniSparkline({ color }: { color: string }) {
    return (
        <div className="relative flex items-end gap-1 h-8 w-16 group">
            <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-slate-500/10 to-transparent blur-xs" />
            {[40, 70, 45, 90, 65, 80, 50].map((h, i) => (
                <motion.div
                    key={i}
                    className="w-full rounded-t-[1px] relative overflow-hidden"
                    style={{ backgroundColor: color }}
                    initial={{ height: 0 }}
                    animate={{ height: `${h}%` }}
                    transition={{
                        duration: 1.5,
                        repeat: Infinity,
                        repeatType: 'reverse',
                        delay: i * 0.1,
                        ease: 'easeInOut'
                    }}
                >
                    <motion.div
                        className="absolute inset-0 bg-white/30"
                        animate={{ y: ['-100%', '100%'] }}
                        transition={{ duration: 2, repeat: Infinity, ease: 'linear', delay: i * 0.2 }}
                    />
                </motion.div>
            ))}
        </div>
    );
}

function MiniDevice() {
    return (
        <div className="w-24 h-16 bg-slate-950 rounded-lg border border-teal-500/30 p-2 overflow-hidden flex flex-col gap-1.5 shadow-2xl relative">
            <div className="absolute inset-0 bg-gradient-to-br from-teal-500/5 to-transparent pointer-events-none" />
            <div className="flex justify-between items-center px-0.5 relative z-10">
                <div className="flex gap-1">
                    <div className="w-1.5 h-1.5 bg-teal-500/80 rounded-full animate-pulse shadow-[0_0_4px_#14b8a6]" />
                    <div className="w-6 h-1 bg-teal-500/40 rounded-full mt-0.5" />
                </div>
                <div className="text-[5px] font-black font-mono text-teal-400/60 uppercase tracking-tighter">WS_SYNC</div>
            </div>
            <div className="grid grid-cols-2 gap-1.5 relative z-10">
                <div className="h-4 bg-white/5 rounded-xs flex items-center justify-center p-0.5">
                    <div className="w-full h-0.5 bg-emerald-500/20 rounded-full overflow-hidden">
                        <motion.div className="h-full bg-emerald-400/60" animate={{ width: ['20%', '90%', '20%'] }} transition={{ duration: 3, repeat: Infinity }} />
                    </div>
                </div>
                <div className="h-4 bg-white/5 rounded-xs flex items-center justify-center p-0.5">
                    <div className="w-full h-0.5 bg-teal-500/20 rounded-full overflow-hidden">
                        <motion.div className="h-full bg-teal-400/60" animate={{ width: ['80%', '10%', '80%'] }} transition={{ duration: 3, repeat: Infinity }} />
                    </div>
                </div>
            </div>
            <div className="w-full h-3 bg-teal-500/10 rounded-sm flex items-center px-1 overflow-hidden relative border border-teal-500/10">
                <motion.div
                    className="absolute left-0 top-0 bottom-0 bg-teal-400/10"
                    animate={{ x: ['-100%', '300%'] }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                    style={{ width: '40%' }}
                />
                <motion.div
                    className="h-0.5 bg-teal-400/80 rounded-full relative z-10 shadow-[0_0_4px_#2dd4bf]"
                    animate={{ width: ['30%', '85%', '30%'] }}
                    transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                />
            </div>
        </div>
    );
}

function AlarmPulse() {
    return (
        <div className="relative w-14 h-14 flex items-center justify-center group">
            <motion.div
                className="absolute inset-0 rounded-full bg-red-500/10 border border-red-500/30"
                animate={{ scale: [1, 1.4, 1], opacity: [0.6, 0.2, 0.6] }}
                transition={{ duration: 2, repeat: Infinity }}
            />
            <motion.div
                className="absolute inset-2 rounded-full border border-orange-500/20"
                animate={{ scale: [1, 1.2, 1], rotate: [0, 5, -5, 0] }}
                transition={{ duration: 0.5, repeat: Infinity }}
            />
            <motion.div
                animate={{
                    rotate: [0, -12, 12, -12, 12, 0],
                    scale: [1, 1.15, 1]
                }}
                transition={{ duration: 0.8, repeat: Infinity, repeatDelay: 1.5, ease: "easeInOut" }}
            >
                <Bell className="w-7 h-7 text-red-500 drop-shadow-[0_0_8px_rgba(239,68,68,0.6)]" />
            </motion.div>
        </div>
    );
}

function MiniJournal() {
    return (
        <div className="w-24 h-16 bg-slate-900 rounded-lg border border-indigo-500/30 p-2 overflow-hidden flex flex-col gap-1.5 font-mono text-[5px] relative">
            <div className="absolute inset-x-0 top-0 h-4 bg-gradient-to-b from-slate-900 to-transparent z-10 pointer-events-none" />
            <div className="absolute inset-x-0 bottom-0 h-4 bg-gradient-to-t from-slate-900 to-transparent z-10 pointer-events-none" />
            <div className="flex justify-between border-b border-indigo-500/20 pb-1 mb-1 relative z-20">
                <span className="text-indigo-400 font-bold uppercase tracking-tighter">Clinical Log</span>
                <div className="w-1 h-1 bg-emerald-500 rounded-full animate-pulse" />
            </div>
            <motion.div
                className="space-y-2 relative z-0"
                animate={{ y: [0, -40] }}
                transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
            >
                {[...Array(8)].map((_, i) => (
                    <div key={i} className="flex gap-1.5 items-center opacity-40">
                        <span className="text-white/40">10:4{i}</span>
                        <div className={`h-[1px] rounded-full ${i % 3 === 0 ? 'bg-indigo-400 w-12' : i % 2 === 0 ? 'bg-emerald-400 w-8' : 'bg-slate-500 w-10'}`} />
                    </div>
                ))}
            </motion.div>
        </div>
    );
}

function MiniWorkflow() {
    return (
        <div className="relative w-24 h-18 group">
            <div className="w-20 h-14 bg-slate-900 rounded border border-indigo-500/30 p-2 mx-auto mt-2 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-indigo-400/40 to-transparent" />
                <div className="w-full h-1 bg-indigo-500/20 rounded-full mb-1.5" />
                <div className="w-2/3 h-[1px] bg-indigo-500/10 rounded-full mb-3" />
                <div className="space-y-1">
                    <div className="w-full h-[1px] bg-slate-700" />
                    <div className="w-5/6 h-[1px] bg-slate-700" />
                </div>
            </div>
            <motion.div
                className="absolute top-0 right-0 w-10 h-10 border border-emerald-500/40 rounded-full flex items-center justify-center bg-slate-950 shadow-[0_0_15px_rgba(16,185,129,0.3)] z-20"
                initial={{ scale: 0, opacity: 0, rotate: -45 }}
                animate={{ scale: [0, 1.3, 1], opacity: 1, rotate: 12 }}
                transition={{ duration: 0.7, repeat: Infinity, repeatDelay: 3, ease: 'backOut' }}
            >
                <CheckCircle className="w-6 h-6 text-emerald-400" />
            </motion.div>
            <motion.div
                className="absolute bottom-4 left-8 z-10"
                initial={{ opacity: 0, scaleX: 0 }}
                animate={{ opacity: [0, 1, 0, 0], scaleX: [0, 1, 1, 0], x: [0, 5, 10, 10] }}
                transition={{ duration: 3.7, repeat: Infinity, ease: "easeInOut" }}
            >
                <div className="w-10 h-[2px] bg-emerald-500/60 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.4)]" />
            </motion.div>
        </div>
    );
}

/* ═══════════════════════════════════════════════════════════════
   MAGNETIC BUTTON WRAPPER
   ═══════════════════════════════════════════════════════════════ */
function MagneticButton({ children, className = '', range = 0.4 }: { children: React.ReactNode; className?: string; range?: number }) {
    const ref = React.useRef<HTMLDivElement>(null);
    const [position, setPosition] = React.useState({ x: 0, y: 0 });

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!ref.current) return;
        const { clientX, clientY } = e;
        const { left, top, width, height } = ref.current.getBoundingClientRect();
        const x = clientX - (left + width / 2);
        const y = clientY - (top + height / 2);
        setPosition({ x: x * range, y: y * range });
    };

    const handleMouseLeave = () => setPosition({ x: 0, y: 0 });

    return (
        <motion.div
            ref={ref}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            animate={{ x: position.x, y: position.y }}
            transition={{ type: 'spring', stiffness: 150, damping: 15, mass: 0.1 }}
            className={className}
        >
            {children}
        </motion.div>
    );
}

/* ═══════════════════════════════════════════════════════════════
   CUSTOM CURSOR
   ═══════════════════════════════════════════════════════════════ */
function CustomCursor() {
    const [pos, setPos] = React.useState({ x: 0, y: 0 });
    const [isHovering, setIsHovering] = React.useState(false);

    React.useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            setPos({ x: e.clientX, y: e.clientY });
            const target = e.target as HTMLElement;
            setIsHovering(window.getComputedStyle(target).cursor === 'pointer' || target.tagName === 'A' || target.tagName === 'BUTTON');
        };
        window.addEventListener('mousemove', handleMouseMove);
        return () => window.removeEventListener('mousemove', handleMouseMove);
    }, []);

    return (
        <>
            <div
                className="cursor-spotlight hidden lg:block"
                style={{ left: pos.x, top: pos.y }}
            />
            <motion.div
                className="fixed top-0 left-0 w-4 h-4 rounded-full border border-teal-400 pointer-events-none z-[9999] hidden lg:block mix-blend-difference"
                animate={{
                    x: pos.x - 8,
                    y: pos.y - 8,
                    scale: isHovering ? 2.5 : 1,
                    backgroundColor: isHovering ? 'rgba(45, 212, 191, 0.2)' : 'rgba(45, 212, 191, 0)'
                }}
                transition={{ type: 'spring', stiffness: 500, damping: 28, mass: 0.5 }}
            />
            <motion.div
                className="fixed top-0 left-0 w-1.5 h-1.5 bg-teal-400 rounded-full pointer-events-none z-[9999] hidden lg:block"
                animate={{ x: pos.x - 3, y: pos.y - 3 }}
                transition={{ type: 'spring', stiffness: 1000, damping: 28, mass: 0.1 }}
            />
        </>
    );
}

/* ═══════════════════════════════════════════════════════════════
   SECTION WRAPPER — Scroll-triggered reveal
   ═══════════════════════════════════════════════════════════════ */
function Section({ children, className = '', delay = 0 }: {
    children: React.ReactNode; className?: string; delay?: number;
}) {
    const ref = React.useRef(null);
    const isInView = useInView(ref, { once: true, margin: '-80px' });
    return (
        <motion.section
            ref={ref}
            initial={{ opacity: 0, y: 60 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] }}
            className={className}
        >
            {children}
        </motion.section>
    );
}

/* ═══════════════════════════════════════════════════════════════
   ANIMATED COUNTER
   ═══════════════════════════════════════════════════════════════ */
function Counter({ target, suffix = '', duration = 2 }: {
    target: number; suffix?: string; duration?: number;
}) {
    const ref = React.useRef(null);
    const isInView = useInView(ref, { once: true });
    const [count, setCount] = React.useState(0);

    React.useEffect(() => {
        if (!isInView) return;
        let start = 0;
        const step = target / (duration * 60);
        const timer = setInterval(() => {
            start += step;
            if (start >= target) { setCount(target); clearInterval(timer); }
            else setCount(Math.floor(start));
        }, 1000 / 60);
        return () => clearInterval(timer);
    }, [isInView, target, duration]);

    return <span ref={ref}>{count}{suffix}</span>;
}

/* ═══════════════════════════════════════════════════════════════
   FEATURES DATA
   ═══════════════════════════════════════════════════════════════ */
const features = [
    {
        icon: Activity,
        title: 'Theo dõi Thời gian thực',
        desc: 'Giám sát tức thì toàn bộ máy PrismaFlex. Tiết kiệm thời gian ghi chép hồ sơ giấy và sai sót do nhập liệu thủ công.',
        color: '#2dd4bf',
        visual: <MiniDevice />
    },
    {
        icon: Bell,
        title: 'Cảnh báo Lâm sàng Đa cấp độ',
        desc: 'Hệ thống cảnh báo 4 cấp độ thông minh — giúp nhận diện sớm các nguy cơ đe dọa tính mạng ngay khi có biến động.',
        color: '#ef4444',
        visual: <AlarmPulse />
    },
    {
        icon: BookOpen,
        title: 'Nhật ký Điều trị Điện tử',
        desc: 'Tự động hóa 100% việc lưu trữ diễn biến ca lọc. Hỗ trợ phác đồ Heparin & Citrate với hồ sơ bệnh án kỹ thuật số.',
        color: '#818cf8',
        visual: <MiniJournal />
    },
    {
        icon: BarChart3,
        title: 'Biểu đồ Huyết động học',
        desc: 'Trực quan hóa đa chiều các chỉ số áp lực. Giúp phát hiện sớm biến chứng qua phân tích xu hướng áp lực chuyên sâu.',
        color: '#f59e0b',
        visual: <MiniSparkline color="#f59e0b" />
    },
    {
        icon: ClipboardCheck,
        title: 'Quy trình Phê duyệt Bác sĩ',
        desc: 'Chuẩn hóa y lệnh và quy trình ký duyệt điện tử. Tăng tính minh bạch và trách nhiệm giải trình trong mỗi ca lọc.',
        color: '#6366f1',
        visual: <MiniWorkflow />
    },
    {
        icon: WifiOff,
        title: 'Phát hiện Mất kết nối',
        desc: 'Tự động cảnh báo khi telemetry bị gián đoạn. Đảm bảo an toàn dữ liệu và tính liên tục trong giám sát bệnh nhân.',
        color: '#64748b',
        visual: <div className="relative w-16 h-12 flex items-center justify-center">
            <Wifi className="w-10 h-10 text-slate-500/40" />
            <motion.div
                className="absolute inset-0 bg-slate-950/40 backdrop-blur-[1px] flex items-center justify-center rounded border border-red-500/20"
                animate={{ opacity: [1, 0.4, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
            >
                <div className="w-10 h-0.5 bg-red-500/60 shadow-[0_0_8px_rgba(239,68,68,0.5)] rotate-45" />
            </motion.div>
        </div>
    },
];

/* ═══════════════════════════════════════════════════════════════
   PIPELINE DATA
   ═══════════════════════════════════════════════════════════════ */
const pipeline = [
    { icon: Cpu, label: 'PrismaFlex', sub: 'Kết nối Vật lý' },
    { icon: Server, label: 'Bộ thu thập', sub: 'Xử lý Tín hiệu' },
    {
        icon: Database,
        label: 'Mirth Connect',
        sub: 'Nền tảng Tích hợp',
        branched: true,
        futureIn: [
            { icon: Activity, label: 'Thiết bị Ngoại vi khác', sub: 'Sắp ra mắt' },
            { icon: PlusCircle, label: 'Nguồn Dữ liệu Ngoài', sub: 'Sẵn sàng' }
        ]
    },
    { icon: Zap, label: 'FastAPI', sub: 'Xử lý Thời gian thực' },
    { icon: Monitor, label: 'Next.js', sub: 'Giao diện Giám sát' },
];

const techStack = [
    { label: 'Python', delay: 0 },
    { label: 'FastAPI', delay: 0.4 },
    { label: 'Next.js 16', delay: 0.8 },
    { label: 'TypeScript', delay: 1.2 },
    { label: 'WebSocket', delay: 1.6 },
    { label: 'Framer Motion', delay: 2.0 },
    { label: 'SQLite', delay: 2.4 },
    { label: 'Mirth Connect', delay: 2.8 },
    { label: 'Tailwind v4', delay: 3.2 },
    { label: 'Recharts', delay: 3.6 },
];

/* ═══════════════════════════════════════════════════════════════
   LANDING PAGE
   ═══════════════════════════════════════════════════════════════ */
export default function LandingPage() {
    const [mousePos, setMousePos] = React.useState({ x: 0, y: 0 });
    const [scrollProgress, setScrollProgress] = React.useState(0);

    React.useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            setMousePos({
                x: (e.clientX / window.innerWidth - 0.5) * 40,
                y: (e.clientY / window.innerHeight - 0.5) * 40
            });
        };
        const handleScroll = () => {
            const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
            setScrollProgress(window.scrollY / totalHeight);
        };
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('scroll', handleScroll);
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    return (
        <div className="landing-root min-h-screen relative selection:bg-teal-500/30">
            <CustomCursor />
            {/* Scroll Progress Bar */}
            <motion.div
                className="fixed top-0 left-0 right-0 h-1 bg-teal-400 origin-left z-[10000]"
                style={{ scaleX: scrollProgress }}
            />
            {/* Noise */}
            <div className="noise-overlay" />

            {/* ─── HERO ─────────────────────────────────────────── */}
            <header className="relative min-h-screen flex flex-col items-center justify-center px-6 overflow-hidden grid-bg">
                {/* Floating orbs with mouse parallax */}
                <motion.div
                    animate={{ x: mousePos.x, y: mousePos.y }}
                    className="hero-orb hero-orb-teal"
                />
                <motion.div
                    animate={{ x: -mousePos.x, y: -mousePos.y }}
                    className="hero-orb hero-orb-cyan"
                />
                <motion.div
                    animate={{ x: mousePos.x * 0.5, y: -mousePos.y * 1.5 }}
                    className="hero-orb hero-orb-indigo"
                />

                {/* PrismaFlex Subtle Watermark - Schematic Aesthetic */}
                <div
                    className="absolute inset-0 z-0 pointer-events-none overflow-hidden"
                >
                    <motion.div
                        initial={{ opacity: 0, scale: 1.1 }}
                        animate={{ opacity: 0.15, scale: 1 }}
                        transition={{ duration: 2, ease: "easeOut" }}
                        className="absolute inset-0 mix-blend-plus-lighter"
                        style={{
                            backgroundImage: 'url(/prismaflex_bg.png)',
                            backgroundPosition: '50% 50%',
                            backgroundRepeat: 'no-repeat',
                            backgroundSize: '70% auto',
                            filter: 'contrast(1.2) brightness(1.2)',
                            maskImage: 'radial-gradient(circle at center, black 20%, transparent 70%)',
                            WebkitMaskImage: 'radial-gradient(circle at center, black 20%, transparent 70%)',
                        }}
                    />
                </div>

                {/* Pulse rings */}
                <div className="pulse-ring w-[300px] h-[300px] absolute" style={{ animationDelay: '0s' }} />
                <div className="pulse-ring w-[500px] h-[500px] absolute" style={{ animationDelay: '1s' }} />
                <div className="pulse-ring w-[700px] h-[700px] absolute" style={{ animationDelay: '2s' }} />

                {/* Heartbeat SVG */}
                <svg className="absolute w-full bottom-0 left-0 opacity-20" height="80" viewBox="0 0 1440 80" preserveAspectRatio="none">
                    <path
                        className="heartbeat-line"
                        d="M0,40 L200,40 L220,40 L240,10 L260,70 L280,20 L300,60 L320,40 L520,40 L540,40 L560,10 L580,70 L600,20 L620,60 L640,40 L840,40 L860,40 L880,10 L900,70 L920,20 L940,60 L960,40 L1140,40 L1160,40 L1180,10 L1200,70 L1220,20 L1240,60 L1260,40 L1440,40"
                        stroke="#2dd4bf"
                        strokeWidth="2"
                        fill="none"
                    />
                </svg>

                <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
                    className="relative z-10 text-center max-w-4xl mx-auto"
                >
                    {/* Icon cluster */}
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3, duration: 0.8 }}
                        className="flex items-center justify-center gap-3 mb-8"
                    >
                        <div className="relative">
                            <div className="absolute inset-0 bg-teal-400/20 rounded-2xl blur-xl" />
                            <div className="relative bg-slate-900/80 backdrop-blur-sm p-4 rounded-2xl border border-teal-500/20">
                                <div className="flex gap-1">
                                    <Droplets className="w-8 h-8 text-red-500 -mr-3 drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]" />
                                    <Droplets className="w-8 h-8 text-sky-400 drop-shadow-[0_0_10px_rgba(56,189,248,0.6)]" />
                                </div>
                            </div>
                            <div className="absolute -bottom-1.5 -right-1.5 w-5 h-5 bg-emerald-400 rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/50">
                                <Heart className="w-3 h-3 text-slate-900" />
                            </div>
                        </div>
                    </motion.div>

                    {/* Title */}
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.5, duration: 1 }}
                    >
                        <p className="text-[10px] font-black uppercase tracking-[0.35em] text-teal-400/60 mb-6">
                            Nền tảng Giám sát CRRT Tiên tiến
                        </p>
                        <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-[0.9]">
                            ICU-B{' '}
                            <span className="shimmer-text">CONNECT</span>
                        </h1>
                        <p className="mt-6 text-lg md:text-xl text-slate-400 max-w-2xl mx-auto leading-relaxed font-light">
                            Hệ thống giám sát thời gian thực thế hệ mới<br />
                            cho máy lọc máu liên tục <span className="text-teal-400 font-semibold">PrismaFlex</span>
                        </p>
                        <p className="mt-2 text-xs text-slate-600 font-bold uppercase tracking-widest">
                            Bệnh viện Chợ Rẫy — Khu ICU B
                        </p>
                        <div className="mt-6 flex items-center justify-center gap-2 text-[10px] font-bold text-teal-400/50 uppercase tracking-[0.1em] bg-white/5 border border-white/5 py-1.5 px-4 rounded-full w-fit mx-auto backdrop-blur-sm">
                            <Lock className="w-3 h-3" />
                            Triển khai Nội bộ · Mã hóa Dữ liệu
                        </div>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 1, duration: 0.8 }}
                        className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-4"
                    >
                        <MagneticButton>
                            <Link href="/" className="cta-btn">
                                Vào Trung tâm Điều hành
                                <ArrowRight className="w-5 h-5" />
                            </Link>
                        </MagneticButton>
                        <a href="#features" className="text-sm text-slate-500 hover:text-teal-400 transition-colors font-semibold uppercase tracking-widest px-4 py-2">
                            Khám phá Tính năng ↓
                        </a>
                    </motion.div>
                </motion.div>

                {/* Scroll indicator */}
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 1.5, duration: 1 }}
                    className="absolute bottom-8 left-1/2 -translate-x-1/2"
                >
                    <motion.div
                        animate={{ y: [0, 8, 0] }}
                        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                        className="w-6 h-10 border-2 border-slate-700 rounded-full flex items-start justify-center p-1.5"
                    >
                        <div className="w-1.5 h-3 bg-teal-400 rounded-full" />
                    </motion.div>
                </motion.div>
            </header>

            {/* ─── STATS ────────────────────────────────────────── */}
            <Section className="py-24 px-6">
                <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-1">
                    <div className="stat-block">
                        <div className="stat-value"><Counter target={3} /></div>
                        <div className="stat-label">Thiết bị Giám sát</div>
                        <p className="mt-2 text-[9px] font-bold text-slate-500 uppercase tracking-widest">Mở rộng 20-30+</p>
                    </div>
                    <div className="stat-block">
                        <div className="stat-value">&lt;<Counter target={3} suffix="s" /></div>
                        <div className="stat-label">Độ trễ Dữ liệu</div>
                    </div>
                    <div className="stat-block">
                        <div className="stat-value"><Counter target={99} suffix="%" duration={1.5} /></div>
                        <div className="stat-label">Thời gian Hoạt động</div>
                    </div>
                    <div className="stat-block">
                        <div className="stat-value"><Counter target={24} duration={1.5} />/7</div>
                        <div className="stat-label">Giám sát Liên tục</div>
                    </div>
                </div>
            </Section>

            <div className="section-divider" />

            {/* ─── FEATURES ─────────────────────────────────────── */}
            <section id="features" className="py-28 px-6">
                <Section className="text-center mb-16">
                    <p className="text-[10px] font-black uppercase tracking-[0.3em] text-teal-400/50 mb-4">Tính năng Cốt lõi</p>
                    <h2 className="text-4xl md:text-5xl font-black tracking-tight">
                        Trí tuệ<br />
                        <span className="shimmer-text">Cấp Lâm sàng</span>
                    </h2>
                    <p className="mt-4 text-slate-500 max-w-lg mx-auto text-sm leading-relaxed">
                        Mỗi tính năng được thiết kế đặc biệt cho môi trường ICU — nơi mỗi giây đều quan trọng.
                    </p>
                </Section>

                <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {features.map((f, i) => (
                        <Section key={f.title} delay={i * 0.1}>
                            <motion.div
                                whileHover={{ y: -10 }}
                                className="feature-card px-8 py-7 h-full group"
                            >
                                <div className="flex justify-between items-start mb-4">
                                    <div className="relative">
                                        <div
                                            className="absolute inset-0 rounded-xl blur-lg opacity-30"
                                            style={{ backgroundColor: f.color }}
                                        />
                                        <div className="relative p-3 bg-slate-900/80 rounded-xl border border-white/5">
                                            <f.icon className="w-6 h-6" style={{ color: f.color }} />
                                        </div>
                                    </div>

                                    {/* World-Class Visual Presentation */}
                                    <MagneticButton range={0.2}>
                                        <div className="hidden sm:block opacity-40 group-hover:opacity-100 transition-all duration-500 scale-90 group-hover:scale-100">
                                            {f.visual}
                                        </div>
                                    </MagneticButton>
                                </div>

                                <h3 className="text-xl font-bold tracking-tight mb-2 group-hover:text-teal-400 transition-colors">{f.title}</h3>
                                <p className="text-sm text-slate-400 leading-relaxed font-light">{f.desc}</p>

                                <div className="mt-6 flex items-center justify-between">
                                    <div className="flex-1" />
                                    <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-teal-400 translate-x-4 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all" />
                                </div>
                            </motion.div>
                        </Section>
                    ))}
                </div>
            </section >

            <div className="section-divider" />

            {/* ─── ARCHITECTURE ─────────────────────────────────── */}
            <Section className="pt-48 pb-48 px-6">
                <div className="text-center mb-64">
                    <p className="text-[10px] font-black uppercase tracking-[0.3em] text-teal-400/50 mb-4">Kiến trúc Hệ thống</p>
                    <h2 className="text-4xl md:text-5xl font-black tracking-tight">
                        Luồng Dữ liệu
                    </h2>
                    <p className="mt-4 text-slate-500 max-w-2xl mx-auto text-sm leading-relaxed">
                        Dòng chảy dữ liệu từ máy PrismaFlex đến giao diện theo dõi — ổn định, nhanh, an toàn.
                    </p>
                </div>

                {/* Desktop pipeline */}
                <div className="max-w-[1440px] mx-auto hidden md:block">
                    <div className="flex items-center justify-center gap-8 lg:gap-10">
                        {pipeline.map((node, i) => (
                            <React.Fragment key={node.label}>
                                <motion.div
                                    initial={{ opacity: 0, y: 20 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: i * 0.15, duration: 0.6 }}
                                    className="pipeline-node relative"
                                >
                                    <node.icon className="w-10 h-10 text-teal-400 mx-auto mb-3" />
                                    <p className="text-base font-bold tracking-tight">{node.label}</p>
                                    <p className="text-xs text-slate-500 mt-1.5 font-bold uppercase tracking-widest">{node.sub}</p>

                                    {/* Architectural Expansion (Hub & Spoke) */}
                                    {node.branched && (
                                        <>
                                            {/* Future Inputs (Upward) */}
                                            {node.futureIn && (
                                                <div className="absolute bottom-full left-1/2 -translate-x-1/2 -translate-y-12 w-64">
                                                    <div className="flex flex-col items-center gap-2.5 mb-2.5">
                                                        {node.futureIn.map((fin, idx) => (
                                                            <motion.div
                                                                key={fin.label}
                                                                initial={{ opacity: 0, x: idx % 2 === 0 ? -10 : 10 }}
                                                                whileInView={{ opacity: 1, x: 0 }}
                                                                transition={{ delay: 0.8 + (idx * 0.2) }}
                                                                className="bg-slate-900/60 border border-slate-700/50 rounded-lg p-3 backdrop-blur-sm flex items-center gap-3 w-full group/future"
                                                            >
                                                                <fin.icon className="w-4 h-4 text-slate-500 group-hover/future:text-teal-500/50 transition-colors" />
                                                                <div className="text-left">
                                                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">{fin.label}</p>
                                                                    <p className="text-[8px] text-slate-500 font-bold uppercase">{fin.sub}</p>
                                                                </div>
                                                            </motion.div>
                                                        ))}
                                                    </div>
                                                    <div className="h-10 w-px bg-gradient-to-t from-teal-500/30 to-transparent mx-auto relative">
                                                        <div className="pipeline-particle-vertical reverse" />
                                                    </div>
                                                </div>
                                            )}

                                            {/* External Outputs (Downward) */}
                                            <div className="absolute top-full left-1/2 -translate-x-1/2 translate-y-12 w-64">
                                                <div className="h-10 w-px bg-gradient-to-b from-teal-500/40 to-slate-500/20 mx-auto relative">
                                                    <div className="pipeline-particle-vertical" />
                                                </div>
                                                <motion.div
                                                    initial={{ opacity: 0, scale: 0.9, y: 10 }}
                                                    whileInView={{ opacity: 1, scale: 1, y: 0 }}
                                                    className="bg-slate-900/90 border border-slate-700/50 rounded-xl p-4 backdrop-blur-md shadow-xl shadow-black/40 ring-1 ring-white/5"
                                                >
                                                    <Globe className="w-6 h-6 text-slate-500 mx-auto mb-2.5" />
                                                    <p className="text-[11px] font-black text-slate-400 uppercase tracking-tighter">Hệ thống bên ngoài</p>
                                                    <div className="flex justify-center gap-2 mt-2">
                                                        <span className="text-[9px] bg-slate-500/10 border border-slate-500/30 px-2 py-0.5 rounded text-slate-400 font-bold">EMR</span>
                                                        <span className="text-[9px] bg-slate-500/10 border border-slate-500/30 px-2 py-0.5 rounded text-slate-400 font-bold">HIS</span>
                                                        <span className="text-[9px] bg-slate-500/10 border border-slate-500/30 px-2 py-0.5 rounded text-slate-400 font-bold">LIS</span>
                                                    </div>
                                                </motion.div>
                                            </div>
                                        </>
                                    )}
                                </motion.div>
                                {i < pipeline.length - 1 && (
                                    <div className="w-32 lg:w-48">
                                        <div className="flow-track">
                                            <div className="flow-particle" style={{ animationDelay: `${i * 0.6}s` }} />
                                        </div>
                                    </div>
                                )}
                            </React.Fragment>
                        ))}
                    </div>
                </div>

                {/* Mobile pipeline (stacked) */}
                <div className="max-w-sm mx-auto md:hidden space-y-4">
                    {pipeline.map((node, i) => (
                        <React.Fragment key={node.label}>
                            <div className="relative">
                                <motion.div
                                    initial={{ opacity: 0, x: -20 }}
                                    whileInView={{ opacity: 1, x: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: i * 0.1, duration: 0.5 }}
                                    className="pipeline-node flex items-center gap-4 text-left relative z-10"
                                >
                                    <node.icon className="w-6 h-6 text-teal-400 shrink-0" />
                                    <div className="flex-1">
                                        <div className="flex items-center justify-between">
                                            <p className="text-sm font-bold">{node.label}</p>
                                            {node.branched && <Globe className="w-3.5 h-3.5 text-slate-500 animate-pulse" />}
                                        </div>
                                        <p className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">{node.sub}</p>
                                    </div>
                                </motion.div>

                                {/* Mobile Branch (Horizontal) */}
                                {node.branched && (
                                    <div className="absolute top-1/2 left-full -translate-y-1/2 ml-4 w-32 hidden sm:block">
                                        <div className="flex items-center">
                                            <div className="w-6 h-px bg-slate-700" />
                                            <div className="bg-slate-900/90 border border-slate-700 rounded-lg p-2 backdrop-blur-md whitespace-nowrap">
                                                <p className="text-[8px] font-black text-slate-500 uppercase tracking-tighter">EMR / HIS / LIS</p>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                            {i < pipeline.length - 1 && (
                                <div className="w-px h-6 bg-gradient-to-b from-teal-500/20 to-transparent mx-auto" />
                            )}
                        </React.Fragment>
                    ))}
                </div>
            </Section>

            <div className="section-divider" />

            {/* ─── TECH STACK ───────────────────────────────────── */}
            <Section className="py-28 px-6">
                <div className="text-center mb-16">
                    <p className="text-xs font-black uppercase tracking-[0.3em] text-teal-400/60 mb-4">Công nghệ Nền tảng</p>
                    <h2 className="text-4xl md:text-5xl font-black tracking-tight">
                        Hệ sinh thái Kỹ thuật
                    </h2>
                </div>

                <div className="max-w-3xl mx-auto flex flex-wrap justify-center gap-4">
                    {techStack.map((tech, i) => (
                        <motion.div
                            key={tech.label}
                            initial={{ opacity: 0, scale: 0.8 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{ delay: i * 0.06, duration: 0.5 }}
                            className="tech-badge"
                            style={{ animationDelay: `${tech.delay}s` }}
                        >
                            {tech.label}
                        </motion.div>
                    ))}
                </div>
            </Section>

            <div className="section-divider" />

            {/* ─── FINAL CTA ────────────────────────────────────── */}
            <Section className="py-32 px-6 text-center relative overflow-hidden">
                {/* Background glow */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-[600px] h-[600px] bg-teal-500/5 rounded-full blur-[120px]" />
                </div>

                <div className="relative z-10">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                    >
                        <Droplets className="w-12 h-12 text-teal-400/40 mx-auto mb-8" />
                        <h2 className="text-4xl md:text-6xl font-black tracking-tighter mb-4">
                            Sẵn sàng <span className="shimmer-text">Kết nối</span>?
                        </h2>
                        <p className="text-slate-500 max-w-md mx-auto text-sm mb-10 leading-relaxed">
                            Truy cập hệ thống giám sát trung tâm và theo dõi tất cả máy lọc máu trong khu vực ICU của bạn.
                        </p>
                        <MagneticButton className="flex justify-center">
                            <Link href="/" className="cta-btn text-lg">
                                Vào Trung tâm Điều hành
                                <ArrowRight className="w-6 h-6" />
                            </Link>
                        </MagneticButton>
                    </motion.div>
                </div>
            </Section>

            {/* ─── FOOTER ───────────────────────────────────────── */}
            <footer className="border-t border-white/5 py-8 px-6">
                <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                        <div className="flex gap-0.5">
                            <Droplets className="w-4 h-4 text-red-500/60" />
                            <Droplets className="w-4 h-4 text-sky-400/60 -ml-2" />
                        </div>
                        <span className="text-xs font-black tracking-tighter text-slate-400">
                            ICU-B <span className="text-teal-500">CONNECT</span>
                        </span>
                    </div>
                    <p className="text-[10px] text-slate-600 font-semibold uppercase tracking-widest">
                        © 2026 ICU Khu B — Bệnh viện Chợ Rẫy. Lưu hành nội bộ.
                    </p>
                    <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                        <span className="text-[10px] text-emerald-500/60 font-bold uppercase tracking-widest">Hệ thống Trực tuyến</span>
                    </div>
                </div>
            </footer>

        </div>
    );
}
