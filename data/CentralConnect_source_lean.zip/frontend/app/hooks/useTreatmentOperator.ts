'use client';

import { useState, useCallback, useEffect } from 'react';

/**
 * Operator Check-In Hook (TREATMENT_OPERATOR_CHECKIN_SPEC)
 * 
 * Manages operator identity per treatment editing session.
 * - Ask once per treatment mutation session
 * - Store in sessionStorage (not localStorage — shared hospital machines)
 * - Clear on treatment switch or role change
 * - Provide modal trigger + header injection
 */

interface OperatorContext {
    name: string;
    role: string;
    captured_at: string;
}

const STORAGE_PREFIX = 'treatment_operator::';

export function useTreatmentOperator(treatmentId: string | null, currentRole: string) {
    const [operator, setOperator] = useState<OperatorContext | null>(null);
    const [showModal, setShowModal] = useState(false);
    const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);

    // Load from sessionStorage on mount or treatment/role change
    useEffect(() => {
        if (!treatmentId) { setOperator(null); return; }
        const key = STORAGE_PREFIX + treatmentId;
        try {
            const stored = sessionStorage.getItem(key);
            if (stored) {
                const ctx: OperatorContext = JSON.parse(stored);
                // Clear if role changed (spec: switching role requires re-entry)
                if (ctx.role !== currentRole) {
                    sessionStorage.removeItem(key);
                    setOperator(null);
                } else {
                    setOperator(ctx);
                }
            } else {
                setOperator(null);
            }
        } catch { setOperator(null); }
    }, [treatmentId, currentRole]);

    const saveOperator = useCallback((name: string) => {
        if (!treatmentId) return;
        const ctx: OperatorContext = {
            name: name.trim().replace(/\s+/g, ' '),
            role: currentRole,
            captured_at: new Date().toISOString(),
        };
        sessionStorage.setItem(STORAGE_PREFIX + treatmentId, JSON.stringify(ctx));
        setOperator(ctx);
    }, [treatmentId, currentRole]);

    const clearOperator = useCallback(() => {
        if (treatmentId) sessionStorage.removeItem(STORAGE_PREFIX + treatmentId);
        setOperator(null);
    }, [treatmentId]);

    /**
     * Gate any mutation action through operator check-in.
     * If operator exists, runs action immediately.
     * If not, opens modal and queues the action for after confirm.
     * targetId: optional ID to use for check-in if it differs from the hook's current treatmentId.
     */
    const ensureOperator = useCallback((action: () => void, targetId?: string) => {
        // If we have a targetId, check sessionStorage for it specifically
        let activeOp = operator;
        const effectiveId = targetId || treatmentId;

        if (targetId && targetId !== treatmentId) {
            try {
                const stored = sessionStorage.getItem(STORAGE_PREFIX + targetId);
                if (stored) {
                    const ctx: OperatorContext = JSON.parse(stored);
                    if (ctx.role === currentRole) activeOp = ctx;
                }
            } catch {}
        }

        if (activeOp) {
            action();
        } else {
            setPendingAction(() => action);
            setShowModal(true);
            // If targetId was provided, we might need a way to 'switch' context on confirm
            if (targetId) (window as any)._pendingOperatorTargetId = targetId;
        }
    }, [operator, treatmentId, currentRole]);

    const confirmOperator = useCallback((name: string) => {
        const targetId = (window as any)._pendingOperatorTargetId || treatmentId;
        if (targetId) {
            const ctx: OperatorContext = {
                name: name.trim().replace(/\s+/g, ' '),
                role: currentRole,
                captured_at: new Date().toISOString(),
            };
            sessionStorage.setItem(STORAGE_PREFIX + targetId, JSON.stringify(ctx));
            
            // Fix: If we're in list mode (treatmentId=null), we still want to set the current 
            // operator state so subsequent reactive renders (like modals) see it.
            if (targetId === treatmentId || !treatmentId) {
                setOperator(ctx);
            }
        }
        delete (window as any)._pendingOperatorTargetId;
        
        setShowModal(false);
        if (pendingAction) {
            pendingAction();
            setPendingAction(null);
        }
    }, [treatmentId, currentRole, pendingAction]);

    const cancelModal = useCallback(() => {
        setShowModal(false);
        setPendingAction(null);
    }, []);

    return {
        operator,
        showModal,
        ensureOperator,
        confirmOperator,
        cancelModal,
        clearOperator,
        changeOperator: () => {
            clearOperator();
            setShowModal(true);
        },
    };
}

/**
 * Fetch wrapper that injects X-Operator-Name and X-User-Role headers.
 */
export async function fetchWithOperator(
    url: string,
    options: RequestInit,
    operatorName: string,
    role: string
): Promise<Response> {
    const headers = new Headers(options.headers || {});
    headers.set('X-Operator-Name', encodeURIComponent(operatorName));
    headers.set('X-User-Role', role);
    if (!headers.has('Content-Type') && options.body) {
        headers.set('Content-Type', 'application/json');
    }
    return fetch(url, { ...options, headers });
}
