'use client';

import { useState, useEffect, useRef } from 'react';
import { DeviceData, WebSocketMessage, MockDevice } from '../types';
import { MOCK_DEVICES } from '../utils/mockData';

export function useWebSocket() {
    // Store devices in a map for easy updates by ID
    const [deviceMap, setDeviceMap] = useState<Record<string, DeviceData>>({});
    const [isConnected, setIsConnected] = useState(false);
    const wsRef = useRef<WebSocket | null>(null);

    useEffect(() => {
        // 1. Initialize with Mock Data so the UI isn't empty
        const initialMap: Record<string, DeviceData> = {};
        MOCK_DEVICES.forEach(d => {
            initialMap[d.id] = { ...d };
        });
        setDeviceMap(initialMap);

        // 2. Connect to WebSocket
        const connect = () => {
            // In dev, sometimes we might not have backend running, handle gracefully
            try {
                const ws = new WebSocket('ws://localhost:8000/ws');
                wsRef.current = ws;

                ws.onopen = () => {
                    console.log('✅ WebSocket Connected');
                    setIsConnected(true);
                };

                ws.onmessage = (event) => {
                    try {
                        const message = JSON.parse(event.data);

                        if (message.type === 'TELEMETRY_UPDATE') {
                            const { payload, quality_status } = message;
                            const deviceId = payload.meta?.device_id;

                            if (!deviceId) return;

                            setDeviceMap(prev => {
                                const existing = prev[deviceId] || {
                                    id: deviceId,
                                    name: `New Device ${deviceId}`,
                                    ip: '---',
                                    status: 'UNKNOWN',
                                    lastUpdate: new Date().toISOString(),
                                    packetNum: 0,
                                    data: {}
                                };

                                // Map payload backend structure to frontend structure
                                // Backend sends: { meta, header, body }
                                // Frontend expects: { s_header, s_body } inside data

                                const statusId = payload.header?.therapy_status_id;
                                let newStatus: any = 'UNKNOWN';
                                if (statusId === 4 || statusId === 5) newStatus = 'RUNNING';
                                else if (statusId === 9) newStatus = 'ALARM';
                                else if (statusId === 7 || statusId === 8) newStatus = 'STOPPED';
                                else newStatus = 'UNKNOWN';

                                return {
                                    ...prev,
                                    [deviceId]: {
                                        ...existing,
                                        status: newStatus,
                                        lastUpdate: quality_status?.server_time || new Date().toISOString(),
                                        packetNum: payload.meta?.packet_num || existing.packetNum,
                                        data: {
                                            s_header: payload.header,
                                            s_body: payload.body
                                        },
                                        quality: quality_status
                                    }
                                };
                            });
                        }
                    } catch (e) {
                        console.error('WS Parse Error', e);
                    }
                };

                ws.onclose = () => {
                    console.log('❌ WebSocket Disconnected');
                    setIsConnected(false);
                    // Attempt reconnect
                    setTimeout(connect, 3000);
                };

                ws.onerror = (err) => {
                    console.error('WS Error', err);
                    ws.close();
                };

            } catch (e) {
                console.error('WS Connection Failed', e);
            }
        };

        connect();

        return () => {
            wsRef.current?.close();
        };
    }, []);

    return {
        devices: Object.values(deviceMap),
        isConnected,
        getDevice: (id: string) => deviceMap[id]
    };
}
