'use client';

import React from 'react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

interface StatCardProps {
    title: string;
    value: string | number;
    unit?: string;
    icon?: React.ReactNode;
    trend?: 'up' | 'down' | 'stable';
    className?: string;
}

export function StatCard({ title, value, unit, icon, trend, className }: StatCardProps) {
    return (
        <div
            style={{ boxShadow: 'var(--shadow-sm)' }}
            className={twMerge(
                "bg-[var(--card)] rounded-lg p-3 border border-[var(--border)] flex items-center justify-between transition-colors duration-300",
                className
            )}
        >
            <div className="flex items-center gap-3">
                {icon && <div className="text-slate-400 dark:text-slate-500">{icon}</div>}
                <div>
                    <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide">{title}</p>
                    <div className="flex items-baseline gap-1">
                        <span className="text-xl font-bold text-slate-800 dark:text-slate-100">{value}</span>
                        {unit && <span className="text-xs text-slate-400 dark:text-slate-500 font-medium">{unit}</span>}
                    </div>
                </div>
            </div>
        </div>
    );
}
