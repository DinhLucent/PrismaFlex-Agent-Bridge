'use client';

import React, { useMemo, useRef, useState, useEffect } from 'react';
import {
    AreaChart, Area, XAxis, YAxis, Tooltip,
    CartesianGrid, ReferenceLine, ReferenceArea
} from 'recharts';
import { clsx } from 'clsx';
import { useTheme } from '../providers/ThemeProvider';

interface DualPressureChartProps {
    tmpData: { time: string; value: number; _ts: number }[];
    deltaPData: { time: string; value: number; _ts: number }[];
    tmpLimit?: number;
    dpLimit?: number;
}

// ─── Clinical Color Palette ──────────────────────────────────
const TMP_COLOR = '#a855f7';      // Purple
const DELTA_P_COLOR = '#f59e0b';  // Amber/Orange
const DANGER_COLOR = '#ef4444';   // Red
const DEFAULT_TMP_DANGER = 300;   // mmHg
const DEFAULT_DP_DANGER = 150;    // mmHg (elevated for CRRT)
const CLAMP_MIN = -500;
const CLAMP_MAX = 800;
const MIN_CHART_WIDTH = 80;
const MIN_CHART_HEIGHT = 40;

/**
 * Safe dimension hook — replaces Recharts ResponsiveContainer.
 * Uses ResizeObserver for reliable measurements immune to CSS zoom issues.
 */
function useSafeDimensions(ref: React.RefObject<HTMLDivElement | null>) {
    const [dims, setDims] = useState({ width: 0, height: 0 });

    useEffect(() => {
        const el = ref.current;
        if (!el) return;

        const measure = () => {
            const w = el.clientWidth;
            const h = el.clientHeight;
            setDims(prev => {
                if (prev.width === w && prev.height === h) return prev;
                return { width: Math.max(0, w), height: Math.max(0, h) };
            });
        };

        measure();

        const ro = new ResizeObserver(measure);
        ro.observe(el);
        return () => ro.disconnect();
    }, [ref]);

    return dims;
}

// ─── Custom Dual Tooltip ─────────────────────────────────────
const DualTooltip = ({ active, payload, label, isDark, tmpDanger, dpDanger }: any) => {
    if (!active || !payload?.length) return null;
    const tmpLimit = tmpDanger ?? DEFAULT_TMP_DANGER;
    const dpLimit = dpDanger ?? DEFAULT_DP_DANGER;

    return (
        <div className={clsx(
            "px-3 py-2 rounded-lg border shadow-xl backdrop-blur-md",
            isDark ? "bg-[#1e293b]/90 border-slate-700" : "bg-white/90 border-slate-200"
        )}>
            <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5 border-b border-slate-100 dark:border-slate-700 pb-1">
                {typeof label === 'number' ? new Date(label).toLocaleTimeString('en-GB', { hour12: false }) : label}
            </div>
            {payload.map((entry: any, index: number) => (
                <div key={index} className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                    <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 w-8 capitalize">{entry.name}</span>
                    <span className={clsx(
                        "text-lg font-black font-[family-name:var(--font-mono)]",
                        (entry.name === 'TMP' && entry.value >= tmpLimit) || (entry.name === 'ΔP' && entry.value >= dpLimit)
                            ? "text-red-500"
                            : isDark ? "text-slate-100" : "text-slate-900"
                    )}>
                        {entry.value}
                    </span>
                    <span className="text-[10px] text-slate-400 font-bold">mmHg</span>
                </div>
            ))}
        </div>
    );
};

const DualPressureChartComponent = ({ tmpData, deltaPData, tmpLimit, dpLimit }: DualPressureChartProps) => {
    const { theme } = useTheme();
    const isDark = theme === 'dark';
    const TMP_DANGER = tmpLimit ?? DEFAULT_TMP_DANGER;
    const DELTA_P_DANGER = dpLimit ?? DEFAULT_DP_DANGER;

    // Safe dimension refs for each chart sub-container
    const tmpContainerRef = useRef<HTMLDivElement>(null);
    const dpContainerRef = useRef<HTMLDivElement>(null);
    const tmpDims = useSafeDimensions(tmpContainerRef);
    const dpDims = useSafeDimensions(dpContainerRef);

    // ─── Merge TMP + ΔP data on shared time axis ─────────────
    const mergedData = useMemo(() => {
        const timeMap = new Map<number, { _ts: number; time: string; tmp: number | null; delta_p: number | null }>();

        tmpData.forEach(d => {
            const existing = timeMap.get(d._ts) || { _ts: d._ts, time: d.time, tmp: null, delta_p: null };
            existing.tmp = d.value;
            timeMap.set(d._ts, existing);
        });

        deltaPData.forEach(d => {
            const existing = timeMap.get(d._ts) || { _ts: d._ts, time: d.time, tmp: null, delta_p: null };
            existing.delta_p = d.value;
            timeMap.set(d._ts, existing);
        });

        return Array.from(timeMap.values())
            .sort((a, b) => a._ts - b._ts)
            .slice(-1000);
    }, [tmpData, deltaPData]);

    // ─── Smoothing (3-point moving average) ──────────────────
    const smoothedData = useMemo(() => {
        if (mergedData.length <= 2) return mergedData;
        return mergedData.map((point, i) => {
            if (i < 1 || i > mergedData.length - 2) return point;
            const prev = mergedData[i - 1];
            const next = mergedData[i + 1];
            return {
                ...point,
                tmp: point.tmp !== null && prev.tmp !== null && next.tmp !== null
                    ? Math.round((prev.tmp + point.tmp + next.tmp) / 3) : point.tmp,
                delta_p: point.delta_p !== null && prev.delta_p !== null && next.delta_p !== null
                    ? Math.round((prev.delta_p + point.delta_p + next.delta_p) / 3) : point.delta_p,
            };
        });
    }, [mergedData]);

    // ─── Adaptive Y-Axis Scaling ─────────────────────────────
    const { tmpStats, dpStats, xDomain } = useMemo(() => {
        const calcStats = (data: (number | null)[], dangerLine: number, minRange: number = 20) => {
            // Step 1: Extract and clamp real data values
            const vals = data
                .filter((v): v is number => v !== null)
                .map(v => Math.max(CLAMP_MIN, Math.min(CLAMP_MAX, v)));

            if (vals.length === 0) return { mean: 0, yMin: -10, yMax: 10, thresholdVisible: false };

            // Step 2: Data-first statistics
            const mean = Math.round(vals.reduce((s, v) => s + v, 0) / vals.length);
            const stdDev = vals.length > 1
                ? Math.sqrt(vals.reduce((s, v) => s + (v - mean) ** 2, 0) / vals.length)
                : 10;
            const span = Math.max(minRange, 2.5 * stdDev);

            const rawDataMin = Math.min(...vals);
            const rawDataMax = Math.max(...vals);

            // Step 3: Padding — proportional to data spread, minimum 10
            const padding = Math.max(10, span * 0.15);

            let yMin = Math.floor(Math.min(rawDataMin - padding, mean - span));
            let yMax = Math.ceil(Math.max(rawDataMax + padding, mean + span));

            // Step 4: Conditionally include threshold ONLY if it's near the data cluster
            // "Near" = threshold is within 2× padding distance of the data upper bound
            const thresholdProximity = dangerLine - rawDataMax;
            const inclusionThreshold = padding * 2;
            let thresholdVisible = false;

            if (thresholdProximity <= inclusionThreshold) {
                // Threshold is near data — gently extend domain to show it
                yMax = Math.ceil(Math.max(yMax, dangerLine + padding));
                thresholdVisible = true;
            } else {
                // Threshold is far from data — do NOT stretch the chart
                // Just keep data-driven domain; threshold line will be outside visible area
                thresholdVisible = false;
            }

            return { mean, yMin, yMax, thresholdVisible };
        };

        let xMin: number | 'auto' = 'auto';
        let xMax: number | 'auto' = 'auto';

        if (smoothedData.length > 0) {
            const latestTs = smoothedData[smoothedData.length - 1]._ts;
            const WINDOW_MS = 30 * 60 * 1000;
            xMin = Math.max(smoothedData[0]._ts, latestTs - WINDOW_MS);
            xMax = latestTs;
        }

        return {
            tmpStats: calcStats(smoothedData.map(d => d.tmp), TMP_DANGER, 30),
            dpStats: calcStats(smoothedData.map(d => d.delta_p), DELTA_P_DANGER, 15),
            xDomain: [xMin, xMax]
        };
    }, [smoothedData, TMP_DANGER, DELTA_P_DANGER]);

    const latestTmp = smoothedData.length > 0 ? smoothedData[smoothedData.length - 1].tmp : null;
    const latestDp = smoothedData.length > 0 ? smoothedData[smoothedData.length - 1].delta_p : null;

    // ─── Calculate Gradient Offsets (Percentage from bottom) ──
    const getOffset = (danger: number, stats: { yMin: number; yMax: number }) => {
        const span = stats.yMax - stats.yMin;
        if (span <= 0) return 0;
        return Math.max(0, Math.min(100, ((danger - stats.yMin) / span) * 100));
    };

    const tmpOffset = getOffset(TMP_DANGER, tmpStats);
    const dpOffset = getOffset(DELTA_P_DANGER, dpStats);

    const canRenderTmp = tmpDims.width >= MIN_CHART_WIDTH && tmpDims.height >= MIN_CHART_HEIGHT;
    const canRenderDp = dpDims.width >= MIN_CHART_WIDTH && dpDims.height >= MIN_CHART_HEIGHT;

    return (
        <div className="h-full w-full flex flex-col gap-2">
            {/* TMP Chart Segment */}
            <div className="flex-1 bg-white dark:bg-[#0f172a] rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm relative overflow-hidden group">
                <div className="absolute top-3 left-4 z-10 flex items-center gap-2">
                    <div className="w-1.5 h-3 bg-purple-500 rounded-full" />
                    <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">TMP</span>
                    <div className="flex items-center gap-2">
                        <span className={clsx(
                            "text-sm font-black font-[family-name:var(--font-mono)]",
                            latestTmp !== null && latestTmp >= TMP_DANGER ? "text-red-500 animate-pulse" : "text-purple-500 dark:text-purple-400"
                        )}>
                            {latestTmp ?? '--'} <span className="text-[9px] opacity-60">mmHg</span>
                        </span>
                        {/* Mean Indicator */}
                        <div className="bg-white/40 dark:bg-slate-900/40 backdrop-blur-[2px] px-1.5 py-0.5 rounded border border-slate-200/30 dark:border-slate-700/30">
                            <span className="text-[8px] font-bold font-[family-name:var(--font-mono)] text-purple-600 dark:text-purple-400 opacity-60">
                                μ={tmpStats.mean}
                            </span>
                        </div>
                    </div>
                </div>

                <div ref={tmpContainerRef} className="h-full w-full pt-10 pb-4">
                    {canRenderTmp && (
                        <AreaChart data={smoothedData} syncId="hemoTrends" width={tmpDims.width} height={tmpDims.height} margin={{ top: 0, right: 30, left: 10, bottom: 0 }}>
                            <defs>
                                <linearGradient id="colorTmp" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="0%" stopColor={TMP_COLOR} stopOpacity={0.4} />
                                    <stop offset="25%" stopColor={TMP_COLOR} stopOpacity={0.1} />
                                    <stop offset="60%" stopColor={TMP_COLOR} stopOpacity={0} />
                                </linearGradient>
                                <linearGradient id="dangerGradientTmp" x1="0" y1="1" x2="0" y2="0">
                                    <stop offset={`${tmpOffset}%`} stopColor="transparent" stopOpacity={0} />
                                    <stop offset={`${tmpOffset + 10}%`} stopColor={DANGER_COLOR} stopOpacity={0.1} />
                                    <stop offset="100%" stopColor={DANGER_COLOR} stopOpacity={0.3} />
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDark ? "#1e293b" : "#f1f5f9"} />
                            <XAxis
                                dataKey="_ts"
                                hide
                                type="number"
                                domain={xDomain as any}
                            />
                            <YAxis
                                orientation="left"
                                width={35}
                                axisLine={false}
                                tickLine={false}
                                tick={{ fontSize: 9, fill: '#64748b', fontWeight: 600 }}
                                domain={[tmpStats.yMin, tmpStats.yMax]}
                                allowDecimals={false}
                            />
                            <Tooltip content={<DualTooltip isDark={isDark} tmpDanger={TMP_DANGER} dpDanger={DELTA_P_DANGER} />} />
                            {/* Danger Zone — red shading above threshold (only when threshold is in view) */}
                            {tmpStats.thresholdVisible && (
                                <ReferenceArea
                                    y1={tmpStats.yMin}
                                    y2={tmpStats.yMax}
                                    fill="url(#dangerGradientTmp)"
                                    ifOverflow="hidden"
                                />
                            )}
                            {tmpStats.thresholdVisible && (
                                <ReferenceLine y={TMP_DANGER} stroke={DANGER_COLOR} strokeDasharray="6 4" strokeWidth={1.5} opacity={0.5} />
                            )}
                            <Area
                                type="monotone"
                                dataKey="tmp"
                                name="TMP"
                                stroke={TMP_COLOR}
                                strokeWidth={3}
                                fillOpacity={1}
                                fill="url(#colorTmp)"
                                isAnimationActive={false}
                                activeDot={{ r: 6, strokeWidth: 0, fill: TMP_COLOR }}
                                connectNulls
                                baseValue={tmpStats.yMin}
                            />
                        </AreaChart>
                    )}
                </div>
            </div>

            {/* ΔP Chart Segment */}
            <div className="flex-1 bg-white dark:bg-[#0f172a] rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm relative overflow-hidden group">
                <div className="absolute top-3 left-4 z-10 flex items-center gap-2">
                    <div className="w-1.5 h-3 bg-amber-500 rounded-full" />
                    <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.2em]">ΔP</span>
                    <div className="flex items-center gap-2">
                        <span className={clsx(
                            "text-sm font-black font-[family-name:var(--font-mono)]",
                            latestDp !== null && latestDp >= DELTA_P_DANGER ? "text-red-500 animate-pulse" : "text-amber-500 dark:text-amber-400"
                        )}>
                            {latestDp ?? '--'} <span className="text-[9px] opacity-60">mmHg</span>
                        </span>
                        {/* Mean Indicator */}
                        <div className="bg-white/40 dark:bg-slate-900/40 backdrop-blur-[2px] px-1.5 py-0.5 rounded border border-slate-200/30 dark:border-slate-700/30">
                            <span className="text-[8px] font-bold font-[family-name:var(--font-mono)] text-amber-600 dark:text-amber-400 opacity-60">
                                μ={dpStats.mean}
                            </span>
                        </div>
                    </div>
                </div>

                <div ref={dpContainerRef} className="h-full w-full pt-10 pb-4">
                    {canRenderDp && (
                        <AreaChart data={smoothedData} syncId="hemoTrends" width={dpDims.width} height={dpDims.height} margin={{ top: 0, right: 30, left: 10, bottom: 0 }}>
                            <defs>
                                <linearGradient id="colorDp" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="0%" stopColor={DELTA_P_COLOR} stopOpacity={0.4} />
                                    <stop offset="25%" stopColor={DELTA_P_COLOR} stopOpacity={0.1} />
                                    <stop offset="60%" stopColor={DELTA_P_COLOR} stopOpacity={0} />
                                </linearGradient>
                                <linearGradient id="dangerGradientDp" x1="0" y1="1" x2="0" y2="0">
                                    <stop offset={`${dpOffset}%`} stopColor="transparent" stopOpacity={0} />
                                    <stop offset={`${dpOffset + 10}%`} stopColor={DANGER_COLOR} stopOpacity={0.1} />
                                    <stop offset="100%" stopColor={DANGER_COLOR} stopOpacity={0.3} />
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDark ? "#1e293b" : "#f1f5f9"} />
                            <XAxis
                                dataKey="_ts"
                                type="number"
                                domain={xDomain as any}
                                axisLine={false}
                                tickLine={false}
                                tick={{ fontSize: 9, fill: '#64748b' }}
                                tickFormatter={(ts) => new Date(ts).toLocaleTimeString('en-GB', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                            />
                            <YAxis
                                orientation="left"
                                width={35}
                                axisLine={false}
                                tickLine={false}
                                tick={{ fontSize: 9, fill: '#64748b', fontWeight: 600 }}
                                domain={[dpStats.yMin, dpStats.yMax]}
                                allowDecimals={false}
                            />
                            <Tooltip content={<DualTooltip isDark={isDark} tmpDanger={TMP_DANGER} dpDanger={DELTA_P_DANGER} />} />
                            {/* Danger Zone — red shading above threshold (only when threshold is in view) */}
                            {dpStats.thresholdVisible && (
                                <ReferenceArea
                                    y1={dpStats.yMin}
                                    y2={dpStats.yMax}
                                    fill="url(#dangerGradientDp)"
                                    ifOverflow="hidden"
                                />
                            )}
                            {dpStats.thresholdVisible && (
                                <ReferenceLine y={DELTA_P_DANGER} stroke={DANGER_COLOR} strokeDasharray="6 4" strokeWidth={1.5} opacity={0.5} />
                            )}
                            <Area
                                type="monotone"
                                dataKey="delta_p"
                                name="ΔP"
                                stroke={DELTA_P_COLOR}
                                strokeWidth={3}
                                fillOpacity={1}
                                fill="url(#colorDp)"
                                isAnimationActive={false}
                                activeDot={{ r: 6, strokeWidth: 0, fill: DELTA_P_COLOR }}
                                connectNulls
                                baseValue={dpStats.yMin}
                            />
                        </AreaChart>
                    )}
                </div>
            </div>
        </div>
    );
};

export const DualPressureChart = React.memo(DualPressureChartComponent);
