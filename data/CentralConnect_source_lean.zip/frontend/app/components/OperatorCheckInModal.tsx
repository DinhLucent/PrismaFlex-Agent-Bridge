'use client';

import React, { useState } from 'react';
import { User, X } from 'lucide-react';

/**
 * Operator Check-In Modal (TREATMENT_OPERATOR_CHECKIN_SPEC)
 *
 * Appears on first mutation attempt when no operator is active.
 * Simple free-text name entry for demo mode.
 */
interface OperatorCheckInModalProps {
    open: boolean;
    onConfirm: (name: string) => void;
    onCancel: () => void;
}

export default function OperatorCheckInModal({ open, onConfirm, onCancel }: OperatorCheckInModalProps) {
    const [name, setName] = useState('');
    const [error, setError] = useState('');

    if (!open) return null;

    const handleSubmit = () => {
        const trimmed = name.trim().replace(/\s+/g, ' ');
        if (trimmed.length < 2) {
            setError('Tên phải có ít nhất 2 ký tự.');
            return;
        }
        if (trimmed.length > 60) {
            setError('Tên không được quá 60 ký tự.');
            return;
        }
        setError('');
        onConfirm(trimmed);
        setName('');
    };

    return (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/70 p-4 backdrop-blur-md animate-in fade-in duration-200">
            <div className="w-full max-w-sm overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--card)] shadow-2xl animate-in zoom-in-95 duration-200">
                <div className="border-b border-[var(--border)] bg-teal-500/5 p-8">
                    <div className="mb-4 flex items-center gap-4">
                        <div className="rounded-2xl bg-teal-500/20 p-3">
                            <User className="h-6 w-6 text-teal-400" />
                        </div>
                        <h2 className="text-xl font-black text-[var(--foreground)]">
                            Nhập người thao tác
                        </h2>
                    </div>
                    <p className="text-sm leading-relaxed text-[var(--muted)]">
                        Vui lòng nhập tên điều dưỡng hoặc bác sĩ trước khi chỉnh sửa Journal. Tên này sẽ được lưu để đối chiếu khi cần audit.
                    </p>
                </div>
                <div className="p-6">
                    <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-[var(--muted)]">
                        Người đang thao tác
                    </label>
                    <input
                        autoFocus
                        value={name}
                        onChange={(e) => {
                            setName(e.target.value);
                            setError('');
                        }}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSubmit();
                        }}
                        placeholder="Ví dụ: Điều dưỡng Lan / BS Minh"
                        className="w-full rounded-xl border border-[var(--border)] bg-[var(--background)] px-4 py-3 text-sm text-[var(--foreground)] placeholder:text-[var(--muted)] focus:outline-none focus:ring-2 focus:ring-teal-500/50"
                    />
                    <p className="mt-2 text-xs text-[var(--muted)]">
                        Bạn chỉ cần nhập một lần cho treatment hiện tại. Có thể đổi tên người thao tác ở thanh trên cùng.
                    </p>
                    {error && (
                        <p className="mt-2 text-xs font-bold text-red-400">{error}</p>
                    )}
                </div>
                <div className="flex justify-end gap-3 p-6 pt-0">
                    <button
                        onClick={onCancel}
                        className="rounded-xl border border-[var(--border)] px-5 py-3 text-sm font-bold text-[var(--foreground)] transition-all hover:bg-[var(--background)]"
                    >
                        Hủy
                    </button>
                    <button
                        onClick={handleSubmit}
                        disabled={name.trim().length < 2}
                        className="rounded-xl bg-teal-600 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-teal-500/20 transition-all hover:bg-teal-500 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        Xác nhận
                    </button>
                </div>
            </div>
        </div>
    );
}

/**
 * Small inline badge showing current operator name.
 */
export function OperatorBadge({ name, onClear, onChange }: { name: string; onClear: () => void; onChange: () => void }) {
    return (
        <div className="flex items-center gap-2 rounded-xl border border-teal-500/20 bg-teal-500/10 px-3 py-1.5 text-xs">
            <User className="h-3.5 w-3.5 text-teal-400" />
            <span className="font-bold text-teal-300">{name}</span>
            <button
                onClick={onChange}
                className="ml-1 text-[9px] font-bold uppercase tracking-wider text-teal-400/60 hover:text-teal-400"
            >
                Đổi
            </button>
            <button
                onClick={onClear}
                className="rounded p-0.5 text-red-400/50 transition-colors hover:bg-red-500/20 hover:text-red-400"
            >
                <X className="h-3 w-3" />
            </button>
        </div>
    );
}
