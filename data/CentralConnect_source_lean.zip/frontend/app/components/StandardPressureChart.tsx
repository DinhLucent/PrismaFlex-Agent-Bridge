'use client';

import React, { useMemo, useRef, useState, useEffect } from 'react';
import {
    AreaChart, Area, XAxis, YAxis, Tooltip,
    CartesianGrid, ReferenceLine, Brush
} from 'recharts';
import { clsx } from 'clsx';
import { useTheme } from '../providers/ThemeProvider';

interface StandardPressureChartProps {
    data: { time: string; value: number | null; _ts: number }[];
    color: string;
    name: string;
    unit: string;
    limit?: number;
    windowMode?: '30m' | '2h' | 'full';
    syncId?: string;
    showBrush?: boolean;
    smoothingEnabled?: boolean;
}

const MIN_CHART_WIDTH = 80;
const MIN_CHART_HEIGHT = 60;

function useSafeDimensions(ref: React.RefObject<HTMLDivElement | null>) {
    const [dims, setDims] = useState({ width: 0, height: 0 });

    useEffect(() => {
        const el = ref.current;
        if (!el) return;

        const measure = () => {
            setDims({ width: el.clientWidth, height: el.clientHeight });
        };

        measure();
        const ro = new ResizeObserver(measure);
        ro.observe(el);
        return () => ro.disconnect();
    }, [ref]);

    return dims;
}

const CustomTooltip = ({ active, payload, label, color, name, unit, isDark, limit }: any) => {
    if (!active || !payload?.length) return null;

    const v = payload[0].value;
    const isInvalid = v === null || v === undefined;
    const isDanger = !isInvalid && limit !== undefined && v >= limit;

    return (
        <div className={clsx(
            "px-3 py-2 rounded-lg border shadow-xl backdrop-blur-md transition-colors duration-300",
            isDark ? "bg-[#1e293b]/90 border-slate-700" : "bg-white/90 border-slate-200"
        )}>
            <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5 border-b border-slate-100 dark:border-slate-700 pb-1">
                {typeof label === 'number' ? new Date(label).toLocaleTimeString('en-GB', { hour12: false }) : label}
            </div>
            <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 w-12 uppercase">{name}</span>
                <span className={clsx(
                    "text-lg font-black font-[family-name:var(--font-mono)]",
                    isDanger ? "text-red-500" : isDark ? "text-slate-100" : "text-slate-900"
                )}>
                    {isInvalid ? <span className="text-xs text-slate-400 italic">Sanitized</span> : v}
                </span>
                {!isInvalid && <span className="text-[10px] text-slate-400 font-bold">{unit}</span>}
            </div>
        </div>
    );
};

export function StandardPressureChart({
    data,
    color,
    name,
    unit,
    limit,
    windowMode = '30m',
    syncId = 'commonPressures',
    showBrush = false,
    smoothingEnabled = true,
}: StandardPressureChartProps) {
    const { theme } = useTheme();
    const isDark = theme === 'dark';
    const containerRef = useRef<HTMLDivElement>(null);
    const { width, height } = useSafeDimensions(containerRef);

    const processedData = useMemo(() => {
        let prevValid: number | null = null;
        const sanitized = data.map((pt) => {
            const v = pt.value;
            if (v === null || !Number.isFinite(v) || Math.abs(v) > 5000) {
                return { ...pt, value: null };
            }

            if (prevValid !== null && Math.abs(v - prevValid) > 120) {
                return { ...pt, value: null };
            }

            prevValid = v;
            return { ...pt, value: v };
        });

        if (!smoothingEnabled || sanitized.length <= 2) return sanitized;

        return sanitized.map((pt, i) => {
            if (i < 1 || i > sanitized.length - 2) return pt;
            const p = sanitized[i - 1].value;
            const c = pt.value;
            const n = sanitized[i + 1].value;

            if (p !== null && c !== null && n !== null) {
                return { ...pt, value: Math.round((p + c + n) / 3) };
            }
            return pt;
        });
    }, [data, smoothingEnabled]);

    const { meanValue, yMin, yMax, xDomain, brushIdx } = useMemo(() => {
        const vals = processedData.map((d) => d.value).filter((v): v is number => v !== null);

        if (vals.length === 0) {
            return { meanValue: 0, yMin: -10, yMax: 10, xDomain: ['auto', 'auto'], brushIdx: 0 };
        }

        const mean = Math.round(vals.reduce((s, v) => s + v, 0) / vals.length);
        const dataMin = Math.min(...vals);
        const dataMax = Math.max(...vals);
        const stdDev = vals.length > 1
            ? Math.sqrt(vals.reduce((s, v) => s + (v - mean) ** 2, 0) / vals.length)
            : 5;

        const range = Math.max(20, dataMax - dataMin, 2 * stdDev);
        const pad = Math.max(5, Math.ceil(range * 0.15));
        const yMinFinal = Math.floor(dataMin - pad);
        const yMaxFinal = Math.ceil(dataMax + pad);

        const latestTs = processedData[processedData.length - 1]._ts;
        const firstTs = processedData[0]._ts;
        let xMin = firstTs;

        if (windowMode === '30m') xMin = Math.max(firstTs, latestTs - 30 * 60 * 1000);
        else if (windowMode === '2h') xMin = Math.max(firstTs, latestTs - 2 * 60 * 60 * 1000);

        const bIdx = Math.max(0, processedData.findIndex((d) => d._ts >= xMin));

        return {
            meanValue: mean,
            yMin: yMinFinal,
            yMax: yMaxFinal,
            xDomain: [xMin, latestTs],
            brushIdx: bIdx,
        };
    }, [processedData, windowMode]);

    const latestValue = processedData.length > 0 ? processedData[processedData.length - 1].value : null;

    if (width < MIN_CHART_WIDTH || height < MIN_CHART_HEIGHT) {
        return <div ref={containerRef} className="h-full w-full bg-slate-50 dark:bg-slate-900/20 animate-pulse rounded-lg" />;
    }

    return (
        <div ref={containerRef} className="h-full w-full bg-white dark:bg-[#0f172a] rounded-xl border border-slate-100 dark:border-slate-800 relative overflow-hidden group transition-all duration-300">
            <div className="absolute top-3 left-4 z-10 flex items-center gap-3">
                <div className="w-1.5 h-3 rounded-full" style={{ backgroundColor: color }} />
                <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">{name}</span>
                <div className="h-3 w-[1px] bg-slate-200 dark:bg-slate-800 mx-1" />
                <div className="flex items-center gap-2">
                    <span className={clsx(
                        "text-sm font-black font-[family-name:var(--font-mono)] transition-colors",
                        latestValue !== null && limit !== undefined && latestValue >= limit ? "text-red-500 animate-pulse" : "text-slate-700 dark:text-slate-300"
                    )} style={{ color: (latestValue !== null && limit !== undefined && latestValue >= limit) ? undefined : color }}>
                        {latestValue ?? '--'} <span className="text-[10px] opacity-60 font-bold">{unit}</span>
                    </span>
                    <div className="bg-slate-100/50 dark:bg-slate-900/50 px-1.5 py-0.5 rounded border border-slate-200/30 dark:border-slate-700/30">
                        <span className="text-[8px] font-bold font-[family-name:var(--font-mono)] opacity-60" style={{ color }}>
                            μ={meanValue}
                        </span>
                    </div>
                </div>
            </div>

            <div className="h-full w-full pt-12 pb-2 px-1">
                <AreaChart
                    data={processedData}
                    syncId={syncId}
                    width={width - 8}
                    height={height - 60}
                    margin={{ top: 5, right: 30, left: 10, bottom: showBrush ? 25 : 10 }}
                >
                    <defs>
                        <linearGradient id={`gradient_${name}`} x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor={color} stopOpacity={0.3} />
                            <stop offset="100%" stopColor={color} stopOpacity={0} />
                        </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDark ? "#1e293b" : "#f1f5f9"} />
                    <XAxis
                        dataKey="_ts"
                        type="number"
                        domain={xDomain as any}
                        hide={!showBrush}
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 9, fill: '#64748b' }}
                        tickFormatter={(ts) => new Date(ts).toLocaleTimeString('en-GB', { hour12: false, hour: '2-digit', minute: '2-digit' })}
                    />
                    <YAxis
                        width={35}
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 9, fill: '#64748b', fontWeight: 600 }}
                        domain={[yMin, yMax]}
                        allowDecimals={false}
                    />
                    <Tooltip content={<CustomTooltip color={color} name={name} unit={unit} isDark={isDark} limit={limit} />} />

                    {limit !== undefined && limit >= yMin && limit <= yMax && (
                        <ReferenceLine y={limit} stroke="#ef4444" strokeDasharray="6 4" strokeWidth={1.5} opacity={0.4} />
                    )}

                    <Area
                        type="monotone"
                        dataKey="value"
                        stroke={color}
                        strokeWidth={3}
                        fillOpacity={1}
                        fill={`url(#gradient_${name})`}
                        isAnimationActive={false}
                        activeDot={{ r: 6, strokeWidth: 0, fill: color }}
                        connectNulls={false}
                        baseValue={yMin}
                    />

                    {showBrush && (
                        <Brush
                            dataKey="_ts"
                            height={20}
                            stroke={color}
                            fill={isDark ? '#0f172a' : '#ffffff'}
                            startIndex={brushIdx}
                            tickFormatter={(ts) => new Date(ts).toLocaleTimeString('en-GB', { hour12: false, hour: '2-digit', minute: '2-digit' })}
                        />
                    )}
                </AreaChart>
            </div>
        </div>
    );
}
