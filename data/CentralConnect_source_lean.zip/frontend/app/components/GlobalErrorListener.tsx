'use client';

import { useEffect } from 'react';

export function GlobalErrorListener() {
    useEffect(() => {
        const sendLog = async (error: any, stack: string) => {
            try {
                const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
                await fetch(`${apiUrl}/api/v1/client-errors`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        error: error ? error.toString() : 'Unknown Window Error',
                        stack: stack || 'No stack trace available',
                        url: window.location.href,
                        userAgent: navigator.userAgent
                    }),
                });
            } catch (e) {
                // Ignore silently to avoid infinite loops
            }
        };

        const errorHandler = (event: ErrorEvent) => {
            sendLog(event.error || event.message, event.error?.stack || '');
        };

        const rejectionHandler = (event: PromiseRejectionEvent) => {
            sendLog(event.reason, event.reason?.stack || '');
        };

        window.addEventListener('error', errorHandler);
        window.addEventListener('unhandledrejection', rejectionHandler);

        return () => {
            window.removeEventListener('error', errorHandler);
            window.removeEventListener('unhandledrejection', rejectionHandler);
        };
    }, []);

    return null; // Silent component
}
