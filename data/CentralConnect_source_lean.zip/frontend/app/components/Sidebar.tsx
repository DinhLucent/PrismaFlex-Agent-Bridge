'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Info, X, CheckCircle2, Sun, Moon, BookOpen, History, ClipboardCheck, Shield } from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { useDeviceData } from '../providers/WebSocketProvider';
import { useTheme } from '../providers/ThemeProvider';
import { useLanguage } from '../providers/LanguageProvider';
import { useRole, UserRole } from '../providers/RoleProvider';

const FlagVN = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 20" className="w-3.5 h-2.5 rounded-[1px] shadow-sm">
        <rect width="30" height="20" fill="#da251d" />
        <polygon points="15,4 16.176,8.324 20.755,8.324 17.049,11.026 18.225,15.35 15,12.648 11.775,15.35 12.951,11.026 9.245,8.324 13.824,8.324" fill="#ffff00" />
    </svg>
);

const FlagUK = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 30" className="w-3.5 h-2.5 rounded-[1px] shadow-sm">
        <path d="M0,0 v30 h60 v-30 z" fill="#012169" />
        <path d="M0,0 L60,30 M60,0 L0,30" stroke="#fff" strokeWidth="6" />
        <path d="M0,0 L60,30 M60,0 L0,30" stroke="#C8102E" strokeWidth="4" />
        <path d="M30,0 v30 M0,15 h60" stroke="#fff" strokeWidth="10" />
        <path d="M30,0 v30 M0,15 h60" stroke="#C8102E" strokeWidth="6" />
    </svg>
);

export function Sidebar() {
    const pathname = usePathname();
    const { devices } = useDeviceData();
    const { theme, toggleTheme } = useTheme();
    const [isWhatNewOpen, setIsWhatNewOpen] = React.useState(false);
    const [pendingCount, setPendingCount] = React.useState(0);

    // Check if any device is actively running
    const isAnyRunning = devices.some(d => d.status === 'RUNNING');

    const { language, setLanguage, t } = useLanguage();
    const { role, setRole, isNurse, isDoctor, isAdmin, doctorPin, adminPin, setPins } = useRole();

    // Fetch pending review count for sidebar badge
    React.useEffect(() => {
        const fetchPending = async () => {
            try {
                const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
                const res = await fetch(`${API}/api/v1/treatments/pending-count`);
                if (res.ok) {
                    const data = await res.json();
                    setPendingCount(data.count || 0);
                }
            } catch { /* silent */ }
        };
        fetchPending();
        const interval = setInterval(fetchPending, 15000); // Refresh every 15s
        return () => clearInterval(interval);
    }, []);

    const navItems = [
        {
            label: t('nav_dashboard'),
            href: '/',
            icon: (
                <svg width="20" height="20" fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M18.285 11.25 15.96 4.505a.752.752 0 0 0-1.395-.065L8.84 17.21l-2.055-5.965H2v1.5h3.715L8.04 19.49c.1.29.37.49.675.505h.035a.752.752 0 0 0 .685-.445L15.16 6.785l2.055 5.965H22v-1.5h-3.715Z" fill="currentColor" />
                </svg>
            )
        },
        {
            label: t('nav_treatments'),
            href: '/treatments',
            icon: <BookOpen className="w-5 h-5 text-[var(--sidebar-foreground)] group-hover:text-teal-400" />
        },
        {
            label: t('nav_review'),
            href: '/treatments/review',
            icon: <ClipboardCheck className="w-5 h-5 text-[var(--sidebar-foreground)] group-hover:text-teal-400" />,
            badge: pendingCount > 0 ? pendingCount : undefined,
            hidden: isNurse
        },
        {
            label: t('nav_reference'),
            href: '/reference',
            icon: (
                <svg width="20" height="20" fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path fillRule="evenodd" clipRule="evenodd" d="M12.5 8.25c0 .69.56 1.25 1.25 1.25H20V22H4V2h8.5v6.25Zm2.155 9.15.75-1.3L13.5 15l1.905-1.1-.75-1.3-1.905 1.1v-2.2h-1.5v2.2l-1.905-1.1-.75 1.3L10.5 15l-1.905 1.1.75 1.3 1.905-1.1v2.2h1.5v-2.2l1.905 1.1ZM14 8V2.44L19.56 8H14Z" fill="currentColor" />
                </svg>
            )
        },
        {
            label: t('nav_feedback'),
            href: '/feedback',
            icon: (
                <svg width="20" height="20" fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M19.25 3H4.75A2.755 2.755 0 0 0 2 5.75v9.5A2.755 2.755 0 0 0 4.75 18H6v2.545a1.254 1.254 0 0 0 1.25 1.25c.325 0 .645-.125.88-.365l3.425-3.425h7.69a2.755 2.755 0 0 0 2.75-2.75V5.75A2.755 2.755 0 0 0 19.245 3h.005ZM13.5 13.005h-7v-1.5h7v1.5Zm4-4h-11v-1.5h11v1.5Z" fill="currentColor" />
                </svg>
            )
        },
        {
            label: t('nav_admin'),
            href: '/settings/admin',
            icon: <Shield className="w-5 h-5 text-[var(--sidebar-foreground)] group-hover:text-teal-400" />,
            hidden: !isAdmin
        },
    ];

    const changelog = [
        {
            title: "Giao diện Cảnh báo Đa cấp độ (Clinical-grade Alerts)",
            desc: "Thiết kế thẻ thiết bị trực quan với hiệu ứng động học: Rung lắc cho báo động Đỏ (Critical), Nảy nhẹ cho Vàng (Warning), và Sáng nhịp nhàng cho Xanh lơ (Caution) giúp nhận diện rủi ro ngay tức khắc."
        },
        {
            title: "Hệ thống Âm thanh An toàn (Audio Arming)",
            desc: "Tích hợp profile âm thanh chuẩn y khoa (offline) cùng nút bật chủ động (ARM AUDIO) ngay trên Header, khắc phục hoàn toàn rào cản tự động phát âm thanh của trình duyệt."
        },
        {
            title: "Thanh Điều hướng Thông minh (Smart Header)",
            desc: "Header tự động bám dính (sticky) khi cuộn trang, giao diện kính mờ (glassmorphism) tinh tế, hiển thị thời gian và trạng thái kết nối máy chủ (Frontend ↔ Backend) theo thời gian thực."
        },
        {
            title: "Chỉ báo Dữ liệu Lịch sử (WAS Indicator)",
            desc: "Hiển thị diễn biến thay đổi thông số trực quan (Ví dụ: Flow 180 → 150) tại thẻ mạch trên Dashboard. Kèm theo dòng 'System Sync' hiển thị rõ ràng, giúp bác sĩ tra cứu nhanh nguyên nhân mà không cần xem chi tiết."
        }
    ];

    return (
        <>
            <aside className="h-screen w-64 bg-[var(--sidebar)] text-[var(--sidebar-foreground)] flex flex-col z-40 hidden md:flex shadow-2xl border-r border-[var(--sidebar-border)] transition-colors duration-300 sticky top-0 shrink-0">
                <div className="p-6 border-b border-[var(--sidebar-border)]">
                    <div className="flex items-center gap-4 mb-2">
                        <div className="relative group">
                            <div className="relative w-12 h-12 flex items-center justify-center">
                                <div className={clsx(
                                    "absolute inset-0 rounded-xl blur-md transition-all duration-1000",
                                    isAnyRunning ? "bg-teal-400/30 animate-glow-flow" : "bg-teal-500/10 group-hover:bg-teal-500/20"
                                )}></div>

                                {/* CRRT Circuit Ring - Only appears when running */}
                                {isAnyRunning && (
                                    <div className="absolute inset-0 border-2 border-dashed border-teal-400/40 rounded-xl animate-circuit scale-110"></div>
                                )}

                                <div className="relative bg-slate-100 dark:bg-[#111827] p-2.5 rounded-xl border border-slate-200 dark:border-white/10 shadow-inner overflow-hidden">
                                    <div className={clsx("flex gap-0.5", isAnyRunning && "animate-liquid")}>
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-red-500 -mr-2 drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]">
                                            <path fillRule="evenodd" clipRule="evenodd" d="M10.977 2.903a1.25 1.25 0 0 1 2.046 0l5.116 7.291A7.497 7.497 0 0 1 12 22a7.497 7.497 0 0 1-6.139-11.806l5.116-7.291Z" fill="currentColor" />
                                        </svg>
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-sky-400 drop-shadow-[0_0_10px_rgba(56,189,248,0.6)]">
                                            <path fillRule="evenodd" clipRule="evenodd" d="M10.977 2.903a1.25 1.25 0 0 1 2.046 0l5.116 7.291A7.497 7.497 0 0 1 12 22a7.497 7.497 0 0 1-6.139-11.806l5.116-7.291Z" fill="currentColor" />
                                        </svg>
                                    </div>
                                </div>
                                <div className={clsx(
                                    "absolute -bottom-1 -right-1 p-1.5 rounded-full border-2 border-[var(--sidebar)] shadow-lg transition-all duration-500",
                                    isAnyRunning ? "bg-emerald-400 shadow-emerald-500/50 scale-110" : "bg-teal-400 shadow-teal-500/20"
                                )}>
                                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={clsx("text-slate-900", isAnyRunning && "animate-pulse")}>
                                        <path fillRule="evenodd" clipRule="evenodd" d="M10.977 2.903a1.25 1.25 0 0 1 2.046 0l5.116 7.291A7.497 7.497 0 0 1 12 22a7.497 7.497 0 0 1-6.139-11.806l5.116-7.291Z" fill="currentColor" />
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <div>
                            <h1 className="font-black text-xl tracking-tighter text-[var(--sidebar-active)] leading-none transition-colors">
                                ICU-B <span className="text-teal-400">CONNECT</span>
                            </h1>
                            <p className="text-[9px] text-[var(--sidebar-foreground)] opacity-60 font-bold uppercase tracking-[0.1em] mt-1.5 leading-tight">
                                Advanced CRRT<br />System
                            </p>
                        </div>
                    </div>
                </div>

                <nav className="flex-1 p-4 mt-6 space-y-1 overflow-y-auto">
                    {navItems.filter(item => !(item as any).hidden).map((item) => {
                        const isActive = pathname === item.href || (item.href !== '/' && pathname?.startsWith(item.href));
                        return (
                            <Link
                                key={item.href}
                                href={item.href}
                                className={twMerge(
                                    "flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all duration-300 group relative",
                                    isActive
                                        ? "bg-gradient-to-r from-teal-600 to-teal-800 text-white shadow-lg shadow-teal-500/20 font-semibold"
                                        : "text-[var(--sidebar-foreground)] hover:bg-[var(--sidebar-nav-hover)] hover:text-[var(--sidebar-active)]"
                                )}
                            >
                                <div className={twMerge(
                                    "transition-transform duration-500 group-hover:scale-110",
                                    isActive ? "text-white" : "text-[var(--sidebar-foreground)] group-hover:text-teal-400"
                                )}>
                                    {item.icon}
                                </div>
                                <span className="tracking-wide text-sm">{item.label}</span>
                                {'badge' in item && (item as any).badge && (
                                    <span className="ml-auto px-2 py-0.5 text-[10px] font-black rounded-full bg-indigo-500 text-white shadow-lg shadow-indigo-500/30 animate-pulse">
                                        {(item as any).badge}
                                    </span>
                                )}
                                {isActive && <div className="absolute right-3 w-1 h-5 bg-teal-300 rounded-full"></div>}
                            </Link>
                        );
                    })}


{/* 
                    <button
                        onClick={() => setIsWhatNewOpen(true)}
                        className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all duration-300 text-[var(--sidebar-foreground)] hover:bg-teal-500/10 hover:text-teal-400 group"
                    >
                        <Info className="w-5 h-5 text-[var(--sidebar-foreground)] group-hover:text-teal-400" />
                        <span className="tracking-wide text-sm">{t('nav_whats_new')}</span>
                    </button>
                    */}

                    <div className="flex items-center gap-1 p-1 bg-[var(--sidebar-nav-hover)]/50 rounded-2xl border border-[var(--sidebar-border)]/50">
                        <button
                            onClick={(e) => {
                                const x = e.clientX;
                                const y = e.clientY;
                                toggleTheme(x, y);
                            }}
                            className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl transition-all duration-300 text-[var(--sidebar-foreground)] hover:bg-[var(--sidebar-nav-hover)] hover:text-[var(--sidebar-active)] group"
                            title={theme === 'light' ? t('nav_dark_mode') : t('nav_light_mode')}
                        >
                            {theme === 'light' ? (
                                <Moon className="w-5 h-5 group-hover:text-sky-400 transition-colors" />
                            ) : (
                                <Sun className="w-5 h-5 group-hover:text-amber-400 transition-colors" />
                            )}
                        </button>

                        <div className="w-px h-6 bg-[var(--sidebar-border)]/50 mx-1" />

                        <button
                            onClick={() => setLanguage(language === 'en' ? 'vi' : 'en')}
                            className="flex-1 flex items-center justify-center gap-2.5 px-3 py-2.5 rounded-xl transition-all duration-300 text-[var(--sidebar-foreground)] hover:bg-[var(--sidebar-nav-hover)] hover:text-[var(--sidebar-active)] group font-bold text-[10px] uppercase tracking-widest"
                        >
                            <div className={clsx("flex items-center gap-1.5 transition-all", language === 'en' ? "text-teal-400 scale-105" : "opacity-40")}>
                                <FlagUK />
                                <span>EN</span>
                            </div>
                            <span className="opacity-10 text-[8px]">/</span>
                            <div className={clsx("flex items-center gap-1.5 transition-all", language === 'vi' ? "text-teal-400 scale-105" : "opacity-40")}>
                                <FlagVN />
                                <span>VI</span>
                            </div>
                        </button>
                    </div>

                    {/* Role Selector (Premium Segmented Control) */}
                    {(() => {
                        const [pinTarget, setPinTarget] = React.useState<UserRole | null>(null);
                        const [pin, setPin] = React.useState('');
                        const [pinError, setPinError] = React.useState(false);

                        const ROLE_PINS: Record<string, string> = { doctor: doctorPin, admin: adminPin };

                        const handleRoleChange = (target: UserRole) => {
                            if (target === 'nurse') { setRole(target); setPinTarget(null); return; }
                            if (target === role) return;
                            setPinTarget(target);
                            setPin('');
                            setPinError(false);
                        };

                        const verifyPin = () => {
                            if (pinTarget && pin === ROLE_PINS[pinTarget]) {
                                setRole(pinTarget);
                                setPinTarget(null);
                                setPin('');
                                setPinError(false);
                            } else {
                                setPinError(true);
                                setTimeout(() => setPinError(false), 600);
                            }
                        };

                        const roles: UserRole[] = ['nurse', 'doctor', 'admin'];
                        const activeIndex = roles.indexOf(role);

                        return (
                            <div className="mt-4 px-2">
                                <div className="relative p-1 bg-[var(--sidebar-nav-hover)] border border-[var(--sidebar-border)] rounded-2xl flex items-center overflow-hidden">
                                    {/* Sliding Active Pill */}
                                    <div
                                        className="absolute h-[calc(100%-8px)] rounded-xl transition-all duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)] shadow-sm"
                                        style={{
                                            width: `calc(100% / 3 - 4px)`,
                                            left: `calc(100% / 3 * ${activeIndex} + 2px)`,
                                            backgroundColor: 'rgba(20, 184, 166, 0.12)', // Teal-500 with opacity
                                            border: '1px solid rgba(20, 184, 166, 0.3)', // Teal-500 border
                                        }}
                                    />

                                    {roles.map((r) => (
                                        <button
                                            key={r}
                                            onClick={() => handleRoleChange(r)}
                                            className={twMerge(
                                                "relative z-10 flex-1 py-1.5 text-[9px] font-black uppercase tracking-widest transition-colors duration-300",
                                                role === r
                                                    ? 'text-teal-500 dark:text-teal-400'
                                                    : "text-[var(--sidebar-foreground)] opacity-40 hover:opacity-70"
                                            )}
                                        >
                                            {t(('role_' + r) as any)}
                                        </button>
                                    ))}

                                    {/* PIN Entry Overlay */}
                                    {pinTarget && (
                                        <div className={twMerge(
                                            "absolute inset-0 z-20 bg-[var(--sidebar)] flex items-center px-3 gap-2 animate-in slide-in-from-bottom-2 duration-300",
                                            pinError && "animate-critical-glow-shake"
                                        )}>
                                            <Shield className={twMerge("w-3 h-3", pinError ? "text-red-500" : "text-teal-500")} />
                                            <input
                                                type="password"
                                                value={pin}
                                                onChange={e => setPin(e.target.value)}
                                                onKeyDown={e => { if (e.key === 'Enter') verifyPin(); if (e.key === 'Escape') setPinTarget(null); }}
                                                placeholder="PIN"
                                                autoFocus
                                                maxLength={6}
                                                className="flex-1 bg-transparent text-[10px] font-black tracking-[0.3em] outline-none text-[var(--sidebar-active)] placeholder:opacity-20"
                                            />
                                            <button onClick={verifyPin} className="text-[10px] font-black text-teal-500 hover:text-teal-400">OK</button>
                                            <button onClick={() => setPinTarget(null)} className="text-[var(--sidebar-foreground)] opacity-30 hover:opacity-60">
                                                <X className="w-3 h-3" />
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        );
                    })()}


                    {/* Admin Dashboard / Config Section - Moved to /settings/admin */}
                </nav>

                <div className="p-6 border-t border-[var(--sidebar-border)] bg-[var(--sidebar-nav-hover)]/40 relative overflow-hidden group/developedBy">
                    {/* Decorative archive-grade accent */}
                    <div className="absolute top-0 right-0 w-24 h-24 bg-teal-500/5 -mr-12 -mt-12 rounded-full blur-2xl group-hover/developedBy:scale-150 transition-transform duration-1000"></div>

                    <div className="space-y-1 relative z-10">
                        <p className="text-[10px] font-black text-[var(--sidebar-foreground)] opacity-40 uppercase tracking-[0.2em] mb-2">{t('developed_for')}</p>
                        <p className="text-[11px] font-black text-[var(--sidebar-active)] tracking-tight flex items-center gap-2 group-hover/developedBy:text-teal-400 transition-colors">
                            <span className="w-1.5 h-3.5 bg-teal-500 rounded-full shadow-[0_0_8px_rgba(20,184,166,0.6)]"></span>
                            ICU ZONE B - CHO RAY
                        </p>
                        <div className="flex items-center gap-1.5 pt-3">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>
                            <p className="text-[9px] text-teal-400/80 font-black uppercase tracking-widest">{t('live_monitoring')}</p>
                        </div>
                    </div>
                </div>
            </aside >

            {/*
                 isWhatNewOpen && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
                        ...
                    </div>
                )
             */}
        </>
    );
}
