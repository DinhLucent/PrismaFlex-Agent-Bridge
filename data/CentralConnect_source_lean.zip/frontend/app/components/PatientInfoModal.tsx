import React, { useState } from 'react';
import { X, Save, User, CheckCircle2, AlertCircle } from 'lucide-react';
import { useLanguage } from '../providers/LanguageProvider';

export interface PatientInfo {
    patient_name: string;
    patient_yob: number | '';
    patient_gender: string;
    patient_weight: number | '';
    bed_number: string;
    admission_number: string;
    diagnosis: string;
}


interface PatientInfoModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (data: Partial<PatientInfo>) => Promise<void>;
    initialData?: Partial<PatientInfo>;
}

export default function PatientInfoModal({ isOpen, onClose, onSave, initialData }: PatientInfoModalProps) {
    const { t } = useLanguage();
    const [formData, setFormData] = useState<PatientInfo>({
        patient_name: initialData?.patient_name || '',
        patient_yob: initialData?.patient_yob || '',
        patient_gender: initialData?.patient_gender || '',
        patient_weight: initialData?.patient_weight || '',
        bed_number: initialData?.bed_number || '',
        admission_number: initialData?.admission_number || '',
        diagnosis: initialData?.diagnosis || '',
    });
    const [saving, setSaving] = useState(false);
    const [success, setSuccess] = useState(false);
    const [errors, setErrors] = useState<{ weight?: string; yob?: string; general?: string }>({});

    // Auto-format full name to Title Case
    const toTitleCase = (str: string) => {
        return str.replace(
            /\w\S*/g,
            function (txt) {
                return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
            }
        );
    };

    if (!isOpen) return null;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: (name === 'patient_yob' || name === 'patient_weight') ? (value ? Number(value) : '') : value
        }));

        // Clear specific error on change
        setErrors(prev => ({ ...prev, general: undefined }));
        if (name === 'patient_weight') setErrors(prev => ({ ...prev, weight: undefined }));
        if (name === 'patient_yob') setErrors(prev => ({ ...prev, yob: undefined }));
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        if (name === 'patient_name' && value) {
            setFormData(prev => ({ ...prev, patient_name: toTitleCase(value) }));
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        // Validation
        let hasError = false;
        const newErrors: { weight?: string; yob?: string; general?: string } = {};

        if (formData.patient_weight !== '' && (formData.patient_weight < 0.5 || formData.patient_weight > 300)) {
            newErrors.weight = t('val_weight_invalid');
            hasError = true;
        }

        const currentYear = new Date().getFullYear();
        if (formData.patient_yob !== '' && (formData.patient_yob < 1900 || formData.patient_yob > currentYear)) {
            newErrors.yob = `${t('val_yob_invalid')} (1900 - ${currentYear})`;
            hasError = true;
        }

        // Check if all fields are empty
        const isAllEmpty = Object.values(formData).every(val => val === '' || val === null);
        if (isAllEmpty) {
            newErrors.general = t('val_all_empty');
            hasError = true;
        }

        if (hasError) {
            setErrors(newErrors);
            return;
        }

        setSaving(true);
        try {
            await onSave(formData);
            setSuccess(true);
            setTimeout(() => {
                setSuccess(false);
                onClose();
            }, 800); // Wait 800ms to show the success animation before closing
        } catch (error) {
            console.error(error);
            setErrors(prev => ({ ...prev, general: t('val_save_error') }));
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-lg overflow-hidden border border-slate-200 dark:border-slate-800 transform transition-all">
                {/* Header */}
                <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-900/50">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center text-blue-600 dark:text-blue-400">
                            <User className="w-5 h-5" />
                        </div>
                        <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-100">{t('modal_patient_title')}</h2>
                    </div>
                    <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                        <X className="w-5 h-5" />
                    </button>
                </div>

                {/* Body */}
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <div className="relative">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 px-1">{t('lbl_patient_name')}</label>
                        <input type="text" name="patient_name" value={formData.patient_name} onChange={handleChange} onBlur={handleBlur} className="w-full px-4 py-3 border rounded-xl bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-700/80 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 hover:border-blue-400/50 outline-none transition-all dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600 font-medium" placeholder={t('placeholder_patient_name')} />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="relative">
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 px-1">{t('lbl_patient_yob')}</label>
                            <input type="number" name="patient_yob" value={formData.patient_yob} onChange={handleChange} className={`w-full px-4 py-3 border rounded-xl bg-white dark:bg-slate-950 ${errors.yob ? 'border-orange-500/80 focus:border-orange-500 focus:ring-orange-500/30' : 'border-slate-200 dark:border-slate-700/80 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 hover:border-blue-400/50'} outline-none transition-all dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600 font-mono text-sm`} placeholder={t('placeholder_patient_yob')} />
                            {errors.yob && (
                                <div className="absolute -bottom-5 left-1 flex items-center gap-1 mt-1 text-[10px] text-orange-500 animate-in slide-in-from-top-1">
                                    <AlertCircle className="w-3 h-3" />
                                    <span>{errors.yob}</span>
                                </div>
                            )}
                        </div>
                        <div className="relative">
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 px-1">{t('lbl_patient_gender')}</label>
                            <select name="patient_gender" value={formData.patient_gender} onChange={handleChange} className="w-full px-4 py-3 border rounded-xl bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-700/80 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 hover:border-blue-400/50 outline-none transition-all dark:text-slate-100 appearance-none font-medium">
                                <option value="">{t('select_option')}</option>
                                <option value="Nam">{t('gender_male')}</option>
                                <option value="Nữ">{t('gender_female')}</option>
                            </select>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-2">
                        <div className="relative">
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 px-1">{t('lbl_patient_weight')}</label>
                            <input type="number" step="0.1" name="patient_weight" value={formData.patient_weight} onChange={handleChange} className={`w-full px-4 py-3 border rounded-xl bg-white dark:bg-slate-950 ${errors.weight ? 'border-orange-500/80 focus:border-orange-500 focus:ring-orange-500/30' : 'border-slate-200 dark:border-slate-700/80 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 hover:border-blue-400/50'} outline-none transition-all dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600 font-mono text-sm`} placeholder={t('placeholder_patient_weight')} />
                            {errors.weight && (
                                <div className="absolute -bottom-5 left-1 flex items-center gap-1 mt-1 text-[10px] text-orange-500 animate-in slide-in-from-top-1">
                                    <AlertCircle className="w-3 h-3" />
                                    <span>{errors.weight}</span>
                                </div>
                            )}
                        </div>
                        <div className="relative">
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 px-1">{t('lbl_bed_number')}</label>
                            <input type="text" name="bed_number" value={formData.bed_number} onChange={handleChange} className="w-full px-4 py-3 border rounded-xl bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-700/80 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 hover:border-blue-400/50 outline-none transition-all dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600 font-medium" placeholder={t('placeholder_bed_number')} />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-2">
                        <div className="relative">
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 px-1">{t('lbl_admission_number')}</label>
                            <input type="text" name="admission_number" value={formData.admission_number} onChange={handleChange} className="w-full px-4 py-3 border rounded-xl bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-700/80 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 hover:border-blue-400/50 outline-none transition-all dark:text-slate-100 font-medium placeholder:text-slate-300 dark:placeholder:text-slate-600" placeholder={t('placeholder_admission_number')} />
                        </div>
                        <div className="relative">
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 px-1">{t('lbl_diagnosis')}</label>
                            <input type="text" name="diagnosis" value={formData.diagnosis} onChange={handleChange} className="w-full px-4 py-3 border rounded-xl bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-700/80 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 hover:border-blue-400/50 outline-none transition-all dark:text-slate-100 font-medium placeholder:text-slate-300 dark:placeholder:text-slate-600" placeholder={t('placeholder_diagnosis')} />
                        </div>
                    </div>




                    {/* Footer */}
                    <div className="pt-4 mt-6 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-3 relative">
                        {errors.general && (
                            <div className="flex items-center gap-2 p-3 text-sm text-red-600 bg-red-50 dark:bg-red-500/10 dark:text-red-400 rounded-xl border border-red-200 dark:border-red-500/20 animate-in slide-in-from-top-2">
                                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                                <span className="font-medium">{errors.general}</span>
                            </div>
                        )}
                        <div className="flex justify-end gap-3 w-full">
                            <button type="button" onClick={onClose} className="px-5 py-2.5 rounded-xl font-bold text-slate-500 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800/80 dark:text-slate-400 dark:hover:bg-slate-700 transition-colors uppercase tracking-wider text-[11px]">
                                {t('btn_cancel')}
                            </button>
                            <button type="submit" disabled={saving || success} className={`relative px-5 py-2.5 rounded-xl font-bold text-white uppercase tracking-wider text-[11px] flex items-center gap-2 transition-all active:scale-95 disabled:pointer-events-none overflow-hidden ${success ? 'bg-emerald-500 shadow-lg shadow-emerald-500/20' : 'bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-600/20'} `}>
                                {success && <div className="absolute inset-0 bg-emerald-400 blur-md animate-ping opacity-50" />}

                                <div className="relative flex items-center gap-2">
                                    {saving ? (
                                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                                    ) : success ? (
                                        <CheckCircle2 className="w-4 h-4 animate-in zoom-in spin-in-180 duration-300" />
                                    ) : (
                                        <Save className="w-4 h-4" />
                                    )}
                                    {success ? t('btn_saved') : t('btn_save')}
                                </div>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
}
