'use client';

import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
    children?: ReactNode;
}

interface State {
    hasError: boolean;
    errorMsg: string;
}

export class GlobalErrorBoundary extends Component<Props, State> {
    public state: State = {
        hasError: false,
        errorMsg: ''
    };

    public static getDerivedStateFromError(error: Error): State {
        // Update state so the next render will show the fallback UI.
        return { hasError: true, errorMsg: error.message };
    }

    public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
        console.error('Uncaught error:', error, errorInfo);

        // Send to backend
        this.logErrorToBackend(error, errorInfo);
    }

    private async logErrorToBackend(error: Error, errorInfo: ErrorInfo) {
        try {
            const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
            await fetch(`${apiUrl}/api/v1/client-errors`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    error: error.message || error.toString(),
                    stack: errorInfo.componentStack || error.stack || 'No stack trace',
                    url: window.location.href,
                    userAgent: navigator.userAgent
                }),
            });
        } catch (e) {
            console.error("Failed to send error log to server", e);
        }
    }

    public render() {
        if (this.state.hasError) {
            return (
                <div className="flex flex-col items-center justify-center min-h-[50vh] bg-slate-900/50 p-6 rounded-xl border border-red-500/30">
                    <h2 className="text-xl font-bold text-red-400 mb-2">Something went wrong</h2>
                    <p className="text-slate-300 mb-4 text-center max-w-lg">
                        A critical UI error occurred. It has been automatically logged to the server for the development team.
                    </p>
                    <div className="bg-slate-950 p-4 rounded text-xs text-red-300 font-mono w-full max-w-2xl overflow-auto border border-red-900/50">
                        {this.state.errorMsg}
                    </div>
                    <button
                        className="mt-6 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded transition-colors border border-slate-700"
                        onClick={() => window.location.reload()}
                    >
                        Reload Page
                    </button>
                </div>
            );
        }

        return this.props.children;
    }
}
