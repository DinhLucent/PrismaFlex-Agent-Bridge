'use client';

import React from 'react';
import { createPortal } from 'react-dom';
import { createRoot, Root } from 'react-dom/client';
import { X, Printer, Download } from 'lucide-react';
import PizZip from 'pizzip';
import Docxtemplater from 'docxtemplater';
import { saveAs } from 'file-saver';

interface CrrtPrintPreviewProps {
    detail: any;
    onClose: () => void;
    language?: 'en' | 'vi';
    usePortal?: boolean;
}

let standaloneRoot: Root | null = null;
let standaloneHost: HTMLDivElement | null = null;

function updatePreviewDebug(action: 'open' | 'close') {
    if (typeof window === 'undefined') return;
    const debug = ((window as any).__crrtPreviewDebug ||= {
        openCount: 0,
        closeCount: 0,
        lastAction: '',
        lastAt: ''
    });
    if (action === 'open') {
        debug.openCount += 1;
    } else {
        debug.closeCount += 1;
    }
    debug.lastAction = action;
    debug.lastAt = new Date().toISOString();
    console.info(`[CRRT_PREVIEW] ${action}`, debug);
}

export function openCrrtPrintPreviewStandalone(detail: any, language: 'en' | 'vi' = 'vi') {
    if (typeof document === 'undefined') return;

    if (!standaloneHost) {
        standaloneHost = document.createElement('div');
        standaloneHost.id = 'crrt-print-preview-standalone-root';
        standaloneHost.style.position = 'fixed';
        standaloneHost.style.inset = '0';
        standaloneHost.style.zIndex = '2147483647';
        standaloneHost.style.pointerEvents = 'none';
        standaloneHost.style.isolation = 'isolate';
        standaloneHost.style.contain = 'layout style paint';
        document.body.appendChild(standaloneHost);
    }

    if (!standaloneRoot) {
        standaloneRoot = createRoot(standaloneHost);
    }

    updatePreviewDebug('open');
    standaloneRoot.render(
        <CrrtPrintPreview
            detail={detail}
            language={language}
            onClose={closeCrrtPrintPreviewStandalone}
        />
    );
}

export function closeCrrtPrintPreviewStandalone() {
    updatePreviewDebug('close');
    standaloneRoot?.render(null);
}

const HOURS_24 = [
    '07:00', '08:00', '09:00', '10:00', '11:00', '12:00',
    '13:00', '14:00', '15:00', '16:00', '17:00', '18:00',
    '19:00', '20:00', '21:00', '22:00', '23:00', '24:00',
    '01:00', '02:00', '03:00', '04:00', '05:00', '06:00'
];

// Shift boundaries: solid bottom border at shift changes
const isSolidBottom = (hour: string) => ['14:00', '21:00', '06:00'].includes(hour);

// ═══════════════════════════════════════════════════════════════
// A4 PAGINATION CONSTANTS
// ═══════════════════════════════════════════════════════════════
// A4 Landscape: 297×210mm, usable ~182mm height (Chrome default margins + H&F)
// Header + patient info: ~24mm
// Table <thead>: ~20mm
// Available height for data rows: 182 - 24 - 20 = ~138mm
// Normal pages have no footer, so they can safely carry more rows.
// Last page reserves space for TONG + signatures.
const MAX_ROWS_NORMAL_PAGE = 26;
const MAX_ROWS_LAST_PAGE = 22;

// Row type for the flat list
interface FlatRow {
    type: 'hour' | 'oc' | 'day-separator';
    hourKey: string;        // e.g. '07:00', '01:39'
    displayLabel: string;   // e.g. '0700', '01:39', or day separator text
    snap: any | null;
    isSolid: boolean;
    isOC: boolean;
}

function CrrtPrintPreview({ detail, onClose, language = 'vi', usePortal = true }: CrrtPrintPreviewProps) {
    const locale = language === 'vi' ? 'vi-VN' : 'en-GB';

    if (!detail || !detail.treatment) return null;

    const treatment = detail.treatment;
    const snaps: any[] = detail.snapshots || [];

    // Detect anticoagulant type
    const firstAnticoagId = snaps.length > 0 ? snaps[0]?.anticoag_type_id : null;
    const isCitrate = firstAnticoagId === 2 || firstAnticoagId === 3;

    // ─── Map snapshots to clinical days ─────────────────────────
    const daysMap = new Map<string, Map<string, any>>();
    const ocDaysMap = new Map<string, any[]>();

    snaps.forEach(snap => {
        if (!snap.snapshot_time) return;
        const date = new Date(snap.snapshot_time);
        const hour = date.getHours();

        const clinicalDateObj = new Date(date);
        if (hour < 7) clinicalDateObj.setHours(clinicalDateObj.getHours() - 24);

        const yyyy = clinicalDateObj.getFullYear();
        const mm = String(clinicalDateObj.getMonth() + 1).padStart(2, '0');
        const dd = String(clinicalDateObj.getDate()).padStart(2, '0');
        const clinicalDateStr = `${dd}/${mm}/${yyyy}`;

        if (snap.hour_label && snap.hour_label.startsWith('OC_')) {
            if (!ocDaysMap.has(clinicalDateStr)) ocDaysMap.set(clinicalDateStr, []);
            ocDaysMap.get(clinicalDateStr)!.push(snap);
            return;
        }

        if (!daysMap.has(clinicalDateStr)) daysMap.set(clinicalDateStr, new Map<string, any>());
        const daySnapshots = daysMap.get(clinicalDateStr)!;
        let hourKey = `${hour.toString().padStart(2, '0')}:00`;
        if (hour === 0) hourKey = '24:00';
        daySnapshots.set(hourKey, snap);
    });

    if (daysMap.size === 0) {
        const today = new Date();
        daysMap.set(`${String(today.getDate()).padStart(2, '0')}/${String(today.getMonth() + 1).padStart(2, '0')}/${today.getFullYear()}`, new Map<string, any>());
    }

    const clinicalDays = Array.from(daysMap.entries()).sort((a, b) => {
        const [da, ma, ya] = a[0].split('/').map(Number);
        const [db, mb, yb] = b[0].split('/').map(Number);
        return new Date(ya, ma - 1, da).getTime() - new Date(yb, mb - 1, db).getTime();
    });
    const fmt = (val: any, dec = 0) => val !== null && val !== undefined ? Number(val).toFixed(dec) : '';

    // ═══════════════════════════════════════════════════════════════
    // BUILD FLAT ROW LIST — merge H-rows + OC rows, trim empties
    // ═══════════════════════════════════════════════════════════════
    const buildFlatRows = (snapshotMap: Map<string, any>, ocSnaps: any[]): FlatRow[] => {
        const rows: FlatRow[] = [];
        const usedOC = new Set<number>(); // Track consumed OC indices to prevent duplication

        for (let idx = 0; idx < HOURS_24.length; idx++) {
            const hour = HOURS_24[idx];
            const snap = snapshotMap.get(hour);

            rows.push({
                type: 'hour',
                hourKey: hour,
                displayLabel: hour.replace(':', ''),
                snap: snap || null,
                isSolid: isSolidBottom(hour),
                isOC: false
            });

            // Inject OC rows after matching hour
            const hourNum = parseInt(hour.replace(':', ''));
            const nextHour = HOURS_24[idx + 1];
            const nextHourNum = nextHour ? parseInt(nextHour.replace(':', '')) : 9999;

            ocSnaps.forEach((oc: any, ocIdx: number) => {
                if (usedOC.has(ocIdx)) return; // Already placed — skip
                if (!oc.snapshot_time) return;
                const ocDate = new Date(oc.snapshot_time);
                const ocH = ocDate.getHours() * 100 + ocDate.getMinutes();

                let matches = false;
                if (hourNum <= nextHourNum) {
                    matches = ocH >= hourNum && ocH < nextHourNum;
                } else {
                    matches = ocH >= hourNum || ocH < nextHourNum;
                }

                if (matches) {
                    usedOC.add(ocIdx);
                    const ocTimeStr = `${ocDate.getHours().toString().padStart(2, '0')}:${ocDate.getMinutes().toString().padStart(2, '0')}`;
                    rows.push({
                        type: 'oc',
                        hourKey: ocTimeStr,
                        displayLabel: ocTimeStr,
                        snap: oc,
                        isSolid: false,
                        isOC: true
                    });
                }
            });
        }

        // ─── Trim leading + trailing empty rows ──────────────────
        // Find the first and last rows that have data
        let firstDataIdx = -1;
        let lastDataIdx = -1;
        for (let i = 0; i < rows.length; i++) {
            if (rows[i].snap) { if (firstDataIdx < 0) firstDataIdx = i; lastDataIdx = i; }
        }

        if (firstDataIdx < 0) {
            // No data at all, return minimal
            return rows.slice(0, 8);
        }

        // Trim start: directly at first data row (no empty padding)
        const trimStart = firstDataIdx;

        // Trim end: directly at last data row (no empty padding)
        const trimEnd = lastDataIdx;

        const trimmed = rows.slice(trimStart, trimEnd + 1);

        // Keep hour rows in their clinical-day order. OC rows are already
        // injected into the matching hour window above.
        return trimmed;
    };

    // ═══════════════════════════════════════════════════════════════
    // CHUNK ROWS INTO PAGES
    // ═══════════════════════════════════════════════════════════════
    const chunkRows = (rows: FlatRow[]): FlatRow[][] => {
        if (rows.length === 0) return [[]];

        if (rows.length <= MAX_ROWS_LAST_PAGE) {
            return [rows];
        }

        const pages: FlatRow[][] = [];
        let cursor = 0;

        while (cursor < rows.length) {
            const remaining = rows.length - cursor;
            if (remaining <= MAX_ROWS_LAST_PAGE) {
                pages.push(rows.slice(cursor));
                cursor = rows.length;
            } else {
                pages.push(rows.slice(cursor, cursor + MAX_ROWS_NORMAL_PAGE));
                cursor += MAX_ROWS_NORMAL_PAGE;
            }
        }

        if (pages.length >= 2) {
            const lastPage = pages[pages.length - 1];
            if (lastPage.length > MAX_ROWS_LAST_PAGE) {
                const overflow = lastPage.length - MAX_ROWS_LAST_PAGE;
                const movedRows = lastPage.splice(0, overflow);
                pages.splice(pages.length - 1, 0, movedRows);
            }
        }

        return pages;
    };

    // ═══════════════════════════════════════════════════════════════
    // COMPUTE TOTALS
    // ═══════════════════════════════════════════════════════════════
    const computeTotals = (allRows: FlatRow[]) => {
        // Only sum from H-rows (not OC — OC are parameter changes, not hourly accumulation)
        const dataRows = allRows.filter(r => r.snap && r.type === 'hour');
        if (dataRows.length === 0) return null;

        // UF total = last snapshot's uf_total (cumulative)
        const lastSnap = dataRows[dataRows.length - 1].snap;
        const ufTotal = lastSnap?.uf_total;

        // Heparin bolus sum
        let hepBolus = 0;
        dataRows.forEach(r => { if (r.snap?.heparin_bolus) hepBolus += Number(r.snap.heparin_bolus) || 0; });

        return { ufTotal: ufTotal ? fmt(ufTotal) : '', hepBolus: hepBolus > 0 ? fmt(hepBolus) : '' };
    };

    const handlePrint = () => { window.print(); };

    const handleExportWord = async () => {
        try {
            const templateFileName = isCitrate ? 'CRRT_Citrat_2025_ready.docx' : 'CRRT_2025_ready.docx';
            const response = await fetch(`/${templateFileName}`);
            if (!response.ok) throw new Error(`Template '${templateFileName}' not found.`);
            const blob = await response.blob();
            const arrayBuffer = await blob.arrayBuffer();
            const zip = new PizZip(arrayBuffer);
            const doc = new Docxtemplater(zip, { paragraphLoop: true, linebreaks: true });

            let durationStr = '';
            if (treatment.start_time) {
                const start = new Date(treatment.start_time);
                const end = treatment.end_time ? new Date(treatment.end_time) : new Date();
                const diffMs = end.getTime() - start.getTime();
                if (diffMs > 0) {
                    const hours = Math.floor(diffMs / (1000 * 60 * 60));
                    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                    durationStr = `${hours} giờ ${minutes} phút`;
                }
            }

            const firstClinicalDayEntry = daysMap.entries().next().value;
            const snapMapForTemplate = firstClinicalDayEntry ? firstClinicalDayEntry[1] : new Map();

            const hoursData = HOURS_24.map(hour => {
                const snap = snapMapForTemplate.get(hour);
                return {
                    time: hour,
                    uf_total: fmt(snap?.uf_total), uf_hourly: fmt(snap?.uf_hourly),
                    qb: fmt(snap?.qb), qs: fmt(snap?.qs), qd: fmt(snap?.qd), qpbp: fmt(snap?.qpbp),
                    pa: fmt(snap?.pa), pv: fmt(snap?.pv), pbe: fmt(snap?.pbe), tmp: fmt(snap?.tmp),
                    sol_duosol: snap?.duosol_count !== null && snap?.duosol_count !== undefined ? fmt(snap.duosol_count) : '',
                    sol_prismasol: snap?.prismasol_count !== null && snap?.prismasol_count !== undefined ? fmt(snap.prismasol_count) : '',
                    ant_col1: isCitrate ? fmt(snap?.citrate_dose, 1) : (snap?.heparin_bolus || ''),
                    ant_col2: isCitrate ? fmt(snap?.calcium_rate, 1) : fmt(snap?.heparin_rate, 1),
                    kali: fmt(snap?.kali, 1)
                };
            });

            doc.render({
                patient_name: treatment.patient_name || treatment.patient_id || '',
                patient_yob: treatment.patient_yob || '',
                patient_gender: treatment.patient_gender === 'Nam' ? '[ ] Nữ   [x] Nam' : treatment.patient_gender === 'Nữ' ? '[x] Nữ   [ ] Nam' : '[ ] Nữ   [ ] Nam',
                bed_number: treatment.bed_number || '',
                admission_number: treatment.admission_number || '',
                start_time: treatment.start_time ? new Date(treatment.start_time).toLocaleString(locale) : '',
                end_time: treatment.end_time ? new Date(treatment.end_time).toLocaleString(locale) : '',
                clinical_date: Array.from(daysMap.keys())[0] || '',
                total_time: durationStr,
                anticoagulant_type: isCitrate ? 'Citrate' : 'Heparin',
                ant_col1_header: isCitrate ? 'Dose' : 'bolus',
                ant_col2_header: isCitrate ? 'Rate' : 'duy trì',
                hours: hoursData
            });

            const out = doc.getZip().generate({ type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
            const safePatientName = (treatment.patient_name || treatment.patient_id || 'BenhNhan').replace(/[^a-z0-9]/gi, '_');
            saveAs(out, `CRRT_${safePatientName}.docx`);
        } catch (error) {
            console.error("Error generating Word document:", error);
            alert(`Có lỗi xảy ra khi tạo file Word. Chi tiết lỗi xem ở Console.`);
        }
    };

    // ═══════════════════════════════════════════════════════════════
    // RENDER HEADER (repeated on each page)
    // ═══════════════════════════════════════════════════════════════
    const renderHeader = () => (
        <>
            <div className="flex justify-between items-end mb-1">
                <div className="font-bold text-[11px] leading-tight">
                    <div className="text-sm uppercase tracking-wide">BỆNH VIỆN CHỢ RẪY</div>
                    <div>KHOA: HỒI SỨC CẤP CỨU & CHỐNG ĐỘC (ICU)</div>
                </div>
                <div className="text-center flex-1 mx-2">
                    <h1 className="text-[17px] sm:text-[19px] font-black uppercase tracking-widest mb-0">
                        PHIẾU THEO DÕI LỌC MÁU LIÊN TỤC (CRRT)
                    </h1>
                </div>
                <div className="border border-red-600 p-0.5 px-1 text-center text-[8px] text-red-600 font-bold max-w-[180px] leading-tight whitespace-nowrap">
                    <div className="uppercase">MÃ Y LỆNH LIÊN KẾT</div>
                    <div className="font-normal text-red-500">Mã quy trình: 000105, 000106, 000104</div>
                    <div className="uppercase text-red-600">KHÁNG ĐÔNG {isCitrate ? 'CITRATE' : 'HEPARIN'}</div>
                </div>
            </div>

            <div className="mb-1 text-[11px]">
                <div className="flex items-end mb-0.5">
                    <span className="font-bold mr-1 whitespace-nowrap">Họ và tên bệnh nhân:</span>
                    <span className="uppercase font-bold text-xs tracking-wide flex-1 border-b border-dotted border-black pb-0">{treatment.patient_name || treatment.patient_id || ''}</span>
                    <span className="font-bold mx-2">Năm sinh:</span>
                    <span className="border-b border-dotted border-black pb-0.5 min-w-[60px] text-center font-bold px-2">{treatment.patient_yob || ''}</span>
                    <span className="font-bold mx-2">Giới tính:</span>
                    <span className="font-bold px-1">{treatment.patient_gender === 'Nam' ? '[ ] Nữ   [x] Nam' : treatment.patient_gender === 'Nữ' ? '[x] Nữ   [ ] Nam' : '[ ] Nữ   [ ] Nam'}</span>
                    <span className="font-bold mx-2">Số giường:</span>
                    <span className="border-b border-dotted border-black pb-0.5 min-w-[60px] text-center font-bold px-2">{treatment.bed_number || ''}</span>
                    <span className="font-bold ml-2 mr-1 whitespace-nowrap">Mã nhập viện (PRN):</span>
                    <span className="border-b border-dotted border-black pb-0.5 min-w-[100px] text-center font-bold px-2">{treatment.admission_number || ''}</span>
                </div>

                {(() => {
                    let durationStr = '';
                    const startSource = treatment.start_time_override || treatment.start_time;
                    const endSource = treatment.end_time_override || treatment.end_time;
                    if (startSource) {
                        const start = new Date(startSource);
                        const end = endSource ? new Date(endSource) : new Date();
                        const diffMs = end.getTime() - start.getTime();
                        if (diffMs > 0) {
                            const hours = Math.floor(diffMs / (1000 * 60 * 60));
                            const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                            durationStr = `${hours} giờ ${minutes} phút`;
                        }
                    }
                    return (
                        <div className="flex items-end mt-0.5">
                            <span className="font-bold mr-1 whitespace-nowrap">Bắt đầu:</span>
                            <span className="flex-1 border-b border-dotted border-black pb-0 font-bold px-1">
                                {treatment.start_time_override
                                    ? <>{new Date(treatment.start_time_override).toLocaleString('vi-VN')}<span className="text-[8px] ml-1 print:text-gray-600"> ✎</span></>
                                    : (treatment.start_time ? new Date(treatment.start_time).toLocaleString('vi-VN') : '')}
                            </span>
                            <span className="font-bold mx-1 whitespace-nowrap">Kết thúc:</span>
                            <span className="flex-1 border-b border-dotted border-black pb-0 font-bold px-1">
                                {treatment.end_time_override
                                    ? <>{new Date(treatment.end_time_override).toLocaleString('vi-VN')}<span className="text-[8px] ml-1 print:text-gray-600"> ✎</span></>
                                    : (treatment.end_time ? new Date(treatment.end_time).toLocaleString('vi-VN') : '')}
                            </span>
                            <span className="font-bold mx-1 whitespace-nowrap">Tổng thời gian:</span>
                            <span className="flex-1 border-b border-dotted border-black pb-0 font-bold px-1">{durationStr}</span>
                        </div>
                    );
                })()}
            </div>
        </>
    );

    // ═══════════════════════════════════════════════════════════════
    // RENDER TABLE HEADER (<thead>)
    // ═══════════════════════════════════════════════════════════════
    const renderThead = () => (
        <thead>
            <tr className="bg-transparent font-bold">
                <th rowSpan={2} className="border-2 border-black w-14 p-0 align-top">
                    <div className="border-b border-black pb-1 mb-1 mt-2 mx-1">Giờ</div>
                    <div>Ngày</div>
                </th>
                <th rowSpan={2} className="border border-black p-0 w-10"><div className="[writing-mode:vertical-rl] rotate-180 m-auto text-[11px] py-2">UF (2)</div></th>
                <th rowSpan={2} className="border border-black p-0 w-10">
                    <div className="[writing-mode:vertical-rl] rotate-180 m-auto text-[11px] py-1">
                        <div className="whitespace-nowrap pb-1">Tốc độ UF</div>
                        <div className="whitespace-nowrap text-[9px] font-normal">Tổng UF (t) - (t-1) / giờ</div>
                    </div>
                </th>
                <th rowSpan={2} className="border border-black w-10">Qb</th>
                <th rowSpan={2} className="border border-black w-10">Qs</th>
                <th rowSpan={2} className="border border-black w-10">Qd</th>
                <th rowSpan={2} className="border border-black w-12 text-[11px]">{isCitrate ? 'Qci' : <>Q<sub>PBP</sub></>}</th>
                <th rowSpan={2} className="border border-black w-10">PA</th>
                <th rowSpan={2} className="border border-black w-10">PV</th>
                <th rowSpan={2} className="border border-black w-10">PBE</th>
                <th rowSpan={2} className="border border-black w-10">TMP</th>

                {isCitrate ? (
                    <>
                        <th colSpan={4} className="border border-black py-2">Loại dịch</th>
                        <th colSpan={3} className="border border-black py-2">Dụng cụ</th>
                        <th rowSpan={2} className="border border-black p-0 w-10"><div className="[writing-mode:vertical-rl] rotate-180 m-auto text-[11px] py-1">Canxi Comp</div></th>
                        <th rowSpan={2} className="border border-black p-0 w-10"><div className="[writing-mode:vertical-rl] rotate-180 m-auto text-[11px] py-1">Citrate Dose</div></th>
                        <th rowSpan={2} className="border-2 border-l-black border-r-black border-t-black border-b-transparent p-0 w-10"><div className="[writing-mode:vertical-rl] rotate-180 m-auto text-[11px] py-1">Canci</div></th>
                    </>
                ) : (
                    <>
                        <th colSpan={2} className="border border-black py-2">Loại dịch</th>
                        <th colSpan={5} className="border border-black py-2">Dụng cụ</th>
                        <th colSpan={2} className="border border-black py-2">Heparin</th>
                        <th rowSpan={2} className="border-2 border-l-black border-r-black border-t-black border-b-transparent w-10">Kali</th>
                    </>
                )}
            </tr>
            <tr className="bg-transparent font-bold text-[9px]">
                {isCitrate ? (
                    <>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-wide leading-none">Citrate</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-wide leading-none">PrismOCal</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-wide leading-none">PrismaSol</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-wide leading-none">DuoSol</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-wide leading-none">OXIRIS</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-wide leading-none">Kit M100</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-wide leading-none">dây canxi</div></th>
                    </>
                ) : (
                    <>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-widest leading-none">DUOSOL</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-widest leading-none">PRISMASOL</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-widest leading-none">KIT HDF600</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-widest leading-none">Kit M100</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-widest leading-none">OXIRIS</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-widest leading-none">OMNI</div></th>
                        <th className="border border-black p-0 h-16"><div className="[writing-mode:vertical-rl] rotate-180 m-auto tracking-widest leading-none uppercase">HẤP PHỤ</div></th>
                        <th className="border border-black p-1 leading-tight">bolus</th>
                        <th className="border border-black p-1 leading-tight">duy trì</th>
                    </>
                )}
            </tr>
            <tr className="border-b-2 border-black"></tr>
        </thead>
    );

    // ═══════════════════════════════════════════════════════════════
    // RENDER A DATA ROW
    // ═══════════════════════════════════════════════════════════════
    const renderDataRow = (row: FlatRow) => {
        const { snap, isSolid, isOC, displayLabel } = row;
        const borderB = isSolid ? 'border-b-2 border-b-black' : 'border-b border-b-dotted border-b-gray-400 print:border-b-black';

        if (row.type === 'day-separator') {
            const colCount = isCitrate ? 21 : 21;
            return (
                <tr key={row.hourKey} className="h-[22px] print:h-[5mm]">
                    <td colSpan={colCount} className="border-2 border-black bg-gray-100 print:bg-transparent text-center font-black text-[11px] tracking-wide py-0">
                        {displayLabel}
                    </td>
                </tr>
            );
        }

        if (isOC) {
            return (
                <tr key={row.hourKey + '-oc-' + displayLabel} className="h-[22px] print:h-[5mm] bg-amber-50 print:bg-transparent">
                    <td className={`border-l-2 border-r-2 border-black font-black text-[10px] ${borderB}`}>
                        <span className="text-amber-700 print:text-black">{displayLabel}</span>
                    </td>
                    <td className={`border-r border-black font-medium text-cyan-800 print:text-black ${borderB}`}>{fmt(snap?.uf_total)}</td>
                    <td className={`border-r border-black font-medium text-cyan-800 print:text-black ${borderB}`}>{fmt(snap?.uf_hourly)}</td>
                    <td className={`border-r border-black font-medium text-emerald-800 print:text-black ${borderB}`}>{fmt(snap?.qb)}</td>
                    <td className={`border-r border-black font-medium text-emerald-800 print:text-black ${borderB}`}>{fmt(snap?.qs)}</td>
                    <td className={`border-r border-black font-medium text-emerald-800 print:text-black ${borderB}`}>{fmt(snap?.qd)}</td>
                    <td className={`border-r border-black font-medium text-emerald-800 print:text-black ${borderB}`}>{fmt(snap?.qpbp)}</td>
                    <td className={`border-r border-black font-medium text-rose-700 print:text-black ${borderB}`}>{fmt(snap?.pa)}</td>
                    <td className={`border-r border-black font-medium text-rose-700 print:text-black ${borderB}`}>{fmt(snap?.pv)}</td>
                    <td className={`border-r border-black font-medium text-rose-700 print:text-black ${borderB}`}>{fmt(snap?.pbe)}</td>
                    <td className={`border-r border-black font-medium text-rose-700 print:text-black ${borderB}`}>{fmt(snap?.tmp)}</td>
                    {isCitrate ? (
                        <>
                            <td className={`border-r border-black ${borderB}`}></td><td className={`border-r border-black ${borderB}`}></td>
                            <td className={`border-r border-black ${borderB}`}></td><td className={`border-r border-black ${borderB}`}></td>
                            <td className={`border-r border-black ${borderB}`}></td><td className={`border-r border-black ${borderB}`}></td>
                            <td className={`border-r border-black ${borderB}`}></td>
                            <td className={`border-r border-black font-medium text-amber-700 print:text-black ${borderB}`}>{fmt(snap?.calcium_rate, 1)}</td>
                            <td className={`border-r border-black font-medium text-amber-700 print:text-black ${borderB}`}>{fmt(snap?.citrate_dose, 1)}</td>
                            <td className={`border-r-2 border-black ${borderB}`}></td>
                        </>
                    ) : (
                        <>
                            <td className={`border-r border-black ${borderB}`}></td><td className={`border-r border-black ${borderB}`}></td>
                            <td className={`border-r border-black ${borderB}`}></td><td className={`border-r border-black ${borderB}`}></td>
                            <td className={`border-r border-black ${borderB}`}></td><td className={`border-r border-black ${borderB}`}></td>
                            <td className={`border-r border-black ${borderB}`}></td>
                            <td className={`border-r border-black ${borderB}`}></td>
                            <td className={`border-r border-black font-medium text-amber-700 print:text-black ${borderB}`}>{fmt(snap?.heparin_rate, 1)}</td>
                            <td className={`border-r-2 border-black font-medium text-purple-700 print:text-black ${borderB}`}>{fmt(snap?.kali, 1)}</td>
                        </>
                    )}
                </tr>
            );
        }

        // Normal hour row
        return (
            <tr key={row.hourKey} className="transition-colors hover:bg-slate-50 print:bg-transparent h-[22px] print:h-[5mm]">
                <td className={`border-l-2 border-r-2 border-black font-black relative ${borderB}`}>
                    <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-green-700 print:border-black print:opacity-50" />
                    {displayLabel}
                </td>
                <td className={`border-r border-black font-medium text-cyan-800 print:text-black ${borderB}`}>{fmt(snap?.uf_total)}</td>
                <td className={`border-r border-black font-medium text-cyan-800 print:text-black ${borderB}`}>{fmt(snap?.uf_hourly)}</td>
                <td className={`border-r border-black font-medium text-emerald-800 print:text-black ${borderB}`}>{fmt(snap?.qb)}</td>
                <td className={`border-r border-black font-medium text-emerald-800 print:text-black ${borderB}`}>{fmt(snap?.qs)}</td>
                <td className={`border-r border-black font-medium text-emerald-800 print:text-black ${borderB}`}>{fmt(snap?.qd)}</td>
                <td className={`border-r border-black font-medium text-emerald-800 print:text-black ${borderB}`}>{fmt(snap?.qpbp)}</td>
                <td className={`border-r border-black font-medium text-rose-700 print:text-black ${borderB}`}>{fmt(snap?.pa)}</td>
                <td className={`border-r border-black font-medium text-rose-700 print:text-black ${borderB}`}>{fmt(snap?.pv)}</td>
                <td className={`border-r border-black font-medium text-rose-700 print:text-black ${borderB}`}>{fmt(snap?.pbe)}</td>
                <td className={`border-r border-black font-medium text-rose-700 print:text-black ${borderB}`}>{fmt(snap?.tmp)}</td>

                {isCitrate ? (
                    <>
                        <td className={`border-r border-black text-[14px] ${borderB}`}>{snap?.solution_type?.toLowerCase().includes('citrate') ? '✓' : ''}</td>
                        <td className={`border-r border-black text-[14px] ${borderB}`}>{snap?.solution_type?.toLowerCase().includes('prismocal') ? '✓' : ''}</td>
                        <td className={`border-r border-black font-bold text-amber-800 print:text-black ${borderB}`}>{snap?.prismasol_count !== null && snap?.prismasol_count !== undefined ? fmt(snap.prismasol_count) : (snap?.solution_type?.toLowerCase().includes('prisma') && !snap?.solution_type?.toLowerCase().includes('prismocal') ? '✓' : '')}</td>
                        <td className={`border-r border-black font-bold text-amber-800 print:text-black ${borderB}`}>{snap?.duosol_count !== null && snap?.duosol_count !== undefined ? fmt(snap.duosol_count) : (snap?.solution_type?.toLowerCase().includes('duo') ? '✓' : '')}</td>
                        <td className={`border-r border-black text-[14px] ${borderB}`}>{snap?.filter_type?.toLowerCase().includes('oxiris') ? '✓' : ''}</td>
                        <td className={`border-r border-black text-[14px] ${borderB}`}>{snap?.filter_type?.toLowerCase().includes('m100') ? '✓' : ''}</td>
                        <td className={`border-r border-black text-[14px] ${borderB}`}></td>
                        <td className={`border-r border-black font-medium text-amber-700 print:text-black ${borderB}`}>{fmt(snap?.calcium_rate, 1)}</td>
                        <td className={`border-r border-black font-medium text-amber-700 print:text-black ${borderB}`}>{fmt(snap?.citrate_dose, 1)}</td>
                        <td className={`border-r-2 border-black font-medium text-purple-700 print:text-black ${borderB}`}></td>
                    </>
                ) : (
                    <>
                        <td className={`border-r border-black font-bold text-amber-800 print:text-black ${borderB}`}>{snap?.duosol_count !== null && snap?.duosol_count !== undefined ? fmt(snap.duosol_count) : (snap?.solution_type?.toLowerCase().includes('duo') ? '✓' : '')}</td>
                        <td className={`border-r border-black font-bold text-amber-800 print:text-black ${borderB}`}>{snap?.prismasol_count !== null && snap?.prismasol_count !== undefined ? fmt(snap.prismasol_count) : (snap?.solution_type?.toLowerCase().includes('prisma') ? '✓' : '')}</td>
                        <td className={`border-r border-black text-[14px] ${borderB}`}>{snap?.filter_type?.toLowerCase().includes('hdf') ? '✓' : ''}</td>
                        <td className={`border-r border-black text-[14px] ${borderB}`}>{snap?.filter_type?.toLowerCase().includes('m100') ? '✓' : ''}</td>
                        <td className={`border-r border-black text-[14px] ${borderB}`}>{snap?.filter_type?.toLowerCase().includes('oxiris') ? '✓' : ''}</td>
                        <td className={`border-r border-black text-[14px] ${borderB}`}></td>
                        <td className={`border-r border-black text-[14px] ${borderB}`}></td>
                        <td className={`border-r border-black font-medium text-amber-700 print:text-black ${borderB}`}>{snap?.heparin_bolus || ''}</td>
                        <td className={`border-r border-black font-medium text-amber-700 print:text-black ${borderB}`}>{fmt(snap?.heparin_rate, 1)}</td>
                        <td className={`border-r-2 border-black font-medium text-purple-700 print:text-black ${borderB}`}>{fmt(snap?.kali, 1)}</td>
                    </>
                )}
            </tr>
        );
    };

    // ═══════════════════════════════════════════════════════════════
    // RENDER TỔNG ROW
    // ═══════════════════════════════════════════════════════════════
    const renderTotalRow = (totals: { ufTotal: string; hepBolus: string } | null) => {
        const colCount = isCitrate ? 21 : 21;
        return (
            <tr className="border-t-2 border-t-black h-[22px] print:h-[5mm]">
                <td className="border-2 border-black font-black text-sm text-center px-1 py-0">TỔNG</td>
                <td className="border border-black font-bold text-cyan-800 print:text-black">{totals?.ufTotal || ''}</td>
                {/* remaining cols empty except heparin bolus */}
                {Array.from({ length: isCitrate ? 16 : 15 }).map((_, i) => <td key={i} className="border border-black"></td>)}
                {!isCitrate && <td className="border border-black font-bold text-amber-700 print:text-black">{totals?.hepBolus || ''}</td>}
                {Array.from({ length: isCitrate ? 3 : 2 }).map((_, i) => <td key={`e${i}`} className="border border-black"></td>)}
                <td className="border-2 border-l-black border-r-black border-b-black border-t-transparent"></td>
            </tr>
        );
    };

    // ═══════════════════════════════════════════════════════════════
    // RENDER SIGNATURE FOOTER
    // ═══════════════════════════════════════════════════════════════
    const renderSignatureFooter = () => (
        <div className="mt-2 flex justify-between items-start px-8 text-[11px]">
            <div className="text-center">
                <div className="font-bold mb-8">ĐIỀU DƯỠNG THỰC HIỆN</div>
                <div className="italic text-[10px] text-gray-500 print:text-gray-700">(Ký và ghi rõ họ tên)</div>
            </div>
            <div className="text-center">
                <div className="font-bold mb-8">BÁC SĨ ĐIỀU TRỊ</div>
                <div className="italic text-[10px] text-gray-500 print:text-gray-700">(Ký và ghi rõ họ tên)</div>
            </div>
        </div>
    );

    // ═══════════════════════════════════════════════════════════════
    // RENDER A SINGLE PAGE
    // ═══════════════════════════════════════════════════════════════
    const renderPage = (
        pageRows: FlatRow[],
        pageIdx: number,
        totalPages: number,
        isLastPage: boolean,
        totals: { ufTotal: string; hepBolus: string } | null,
        dateStr: string
    ) => (
        <div
            key={`${dateStr}-p${pageIdx}`}
            className={`bg-white text-black w-[297mm] shadow-2xl mx-auto p-4 sm:p-6 mb-8 print:shadow-none print:m-0 print:p-0 print:px-[5mm] print:pt-[5mm] print:w-full print:h-auto print:min-h-0 relative font-['Times_New_Roman',Times,serif] [text-rendering:optimizeLegibility] flex flex-col print:block page-container ${!isLastPage ? 'print:break-after-page' : ''}`}
        >
            {renderHeader()}

            <div className="flex-1 flex flex-col items-stretch">
                <table className="w-full print:h-auto border-collapse border-2 border-black text-center text-[12px]">
                    {renderThead()}
                    <tbody className="text-[12px] font-bold">
                        {pageRows.map(row => renderDataRow(row))}
                        {isLastPage && renderTotalRow(totals)}
                    </tbody>
                </table>
            </div>

            {isLastPage && renderSignatureFooter()}

            {/* Page number */}
            {totalPages > 1 && (
                <div className="text-center text-[9px] text-gray-400 print:text-black mt-1">
                    Trang {pageIdx + 1}/{totalPages}
                </div>
            )}
        </div>
    );

    // ═══════════════════════════════════════════════════════════════
    // MAIN RENDER
    // ═══════════════════════════════════════════════════════════════
    const content = (
        <div id="crrt-print-modal" data-preview-version="standalone-v2" className="fixed inset-0 z-[100] bg-slate-900/80 backdrop-blur-sm flex flex-col justify-start items-center overflow-y-auto p-4 sm:p-8 print:static print:p-0 print:bg-white print:block pointer-events-auto [transform:translateZ(0)] [backface-visibility:hidden]">
            {/* Screen-only Controls */}
            <div className="fixed top-4 right-4 sm:top-8 sm:right-8 flex flex-col gap-3 print:hidden z-50">
                <button onClick={onClose} className="p-3 bg-white/10 hover:bg-red-500/20 text-white hover:text-red-400 rounded-full backdrop-blur-md transition-all border border-white/20 shadow-xl" title="Đóng">
                    <X className="w-6 h-6" />
                </button>
                <button disabled className="p-3 bg-blue-500/30 text-white/50 cursor-not-allowed rounded-full border border-white/10 shadow-none transition-all group relative" title="Lưu Word">
                    <Download className="w-6 h-6" />
                    <span className="absolute right-14 top-1/2 -translate-y-1/2 bg-black text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap pointer-events-none transition-opacity uppercase font-bold tracking-widest">
                        ĐANG PHÁT TRIỂN (Lưu Word)
                    </span>
                </button>
                <button onClick={handlePrint} className="p-3 bg-teal-500 hover:bg-teal-400 text-white rounded-full shadow-[0_0_20px_rgba(20,184,166,0.5)] transition-all animate-pulse hover:animate-none hover:scale-105 active:scale-95" title="In Mẫu">
                    <Printer className="w-6 h-6" />
                </button>
            </div>

            {/* Generate Pages — merge all clinical days with day separators */}
            {(() => {
                // Build merged flat rows from all clinical days
                const allRows: FlatRow[] = [];
                const isMultiDay = clinicalDays.length > 1;

                clinicalDays.forEach(([dateStr, snapshotMap], dayIdx) => {
                    if (isMultiDay && dayIdx > 0) {
                        allRows.push({
                            type: 'day-separator',
                            hourKey: `day-${dayIdx}`,
                            displayLabel: `── Ngày ${dateStr} ──`,
                            snap: null,
                            isSolid: true,
                            isOC: false
                        });
                    }

                    const ocSnaps = ocDaysMap.get(dateStr) || [];
                    const dayRows = buildFlatRows(snapshotMap, ocSnaps);
                    allRows.push(...dayRows);
                });

                const pages = chunkRows(allRows);
                const totals = computeTotals(allRows);
                const firstDate = clinicalDays.length > 0 ? clinicalDays[0][0] : '';

                return pages.map((pageRows, pageIdx) =>
                    renderPage(
                        pageRows,
                        pageIdx,
                        pages.length,
                        pageIdx === pages.length - 1,
                        totals,
                        firstDate
                    )
                );
            })()}

            {/* Global Print Styles for A4 Landscape */}
            <style dangerouslySetInnerHTML={{
                __html: `
                @media print {
                    @page { 
                        size: A4 landscape; 
                        margin: 4mm !important; 
                        margin-bottom: 2mm !important;
                    }
                    
                    body > *:not(#crrt-print-modal) {
                        display: none !important;
                    }
                    
                    #crrt-print-modal, #crrt-print-modal * {
                        visibility: visible !important;
                    }
                    
                    #crrt-print-modal {
                        position: relative !important;
                        left: 0 !important;
                        top: 0 !important;
                        margin: 0 !important;
                        padding: 0 !important;
                        background: white !important;
                        height: auto !important;
                        min-height: auto !important;
                        width: 100% !important;
                        overflow: visible !important;
                    }

                    html, body {
                        -webkit-print-color-adjust: exact; 
                        print-color-adjust: exact; 
                        background: white !important; 
                        margin: 0 !important; 
                        padding: 0 !important; 
                        height: auto !important; 
                        min-height: auto !important;
                        overflow: visible !important; 
                    }
                    
                    .break-after-page { page-break-after: always; break-after: page; }
                    ::-webkit-scrollbar { display: none; }
                }
            `}} />
        </div>
    );

    if (!usePortal) return content;
    if (typeof document === 'undefined') return null;
    return createPortal(content, document.body);
}

export default React.memo(CrrtPrintPreview);
