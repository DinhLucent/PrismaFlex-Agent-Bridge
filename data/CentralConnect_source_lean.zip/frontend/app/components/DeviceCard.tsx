'use client';

import React from 'react';
import Link from 'next/link';
import { Clock, Power, WifiOff, X } from 'lucide-react';
import { clsx } from 'clsx';
import { useDeviceData } from '../providers/WebSocketProvider';
import { twMerge } from 'tailwind-merge';
import { THERAPY_STATUS_MAP, THERAPY_STATUS_COLORS } from '../utils/constants';
import { CRRT_PARAMETER_MAP } from '../utils/crrtMap';
import { useLanguage } from '../providers/LanguageProvider';

// ─── Types ────────────────────────────────────────────────────────

interface DeviceEvent {
    paramId: string;
    paramName?: string;
    oldValue: string;
    newValue: string;
    timestamp: number;
}

interface DeviceCardProps {
    id: string;
    name: string;
    status: 'RUNNING' | 'STOPPED' | 'ALARM' | 'UNKNOWN' | 'OFFLINE';
    lastUpdate: string;
    mode?: string;
    patientId?: string;
    therapyStatusId?: number;
    className?: string;
    activeAlarms?: {
        id: number;
        title: string;
        category: string;
        state: 'PRESENT' | 'OVERRIDDEN';
        severity: string;
    }[];
    /** Events data from centralized WebSocketProvider (no more self-polling) */
    events?: DeviceEvent[];
    vitals?: {
        access?: number;
        filter?: number;
        effluent?: number;
        return?: number;
        qb?: number;
        tmp?: number;
    };
}

// ─── Constants ────────────────────────────────────────────────────

const EXCLUDED_IDS = [
    'therapy_status_id',
    '1', '2', '3', '4', '6',     // Pressures (too volatile)
    '59', '415', '461'            // Time counters (too frequent)
];

const THIRTY_MINS = 30 * 60 * 1000;

// ─── Component ────────────────────────────────────────────────────

export const DeviceCard = React.memo(function DeviceCard({
    id, name, status, lastUpdate, mode, patientId,
    therapyStatusId, className, activeAlarms, events = [], vitals
}: DeviceCardProps) {
    const { t, language } = useLanguage();
    const [isHovered, setIsHovered] = React.useState(false);

    // Logic to determine the dominant alarm for UI coloring
    const presentAlarms = activeAlarms?.filter(a => a.state === 'PRESENT') || [];
    const hasCritical = presentAlarms.some(a => ['ALARM', 'MALFUNCTION'].includes(a.category));
    const hasWarning = presentAlarms.some(a => a.category === 'WARNING');
    const hasCaution = presentAlarms.some(a => a.category === 'CAUTION');
    const hasAdvisory = presentAlarms.some(a => a.category === 'ADVISORY');
    const isAlarmCard = hasCritical || hasWarning || hasCaution || hasAdvisory;

    // Choose status color based on priority: ALARM > WARNING > CAUTION > RUNNING
    let cardStyle = 'bg-[var(--card)] border-[var(--border)]';
    let textStyle = 'text-slate-900 dark:text-slate-100';
    let iconColor = 'text-slate-500 dark:text-slate-400';
    let badgeStyle = 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200';

    if (hasCritical) {
        cardStyle = 'bg-gradient-to-br from-[#f43f5e] to-[#e11d48] border-rose-400/50 text-white animate-critical-glow-shake relative z-10';
        textStyle = 'text-white';
        iconColor = 'text-white';
        badgeStyle = 'bg-white/20 text-white';
    } else if (hasWarning) {
        cardStyle = 'bg-gradient-to-br from-[#fbbf24] to-[#f59e0b] border-amber-400/50 text-white animate-warning-glow-bump relative z-10';
        textStyle = 'text-white';
        iconColor = 'text-white';
        badgeStyle = 'bg-white/20 text-white';
    } else if (hasCaution) {
        cardStyle = 'bg-gradient-to-br from-[#38bdf8] to-[#0284c7] border-sky-400/50 text-white animate-caution-glow-bump relative z-10';
        textStyle = 'text-white';
        iconColor = 'text-white';
        badgeStyle = 'bg-white/20 text-white';
    } else if (hasAdvisory) {
        cardStyle = 'bg-gradient-to-br from-[#818cf8] to-[#6366f1] border-indigo-400/50 text-white animate-advisory-glow-pulse relative z-10';
        textStyle = 'text-white';
        iconColor = 'text-white';
        badgeStyle = 'bg-white/20 text-white';
    } else if (status === 'RUNNING') {
        cardStyle = 'bg-gradient-to-br from-teal-50/50 to-teal-200/60 dark:from-[#0f172a] dark:to-[#134e4a] border-teal-200/60 dark:border-teal-800/60 shadow-[0_12px_24px_-8px_rgba(45,212,191,0.2)] dark:shadow-[0_12px_24px_-8px_rgba(17,94,89,0.3)]';
        textStyle = 'text-teal-950 dark:text-white';
        iconColor = 'text-teal-900 dark:text-white';
        badgeStyle = 'bg-teal-100 dark:bg-teal-900/50 text-teal-800 dark:text-teal-300';
    } else if (status === 'STOPPED' || therapyStatusId === 0 || therapyStatusId === 7 || therapyStatusId === 8) {
        cardStyle = 'bg-white dark:bg-[#0f172a] border-slate-200 dark:border-slate-800 shadow-sm';
        textStyle = 'text-slate-900 dark:text-slate-100';
        iconColor = 'text-slate-400 dark:text-slate-500';
        badgeStyle = 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200';
    } else if (status === 'OFFLINE') {
        cardStyle = 'bg-slate-50 dark:bg-slate-900/30 opacity-90 border-slate-300 dark:border-slate-700/80 shadow-sm';
        textStyle = 'text-slate-600 dark:text-slate-400 font-semibold';
        iconColor = 'text-slate-400 dark:text-slate-400';
        badgeStyle = 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300';
    } else {
        cardStyle = 'bg-[var(--card)] opacity-60 border-[var(--border)]';
        textStyle = 'text-slate-500 dark:text-slate-400 font-medium';
        iconColor = 'text-slate-400 dark:text-slate-400';
    }

    // ─── Process Events (Pure Computation from Props) ─────────────
    const MERGE_WINDOW = 5 * 60 * 1000; // 5 minutes — merge only within this window
    const [, setTick] = React.useState(0);

    // Force re-render every minute to keep "time ago" labels fresh
    React.useEffect(() => {
        const timer = setInterval(() => setTick(t => t + 1), 60000);
        return () => clearInterval(timer);
    }, []);

    const recentEvents = React.useMemo(() => {
        if (!events || events.length === 0) return [];
        const now = Date.now();

        // Step 1: Filter to relevant events
        const filtered = events
            .filter(evt => {
                const ageMs = now - evt.timestamp;
                const isRelevantTime = ageMs >= 0 && ageMs < THIRTY_MINS;
                const isNotExcluded = !EXCLUDED_IDS.includes(String(evt.paramId));
                return isRelevantTime && isNotExcluded;
            })
            .sort((a, b) => a.timestamp - b.timestamp); // oldest first for dedup

        // Step 2: Deduplicate per parameter with time-aware merge
        // - Events within 5min: merge (keep earliest old + latest new) → filter bounce-backs
        // - Events >5min apart: latest event wins (independent clinical decision)

        // Group by paramId first
        const grouped = new Map<string, any[]>();
        for (const evt of filtered) {
            const key = String(evt.paramId);
            if (!grouped.has(key)) grouped.set(key, []);
            grouped.get(key)!.push({ ...evt });
        }

        const dedupedEvents: any[] = [];
        for (const [key, paramEvents] of grouped.entries()) {
            if (paramEvents.length === 0) continue;

            const paramConfig = Object.values(CRRT_PARAMETER_MAP).find(p => String(p.key) === key);
            const rawName = paramConfig ? paramConfig.name : `Param ${key}`;
            const paramName = (t as any)(rawName) || rawName;

            let currentMerge = { ...paramEvents[0], paramName };

            for (let i = 1; i < paramEvents.length; i++) {
                const nextEvt = paramEvents[i];
                const timeDiff = nextEvt.timestamp - currentMerge.timestamp;

                if (timeDiff <= MERGE_WINDOW) {
                    // Close in time → merge (accumulate changes like 200→220→250)
                    currentMerge.newValue = nextEvt.newValue;
                    currentMerge.timestamp = nextEvt.timestamp;
                } else {
                    // Far apart → commit current merge as an independent change, start new tracking
                    // Before committing, apply mapping if it exists
                    if (paramConfig?.mapping) {
                        currentMerge.oldValue = paramConfig.mapping[currentMerge.oldValue] || currentMerge.oldValue;
                        currentMerge.newValue = paramConfig.mapping[currentMerge.newValue] || currentMerge.newValue;
                    }
                    dedupedEvents.push(currentMerge);
                    currentMerge = { ...nextEvt, paramName };
                }
            }
            // Apply mapping to the last active merge
            if (paramConfig?.mapping) {
                currentMerge.oldValue = paramConfig.mapping[currentMerge.oldValue] || currentMerge.oldValue;
                currentMerge.newValue = paramConfig.mapping[currentMerge.newValue] || currentMerge.newValue;
            }
            // Commit the last active merge
            dedupedEvents.push(currentMerge);
        }

        // Step 3: Sort by most recent, filter bounce-backs
        return dedupedEvents
            .filter(evt => evt.oldValue !== evt.newValue)
            .sort((a, b) => b.timestamp - a.timestamp);
    }, [events]);

    const { forgetDevice } = useDeviceData();

    const handleForget = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (window.confirm(t('dash_forget_confirm').replace('{name}', name))) {
            forgetDevice(id);
        }
    };

    // Calculate dynamic rotation speed based on Qb (blood flow rate)
    // Formula: 800 / Qb (clamped between 1s and 10s)
    // Higher Qb = lower duration = faster rotation
    const qbValue = vitals?.qb || 0;
    const animationDuration = status === 'RUNNING' && qbValue > 0
        ? `${Math.max(1, Math.min(10, 800 / qbValue)).toFixed(1)}s`
        : status === 'RUNNING' ? '6s' : '0s';

    return (
        <Link href={`/monitor/${id}`} className="block animate-slide-up">
            <div
                style={{
                    boxShadow: status === 'STOPPED' || status === 'OFFLINE' ? 'var(--shadow-sm)' : undefined,
                    '--hover-shadow': 'var(--shadow-lg)'
                } as React.CSSProperties}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
                className={twMerge(
                    "relative rounded-2xl border p-5 transition-all duration-500 hover:[box-shadow:var(--hover-shadow)] hover:-translate-y-2 cursor-pointer group flex flex-col justify-between min-h-[220px]",
                    isHovered ? "z-[60]" : "z-10",
                    cardStyle,
                    className
                )}
            >
                {/* VITAL SUMMARY TOOLTIP — Only for non-RUNNING cards (RUNNING shows vitals inline) */}
                {isHovered && vitals && status !== 'OFFLINE' && status !== 'RUNNING' && (
                    <div className="absolute -inset-1 z-[100] flex items-center justify-center animate-in fade-in zoom-in-95 duration-200 pointer-events-none">
                        <div className="w-[105%] h-[105%] bg-white/95 dark:bg-[#080d1a]/95 backdrop-blur-3xl rounded-2xl relative shadow-[0_20px_50px_rgba(0,0,0,0.2)] dark:shadow-[0_20px_50px_rgba(0,0,0,0.6)] flex flex-col overflow-hidden group/tooltip p-[2px]">
                            {/* Gradient Border Wrap */}
                            <div className="absolute inset-0 rounded-[inherit] bg-gradient-to-bl from-cyan-400 via-transparent to-transparent opacity-60 dark:from-cyan-500 dark:via-blue-500/20 dark:to-transparent"></div>

                            {/* Inner Content Container */}
                            <div className="relative h-full w-full bg-white/95 dark:bg-[#080d1a]/95 rounded-[14px] flex flex-col p-5 overflow-hidden">
                                {/* Decorative Background for Tooltip */}
                                <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 blur-3xl rounded-full"></div>
                                <div className="absolute bottom-0 left-0 w-24 h-24 bg-emerald-500/5 blur-3xl rounded-full"></div>

                                <div className="flex justify-between items-center mb-3 relative z-10">
                                    <h4 className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest drop-shadow-sm">{t('lbl_vital_summary')}</h4>
                                    <div className="flex items-center gap-1">
                                        <div className="w-1 h-1 rounded-full bg-emerald-500 dark:bg-emerald-400 animate-pulse"></div>
                                        <span className="text-[8px] font-bold text-emerald-600 dark:text-emerald-400 uppercase">{t('lbl_live_data')}</span>
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-3 flex-1 relative z-10">
                                    {[
                                        { label: t('lbl_access'), value: vitals.access, unit: 'mmHg', color: 'text-rose-600 dark:text-rose-400' },
                                        { label: t('lbl_return'), value: vitals.return, unit: 'mmHg', color: 'text-emerald-600 dark:text-emerald-400' },
                                        { label: t('lbl_filter'), value: vitals.filter, unit: 'mmHg', color: 'text-amber-600 dark:text-amber-400' },
                                        { label: t('lbl_effluent'), value: vitals.effluent, unit: 'mmHg', color: 'text-sky-600 dark:text-sky-400' },
                                        { label: t('lbl_qb_flow'), value: vitals.qb, unit: 'ml/min', color: 'text-slate-900 dark:text-white' },
                                        { label: t('lbl_tmp_title'), value: vitals.tmp, unit: 'mmHg', color: 'text-purple-600 dark:text-purple-400' },
                                    ].map((vital) => (
                                        <div key={vital.label} className="flex flex-col">
                                            <span className="text-[7px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-tighter opacity-80">{vital.label}</span>
                                            <div className="flex items-baseline gap-1">
                                                <span className={twMerge("text-base font-black font-[family-name:var(--font-mono)] drop-shadow-none dark:drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]", vital.color)}>
                                                    {vital.value !== undefined ? vital.value : '--'}
                                                </span>
                                                <span className="text-[8px] font-bold text-slate-500 dark:text-slate-400">{vital.unit}</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>

                                <div className="mt-auto pt-2 border-t border-black/10 dark:border-white/20 flex justify-between items-center relative z-10">
                                    <span className="text-[7px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-tight">{t('lbl_assist_version')}</span>
                                    <span className="text-[8px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-tighter">{t('lbl_click_detail')}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                {/* Background Clipping Layer - To contain glow elements while allowing foreground to breathe */}
                <div className="absolute inset-0 overflow-hidden rounded-[inherit] pointer-events-none">
                    {/* Subtle Animated Glow in background */}
                    <div className={clsx(
                        "absolute -inset-2 opacity-0 group-hover:opacity-20 transition-opacity blur-2xl",
                        status === 'RUNNING' ? "bg-emerald-400" : hasCritical ? "bg-red-400" : "bg-blue-400"
                    )} />

                    {/* Decorative background element with animation - refined for World-Class look */}
                    <div className={clsx(
                        "absolute -right-8 -bottom-8 w-32 h-32 rounded-full transition-all duration-1000 group-hover:scale-125 blur-[50px] opacity-20 group-hover:opacity-40",
                        hasCritical ? "bg-rose-100"
                            : hasWarning ? "bg-amber-100"
                                : hasCaution ? "bg-sky-100"
                                    : status === 'RUNNING' ? "bg-emerald-200"
                                        : "bg-slate-200"
                    )} />
                </div>

                <div>
                    <div className="flex justify-between items-start mb-4 relative z-10">
                        <div>
                            <div className="flex items-center gap-2 mb-1">
                                <div className={clsx(
                                    "w-2 h-2 rounded-full",
                                    status === 'RUNNING' ? "bg-emerald-500 animate-breathe" :
                                        hasCritical ? "bg-red-500 animate-breathe drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]" :
                                            hasWarning ? "bg-amber-400 animate-breathe drop-shadow-[0_0_8px_rgba(251,191,36,0.8)]" :
                                                status === 'OFFLINE' ? "bg-slate-400" : "bg-amber-500"
                                )}></div>
                                <span className={clsx("text-[10px] font-black uppercase tracking-widest opacity-70 flex items-center gap-1.5", textStyle)}>
                                    {status === 'OFFLINE' ? t('lbl_offline_card') : (
                                        <>
                                            {t('lbl_online')}
                                            {status === 'RUNNING' && (
                                                <svg width="12" height="8" viewBox="0 0 12 8" fill="none" className="text-emerald-500 animate-pulse">
                                                    <path d="M1 4h2M4 4l1-3 1.5 6 1-3h3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            )}
                                        </>
                                    )}
                                </span>
                            </div>
                            <h3 className={clsx("font-black text-xl uppercase tracking-tight", textStyle)}>
                                PRISMAFLEX_{id.replace('PF_', '')}
                            </h3>
                            <div className="flex items-center gap-1 opacity-20">
                                <div className="h-[2px] w-8 bg-current rounded-full"></div>
                                <span className="text-[7px] font-mono font-bold uppercase tracking-tighter">SIG_{id.slice(-4)}</span>
                            </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                            <div className="flex items-center gap-2">
                                {status === 'OFFLINE' && (
                                    <button
                                        onClick={handleForget}
                                        title="Forget this device"
                                        className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 transition-all border border-slate-200 dark:border-slate-700 shadow-sm"
                                    >
                                        <X className="w-4 h-4" />
                                    </button>
                                )}
                                <div className="p-1 rounded-2xl bg-black/5 dark:bg-white/5 shadow-[inset_0_2px_8px_rgba(0,0,0,0.08)] dark:shadow-[inset_0_2px_12px_rgba(0,0,0,0.4)] border border-black/5 dark:border-white/5">
                                    <div className={clsx(
                                        "p-2 rounded-xl backdrop-blur-md transition-all duration-500 group-hover:rotate-12 relative",
                                        (hasCritical || hasWarning || hasCaution) ? "bg-white/20 shadow-lg shadow-black/10" : status === 'RUNNING' ? "bg-white/80 dark:bg-white/10 shadow-lg shadow-teal-500/10 backdrop-blur-md border border-white/40" : "bg-slate-100/50 dark:bg-white/5"
                                    )}>
                                        {status === 'RUNNING' && (
                                            <div
                                                className="absolute inset-0 border border-dashed border-teal-700/40 dark:border-teal-300/50 rounded-xl animate-circuit scale-125"
                                                style={{ animationDuration }}
                                            ></div>
                                        )}
                                        {status === 'OFFLINE' ? (
                                            <WifiOff className={clsx("w-4 h-4 transition-all duration-500", iconColor)} />
                                        ) : (
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={clsx(
                                                "transition-all duration-500 relative z-10",
                                                iconColor,
                                                status === 'RUNNING' ? "animate-liquid" : hasCritical ? "animate-breathe text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]" : hasWarning ? "animate-breathe drop-shadow-[0_0_8px_rgba(255,255,255,0.6)]" : ""
                                            )}>
                                                <path fillRule="evenodd" clipRule="evenodd" d="M10.977 2.903a1.25 1.25 0 0 1 2.046 0l5.116 7.291A7.497 7.497 0 0 1 12 22a7.497 7.497 0 0 1-6.139-11.806l5.116-7.291Z" fill="currentColor" />
                                            </svg>
                                        )}
                                    </div>
                                </div>
                            </div>
                            {therapyStatusId !== undefined && (
                                <span className={clsx(
                                    "px-2 py-0.5 rounded-full text-[9px] font-black text-white shadow-md uppercase tracking-wider transition-colors duration-500",
                                    (hasCritical || hasWarning || hasCaution)
                                        ? "bg-white/20"
                                        : (THERAPY_STATUS_COLORS[therapyStatusId] || "bg-slate-500")
                                )}>
                                    {THERAPY_STATUS_MAP[therapyStatusId] || 'UNKNOWN'}
                                </span>
                            )}
                        </div>
                    </div>

                    <div className="space-y-3 relative z-10">
                        {activeAlarms && activeAlarms.length > 0 && (
                            <div className="flex justify-end mb-1">
                                <span className={clsx(
                                    "px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest shadow-sm backdrop-blur-sm transition-all",
                                    (hasCritical || hasWarning || hasCaution)
                                        ? "bg-white/20 text-white/90 border border-white/20"
                                        : "bg-white/50 dark:bg-black/40 text-teal-950 dark:text-teal-100 border border-teal-900/20 dark:border-teal-100/20"
                                )}>
                                    {activeAlarms.length} {t('lbl_active_alerts')}
                                </span>
                            </div>
                        )}

                        {presentAlarms && presentAlarms.length > 0 && (
                            <div className={clsx(
                                "py-1.5 px-1 text-[12px] font-black mt-2 leading-tight flex items-center gap-2",
                                (hasCritical || hasWarning || hasCaution) ? "text-white drop-shadow-sm" : textStyle
                            )}>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={clsx(
                                    "shrink-0 animate-breathe",
                                    (hasCritical || hasWarning || hasCaution) ? "text-white drop-shadow-md" : iconColor
                                )}>
                                    <path d="m22.225 19.13-9.14-15.99a1.25 1.25 0 0 0-2.17 0l-9.14 15.99c-.225.39-.22.86 0 1.245.225.39.63.625 1.08.625H21.14c.45 0 .855-.235 1.08-.625a1.22 1.22 0 0 0 0-1.245h.005ZM11.25 8.5h1.5v6h-1.5v-6ZM12 18c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1Z" fill="currentColor" />
                                </svg>
                                <span className="truncate opacity-95 tracking-tight">{presentAlarms[0].title}</span>
                            </div>
                        )}

                        <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-black/10 dark:border-white/10">
                            {patientId && (
                                <div>
                                    <span className={clsx("text-[8px] uppercase font-bold opacity-40 block mb-0.5 tracking-wider", textStyle)}>{t('lbl_patient_id_card')}</span>
                                    <span className={clsx("font-black text-sm tracking-tight", textStyle)}>{patientId}</span>
                                </div>
                            )}
                            {mode && (
                                <div>
                                    <span className={clsx("text-[8px] uppercase font-bold opacity-40 block mb-0.5 tracking-wider", textStyle)}>{t('lbl_therapy_modality')}</span>
                                    <span className={clsx("font-black text-sm tracking-tight", textStyle)}>{mode}</span>
                                </div>
                            )}
                        </div>

                        {/* ── Vital Signs Grid (Always visible on active cards) ── */}
                        {status === 'RUNNING' && vitals && !isAlarmCard && (
                            <div className="mt-4 pt-3 border-t border-teal-900/10 dark:border-white/10">
                                <div className="grid grid-cols-5 gap-1.5">
                                    {[
                                        { label: 'PA', value: vitals.access, color: 'text-rose-600 dark:text-rose-400', signed: true },
                                        { label: 'PV', value: vitals.return, color: 'text-emerald-600 dark:text-emerald-400', signed: true },
                                        { label: 'PBE', value: vitals.effluent, color: 'text-sky-600 dark:text-sky-400', signed: true },
                                        { label: 'TMP', value: vitals.tmp, color: 'text-amber-600 dark:text-amber-400', signed: true },
                                        { label: 'QB', value: vitals.qb, color: 'text-teal-700 dark:text-teal-300', signed: false },
                                    ].map((v) => (
                                        <div key={v.label} className="flex flex-col items-center bg-black/[0.03] dark:bg-white/[0.04] rounded-lg py-1.5 px-1">
                                            <span className="text-[7px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-0.5">{v.label}</span>
                                            <span className={`text-[13px] font-black font-[family-name:var(--font-mono)] leading-none ${v.color}`}>
                                                {v.value !== undefined && v.value !== null
                                                    ? v.signed
                                                        ? (v.value > 0 ? `+${Math.round(v.value)}` : Math.round(v.value))
                                                        : Math.round(v.value)
                                                    : '—'}
                                            </span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                {/* SYSTEM EVENTS / WAS INDICATORS */}
                <div className="mt-4 space-y-1 relative z-10">
                    {recentEvents.map((evt: any, idx: number) => {
                        const isColoredCard = isAlarmCard || status === 'RUNNING';
                        const isVeryRecent = (Date.now() - evt.timestamp) < 600000; // 10 minutes

                        return (
                            <div key={`${evt.paramId}-${evt.timestamp}`}
                                className={clsx(
                                    "flex items-center gap-3 py-1.5 transition-all duration-300 rounded-lg px-2 -mx-2 relative overflow-hidden",
                                    idx !== recentEvents.length - 1 && (isColoredCard ? (isAlarmCard ? "border-b border-white/10" : "border-b border-teal-900/10 dark:border-white/10") : "border-b border-black/5 dark:border-white/5"),
                                    isVeryRecent && (!isAlarmCard) && status !== 'OFFLINE' && "animate-audit-glow audit-shimmer-container",
                                    isVeryRecent && isAlarmCard && status !== 'OFFLINE' && "audit-shimmer-container",
                                    { "animate-in fade-in slide-in-from-bottom-2 duration-700": idx === 0 }
                                )}>
                                <div className={clsx(
                                    "w-1 h-1 rounded-full shrink-0 relative",
                                    isAlarmCard ? "bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]" :
                                        status === 'OFFLINE' ? "bg-slate-300 dark:bg-slate-600 shadow-none" :
                                            "bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]"
                                )}>
                                    {isVeryRecent && status !== 'OFFLINE' && (
                                        <div className={clsx(
                                            "absolute inset-0 rounded-full animate-ping opacity-75",
                                            isAlarmCard ? "bg-white" : "bg-amber-400"
                                        )}></div>
                                    )}
                                </div>

                                <span className={clsx(
                                    "text-[9px] font-black uppercase truncate max-w-[80px] tracking-tight opacity-70 relative z-10",
                                    isAlarmCard ? "text-white" : textStyle
                                )}>
                                    {evt.paramName}
                                </span>

                                <div className="flex items-center gap-1.5 ml-auto relative z-10">
                                    <div className="flex items-center">
                                        <span className={clsx(
                                            "font-black text-xs font-[family-name:var(--font-mono)] opacity-70",
                                            isAlarmCard ? "text-white" : textStyle
                                        )}>{evt.oldValue}</span>
                                        <span className={clsx(
                                            "mx-1 text-[8px] opacity-30",
                                            isAlarmCard ? "text-white" : "text-black dark:text-white"
                                        )}>→</span>
                                        <span className={clsx(
                                            "font-black text-sm font-[family-name:var(--font-mono)]",
                                            isAlarmCard ? "text-white" : (status === 'RUNNING' ? "text-emerald-700 dark:text-emerald-400" : "text-emerald-600 dark:text-emerald-400")
                                        )}>{evt.newValue}</span>
                                    </div>
                                    <span className={clsx(
                                        "text-[8px] font-medium opacity-60 uppercase tracking-tighter",
                                        isAlarmCard ? "text-white" : textStyle
                                    )}>
                                        {(() => {
                                            const ageMs = Math.max(0, Date.now() - evt.timestamp);
                                            const m = Math.floor(ageMs / 60000);
                                            return m < 1 ? t('lbl_just_now') : `${m}m`;
                                        })()}
                                    </span>
                                </div>
                            </div>
                        );
                    })}
                    <div className={clsx("pt-2 flex items-center text-[10px] font-medium",
                        isAlarmCard ? "text-white opacity-90" : `${textStyle} opacity-80`
                    )}>
                        <Clock className="w-3 h-3 mr-1" />
                        <span>{t('lbl_last_sync')} {lastUpdate && !isNaN(new Date(lastUpdate).getTime()) ? <span className="font-[family-name:var(--font-mono)]">{new Date(lastUpdate).toLocaleTimeString('en-GB', { hour12: false })}</span> : t('lbl_offline')}</span>
                    </div>
                </div>


            </div>
        </Link>
    );
}, (prevProps, nextProps) => {
    // Custom comparison to guarantee no re-renders unless the device's actual data changes
    return (
        prevProps.id === nextProps.id &&
        prevProps.status === nextProps.status &&
        prevProps.lastUpdate === nextProps.lastUpdate &&
        prevProps.mode === nextProps.mode &&
        prevProps.patientId === nextProps.patientId &&
        prevProps.therapyStatusId === nextProps.therapyStatusId &&
        prevProps.activeAlarms === nextProps.activeAlarms &&
        prevProps.events === nextProps.events &&
        prevProps.vitals?.access === nextProps.vitals?.access &&
        prevProps.vitals?.filter === nextProps.vitals?.filter &&
        prevProps.vitals?.effluent === nextProps.vitals?.effluent &&
        prevProps.vitals?.return === nextProps.vitals?.return &&
        prevProps.vitals?.qb === nextProps.vitals?.qb &&
        prevProps.vitals?.tmp === nextProps.vitals?.tmp
    );
});
