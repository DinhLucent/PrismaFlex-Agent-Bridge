'use client';

import React, { useMemo, useRef, useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ReferenceLine } from 'recharts';
import { clsx } from 'clsx';
import { useTheme } from '../providers/ThemeProvider';

interface PressureChartProps {
    data: { time: string; value: number; _ts: number }[];
    color: string;
    name: string;
    unit: string;
    smoothingEnabled?: boolean;
}

const CLAMP_MIN = -500;
const CLAMP_MAX = 800;
const MIN_CHART_WIDTH = 80;
const MIN_CHART_HEIGHT = 60;

/**
 * Safe dimension hook — replaces Recharts ResponsiveContainer.
 * Uses ResizeObserver for reliable measurements immune to CSS zoom issues.
 */
function useSafeDimensions(ref: React.RefObject<HTMLDivElement | null>) {
    const [dims, setDims] = useState({ width: 0, height: 0 });

    useEffect(() => {
        const el = ref.current;
        if (!el) return;

        const measure = () => {
            // Use clientWidth/clientHeight which are integers, not affected by zoom transforms
            const w = el.clientWidth;
            const h = el.clientHeight;
            setDims(prev => {
                if (prev.width === w && prev.height === h) return prev;
                return { width: Math.max(0, w), height: Math.max(0, h) };
            });
        };

        measure();

        const ro = new ResizeObserver(measure);
        ro.observe(el);
        return () => ro.disconnect();
    }, [ref]);

    return dims;
}

// Custom Tooltip Component
const CustomTooltip = ({ active, payload, label, color, name, unit, isDark }: any) => {
    if (active && payload && payload.length) {
        return (
            <div className={clsx(
                "px-3 py-2 rounded-lg border-2 transition-colors duration-300",
                isDark ? "bg-[#1e293b] border-slate-700" : "bg-white border-white"
            )} style={{ borderColor: active ? color : undefined, boxShadow: 'var(--shadow-lg)' }}>
                <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-1">{name}</div>
                <div className="text-xl font-bold font-[family-name:var(--font-mono)]" style={{ color: color }}>
                    {payload[0].value} <span className="text-sm font-semibold text-slate-400 dark:text-slate-500">{unit}</span>
                </div>
                <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 font-medium">
                    🕐 {typeof label === 'number' ? new Date(label).toLocaleTimeString('en-GB', { hour12: false }) : label}
                </div>
            </div>
        );
    }
    return null;
};

export function PressureChart({ data, color, name, unit, smoothingEnabled = true }: PressureChartProps) {
    const { theme } = useTheme();
    const isDark = theme === 'dark';
    const containerRef = useRef<HTMLDivElement>(null);
    const { width, height } = useSafeDimensions(containerRef);

    // ─── Memoized Smoothing & Statistics ──────────────────────────
    const smoothData = useMemo(() => {
        if (!smoothingEnabled || data.length <= 2) return data;
        return data.map((point, index) => {
            if (index < 1 || index > data.length - 2) return point;
            const v1 = data[index - 1].value;
            const v2 = point.value;
            const v3 = data[index + 1].value;
            return { ...point, value: Math.round((v1 + v2 + v3) / 3) };
        });
    }, [data, smoothingEnabled]);

    const { meanValue, yMin, yMax, xDomain } = useMemo(() => {
        if (smoothData.length === 0) return { meanValue: 0, yMin: -30, yMax: 30, xDomain: ['auto', 'auto'] };

        const clampedValues = smoothData.map(p => Math.max(CLAMP_MIN, Math.min(CLAMP_MAX, p.value)));

        const mean = Math.round(
            clampedValues.reduce((sum, v) => sum + v, 0) / clampedValues.length
        );

        const stdDev = clampedValues.length > 1
            ? Math.sqrt(
                clampedValues.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / clampedValues.length
            )
            : 5;

        const minSpan = 10;
        const adaptiveSpan = Math.max(minSpan, 2 * stdDev);

        const latestTs = smoothData[smoothData.length - 1]._ts;
        const WINDOW_MS = 30 * 60 * 1000;
        const xMin = Math.max(smoothData[0]._ts, latestTs - WINDOW_MS);

        return {
            meanValue: mean,
            yMin: Math.floor(mean - adaptiveSpan),
            yMax: Math.ceil(mean + adaptiveSpan),
            xDomain: [xMin, latestTs]
        };
    }, [smoothData]);

    const canRender = width >= MIN_CHART_WIDTH && height >= MIN_CHART_HEIGHT;

    return (
        <div
            ref={containerRef}
            style={{ boxShadow: 'var(--shadow-sm)' }}
            className="h-48 w-full bg-white dark:bg-[#0f172a] rounded-lg p-2 border border-slate-100 dark:border-slate-800 relative transition-colors duration-300"
        >
            {/* ─── Compact Header Badge ───────────────────────── */}
            <div className="absolute top-2 left-2 z-10 flex items-center gap-2">
                <div
                    style={{ boxShadow: 'var(--shadow-sm)' }}
                    className="bg-white/95 dark:bg-slate-900/95 px-2 py-1 rounded-lg border border-slate-200/60 dark:border-slate-800/60 transition-colors duration-300"
                >
                    <div className="flex items-center gap-1.5 mb-0.5">
                        <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
                        <span className="text-[9px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">{name}</span>
                    </div>
                    <div className="flex items-baseline gap-1">
                        <span className="text-sm font-black font-[family-name:var(--font-mono)] text-slate-800 dark:text-slate-200">
                            {smoothData.length > 0 ? smoothData[smoothData.length - 1].value : '--'}
                        </span>
                        <span className="text-[8px] font-bold text-slate-400 dark:text-slate-500">{unit}</span>
                    </div>
                </div>

                {/* Subtle Mean Indicator */}
                <div className="bg-white/40 dark:bg-slate-900/40 backdrop-blur-[2px] px-1.5 py-0.5 rounded border border-slate-200/30 dark:border-slate-700/30">
                    <span className="text-[8px] font-bold font-[family-name:var(--font-mono)] opacity-60" style={{ color: color }}>
                        μ={meanValue}
                    </span>
                </div>
            </div>

            {canRender && (
                <LineChart data={smoothData} width={width - 16} height={height - 16}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDark ? "#1e293b" : "#E5E7EB"} />
                    <XAxis
                        dataKey="_ts"
                        type="number"
                        domain={xDomain as any}
                        hide={false}
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 8, fill: isDark ? '#475569' : '#9CA3AF' }}
                        tickFormatter={(unixTime) => {
                            if (!unixTime) return '';
                            const date = new Date(unixTime);
                            return date.toLocaleTimeString('en-GB', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
                        }}
                        minTickGap={20}
                    />
                    <YAxis
                        hide={false}
                        width={30}
                        axisLine={false}
                        tickLine={false}
                        tick={{ fontSize: 10, fill: isDark ? '#475569' : '#9CA3AF' }}
                        domain={[yMin, yMax]}
                        allowDecimals={false}
                    />
                    <Tooltip
                        content={<CustomTooltip color={color} name={name} unit={unit} isDark={isDark} />}
                        cursor={{ stroke: color, strokeWidth: 1, strokeDasharray: '5 5' }}
                    />
                    {smoothData.length > 0 && (
                        <ReferenceLine
                            y={meanValue}
                            stroke={color}
                            strokeDasharray="3 3"
                            strokeWidth={1.5}
                            opacity={0.3}
                            label={{
                                value: `μ=${meanValue}`,
                                position: 'right',
                                fill: color,
                                fontSize: 9,
                                fontWeight: 'bold'
                            }}
                        />
                    )}
                    <Line
                        type="monotoneX"
                        dataKey="value"
                        stroke={color}
                        strokeWidth={2.5}
                        dot={false}
                        activeDot={{ r: 5, strokeWidth: 2, stroke: isDark ? '#0f172a' : '#fff', fill: color }}
                        isAnimationActive={false}
                    />
                </LineChart>
            )}
        </div>
    );
}
