'use client';

import React, { useEffect, useState, useRef } from 'react';
import { Zap, VolumeX, Volume2, Wifi, WifiOff } from 'lucide-react';
import { clsx } from 'clsx';
import { useDeviceData } from '../providers/WebSocketProvider';
import { useLanguage } from '../providers/LanguageProvider';

export default function Header() {
    const { t } = useLanguage();
    const { devices, isAudioEnabled, enableAudio, serverTime, isConnected, connectionStatus } = useDeviceData();
    const [currentTime, setCurrentTime] = useState<string>('');

    // Store the local performance timestamp when we last received a server update
    const syncRef = useRef<{ server: number, local: number } | null>(null);

    // Sync reference when server time updates (every 5s via Heartbeat)
    useEffect(() => {
        if (serverTime) {
            syncRef.current = {
                server: serverTime.getTime(),
                local: performance.now()
            };
        }
    }, [serverTime]);

    // Fast local timer to tick the seconds smoothly between server updates
    useEffect(() => {
        const timer = setInterval(() => {
            let displayDate = new Date(); // Fallback

            if (syncRef.current) {
                // Calculate exactly how much real time has passed since the last server sync
                const elapsedLocal = performance.now() - syncRef.current.local;
                displayDate = new Date(syncRef.current.server + elapsedLocal);
            }

            setCurrentTime(displayDate.toLocaleTimeString('en-GB', {
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            }));
        }, 1000);

        return () => clearInterval(timer);
    }, []);

    const activeDevices = devices.filter(d => d.status !== 'OFFLINE').length;
    const totalDevices = devices.filter(d => d.id.startsWith('PF_')).length;

    return (
        <header className="relative w-full bg-slate-50/80 dark:bg-slate-900/60 backdrop-blur-xl border border-[var(--border)] rounded-xl shadow-[inset_0_2px_4px_rgba(0,0,0,0.04)] dark:shadow-[inset_0_2px_4px_rgba(0,0,0,0.2)] flex items-center justify-between px-5 py-2.5 z-30 transition-colors duration-300">
            {/* Left Section: Title + Status */}
            <div className="flex items-center gap-4 relative z-10">
                <div className="flex flex-col">
                    <h2 className="text-sm font-black tracking-widest uppercase text-[var(--foreground)] flex items-center gap-2">
                        {t('header_title')}
                        <span className="flex h-2 w-2 relative">
                            {isConnected ? (
                                <>
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                                </>
                            ) : (
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                            )}
                        </span>
                    </h2>
                    <div className="flex items-center gap-1.5 mt-0.5">
                        {isConnected ? (
                            <Wifi className="w-3 h-3 text-emerald-500" />
                        ) : (
                            <WifiOff className="w-3 h-3 text-rose-500" />
                        )}
                        <p className={clsx(
                            "text-[10px] uppercase font-bold tracking-widest",
                            isConnected ? "text-emerald-600 dark:text-emerald-400 opacity-80" : "text-rose-600 dark:text-rose-400"
                        )}>
                            {connectionStatus === 'CONNECTED' ? t('status_connected') :
                                connectionStatus === 'CONNECTING' ? t('status_connecting') :
                                    connectionStatus === 'DISCONNECTED' || connectionStatus === 'ERROR' ? t('status_offline') : t('status_connecting')}
                        </p>
                    </div>
                </div>
            </div>

            {/* Center Section: Device Counts */}
            <div className="hidden md:flex items-center gap-1.5 bg-black/[0.03] dark:bg-white/[0.04] rounded-lg px-3 py-1.5 shadow-[inset_0_1px_3px_rgba(0,0,0,0.06)] dark:shadow-[inset_0_1px_3px_rgba(0,0,0,0.3)] relative z-10">
                <Zap className="w-3 h-3 text-amber-500" />
                <span className="text-[10px] font-black text-[var(--foreground)] tabular-nums">
                    {activeDevices}<span className="text-[var(--muted)] font-bold mx-0.5">/</span>{totalDevices}
                </span>
                <span className="text-[9px] font-bold text-[var(--muted)] uppercase tracking-wider">{t('lbl_actives')}</span>
            </div>

            {/* Right Section: Audio + Clock */}
            <div className="flex items-center gap-3 relative z-10">
                {/* Audio Arming Button */}
                <button
                    onClick={enableAudio}
                    className={clsx(
                        "flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-[10px] font-black uppercase tracking-wider transition-all duration-300",
                        isAudioEnabled
                            ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-600 dark:text-emerald-400"
                            : "bg-rose-500 border-rose-600 text-white shadow-md shadow-rose-500/20 hover:bg-rose-600 active:scale-95 animate-pulse"
                    )}
                >
                    {isAudioEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                    <span className="hidden lg:inline">
                        {isAudioEnabled ? t('btn_audio_enabled') : t('btn_enable_audio')}
                    </span>
                </button>

                <div className="w-px h-6 bg-[var(--border)]" />

                <div className="flex flex-col items-end">
                    <span className="text-[8px] font-bold text-[var(--muted)] tracking-[0.15em] uppercase leading-tight">
                        {t('lbl_sync_time')}
                    </span>
                    <span className="text-sm font-black text-[var(--foreground)] font-[family-name:var(--font-mono)] tracking-tight tabular-nums leading-tight">
                        {currentTime || '--:--:--'}
                    </span>
                </div>
            </div >
        </header >
    );
}
