## Backend Postgres Phase 1 Handoff

Purpose: Backend implementation handoff for `TASK-107` and `TASK-108`  
Audience: backend-agent / OPUS / backend reviewers  
Scope: PostgreSQL foundation + command-driven API rollout scaffolding

### 1. What This Handoff Covers

This document is intentionally practical.

It tells the backend team:

- what to build first,
- what not to touch yet,
- which current SQLite structures map to which PostgreSQL structures,
- which command endpoints must exist in Phase 1,
- and what verification is required before handing off to frontend/QA.

This handoff is subordinate to:

- [implementation_plan.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/implementation_plan.md)
- [TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC.md)

### 2. Phase 1 Goal

Phase 1 is **not** full migration.

Phase 1 goal is:

- establish the PostgreSQL schema,
- establish repository/service boundaries,
- establish command endpoints,
- preserve current workflow semantics,
- and create a safe compatibility path from SQLite-backed logic toward PostgreSQL-backed logic.

### 3. Non-Goals For Phase 1

Do **not** do these in Phase 1:

- full raw telemetry migration
- full SQLite removal
- generic CRUD redesign of the UI
- EAV/per-cell modeling
- rewriting continuation logic
- redesigning clinical workflow

### 4. Current SQLite -> PostgreSQL Mapping

#### Existing SQLite tables

- `treatments`
- `treatment_phases`
- `treatment_status_log`
- `treatment_hourly_snapshots`
- `treatment_config`
- `treatment_notes`
- `treatment_index`
- `treatment_raw_packets`
- `snapshot_originals`

#### PostgreSQL target tables for Phase 1

- `treatments`
- `treatment_phases`
- `treatment_status_events`
- `treatment_journal_rows`
- `treatment_config`
- `treatment_notes`
- `treatment_review_state`
- `snapshot_originals`
- `snapshot_audit_log`
- `treatment_list_projection`
- `raw_packet_manifest`

### 5. Table Mapping Notes

#### `treatments` -> `treatments`

Keep as the treatment master.

Must preserve:

- lifecycle timestamps
- outcome
- state
- continuation-related metadata
- patient context

#### `treatment_phases` -> `treatment_phases`

Mostly direct mapping.

Add:

- `created_at`
- `updated_at`

#### `treatment_status_log` -> `treatment_status_events`

Same functional purpose, but explicitly event-oriented.

Rename:

- `timestamp` -> `event_time`

Add:

- `event_code`
- `created_at`

#### `treatment_hourly_snapshots` -> `treatment_journal_rows`

This is the most important table in the migration.

Keep the row wide.

Must preserve:

- one row per `Hxx` or `OC_XX`
- immutable `snapshot_time`
- `updated_by`
- manual + auto fields in the same row

Add:

- `row_kind`
- `stable_at`
- `version`
- `is_deleted`
- `deleted_at`
- `deleted_by`
- `created_by`

#### `treatment_notes` -> `treatment_notes`

Keep append-only semantics.

#### `snapshot_originals` -> `snapshot_originals`

Keep freeze-on-submit semantics.

Must preserve:

- `row_code/hour_label`
- `snapshot_time`
- frozen JSON payload

#### `treatment_index` -> `treatment_list_projection`

Do not remove this concept.

This is still required for:

- list/history view
- fast paginated filters
- reduced join cost

#### `treatment_raw_packets` -> `raw_packet_manifest`

Do not carry over raw packet row-by-row storage into PostgreSQL OLTP in Phase 1.

Instead:

- define only the manifest table
- keep actual raw packet bodies in current chunked JSONL/local storage path for now

### 6. SQLAlchemy Module Layout

Recommended layout:

```text
backend/
  db/
    postgres/
      base.py
      session.py
      models/
        treatments.py
        journal.py
        review.py
        notes.py
        audit.py
        projection.py
        raw_manifest.py
      repositories/
        treatment_repository.py
        journal_repository.py
        review_repository.py
        notes_repository.py
        audit_repository.py
        projection_repository.py
        raw_manifest_repository.py
      services/
        journal_command_service.py
        journal_query_service.py
        review_service.py
        projection_service.py
```

This does **not** require deleting the current SQLite code in Phase 1.

### 7. Alembic Expectations

Phase 1 must include:

- Alembic initialized
- one initial revision for Postgres platform tables
- idempotent local setup path

Required result:

- fresh PostgreSQL DB can be created from zero with migrations only

### 8. Core Indexes To Implement First

These are the must-have first-wave indexes.

#### `treatment_journal_rows`

- unique `(treatment_id, row_code)`
- `(treatment_id, snapshot_time ASC)`
- `(treatment_id, row_kind, snapshot_time ASC)`
- partial `(treatment_id, snapshot_time ASC) WHERE is_deleted = FALSE`

#### `treatment_status_events`

- `(treatment_id, event_time ASC)`
- `(device_id, event_time DESC)`

#### `treatment_notes`

- `(treatment_id, created_at ASC)`

#### `snapshot_originals`

- unique `(treatment_id, row_code)`
- `(treatment_id, snapshot_time ASC)`

#### `snapshot_audit_log`

- `(treatment_id, created_at DESC)`
- `(treatment_id, row_code, created_at DESC)`

#### `treatment_list_projection`

- `(outcome, start_time DESC)`
- `(approval_status, start_time DESC)`
- `(patient_id, start_time DESC)`

### 9. Command Endpoints Required In Phase 1

Do not wait until full migration to define the new API shape.

The following command endpoints should exist or be stubbed in Phase 1:

#### Journal commands

- `POST /api/v1/treatments/{id}/commands/edit-existing-snapshot-values`
- `POST /api/v1/treatments/{id}/commands/restore-existing-snapshot`

#### Review commands

- `POST /api/v1/treatments/{id}/commands/submit-review`
- `POST /api/v1/treatments/{id}/commands/approve`
- `POST /api/v1/treatments/{id}/commands/reject`
- `POST /api/v1/treatments/{id}/commands/unlock`

#### Notes / patient commands

- `POST /api/v1/treatments/{id}/commands/update-patient-context`
- `POST /api/v1/treatments/{id}/commands/update-clinical-notes`
- `POST /api/v1/treatments/{id}/commands/add-note`

### 10. Commands That Must Not Exist In Clinical UI API

Do not expose or preserve as first-class clinical commands:

- `fill-gap`
- `restore-missing-row`
- `add-hour`
- generic `delete snapshot row`

If a temporary compatibility endpoint still exists in old code, do not extend it.

### 11. Service Responsibilities

#### `journal_command_service`

Owns:

- edit existing row values
- restore existing row from originals
- validation of allowed manual fields
- optimistic concurrency checks
- audit log creation

Must enforce:

- no mutation of `snapshot_time`
- row exists for edit
- only safe fields are editable
- role/policy rules

#### `journal_query_service`

Owns:

- treatment detail journal load
- review compare load
- timeline ordering by `snapshot_time`

#### `review_service`

Owns:

- submit
- approve
- reject
- unlock
- state transition logging

#### `projection_service`

Owns:

- maintaining `treatment_list_projection`

### 12. Field Editing Rules

Backend must enforce allowlists.

Editable by nurse on existing stable rows:

- `heparin_bolus`
- `heparin_rate`
- `duosol_count`
- `prismasol_count`
- `filter_type`
- `kali`
- `notes`
- citrate-related allowed manual fields where applicable

Not editable as manual value fields:

- `qb`
- `qd`
- `qs`
- `qpbp`
- `pa`
- `pv`
- `pbe`
- `tmp`
- `uf_total`
- `uf_hourly`

### 13. Compatibility Strategy

Phase 1 backend must support additive rollout.

That means:

- new command endpoints can coexist with old endpoints temporarily
- command services should be written first
- legacy routes can internally delegate to command services where safe
- do not remove old endpoints until frontend and parity are ready

### 14. Audit Requirements

Every manual mutation command must write to `snapshot_audit_log`.

At minimum log:

- treatment id
- row code
- action
- changed field
- old value
- new value
- operator name
- operator role
- timestamp

### 15. Verification Required Before Handing Off

#### TASK-107 must prove

- PostgreSQL schema boots cleanly
- migrations run from zero
- required indexes exist
- table names and columns match approved architecture

#### TASK-108 must prove

- command endpoints boot
- commands do not mutate `snapshot_time`
- commands enforce policy
- audit rows are written
- compatibility map is documented

### 16. Suggested Order Of Work

#### Step 1

- bootstrap SQLAlchemy base, engine, session, Alembic

#### Step 2

- implement models for:
  - `treatments`
  - `treatment_journal_rows`
  - `treatment_review_state`
  - `snapshot_originals`
  - `treatment_notes`
  - `snapshot_audit_log`
  - `treatment_list_projection`
  - `raw_packet_manifest`

#### Step 3

- implement repositories

#### Step 4

- implement command services

#### Step 5

- add command endpoints

#### Step 6

- document compatibility path for old endpoints

#### Step 7

- hand off to frontend and QA

### 17. Definition Of Backend Phase 1 Done

Backend Phase 1 is done only if:

1. PostgreSQL foundation schema exists in SQLAlchemy + Alembic
2. command services exist
3. command endpoints exist or are stubbed with final request shape
4. audit integration exists
5. parity handoff notes are written

If any one of those is missing, `TASK-107` or `TASK-108` is not done.
