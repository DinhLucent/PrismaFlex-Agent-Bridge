# Treatment Journal: Old vs New Architecture Review

Status: Review artifact  
Audience: CTO, backend reviewers, external experts, QA, browser-test reviewers  
Purpose: Give a **visual, side-by-side evaluation pack** for the Treatment Journal migration from legacy SQLite architecture to the new PostgreSQL-based data platform.

---

## 1. Executive Summary

This document compares:

- the **old Treatment Journal architecture** built around a monolithic SQLite wrapper and a spreadsheet-like mutation model
- the **new Treatment Journal architecture** built around PostgreSQL, SQLAlchemy, repositories, command/query services, and raw-manifest separation

It is meant for **eyeball review**, not implementation.

Use this when you want to quickly answer:

1. What changed structurally?
2. Which modules moved where?
3. Which workflows are safer now?
4. Which risks still need stabilization before production sign-off?

---

## 2. High-Level Verdict

### Old system

Strengths:
- Fast to bootstrap
- Simple local deployment
- Good enough for early single-machine capture

Weaknesses:
- SQLite single-writer mindset
- monolithic treatment DB service
- UI and backend both had too much freedom to mutate timeline shape
- chronology correctness was fragile
- audit and review concerns were layered onto a table-centric implementation

### New system

Strengths:
- Correct architectural direction for multi-user clinical workflow
- PostgreSQL operational DB
- wide-row journal retained for usability and reporting
- raw telemetry separated from OLTP journal tables
- projection table retained
- review/audit/originals become first-class tables

Weaknesses still seen in current implementation branch:
- some runtime paths still assume old SQLite contracts
- command-driven API exists but is not fully enforced end-to-end yet
- raw manifest integration still needs cleanup
- release readiness is not the same as sprint completion

---

## 3. Side-by-Side Architecture

### 3.1 Old architecture

```mermaid
flowchart TD
    A["Telemetry packets"] --> B["TreatmentRecorderService"]
    A --> C["TreatmentSnapshotService"]
    A --> D["RawDataStreamer"]

    B --> E["TreatmentDatabase (SQLite monolith)"]
    C --> E
    D --> F["JSONL / raw files"]

    G["Treatment Router"] --> E
    H["Review / Journal UI"] --> G

    E --> I["treatments"]
    E --> J["treatment_hourly_snapshots"]
    E --> K["treatment_status_log"]
    E --> L["treatment_phases"]
    E --> M["treatment_index"]
    E --> N["snapshot_originals"]
    E --> O["treatment_notes"]
```

### 3.2 New architecture

```mermaid
flowchart TD
    A["Telemetry packets"] --> B["TreatmentRecorderService"]
    A --> C["TreatmentSnapshotService"]
    A --> D["RawDataStreamer"]

    B --> E["PostgresTreatmentDB adapter"]
    C --> E
    D --> F["Raw chunk store (JSONL / Parquet)"]
    D --> G["raw_packet_manifest"]

    H["Legacy Router v1"] --> E
    I["Command Router v2"] --> J["JournalCommandService"]
    I --> K["JournalQueryService"]
    I --> L["ReviewService"]
    L --> M["ProjectionService"]

    J --> N["Repositories"]
    K --> N
    L --> N
    M --> N

    N --> O["PostgreSQL OLTP"]
    O --> P["treatments"]
    O --> Q["treatment_journal_rows"]
    O --> R["treatment_review_state"]
    O --> S["snapshot_originals"]
    O --> T["snapshot_audit_log"]
    O --> U["treatment_notes"]
    O --> V["treatment_list_projection"]
    O --> W["treatment_status_events"]
    O --> X["treatment_phases"]
```

---

## 4. Module Map: Old vs New

| Concern | Old architecture | New architecture | Review comment |
| --- | --- | --- | --- |
| Treatment master persistence | `backend/_trash/treatment_database.py` -> `treatments` in SQLite | `backend/db/postgres/models/treatments.py` + repositories | Better separation in new design |
| Journal rows | `treatment_hourly_snapshots` in SQLite | `treatment_journal_rows` in PostgreSQL | New name is cleaner and closer to domain |
| Review state | embedded/implicit behavior | `treatment_review_state` table | Strong improvement |
| Original snapshot freeze | `snapshot_originals` in SQLite | `snapshot_originals` in PostgreSQL JSONB | Good carry-forward |
| Manual edit audit | weak/row-level only | `snapshot_audit_log` | Correct direction |
| List/history | `treatment_index` | `treatment_list_projection` | Keeps fast list UX |
| Raw telemetry | loose JSONL side path | chunk files + `raw_packet_manifest` | Good architecture, still needs runtime stabilization |
| DB access style | one monolithic wrapper | models + repositories + services + adapter | Much better long-term maintainability |
| API style | mixed CRUD-ish behavior | command router `/api/v2/treatments/...` | Right direction, not fully enforced yet |

---

## 5. Core Schema Comparison

### 5.1 Old SQLite core tables

```mermaid
erDiagram
    treatments ||--o{ treatment_phases : has
    treatments ||--o{ treatment_status_log : logs
    treatments ||--o{ treatment_hourly_snapshots : has
    treatments ||--o{ treatment_config : has
    treatments ||--o{ treatment_notes : has
    treatments ||--o{ snapshot_originals : stores
    treatments ||--|| treatment_index : projects
```

### 5.2 New PostgreSQL core tables

```mermaid
erDiagram
    treatments ||--o{ treatment_phases : has
    treatments ||--o{ treatment_status_events : logs
    treatments ||--o{ treatment_journal_rows : has
    treatments ||--o{ treatment_notes : has
    treatments ||--o{ snapshot_audit_log : records
    treatments ||--o{ raw_packet_manifest : references
    treatments ||--o| treatment_config : config
    treatments ||--|| treatment_review_state : review
    treatments ||--|| treatment_list_projection : projects
    treatments ||--o{ snapshot_originals : freeze_source
```

### 5.3 Table-by-table mapping

| Old SQLite | New PostgreSQL | Status |
| --- | --- | --- |
| `treatments` | `treatments` | retained and expanded |
| `treatment_hourly_snapshots` | `treatment_journal_rows` | renamed and formalized |
| `treatment_status_log` | `treatment_status_events` | renamed and improved |
| `treatment_index` | `treatment_list_projection` | renamed and formalized |
| `snapshot_originals` | `snapshot_originals` | retained |
| `treatment_notes` | `treatment_notes` | retained |
| `treatment_config` | `treatment_config` | retained |
| raw files only | `raw_packet_manifest` + raw chunks | upgraded architecture |
| implicit review flags | `treatment_review_state` | new |
| weak edit trace | `snapshot_audit_log` | new |

---

## 6. Workflow Comparison

### 6.1 Old workflow

```mermaid
flowchart LR
    A["Packet"] --> B["Recorder"]
    A --> C["Snapshot service"]
    C --> D["SQLite: treatment_hourly_snapshots"]
    B --> E["SQLite: treatments / status log / index"]
    F["Journal UI"] --> G["Router"]
    G --> D
    G --> E
```

Weaknesses:
- one DB wrapper did too much
- chronology and edit policy were layered on top of generic update paths
- timeline-structure actions could collide with active recording behavior

### 6.2 New target workflow

```mermaid
flowchart LR
    A["Packet"] --> B["Recorder"]
    A --> C["Snapshot capture"]
    B --> D["Treatment master update"]
    C --> E["Journal row upsert (auto path)"]
    A --> F["Raw chunk writer"]

    F --> G["Chunk files"]
    F --> H["raw_packet_manifest"]

    I["Nurse UI"] --> J["edit_existing_snapshot_values"]
    I --> K["submit_review"]
    L["Doctor UI"] --> M["approve / reject / unlock"]

    J --> N["JournalCommandService"]
    K --> O["ReviewService"]
    M --> O

    N --> P["PostgreSQL"]
    O --> P
```

Strengths:
- clearer ownership
- audit and review are explicit
- raw path no longer overloads OLTP tables
- projection remains optimized for list screens

---

## 7. What Changed in Design Philosophy

| Area | Old philosophy | New philosophy |
| --- | --- | --- |
| Journal | spreadsheet-like mutable table | clinical record with policy and audit |
| Edit behavior | update row directly | command-driven mutation with audit |
| Review | layered onto existing data path | first-class workflow state |
| Raw storage | sidecar local file | sidecar file + manifest contract |
| List/history | convenience index | intentional projection model |
| Backend boundary | monolith wrapper | separated repositories and services |
| DB role | local persistence | operational source of truth |

---

## 8. What Is Architecturally Better in the New System

### Strong improvements

1. **Wide-row retained**
- Correct choice for clinical grid/reporting shape
- Avoids EAV query complexity

2. **Projection retained**
- Prevents list/history screens from joining heavy row tables

3. **Raw telemetry separated**
- Protects OLTP from high-write bursts

4. **Review state separated**
- Makes workflow explicit and testable

5. **Audit table introduced**
- Supports manual edit trace properly

6. **Command API introduced**
- Correct direction for clinical safety

---

## 9. What Still Needs Care Before Calling the New System “Clean”

This section is the reality check.

### 9.1 Architecture on paper vs runtime in code

The new schema is mostly correct, but the runtime branch still appears to have some mixed layers:
- some legacy helper expectations remain in active services
- some services still think in SQLite-style helper methods
- some raw manifest integration is still inconsistent

### 9.2 Dual architecture smell

At the moment there is a risk of:
- new repositories/services existing
- while the old adapter-style compatibility layer still remains primary in parts of runtime

That is acceptable temporarily during migration, but not as a permanent state.

### 9.3 Raw manifest is the most fragile area

This is currently the place most likely to fail if:
- treatment creation and raw manifest writes are not ordered strictly
- model / migration / repository contract drift
- archive worker and streamer disagree on manifest lifecycle

---

## 10. Visual Review Checklist

Use this section when reviewing the migration quickly by eye.

### A. Schema review

Ask:
- Is `treatment_journal_rows` clearly the new source of truth?
- Is `snapshot_time` treated as clinical chronology, not edit time?
- Is `treatment_list_projection` still present?
- Is `raw_packet_manifest` only metadata, not raw payload?
- Are review and audit tables clearly separated?

### B. Backend review

Ask:
- Does the runtime still contain references to `treatment_hourly_snapshots`?
- Are `/api/v2` commands truly policy-driven?
- Are query services returning structured DTOs or still placeholders?
- Is audit old/new trustworthy?

### C. Workflow review

Ask:
- Can a stable row be edited without chronology drift?
- Can review state change without bypassing policy?
- Can raw chunks be written without FK errors?
- Is same-patient continuation still safe?

---

## 11. Recommended Review Artifacts

To evaluate old vs new migration by eye, reviewers should open these in order:

1. [implementation_plan.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/implementation_plan.md)
2. [TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC.md)
3. [BACKEND_POSTGRES_PHASE1_HANDOFF.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/BACKEND_POSTGRES_PHASE1_HANDOFF.md)
4. [POSTGRES_RELEASE_READINESS_GATE.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/POSTGRES_RELEASE_READINESS_GATE.md)
5. [backend/_trash/treatment_database.py](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/_trash/treatment_database.py)
6. [backend/db/postgres/models](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/db/postgres/models)

---

## 12. CTO Judgment

If the question is:

**“Is the new overall architecture better than the old one?”**

Answer: **Yes, clearly.**

If the question is:

**“Is the current implementation already as clean as the target architecture?”**

Answer: **Not yet.**

So the right conclusion is:

- **Architecture direction:** approved
- **Core data model:** largely correct
- **Runtime migration quality:** still needs stabilization before production sign-off

That is the honest expert answer.
