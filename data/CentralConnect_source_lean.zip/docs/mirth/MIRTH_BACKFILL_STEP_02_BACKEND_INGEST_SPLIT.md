# Step 02 — Backend Ingest: Live/Backfill Split

## Muc tieu cua buoc nay

Tai buoc 01, Mirth da tao payload chuan voi `meta.mode = "BACKFILL"` hoac `"LIVE"`.
Tai buoc 02 nay, backend nhan payload do va **tach thanh 2 duong di hoan toan rieng biet**.

Muc tieu:

- tach route: 2 endpoint rieng (`/telemetry/live` va `/telemetry/backfill`)
- tach service: 2 ingest service rieng biet
- tach queue: 2 async queue rieng biet
- dam bao BACKFILL khong keo theo websocket, alarm, heartbeat, live recovery

---

## 1. Van de cua kien truc hien tai

Hien tai, toan bo du lieu di qua **1 duong ong duy nhat**:

```
POST /api/v1/telemetry
    → telemetry_queue (1 queue chung)
        → telemetry_worker (4 worker chung)
            → recorder.process_packet()     ← stateful session map
            → snapshot_svc.process_packet() ← stateful DeviceCache
            → event_svc.track_parameter_changes()
            → alarm_svc.process()
            → manager.broadcast()           ← websocket
```

Bug xay ra do:

1. `recorder` dung chung `_live_sessions` va `_backfill_sessions` → session lan nhau
2. `snapshot_svc` dung `DeviceCache` theo `device_id` → backfill ghi de live cache
3. `event_svc.track_parameter_changes()` → backfill tao ra event gia (WAS alert)
4. `alarm_svc.process()` → backfill tao ra alarm gia
5. `manager.broadcast()` → backfill do du lieu cu len UI realtime

---

## 2. Kien truc moi

```mermaid
flowchart TD
    M1["Mirth Live Channel"] -->|"POST /api/v1/telemetry/live"| R1["receive_live()"]
    M2["Mirth Backfill Channel"] -->|"POST /api/v1/telemetry/backfill"| R2["receive_backfill()"]

    R1 --> Q1["live_queue\n(asyncio.Queue)"]
    R2 --> Q2["backfill_queue\n(asyncio.Queue)"]

    Q1 --> W1["live_worker (x4)\n━━━━━━━━━━━━━━\n1. Enrichment\n2. WebSocket broadcast\n3. Alarm processing\n4. Live Recorder\n5. Snapshot Projector\n6. Event tracking (WAS)"]

    Q2 --> W2["backfill_worker (x2)\n━━━━━━━━━━━━━━\n1. Backfill Importer\n2. Snapshot Projector\n3. Raw manifest"]

    W1 --> DB["PostgreSQL"]
    W2 --> DB

    W1 --> WS["WebSocket / UI"]
    W2 -.->|"KHONG broadcast"| WS
```

### Nguyen tac

| Thao tac | LIVE | BACKFILL |
| --- | :---: | :---: |
| WebSocket broadcast | ✅ | ❌ |
| Alarm processing | ✅ | ❌ |
| Event tracking (WAS changes) | ✅ | ❌ |
| Trend storage | ✅ | ❌ |
| Treatment Recorder (stateful) | ✅ | ❌ |
| Backfill Importer (stateless) | ❌ | ✅ |
| Snapshot Projector | ✅ | ✅ |
| Raw manifest/chunk ghi | ✅ | ✅ |
| device_mode_lock | ✅ | ✅ |

---

## 3. Thay doi route trong `main.py`

### 3.1. Endpoint moi

```python
# --- LIVE Ingestion ---
@app.post("/api/v1/telemetry/live")
async def receive_live(request: Request, data: Dict[str, Any] = Body(...)):
    """Live telemetry from Mirth Live Channel."""
    meta = data.get("meta", {})
    device_id = str(meta.get("device_id", "unknown")).strip()

    # Guard: reject if device is locked to BACKFILL
    if device_mode_registry.get(device_id) == "BACKFILL":
        return JSONResponse(status_code=409, content={
            "error": "DEVICE_MODE_CONFLICT",
            "detail": f"{device_id} is currently in BACKFILL mode"
        })

    device_mode_registry[device_id] = "LIVE"
    await request.app.state.live_queue.put({
        "t_start": time.perf_counter(),
        "data": data
    })
    return {"status": "queued", "mode": "live"}


# --- BACKFILL Ingestion ---
@app.post("/api/v1/telemetry/backfill")
async def receive_backfill(request: Request, data: Dict[str, Any] = Body(...)):
    """Historical replay from Mirth Backfill Channel."""
    meta = data.get("meta", {})
    device_id = str(meta.get("device_id", "unknown")).strip()

    # Guard: reject if device is locked to LIVE
    if device_mode_registry.get(device_id) == "LIVE":
        return JSONResponse(status_code=409, content={
            "error": "DEVICE_MODE_CONFLICT",
            "detail": f"{device_id} is currently in LIVE mode"
        })

    device_mode_registry[device_id] = "BACKFILL"
    await request.app.state.backfill_queue.put({
        "t_start": time.perf_counter(),
        "data": data
    })
    return {"status": "queued", "mode": "backfill"}
```

### 3.2. Backward Compatibility

Endpoint cu `POST /api/v1/telemetry` van giu lai, nhung chi lam **router**:

```python
@app.post("/api/v1/telemetry")
async def receive_telemetry(request: Request, data: Dict[str, Any] = Body(...)):
    """Legacy endpoint — routes to live or backfill based on meta.mode."""
    meta = data.get("meta", {})
    mode = meta.get("mode", "").upper()

    if mode == "BACKFILL":
        return await receive_backfill(request, data)
    else:
        return await receive_live(request, data)
```

---

## 4. Thay doi lifecycle trong `lifespan()`

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Queues
    app.state.live_queue = asyncio.Queue(maxsize=10000)
    app.state.backfill_queue = asyncio.Queue(maxsize=5000)

    # Services
    app.state.treat_db = TreatmentDatabase()
    app.state.streamer = RawDataStreamer()

    # LIVE services (stateful)
    app.state.recorder = TreatmentRecorderService(app.state.treat_db, app.state.streamer)
    app.state.snapshot_svc = TreatmentSnapshotService(app.state.treat_db)

    # BACKFILL services (stateless)
    app.state.backfill_importer = HistoricalBackfillImporter(app.state.treat_db)

    # Workers
    app.state.live_workers = [
        asyncio.create_task(live_worker(app)) for _ in range(4)
    ]
    app.state.backfill_workers = [
        asyncio.create_task(backfill_worker(app)) for _ in range(2)
    ]
    ...
```

---

## 5. Live Worker — chi danh cho LIVE

Worker nay giu nguyen logic hien tai (enrichment, WS, alarm, recorder, snapshot):

```python
async def live_worker(app: FastAPI):
    queue = app.state.live_queue
    while True:
        job = await queue.get()
        data = job['data']
        meta = data.get("meta", {})
        header = data.get("header", data.get("s_header", {}))
        body = data.get("body", data.get("s_body", {}))
        device_id = str(meta.get("device_id", "unknown")).strip()
        timestamp_str = meta.get("timestamp") or header.get("timestamp")

        async with _get_device_lock(device_id):
            # 1. Enrichment (ref_db)
            # 2. WebSocket broadcast ← CHI LIVE
            # 3. Alarm processing ← CHI LIVE
            # 4. recorder.process_packet(is_live=True) ← CHI LIVE
            # 5. snapshot_svc.process_packet()
            # 6. event_svc.track_parameter_changes() ← CHI LIVE
            # 7. OC detection + snapshot
            pass

        queue.task_done()
```

---

## 6. Backfill Worker — chi danh cho BACKFILL

Worker nay don gian hon nhieu, khong co side effect realtime:

```python
async def backfill_worker(app: FastAPI):
    queue = app.state.backfill_queue
    importer = app.state.backfill_importer
    while True:
        job = await queue.get()
        data = job['data']
        meta = data.get("meta", {})
        header = data.get("header", data.get("s_header", {}))
        body = data.get("body", data.get("s_body", {}))
        device_id = str(meta.get("device_id", "unknown")).strip()
        timestamp_str = meta.get("timestamp") or header.get("timestamp")

        async with _get_device_lock(device_id):
            # 1. Parse packet time
            pkt_time = parse_time(timestamp_str)

            # 2. Resolve treatment (stateless — lookup or create)
            treatment_id, start_time = importer.resolve_treatment(
                device_id, header, pkt_time
            )

            # 3. Project snapshot (deterministic)
            importer.process_packet(
                treatment_id, device_id, pkt_time, start_time, body
            )

            # KHONG lam:
            # - websocket broadcast
            # - alarm processing
            # - event tracking (WAS)
            # - trend storage
            # - live session recovery

        queue.task_done()
```

---

## 7. Device Mode Lock

```python
# In-memory registry: device_id -> "LIVE" | "BACKFILL" | None
device_mode_registry: Dict[str, str] = {}
```

### API de quan ly

```python
@app.post("/api/v1/devices/{device_id}/mode")
async def set_device_mode(device_id: str, data: Dict[str, Any] = Body(...)):
    """Admin endpoint to switch device mode."""
    mode = data.get("mode", "").upper()
    if mode not in ("LIVE", "BACKFILL", "RESET"):
        raise HTTPException(400, "mode must be LIVE, BACKFILL, or RESET")
    
    if mode == "RESET":
        device_mode_registry.pop(device_id, None)
    else:
        device_mode_registry[device_id] = mode
    
    return {"device_id": device_id, "mode": device_mode_registry.get(device_id, "NONE")}


@app.get("/api/v1/devices/mode")
async def get_all_device_modes():
    """View current mode lock for all devices."""
    return device_mode_registry
```

---

## 8. So do toan canh Step 01 + Step 02

```mermaid
flowchart LR
    subgraph MIRTH
        A["Raw Packet"] --> B["Backfill Channel\n(mode=BACKFILL)"]
        A --> C["Live Channel\n(mode=LIVE)"]
    end

    subgraph BACKEND_ROUTE
        B -->|"POST /telemetry/backfill"| D["receive_backfill()"]
        C -->|"POST /telemetry/live"| E["receive_live()"]
    end

    subgraph BACKEND_QUEUE
        D --> F["backfill_queue"]
        E --> G["live_queue"]
    end

    subgraph BACKEND_WORKER
        F --> H["backfill_worker (x2)"]
        G --> I["live_worker (x4)"]
    end

    subgraph SERVICES
        H --> J["BackfillImporter"]
        H --> K["Snapshot Projector"]

        I --> L["Live Recorder"]
        I --> K
        I --> M["Alarm Service"]
        I --> N["Event Service"]
        I --> O["WebSocket"]
    end

    J --> DB["PostgreSQL"]
    K --> DB
    L --> DB
```

---

## 9. Service nao nhan gi

| Service | Nhan tu | Lam gi |
| --- | --- | --- |
| `TreatmentRecorderService` | `live_worker` | Tao/resume/close treatment session (stateful) |
| `TreatmentSnapshotService` | `live_worker` | Project hourly snapshot + OC (stateful cache) |
| `HistoricalBackfillImporter` | `backfill_worker` | Tao treatment lich su + project snapshot (stateless) |
| `SmartAlarmService` | `live_worker` | Xu ly alarm debouncing |
| `EventService` | `live_worker` | Track parameter changes (WAS) |
| `ConnectionManager` | `live_worker` | Broadcast WebSocket |

---

## 10. Khong lam gi o buoc nay

- khong sua logic ben trong `TreatmentRecorderService` hoac `TreatmentSnapshotService`
- khong thay doi schema database
- khong sua Mirth transform (da xong o Step 01)
- khong sua frontend

---

## 11. Acceptance criteria

1. Packet co `mode=BACKFILL` khong di qua `live_worker`
2. Packet co `mode=LIVE` khong di qua `backfill_worker`
3. Cung `device_id` khong the vua LIVE vua BACKFILL (409 Conflict)
4. Backfill khong tao alarm, khong broadcast websocket
5. Endpoint cu `/api/v1/telemetry` van hoat dong (backward compatible)
6. `device_mode_registry` co the reset qua admin API
7. Queue backfill va live co size rieng, khong tranh chap

---

## 12. Buoc tiep theo

Sau khi Step 02 duoc implement, cac buoc tiep theo la:

- **Step 03**: Nang cap `HistoricalBackfillImporter` de tu tao treatment lich su (stateless treatment builder)
- **Step 04**: Handoff protocol — chuyen device tu BACKFILL → LIVE an toan
- **Step 05**: QA hardening — replay 6h nhanh, cutover, va song song test
