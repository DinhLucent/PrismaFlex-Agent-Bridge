# Step 04 — Handoff Protocol: BACKFILL → LIVE

## Muc tieu

Khi backfill xong cho mot device, operator can chuyen sang LIVE.
Buoc nay phai dam bao:

1. Importer flush het du lieu con cache
2. Backfill session dong dung cach
3. Mode lock reset
4. Device san sang nhan LIVE packet

## API Endpoint

```
POST /api/v1/devices/{device_id}/handoff
Body: { "from": "BACKFILL", "to": "LIVE" }
```

## Logic

1. Kiem tra device dang o mode BACKFILL
2. `backfill_importer.flush_treatment()` cho device
3. `recorder.clear_backfill_session(device_id)` 
4. `device_mode_registry[device_id] = "LIVE"`
5. Return success

## Acceptance criteria

1. Sau handoff, device co the nhan LIVE packet
2. Backfill data da duoc flush hoan toan
3. Backfill session khong con trong memory
4. Khong co data loss
