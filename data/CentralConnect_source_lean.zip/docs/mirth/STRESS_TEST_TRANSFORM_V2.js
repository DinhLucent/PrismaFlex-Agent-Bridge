/* ═══════════════════════════════════════════════════════════════
 * MIRTH STRESS TEST TRANSFORM v2 — BACKFILL MODE (Max Speed)
 * ═══════════════════════════════════════════════════════════════
 * TASK-130 | Spec v2.1 §12.3-12.5
 * 
 * CHANGES from v1:
 *   1. REMOVED: new Date().toISOString() fallback → REJECT if no timestamp
 *   2. ADDED:   output.meta.mode = "BACKFILL" → tells backend this is replay
 *   3. KEPT:    Max speed (no Thread.sleep)
 * 
 * Copy this code into Mirth Connect → Channel → Source Transformer
 * ═══════════════════════════════════════════════════════════════ */

var rawData = connectorMessage.getRawData();
var input = (rawData && rawData != '') ? JSON.parse(rawData) : {};

// 1. VALIDATE: machine_id is required
if (!input.s_header || !input.s_header.machine_id) {
    channelMap.put('skipMessage', true);
    return false; 
}

var machineId = input.s_header.machine_id;

// 2. EXTRACT ORIGINAL TIMESTAMP — NEVER fabricate wall-clock timestamps
//    Clinical data integrity: historical timestamps MUST be preserved
var originalTime = input.s_header.timestamp;
if (!originalTime && input.timestamp) {
    originalTime = input.timestamp;
}

// ▼▼▼ CRITICAL FIX (v2): Reject packets without original timestamp ▼▼▼
if (!originalTime) {
    channelMap.put('skipMessage', true);
    logger.error('[STRESS_TEST] REJECTED: Packet from machine ' + machineId + 
                 ' has no original timestamp. Cannot use wall clock for clinical data.');
    return false;
}
// ▲▲▲ END FIX ▲▲▲

// 3. BUILD OUTPUT (Clean Structure)
var output = {};
output.meta = {};
output.meta.device_id = "PF_" + ("000" + machineId).slice(-3);
output.meta.timestamp = originalTime;     // Always original, never fabricated
output.meta.packet_num = input.packet_num;
output.meta.mode = "BACKFILL";            // ← NEW: Tells backend this is replay data

output.header = input.s_header;
output.header.timestamp = originalTime;   // Consistent with meta
output.body = input.s_body;

// 4. SEND AT MAX SPEED (No delay)
// java.lang.Thread.sleep(5000);  // REMOVED — max throughput

msg = JSON.stringify(output);
