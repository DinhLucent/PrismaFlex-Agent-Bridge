# Step 03 — Backfill Worker: Wire HistoricalBackfillImporter

## Muc tieu

Tai Step 02, `backfill_worker` da tach khoi live worker nhung van dung:

1. `TreatmentSnapshotService.process_packet()` — stateful cache (`DeviceCache`)
2. Shared `_caches` dict voi live worker

Step 03 chuyen `backfill_worker` sang dung `HistoricalBackfillImporter.process_packet()` 
cho phan snapshot projection, loai bo hoan toan viec chia se state voi live path.

## Thay doi

### `backfill_worker` trong `main.py`

**Truoc (Step 02):**
```python
# backfill_worker goi snapshot_svc (SHARED stateful cache)
await asyncio.to_thread(
    app.state.snapshot_svc.process_packet,
    device_id, timestamp_str, treatment_id, header, body
)
```

**Sau (Step 03):**
```python
# backfill_worker goi backfill_importer (RIENG, per-treatment cache)
pkt_time = parse_clinical_time(timestamp_str)
treatment = get_treatment_for_backfill(treatment_id)
await asyncio.to_thread(
    app.state.backfill_importer.process_packet,
    treatment_id, device_id, pkt_time, treatment.started_at, body
)
```

### `HistoricalBackfillImporter`

Them `device_id` tracking vao `_batch_cache` de `_get_device_id()` khong can query DB.

### Flush on treatment end

Khi `recorder.process_packet()` tra ve treatment close → goi `backfill_importer.flush_treatment()`.

## Acceptance criteria

1. `backfill_worker` KHONG goi `snapshot_svc.process_packet()`
2. `backfill_worker` goi `backfill_importer.process_packet()` cho moi packet
3. Backfill snapshot ghi dung `source='BACKFILL'`
4. Live DeviceCache khong bi anh huong boi backfill
