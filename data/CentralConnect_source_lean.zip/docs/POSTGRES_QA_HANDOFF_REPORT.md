# PostgreSQL QA Handoff Report

Date: 2026-04-04  
Prepared by: `cto-agent`  
Audience: `qa-lead-agent`, Codex QA, browser QA operators

## 1. Current Project State

Treatment Journal has already gone through:

- architecture redesign
- PostgreSQL schema foundation
- command-driven API introduction
- chronology parity verification
- release-gate stabilization work

Task-board status is strong:

- Sprint 4: complete
- Sprint 5/6: complete per execution plan

But release sign-off is **not closed yet**.

Reason:

- QA still needs to validate the PostgreSQL runtime path in real usage
- one known backend hardening concern remains around stable-row edit enforcement

## 2. What Is Already Strong

These areas currently look good enough to move into QA:

- PostgreSQL parity report shows `77/77 PASS`
- legacy SQLite runtime refs were removed from the reviewed Postgres path
- raw manifest schema drift was aligned
- manifest FK ordering was hardened
- query endpoints now return structured JSON
- audit old/new capture was improved
- review role gates were tightened

## 3. Known Open Concern

### Stable-row policy

Backend edit command may still allow mutation of a row that is not yet stable.

This is not a theoretical architecture note only. QA should actively try to
prove or disprove it.

Expected product policy:

- nurse edits should apply only to existing, stable rows
- unstable rows should be blocked server-side, not just hidden in UI

QA must record whether:

- the UI blocks it
- the backend blocks it
- both block it
- neither blocks it

## 4. What QA Must Check

There are 2 required test packs:

### Pack A - General runtime/browser QA

Use:

- [TREATMENT_JOURNAL_RUNTIME_QA_CHECKLIST.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/TREATMENT_JOURNAL_RUNTIME_QA_CHECKLIST.md)

This covers:

- detail/review/open flows
- chronology
- operator check-in
- nurse/doctor policy
- review workflow
- print/export parity
- Postgres sanity checks

### Pack B - Backfill to live handoff

Use:

- [BACKFILL_LIVE_HANDOFF_QA_MATRIX.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/BACKFILL_LIVE_HANDOFF_QA_MATRIX.md)

This covers:

- historical replay arriving fast but in correct time order
- backfill session continuity
- same-patient continuation
- fresh start detection
- backfill -> live promote/close behavior
- raw/journal/projection integrity after handoff

## 5. Recommended QA Execution Order

Run in this order:

1. Smoke `S1-S10`
2. Chronology `JC1-JC6`
3. Nurse/doctor policy `NP1-NP6`, `RV1-RV7`
4. PostgreSQL sanity `PG1-PG6`
5. Backfill/live matrix `A -> B -> C`
6. Browser smoke with FLASH

## 6. Evidence QA Must Capture

For every fail:

- screenshot or video
- treatment id
- row code (`H00`, `H01`, `OC_01`, ...)
- role used
- exact click path
- whether fail is:
  - UI
  - API
  - chronology
  - policy
  - raw/manifest

For backend-related fails, also capture:

- timestamp
- relevant browser network call if possible
- backend log snippet if available

## 7. SQL Quick Checks

Use these during QA if database verification is needed.

### Tables present

```sql
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;
```

### Alembic migration state

```sql
SELECT * FROM alembic_version;
```

### Journal chronology

```sql
SELECT treatment_id, row_code, row_kind, snapshot_time, created_at, updated_at
FROM treatment_journal_rows
WHERE treatment_id = '<TREATMENT_ID>'
ORDER BY snapshot_time ASC, row_code ASC;
```

### Raw manifest continuity

```sql
SELECT treatment_id, chunk_index, first_timestamp, last_timestamp, packet_count, status
FROM raw_packet_manifest
WHERE treatment_id = '<TREATMENT_ID>'
ORDER BY chunk_index ASC;
```

## 8. What QA Should Treat as Release-Blocking

Any of the following should block release:

- chronology drift after edit or reload
- `OC_XX` pushed to the end
- wrong role can approve/reject/unlock
- operator flow fails on first mutation
- unstable row can be edited against policy
- raw manifest FK/schema runtime errors
- backfill/live handoff creates wrong treatment boundary
- detail/review/print/export disagree

## 9. Decoder / Payload Note

Journal currently consumes:

- `s_header`
- `s_body.parameters[]`

It maps selected PIDs into journal columns. If QA or backend needs help tracing a
packet into journal fields, use:

- [TREATMENT_JOURNAL_PACKET_TO_PID_MAPPING.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/TREATMENT_JOURNAL_PACKET_TO_PID_MAPPING.md)

## 10. Exit Decision Rule

QA may recommend:

- `GO FOR WIDER TRIAL`
- `GO WITH KNOWN LIMITATION`
- `NO-GO`

CTO release sign-off requires:

- no P0 or P1 runtime issue left open
- chronology stable
- backfill/live handoff stable
- policy enforcement acceptable
- no significant Postgres runtime error during QA session
