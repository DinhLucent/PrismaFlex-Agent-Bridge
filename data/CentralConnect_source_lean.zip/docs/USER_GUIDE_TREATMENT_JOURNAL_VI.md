# HƯỚNG DẪN SỬ DỤNG: NHẬT KÝ ĐIỀU TRỊ (TREATMENT JOURNAL)

_Phiên bản: 1.1 — Cập nhật: 2026-04-03_
_Phạm vi áp dụng: Bác sĩ, Điều dưỡng, Quản trị viên lâm sàng_

---

## 1. TỔNG QUAN

**Nhật ký Điều trị (Treatment Journal)** là module lưu trữ và quản lý toàn bộ dữ liệu vận hành máy, thông số sinh tồn và các can thiệp lâm sàng trong một phiên lọc máu liên tục (CRRT) trên hệ thống PrismaFlex. Module này đảm bảo tính **toàn vẹn dữ liệu gốc** (dữ liệu truyền từ máy) đồng thời cho phép **ghi nhận thao tác thủ công** với đầy đủ thông tin người thực hiện, cam kết không làm thay đổi thứ tự thời gian của hồ sơ bệnh án.

### Mục tiêu chính:

1. Tập hợp các thông số vận hành máy theo từng giờ (Hourly Buckets).
2. Ghi nhận mọi thay đổi y lệnh điều trị (Order Changes).
3. Đảm bảo quy trình phê duyệt khép kín (Điều dưỡng Đệ trình → Bác sĩ Phê duyệt).

---

## 2. QUY TRÌNH HOẠT ĐỘNG (WORKFLOW)

Dữ liệu trong Nhật ký Điều trị được thu thập từ hai nguồn song song:

### A. Nguồn Tự Động (Telemetry — Dữ liệu từ máy)

- Khi phiên lọc máu bắt đầu, hệ thống tự động chốt và ghi nhận các mốc thời gian theo giờ (H00, H01, H02...).
- Mốc **H00 (Baseline)** được khóa sau 60 giây đầu tiên nhằm lưu lại trạng thái khởi điểm của phiên điều trị.
- Khi có thay đổi y lệnh (ví dụ: thay đổi tốc độ bơm Heparin), hệ thống tự động bổ sung bản ghi **OC** (Order Change) xen kẽ giữa các mốc giờ.

### B. Nguồn Thủ Công (Thao tác của nhân viên y tế)

Sơ đồ dưới đây mô tả các giai đoạn và phân quyền tác động vào dữ liệu:

```
[Bắt đầu Phiên] --> (Hệ thống tự động ghi nhận dữ liệu mỗi giờ / khi đổi y lệnh)
                        │
                        v
[Phiên đang chạy] --> (Chỉ đọc dữ liệu / Chỉ được ghi chú đặc điểm lâm sàng)
                        │
                        v
[Kết thúc phiên] ----> (Điều dưỡng rà soát tổng thể, hiệu chỉnh nếu cần)
                        │
                        v
[Đệ trình duyệt] ---> (Phiên chuyển sang "Chờ duyệt" — Khóa quyền Điều dưỡng)
                        │
                        v
[Bác sĩ đánh giá] --> (Bác sĩ xem xét, hiệu chỉnh bổ sung, bấm "Phê duyệt")
                        │
                        v
[Đã Phê duyệt] -----> (TOÀN BỘ NHẬT KÝ BỊ KHÓA HỒ SƠ)
```

---

## 3. CƠ CHẾ ĐỊNH DANH NGƯỜI THAO TÁC (OPERATOR CHECK-IN)

**Nguyên tắc: Mọi thay đổi dữ liệu đều phải gắn liền với định danh của nhân viên y tế thực hiện.**

Trước khi thực hiện bất kỳ hiệu chỉnh nào (sửa số liệu, thêm dòng, đệ trình, phê duyệt...), hệ thống yêu cầu xác nhận danh tính:

1. **Hộp thoại xác nhận danh tính:** Khi bắt đầu thao tác ghi dữ liệu lần đầu, hệ thống hiển thị hộp thoại yêu cầu nhập họ tên Điều dưỡng hoặc Bác sĩ.
2. **Lưu phiên làm việc (Session):** Sau khi xác nhận, hệ thống ghi nhớ danh tính trên trình duyệt hiện tại. Các thao tác tiếp theo trong cùng phiên không yêu cầu nhập lại. Khi đóng trình duyệt, phiên danh tính sẽ kết thúc.
3. **Bàn giao ca trực (Handoff):** Khi bàn giao cho đồng nghiệp, người tiếp nhận bấm nút **[Đổi]** bên cạnh tên hiển thị trên đầu trang và cập nhật tên mới. Từ thời điểm đó, mọi thao tác sẽ được định danh dưới tên nhân sự mới.

---

## 4. CÁC TRẠNG THÁI KHÓA VÀ AN TOÀN LÂM SÀNG

Nhật ký tự động áp dụng chính sách khóa theo trạng thái phiên điều trị nhằm ngăn chặn sự can thiệp sai lệch vào hệ thống dữ liệu:

### 4.1. Đang Ghi Dữ Liệu (IN PROGRESS)

- Hệ thống lọc máu đang hoạt động và truyền dữ liệu liên tục.
- Toàn bộ bảng thông số vận hành **bị khóa chỉnh sửa**.
- Hệ thống chỉ cho phép nhập **Ghi chú Lâm sàng (Clinical Notes)** tại các mốc thời gian tương ứng để mô tả diễn biến bệnh nhân.

### 4.2. Chờ Phê Duyệt (PENDING REVIEW)

- Điều dưỡng đã hoàn tất đệ trình hồ sơ của ca lọc máu.
- Nhật ký phân quyền Điều dưỡng bị **khóa hoàn toàn**.
- Bác sĩ hoặc Quản trị viên lâm sàng vẫn có quyền rà soát và hiệu chỉnh.

### 4.3. Đã Phê Duyệt (APPROVED)

- Toàn bộ hồ sơ bệnh án điện tử bị **đóng băng (Locked)** chuẩn bị cho việc lưu trữ và in ấn.
- Vô hiệu hóa tính năng chỉnh sửa ở mọi cấp quyền.
- Nếu bát buộc phải đính chính y khoa, Bác sĩ hoặc Quản trị viên phải sử dụng chức năng **[Mở khóa — Unlock]**. Thao tác này bắt buộc ghi nhận vào nhật ký kiểm toán (Audit Trail).

> Khi một thao tác bị từ chối, hệ thống hiển thị thông báo ở góc màn hình cho biết nguyên nhân (ví dụ: "Không đủ quyền hạn", "Phiên đang ghi dữ liệu gốc — không thể can thiệp").

---

## 5. HƯỚNG DẪN CÁC THAO TÁC HIỆU CHỈNH

_(Các thao tác dưới đây chỉ khả dụng khi phiên lọc máu đã kết thúc và chưa được phê duyệt)_

### 5.1. Hiệu chỉnh ô dữ liệu (Edit Cell)

Trong trường hợp thông số ghi nhận bị sai lệch (ví dụ: nhiễu tín hiệu truyền), người dùng chọn trực tiếp vào ô cần tương tác và nhập giá trị chuẩn xác. Ô đã hiệu chỉnh sẽ hiển thị biểu tượng ✎ nhận diện sự can thiệp thủ công.
_Khi di chuột vào ô hoặc xuất báo cáo, hệ thống sẽ hiển thị minh bạch định danh người đã thực hiện hiệu chỉnh._

### 5.2. Khôi phục dữ liệu gốc (Restore)

Nếu cần hoàn tác một dữ liệu đã sửa rước đó, chọn bản ghi tương ứng và sử dụng lệnh **Khôi phục bản gốc**. Hệ thống sẽ truy xuất và hiển thị lại giá trị nguyên bản do máy lọc máu truyền lên (Raw Data).

### 5.3. Bổ sung khoảng trống theo dõi (Fill Gap)

Trong trường hợp mất kết nối mạng lưới kéo dài dẫn đến khuyết mốc theo dõi giờ, người dùng thiết lập chức năng **Fill Gap**, thiết lập mốc giờ cần cập nhật và nhập thủ công các thông số vận hành đã được điều dưỡng ghi chép trên giấy.

---

## 6. BẢO TOÀN TRÌNH TỰ THỜI GIAN (CHRONOLOGY)

Khi hiệu chỉnh dữ liệu tại một mốc giờ trong quá khứ, hệ thống **cố định vị trí thời gian gốc** của bản ghi trong hồ sơ. Ví dụ: nếu vào lúc 14:00 phát hiện số liệu lúc 10:00 (H02) bị sai lệch và tiến hành hiệu chỉnh, bản ghi H02 vẫn cố định tại vị trí 10:00 trong trình tự thời gian, tuyệt đối không bị di chuyển xuống cuối danh sách báo cáo.

Cơ chế này đảm bảo tính y khoa liên tục và chính xác cấu trúc hồ sơ khi Bác sĩ đọc bệnh án.

---

## 7. XUẤT DỮ LIỆU VÀ BÁO CÁO (EXPORT)

Sau khi hồ sơ hoàn thiện, Nhật ký Điều trị hỗ trợ các định dạng xuất hóa sau:

1. **Xuất PDF / In ấn:** Hiển thị trạng thái phê duyệt, định danh Bác sĩ phê duyệt, và chú thích rõ các ô dữ liệu có sự can thiệp thủ công.
2. **Xuất Excel:** Ghi nhận toàn bộ bảng liệu đính kèm cột Tracking định danh, phục vụ công tác thanh tra và kiểm toán y tế (Audit).

---

_Tài liệu thuộc hệ thống ICU-B Connect — PrismaFlex Device Manager._
