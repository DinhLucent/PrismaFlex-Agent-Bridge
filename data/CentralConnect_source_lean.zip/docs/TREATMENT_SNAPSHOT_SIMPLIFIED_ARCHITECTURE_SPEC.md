# Treatment Snapshot Simplified Architecture Spec

> Date: 2026-04-05
> Status: Proposed
> Scope: Treatment Journal snapshot generation, backfill/live separation, GAP semantics, and bug reduction

## Executive Decision

The current snapshot pipeline is too stateful. It mixes:

- treatment lifecycle
- live telemetry ingest
- historical backfill
- hourly snapshot projection
- order-change projection
- startup recovery

in one runtime path.

That design is the root reason the team keeps fixing one snapshot bug and creating another.

This spec proposes a simpler model:

- `Hourly snapshots` are determined only by `treatment_start_time` and `packet_time`
- `Order changes` are separate timeline events
- `GAP` is never filled in backend
- `Backfill` is a dedicated import mode, not the normal live runtime path

## Problem Summary

Observed classes of bugs:

- H00 infinite clamp during fast backfill
- FK timing race between `treatments` and `treatment_journal_rows`
- OC rows appearing without hourly rows
- auto gap-fill erasing true downtime
- recovery/resume state contaminating replay tests
- backfill behavior affecting live behavior

These bugs are not random. They come from a pipeline that uses mutable cache state like:

- `last_hour_label`
- `last_pkt_time`
- `h00_saved`
- in-memory recovery state

as if those were the source of truth.

They should not be.

## CTO Position

The correct source of truth is:

1. treatment start time
2. packet timestamp
3. journal row kind
4. deterministic slot math

Not:

1. replay speed
2. packet arrival wall-clock
3. mutable cache labels
4. whether a previous packet happened to save successfully

Backfill must not need to be "slowed down" to work correctly. If slower replay is required, the architecture is wrong.

## Clinical Semantics To Preserve

The new design must preserve the existing clinical meaning from the old program:

- `H00` = baseline hour bucket at treatment start
- `H01`, `H02`, ... = hourly clinical buckets
- `OC_XX` = order-change events between hourly rows
- `snapshot_time` = clinical sample time, not edit time
- `updated_at` = human or system mutation time
- `GAP` = missing hourly rows between actual hourly snapshots

## Non-Goals

- Do not change how PID values are decoded from packets
- Do not redesign the UI review workflow in this spec
- Do not bring back backend smart gap-fill
- Do not couple hourly snapshot generation to order-change generation

## Target Design

## 1. Split Projection Responsibilities

Use two projectors:

### A. Hourly Snapshot Projector

Input:

- `treatment_id`
- `treatment_start_time`
- `packet_time`
- extracted CRRT values

Output:

- exactly one hourly row per `(treatment_id, hour_slot)`

Rule:

```text
hour_slot = floor((packet_time - treatment_start_time) / 3600)
hour_slot = max(hour_slot, 0)
```

Display labels:

- `0 -> H00`
- `1 -> H01`
- `2 -> H02`

### B. Order Change Projector

Input:

- `treatment_id`
- `packet_time`
- detected order PID changes

Output:

- append one row with `row_kind = ORDER_CHANGE`
- chronological position determined only by `snapshot_time`

The order-change projector must not control hourly creation.

## 2. Hourly Rows Must Use Deterministic Slot Keys

Current system relies too much on `last_hour_label`.

Replace the source-of-truth model with:

- `row_kind = HOUR`
- `hour_slot = integer`

Then derive `row_code` from `hour_slot`:

- `row_code = f"H{hour_slot:02d}"`

This makes hourly snapshot generation deterministic even if:

- packets arrive very fast
- packets arrive slightly out of order
- cache is cleared and rebuilt
- save of a previous packet failed

## 3. GAP Must Be Display-Only

Backend must never auto-fill missing hourly rows.

Backend responsibility:

- save only the hourly rows that actually exist

Frontend responsibility:

- if `H00` exists and next hourly row is `H03`, render `GAP` for `H01` and `H02`

Important:

- `OC_XX` does not count as filling an hourly gap
- hourly GAP is computed only from hourly slots

## 4. Backfill Must Be a Dedicated Mode

Backfill should not run through the normal live runtime path with:

- websocket fanout
- live recovery
- device online status assumptions
- recorder side effects intended for real-time

Instead create a dedicated importer mode:

- `HistoricalBackfillImporter`

Responsibilities:

- create or resume treatment deterministically
- write packets in time order for one device
- project hourly rows deterministically
- project OC rows deterministically
- update raw manifest
- update list projection

What it must not do:

- trigger startup recovery logic
- depend on current wall clock
- use live heartbeat assumptions

## 5. Live Runtime Must Stay Lean

Live path should do only:

1. resolve active treatment for packet
2. persist raw chunk
3. update treatment heartbeat/state
4. project hourly row for the packet's hour slot
5. project order-change events

No smart gap-fill.
No replay heuristics.
No special rules based on how quickly packets are arriving.

## Target Data Model Changes

Use the existing `treatment_journal_rows` table, but extend semantics as follows.

### Required Columns

- `treatment_id`
- `row_kind` = `HOUR` or `ORDER_CHANGE`
- `row_code`
- `snapshot_time`
- `hour_slot` nullable integer
- `source`
- `stable_at`
- `created_at`
- `updated_at`
- `version`

### Meaning

- `hour_slot` is required for `HOUR`
- `hour_slot` is null for `ORDER_CHANGE`
- `row_code` is a display/business label
- `snapshot_time` is clinical chronology

### Required Constraints

- unique index on `(treatment_id, row_kind, hour_slot)` where `row_kind = 'HOUR'`
- unique index on `(treatment_id, row_code)` if retained for compatibility
- index on `(treatment_id, snapshot_time)`

## Target Runtime Rules

## Hourly Projector

For each packet:

1. resolve `treatment_start_time`
2. compute `hour_slot`
3. `upsert` the hourly row by `(treatment_id, row_kind='HOUR', hour_slot)`
4. write latest extracted auto values into that slot

Notes:

- `H00` is not a special storage structure
- its only special behavior is that it uses `hour_slot = 0`
- if the team still wants a 60-second "baseline stabilization window", that should only affect `stable_at`, not slot identity

## Order Change Projector

For each packet:

1. detect order PID changes
2. if real change exists, append/update current OC event policy
3. store as:
   - `row_kind = ORDER_CHANGE`
   - `snapshot_time = packet_time`
   - `row_code = OC_XX`

Important:

- OC creation never suppresses hourly creation
- hourly creation never depends on OC logic

## Recovery Rules

Startup recovery currently contaminates replay tests.

New rule:

- `recovery` only applies in live runtime mode
- `backfill importer` must ignore recovery state

Operational rule:

- before historical replay, there must be no residual `IN_PROGRESS` session for that device unless replay is intentionally resuming that exact treatment

## Why This Design Reduces Bugs

### Current Bug Pattern

Today many bugs happen because:

- save fails
- cache resets
- fallback start time changes
- last hour label is lost
- later packets behave differently because earlier persistence failed

That is fragile.

### New Bug Resistance

With `hour_slot`:

- every packet independently maps to the same hourly slot
- packet 1000 and packet 1001 from hour 3 both resolve to `H03`
- if one save fails, the next packet from hour 3 still recreates `H03`
- hourly logic no longer depends on having successfully passed through `H00 -> H01 -> H02` in sequence

This is the main architectural win.

## Recommended Implementation Order

## Phase 1: Stop Digging

- remove backend smart gap-fill permanently
- stop using replay speed as a decision variable
- keep GAP display-only in frontend

## Phase 2: Introduce Hour Slot

- add `hour_slot` column to `treatment_journal_rows`
- backfill existing hourly rows from `row_code`
- add indexes/constraints

## Phase 3: Refactor Hourly Projector

- compute `hour_slot` from `packet_time - treatment_start_time`
- upsert hourly rows by `(treatment_id, row_kind='HOUR', hour_slot)`
- make `last_hour_label` a cache optimization only, not a correctness primitive

## Phase 4: Separate Backfill Importer

- create dedicated backfill command/service
- isolate from live recovery/websocket concerns

## Phase 5: Harden Queries

- detail/review/export use one merged timeline query:
  - hourly rows + OC rows
  - ordered by `snapshot_time`
- GAP computed only from missing hourly slots

## Backward-Compatible Short-Term Fix

If the team cannot implement `hour_slot` immediately, do this minimum:

1. keep `pkt_time` fallback instead of `now()`
2. remove all backend gap-fill
3. ensure hourly creation uses computed `hour_label` every packet
4. never let OC logic overwrite hourly state
5. disable recovery during backfill runs

This is still weaker than the final design, but much safer than the current mixed pipeline.

## Acceptance Criteria

### Historical Backfill

- replay 6 hours of data at max speed
- produce `H00` through at least `H06` when timestamps span those hours
- no dependence on replay pacing
- no auto-created fake hourly rows

### Downtime / Missing Data

- if telemetry spans `H00`, `H01`, `H04`
- backend stores only those hourly rows
- frontend renders `GAP` for `H02`, `H03`

### Order Change

- if order changes between `H02` and `H03`
- timeline shows `OC_XX` between them
- OC does not fill the hourly gap

### Retry Robustness

- if first hourly write fails because treatment row is not yet visible
- later packets still create the correct hourly slot
- system does not get stuck forever in `H00`

### Live Isolation

- backfill logic does not change live rules
- live restart recovery does not contaminate historical replay

## QA Matrix Additions

Must add these cases:

1. fast replay from raw file with 6h+ packet span
2. replay with intentional packet gaps
3. replay with device downtime in the middle
4. replay with repeated order changes inside a single hour
5. replay after forced snapshot save failure
6. live ingest after completed backfill
7. startup with stale `IN_PROGRESS` rows vs clean replay mode

## Final Recommendation

Do not keep layering fixes onto the current mixed pipeline forever.

The simplest stable design is:

- `Hourly = deterministic slot projection`
- `Order change = separate timestamped event projection`
- `GAP = UI visualization of missing hourly slots`
- `Backfill = dedicated importer, not the normal live path`

That is the point where the snapshot system becomes easier to reason about than to debug.
