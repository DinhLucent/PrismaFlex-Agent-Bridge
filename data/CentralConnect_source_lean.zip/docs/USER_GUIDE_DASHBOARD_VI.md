# HƯỚNG DẪN SỬ DỤNG: BẢNG THEO DÕI TRUNG TÂM (DASHBOARD)

_Phiên bản: 1.1 — Cập nhật: 2026-04-03_
_Phạm vi áp dụng: Bác sĩ, Điều dưỡng, Quản trị viên lâm sàng_

---

## 1. TỔNG QUAN

**Dashboard (Bảng Theo Dõi Trung Tâm)** là giao diện chính hiển thị ngay sau khi đăng nhập hệ thống. Dashboard cho phép giám sát đồng thời toàn bộ các hệ thống lọc máu liên tục (CRRT) PrismaFlex đang vận hành trong khoa theo thời gian thực (Real-time), đóng vai trò như một trạm theo dõi bệnh nhân trung tâm (Central Monitoring Station).

---

## 2. CÁC THÀNH PHẦN CHÍNH

### 2.1. Danh Sách Thiết Bị (Device Cards)

Mỗi hệ thống PrismaFlex trong khoa được hiển thị dưới dạng một thẻ thiết bị (Device Card), bao gồm các phân hệ thông tin:

- Số hiệu thiết bị và vị trí giường bệnh lý.
- Dữ kiện định danh bệnh nhân (Họ tên, Mã bệnh nhân - PID).
- Phương thức điều trị đang áp dụng (ví dụ: CVVH, CVVHDF, TPE).
- Thời gian vận hành màng lọc (Run Time).

### 2.2. Biểu Đồ Áp Lực Theo Thời Gian Thực (Pressure Charts)

Trong mỗi thẻ thiết bị đang vận hành, hệ thống hiển thị biểu đồ diễn biến các thông số áp lực liên tục của vòng tuần hoàn ngoài cơ thể:

- Áp lực đường vào (Access Pressure).
- Áp lực đường về (Return Pressure).
- Áp lực xuyên màng (TMP — Transmembrane Pressure).
- Áp lực màng lọc (Filter Pressure).

> **Lưu ý lâm sàng:** Khi giá trị TMP có xu hướng gia tăng (dấu hiệu tắc nghẽn/đông quả lọc), nền biểu đồ chuyển đổi màu sắc theo thang đo: Xanh (Mức độ an toàn) → Vàng (Cảnh báo chú ý) → Đỏ (Báo động can thiệp), hỗ trợ kíp trực nhận biết rủi ro sớm trước khi thiết bị phát cảnh báo chính thức.

### 2.3. Hệ Khảo Báo Động (Alarms & Warnings)

Khi hệ thống PrismaFlex ghi nhận sự kiện bất thường (ví dụ: áp lực đường tĩnh mạch tăng, hết dịch bù (Replacement fluid), phát hiện bọt khí trong vòng tuần hoàn), thông tin được phản ánh trực tiếp trên Dashboard:

- Thẻ thiết bị kích hoạt hiệu ứng cảnh báo quang học (đỏ/vàng) tùy theo phân loại mức độ nghiêm trọng.
- Nội dung báo động được hiển thị rõ ràng, giúp nhân viên y tế chuẩn bị phương án hoặc vật tư tiêu hao trước khi tiếp cận giường bệnh.

---

## 3. THAO TÁC TRÊN HỆ THỐNG

### 3.1. Gán Bệnh Nhân và Khởi Tạo Phiên Điều Trị (Start Treatment)

Khi thiết bị PrismaFlex ở trạng thái kết thúc thiết lập và sẵn sàng vận hành:

1. Thẻ thiết bị trên Dashboard sẽ hiển thị trạng thái **Sẵn sàng (Standby)**.
2. Thông qua thao tác chọn **[Gán Bệnh Nhân / Bắt Đầu]**.
3. Nhập mã số bệnh nhân lưu trữ (PID) hoặc quét mã vạch (Barcode) từ vòng tay định danh.
4. Chọn **Xác nhận**. Từ mốc thời gian này, hệ thống tự động thu thập telemetry và truy suất vào **Nhật ký Điều trị (Treatment Journal)** đối tác bệnh nhân.

### 3.2. Chuyển Tiếp Nhật Ký Điều Trị (Treatment Journal)

Để mở trực tiếp hồ sơ Nhật ký Điều trị của một phiên đang vận hành từ Dashboard, chỉ cần nhấn đúp (Double Click) vào thẻ thiết bị hoặc tương tác biểu tượng cuốn sổ ở góc phải.

### 3.3. Kết Thúc Phiên Điều Trị (End Treatment)

Trong quá trình tiến hành thao tác trả máu về bệnh nhân và ngừng thiết bị PrismaFlex tại giường:

- Dashboard nhận diện tín hiệu kết thúc (**END**) của phiên thiết lập.
- Thẻ thiết bị chuyển qua trạng thái không hoạt động (Offline/Standby).
- Nhật ký điều trị của phiên đó được đóng và chuyển sang trạng thái chờ Y lệnh phê duyệt.

---

## 4. QUY ƯỚC PHÂN LOẠI MÀU SẮC (COLOR CODING)

Nhằm tối ưu hóa công tác giám sát, Dashboard sử dụng hệ thống màu y khoa chuẩn đánh giá trạng thái vận hành:

| Mã màu                   | Tình trạng                  | Phân tích lâm sàng                                                                                                                                               |
| :----------------------- | :-------------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Xanh lá / Xanh dương** | Hoạt động bình thường (RUN) | Tất cả thông số huyết động và áp lực màng nằm trong giới hạn cho phép.                                                                                           |
| **Vàng (Nhấp nháy)**     | Cảnh báo (Warning)          | Một hoặc nhiều thông số đang tiệm cận mức rủi ro. Ví dụ: Sắp hết túi dịch siêu lọc/dịch bù, áp lực duy trì chỉ số tăng liên tục.                                 |
| **Đỏ (Nhấp nháy)**       | Báo động (Alarm)            | Các thông số đã vượt ngưỡng an toàn vận hành. Ví dụ: Thiết bị dừng hệ thống bơm do đông quả lọc, phát hiện lọt khí vào đường tĩnh mạch. BẮT BUỘC CAN THIỆP NGAY. |
| **Xám**                  | Đang chờ thiết lập          | Thiết bị đang tắt hoặc ở trong giai đoạn đuổi khí/mồi bộ dây (PRIME), chưa kết nối tuần hoàn với người bệnh.                                                     |

---

_Tài liệu thuộc hệ thống ICU-B Connect — PrismaFlex Device Manager._
