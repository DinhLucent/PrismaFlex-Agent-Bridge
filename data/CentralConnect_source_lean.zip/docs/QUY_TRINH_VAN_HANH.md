# 📘 Quy trình Vận hành ICU-B Connect

Tài liệu này hướng dẫn chi tiết các quy trình tiêu chuẩn để quản trị, sao lưu, đóng gói và cập nhật hệ thống **ICU-B Connect** trong môi trường lâm sàng thực tế.

---

## 1. Quy trình Đóng gói (Packaging Release)

Để tạo bản cài đặt (release) mang đi triển khai sang máy chủ khác, hệ thống sử dụng các kịch bản đóng gói tự động nhằm loại bỏ các file rác (log, database cũ, cache).

### 📦 Tạo bản cài đặt LEAN (Khuyên dùng)

Bản cài đặt LEAN chỉ bao gồm mã nguồn (Source Only) không chứa thư viện `node_modules` nặng nề, giúp tốc độ chép file cực nhanh.

1. Mở thư mục gốc của dự án.
2. Chạy file `CREATE_LEAN_RELEASE.bat`.
3. Hệ thống sẽ tự động tạo thư mục `releases/ICU-B_Connect_Release_vX.X.X_LEAN`.
4. Copy toàn bộ nội dung trong thư mục này mang sang máy chủ đích để triển khai.

### 📦 Tạo bản cài đặt Full

Nếu máy chủ đích **không có kết nối mạng internet** để tải package npm, hãy chạy `CREATE_GITHUB_RELEASES.bat` và chọn tạo bản Full (chứa sẵn `node_modules`).

---

## 2. Quy trình Sao lưu & Phục hồi (Backup & Recovery)

Hệ thống có hai cơ sở dữ liệu SQLite cực kỳ quan trọng cần được bảo vệ:

- `backend/services/treatment_records.db` (Lưu hồ sơ ca lọc và chữ ký điện tử).
- `backend/trends.db` (Lưu biểu đồ áp lực và lịch sử báo động).

### 🛡️ Sao lưu Tự động

Khi bạn chạy quy trình Cập nhật (Update), hệ thống sẽ **tự động sao lưu** hai file DB này vào thư mục `BACKUPS/backup_DDMMYYYY_HHMMSS`.

### 🛡️ Sao lưu Thủ công (Định kỳ)

Để an toàn dữ liệu, kỹ sư nên sao lưu định kỳ:

1. Vào thư mục `backend/` và `backend/services/`.
2. Copy 2 file `.db` nói trên ra ổ cứng ngoài hoặc Google Drive.

### 🔄 Phục hồi (Restore)

Nếu dữ liệu bị lỗi, hỏng (corrupted):

1. Chạy `STOP_SYSTEM.bat` để dừng toàn bộ hệ thống.
2. Vào thư mục `BACKUPS/`, tìm thư mục backup gần nhất.
3. Copy và chép đè file `treatment_records.db` vào `backend/services/`.
4. Copy và chép đè file `trends.db` vào `backend/`.
5. Chạy `START_SYSTEM.bat`.

---

## 3. Quy trình Cập nhật Hệ thống (Update Process)

Để cập nhật phiên bản mới lên máy chủ đang chạy mà không làm mất dữ liệu điều trị, hãy sử dụng quy trình cập nhật an toàn (Safe Update) 7 bước.

### 🔄 Cập nhật An toàn (Khuyên dùng)

Dùng khi có bản cập nhật thay đổi cả cấu trúc, cài thêm thư viện, hoặc cần độ an toàn tuyệt đối.

1. Copy mã nguồn phiên bản mới (từ USB/Release folder) đè lên thư mục hiện tại.
2. Từ thư mục gốc, click đúp vào `scripts/safe_update.bat`.
3. Kịch bản sẽ thực thi 7 bước tự động:
   - **Bước 1**: Xác nhận trước khi cập nhật.
   - **Bước 2**: Tự động sao lưu DB ra thư mục `BACKUPS/`.
   - **Bước 3**: Tắt Node.js, Python, PM2.
   - **Bước 4**: Copy code Backend & Frontend (bỏ qua file `.db` để bảo vệ dữ liệu).
   - **Bước 5**: Kiểm tra DB còn nguyên vẹn hay không.
   - **Bước 6**: Build lại Frontend (`npm install` & `npm run build`).
   - **Bước 7**: Khởi động lại hệ thống qua PM2.

### ⚡ Cập nhật Nhanh (Hot-patch)

Dùng khi chỉ sửa lỗi nhỏ (hotfix) ở Backend/Frontend mà không muốn tắt hệ thống lâu, có thể chạy `scripts/apply_update.bat`. Quá trình này sẽ thực hiện nhanh hơn nhưng ít bước kiểm tra an toàn hơn.

---

## 4. Khắc phục Sự cố Nhanh (Troubleshooting)

Nếu hệ thống bị đơ, không truy cập được web, hoặc báo lỗi 500, PM2 bị treo tiến trình:

1. Chạy file `scripts/REPAIR_SYSTEM.bat`.
2. Chức năng của file này:
   - Dọn dẹp sạch sẽ (kill) triệt để các tiến trình `python.exe`, `node.exe` đang bị kẹt ngầm không chịu thoát.
   - Khởi động lại hệ thống sạch sẽ từ đầu thông qua `ecosystem.config.js`.

---

_Tài liệu được cập nhật tự động cho ICU-B Connect._
