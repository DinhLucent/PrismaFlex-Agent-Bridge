# Universal Document Extraction & Cleaning Workflow for AI Agents

## Core Philosophy

- No technical document is "clean" by default.
- Agents MUST NOT trust the default OCR/Converters output.
- Agents MUST NOT manually retype long data tables (to prevent hallucinations and row truncation).
- Any hidden technical data within images/diagrams must be reverse-engineered into a machine-readable format (Markdown/Mermaid).

---

## 🚫 STRICT GUARDRAILS (ZERO-TOLERANCE POLICY)

This workflow operates with a strict "Fail-Fast" and zero-tolerance policy against data corruption:

1. **No Hallucinated Edits (Do Not Guess):** The Agent is STRICTLY FORBIDDEN from guessing or "correcting" core technical data (e.g., variables, error codes). If the OCR output is ambiguous (e.g., `0x800Q`), the Agent must flag it as `[UNDECODED_TEXT]` and report the error. **Never** assume it meant `0x8000`.
2. **Mandatory Audit Trail:** Before marking a task as complete, the Agent must formulate a Sanity Check Audit Report (e.g., `analysis_results.md`). It must explicitly state the exact count of tables and items in the source file compared to the destination file. A 100% match is mandatory to proceed.
3. **Fail-Fast Rule:** If the Agent cannot extract the data without loss or distortion, it must HALT the process immediately and escalate to a human engineer. It is completely unacceptable to submit an incomplete technical document.

---

## ⚙️ Step 1: Context Profiling & Initialization

**Input:** Raw document file (`.pdf`, `.docx`, `.xml`, corrupted `.md`).
**Agent Actions:**

1. Skim the first 500 lines to identify the document's "Domain".
2. Establish a Filtering Schema based on the Domain:
   - **Technical Specs (API, Protocol, Code):** Keep data models, error codes, tables, commands, and port specs. Remove marketing texts and repetitive headers.
   - **Business Docs (BRD, Flow, Rules):** Keep workflows, permission matrices, and logic rules.
   - **Legal Docs (NDA, Contracts):** Keep the exact wording, clause structures, and penalty terms unchanged.

---

## ⚙️ Step 2: Script-Based Data Extraction (CRITICAL)

When detecting tables or structured data spanning more than 20 rows:

1. The Agent **ABSOLUTELY MUST NOT** attempt to write the table manually using an LLM generation prompt.
2. The Agent must **WRITE A CUSTOM PYTHON SCRIPT** (using `re` Regex or `pandas`):
   - Scan the raw file to extract messy HTML tags (`<table>`, `<tr>`, `<td>`, etc.).
   - Normalize and enforce the formatting into standard `Markdown Tables` or `JSON/YAML`.
3. The Agent executes the script to automate the extraction and outputs the cleaned `.md` file.

---

## ⚙️ Step 3: Visual Data Recovery (Mermaid Injection)

If image markdown tags (`![](image.jpg)`) are detected:

1. **Context Check:** If it's merely a logo, icon, or generic photo (Ignore).
2. **If it's a structural diagram (Flowchart, Architecture, State Machine):** Prompt a Vision Model (GPT-4V / Sonnet) to translate the logic inside the image into a **Mermaid Diagram**.
3. Inject the ` ```mermaid ` code block into the markdown file in place of the image to retain 100% of the technical context.

---

## ⚙️ Step 4: Self-Correction Loop & Sanity Check

1. **Try / Catch Loop:** If the Python Script from Step 2 fails -> The Agent AUTOMATICALLY reads the stderr log -> Fixes the code -> Reruns it (Max 3 attempts).
2. **Absolute Sanity Check:**
   - Count the total number of `<tr>` rows in the source file and match it against the output Markdown table rows.
   - Any discrepancy (even 1 missing row) triggers an immediate HALT to the entire process with a data distortion warning.
3. Package the final standardized file. All code blocks must be wrapped in backticks, and tables must be properly aligned. Any undecodable variable structures must be explicitly warned for manual user review.
