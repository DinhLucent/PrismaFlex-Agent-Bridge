# Treatment Journal Stable-Row Partial Lock Spec

Updated: 2026-04-05  
Owner: CTO  
Status: FOR ISSUANCE  
Priority: P0 - Journal critical feature

Supersedes for this topic:
- `TREATMENT_SNAPSHOT_EDIT_POLICY_SPEC.md` section "While treatment is actively recording"

Related documents:
- `TREATMENT_JOURNAL_MVP_POLICY.md`
- `TREATMENT_JOURNAL_SIMPLIFICATION_AND_HARDENING_SPEC.md`
- `TREATMENT_JOURNAL_PERMISSION_MATRIX.md`

## 1. Muc tieu

Ban hanh mot chinh sach duy nhat cho Journal trong luc treatment van `IN_PROGRESS`.

Muc tieu:

- cho phep dieu duong bo sung gia tri manual tren cac row da ton tai va da stable
- van khoa row dang live de tranh race condition voi telemetry
- tuyet doi khong mo lai cac thao tac cau truc timeline
- giam bug chronology, giam bug quyen han, giam bug frontend/backend mismatch

## 2. Executive decision

Quyet dinh chot cua CTO:

- Journal **KHONG** bi khoa toan bo chi vi treatment dang `IN_PROGRESS`
- Journal chi khoa **mot phan**
- `Stable existing rows` duoc phep edit manual
- `Active streaming row` bi khoa
- `Gap rows` va moi thao tac cau truc timeline bi khoa

Noi ngan gon:

- `edit noi dung row cu` = duoc phep theo dieu kien
- `tao / xoa / chen row` = khong duoc phep trong luong clinical UI

## 3. Van de can giai quyet

Chinh sach khoa toan bo khi `IN_PROGRESS` an toan theo ky thuat, nhung qua chat cho nghiep vu.

Tinh huong thuc te:

- `H00` la baseline setup dau ca
- dieu duong can dien `heparin`, `solution`, `filter`, `kali`, hoac note sau khi row da snap xong
- neu khoa toan bo journal, workflow tro nen bat hop ly va khong than thien lam sang

Tuy nhien, mo khoa toan bo journal lai rat nguy hiem vi:

- co the dung vao row dang duoc may stream
- co the dan toi mo lai `fill gap`
- co the gay hieu nham Journal thanh spreadsheet editor

Vi vay, giai phap dung la `stable-row partial lock`.

## 4. Nguyen tac cot loi

Treatment Journal phai duoc xem la ho so lam sang, khong phai bang tinh.

Nguyen tac bat buoc:

1. Timeline do telemetry va backend quyet dinh.
2. `snapshot_time` la moc lam sang bat bien.
3. Con nguoi chi duoc sua noi dung tren row da ton tai.
4. UI khong duoc cho phep tao, chen, xoa, hay tai cau truc timeline trong clinical workflow thuong quy.
5. Backend phai la source of truth cho quyen edit.

## 5. Dinh nghia

### 5.1 Data row

Row du lieu that su ton tai trong database, vi du:

- `H00`
- `H01`
- `H02`
- `OC_01`
- `OC_02`

### 5.2 Gap row

Row placeholder de bao cho user biet co khoang trong timeline. Gap row:

- khong phai row du lieu that
- khong co `snapshot_time` thuc te cua may
- khong duoc phep edit
- khong duoc phep bien thanh row du lieu trong clinical UI

### 5.3 Active streaming row

Data row hien tai dang duoc may bo sung them telemetry.

Rule nghiep vu:

- day la row duy nhat phai bi khoa trong luong `IN_PROGRESS`
- frontend khong duoc chi dua vao "row render cuoi" neu dieu do co the sai
- backend hoac model row phai co cach xac dinh row nay mot cach ro rang

### 5.4 Stable row

La data row da ton tai trong DB va khong con la active streaming row.

Stable row la doi tuong duoc phep edit manual trong feature nay.

### 5.5 Structural action

Moi thao tac lam thay doi cau truc timeline:

- fill gap
- add row
- add next hour
- restore missing row
- delete row
- bulk row repair

Tat ca structural action deu ngoai pham vi feature nay.

## 6. Pham vi cua feature

Feature nay chi xu ly:

- quyen edit manual tren stable existing rows
- row-level lock trong luc treatment `IN_PROGRESS`
- phan biet ro row nao editable, row nao read-only

Feature nay KHONG xu ly:

- tao row moi
- fill gap
- restore missing row
- delete row
- bulk update
- doi `snapshot_time`
- doi thu tu `Hxx` / `OC_XX`

## 7. Chinh sach nghiep vu chinh thuc

### 7.1 Trong `IN_PROGRESS`

Allowed:

- edit manual fields tren `stable existing rows`
- edit notes neu notes policy dang mo

Not allowed:

- edit active streaming row
- edit gap row
- fill gap
- create row
- delete row
- restore missing row
- bulk update
- doi `snapshot_time`
- sua telemetry fields

### 7.2 Trong `PENDING_REVIEW`

- Nurse read-only
- Doctor review theo permission matrix hien hanh
- Neu cho phep restore existing row thi chi duoc restore row da ton tai, khong tao row moi

### 7.3 Trong `APPROVED`

- Journal khoa hoan toan
- Muon sua phai `unlock`

### 7.4 Sau `UNLOCK`

- quyen sua quay lai theo chinh sach correction da duoc phe duyet
- van khong mo structural actions trong clinical UI thuong quy

## 8. Rule dac biet cho `H00`

`H00` la baseline setup row.

Rule bat buoc:

- trong cua so freeze ban dau, `H00` read-only
- sau khi freeze xong va row da tro thanh stable, `H00` duoc phep edit manual
- `H00` khong bao gio duoc phep sua telemetry fields

Muc tieu:

- tranh va cham voi baseline auto-capture
- van cho phep dieu duong dien thong tin setup ban dau sau khi row da snap

## 9. Rule cho `H01/H02/...`

Moi row `Hxx` da ton tai va khong con la active streaming row deu duoc xem la stable row.

Stable `Hxx` duoc phep:

- sua field manual trong allowlist
- luu audit
- giu nguyen chronology

Stable `Hxx` khong duoc:

- doi `snapshot_time`
- doi hour label
- bi day xuong cuoi timeline
- tao them row moi lien quan

## 10. Rule cho `OC_XX`

`OC_XX` la row su kien chen giua cac moc gio.

Chinh sach:

- `OC_XX` la data row neu no da ton tai trong DB
- `OC_XX` cung phai ton trong chronology hien co
- `OC_XX` khong duoc phep lam sai co che xac dinh active row

Yeu cau ky thuat:

- frontend khong duoc mac dinh "row render cuoi" la active row neu `OC_XX` co the nam cuoi mang hien thi
- row-level lock phai dua tren "active data row that su", khong dua tren UI ordering mot cach mong manh

## 11. Field-level edit policy

### 11.1 Chi sua manual fields

Backend va frontend bat buoc thong nhat allowlist.

Manual field allowlist MVP:

- `heparin_bolus`
- `heparin_rate`
- `duosol_count`
- `prismasol_count`
- `filter_type`
- `kali`
- `calcium_comp`
- `citrate_dose`
- row-level clinical note neu duoc thiet ke trong cung row

### 11.2 Telemetry denylist

Tuyet doi khong cho manual edit:

- `qb`
- `qd`
- `qs`
- `qpbp`
- `uf_total`
- `uf_hourly`
- `pa`
- `pv`
- `pbe`
- `tmp`

Neu san pham muon mo edit cho mot telemetry field trong tuong lai, phai co spec moi.

## 12. Role matrix cho feature nay

| Role | IN_PROGRESS stable row | IN_PROGRESS active row | PENDING_REVIEW | APPROVED |
|---|---|---|---|---|
| Nurse | Edit manual duoc phep | Read-only | Read-only | Read-only |
| Doctor | Theo permission matrix review hien hanh | Read-only | Review actions theo policy | Read-only tru khi unlock |
| Admin/Maintenance | Khong su dung UI thuong quy cho structural action | Read-only | Theo maintenance path rieng | Theo maintenance path rieng |

Ghi chu:

- Feature nay khong mo them structural quyen cho doctor hay admin trong clinical UI.
- Maintenance path neu co phai tach rieng va khong nam trong scope document nay.

## 13. UI requirements

### 13.1 Banner

Khi treatment dang `IN_PROGRESS`, UI phai hien ro:

- row dang ghi bi khoa
- cac row truoc do co the chinh sua neu la stable row

UI khong duoc hien message gay hieu nham rang "toan bo journal bi khoa" neu feature nay da bat.

### 13.2 Editable affordance

Edit icon / editable cell chi duoc hien khi:

- row la stable row
- field nam trong allowlist
- state va role cho phep edit

### 13.3 Gap rows

Gap rows:

- khong co edit affordance
- khong co button "fill"
- khong co button "restore missing"

### 13.4 Structural actions

Trong clinical UI thuong quy, khong duoc hien:

- fill gap
- add row
- add next hour
- restore missing
- delete row
- bulk update

## 14. Backend contract

### 14.1 Backend la source of truth

Frontend disable chi la lop UX.

Backend bat buoc enforce:

- role check
- treatment state check
- stable-row check
- field allowlist
- operator check
- audit trail

### 14.2 API expectation

API dung cho feature nay phai ho tro:

- edit existing row manual values trong `IN_PROGRESS` neu row da stable
- reject neu row la active streaming row
- reject neu field khong nam trong allowlist
- reject neu row la gap / row khong ton tai

### 14.3 Legacy mismatch khong duoc chap nhan

Neu frontend mo edit mode nhung API save van blanket-block `IN_PROGRESS`, thi feature duoc xem la **CHUA HOAN TAT**.

Day la release blocker.

## 15. Audit requirements

Moi lan edit hop le phai luu:

- `updated_by`
- `updated_at`
- operator name
- field da sua
- gia tri truoc / sau neu co audit detail

Edit khong duoc:

- tao row moi
- doi `snapshot_time`
- doi chronology

## 16. Acceptance criteria

Feature chi duoc xem la DONE khi tat ca dieu kien sau dung:

1. Nurse co the edit manual field tren `H00/H01/...` da stable ngay ca khi treatment dang `IN_PROGRESS`.
2. Active streaming row van read-only.
3. Gap rows va structural actions van bi khoa hoan toan.
4. Telemetry fields van read-only.
5. Save thanh cong qua API hop le, khong fail `409` chi vi treatment con `IN_PROGRESS` neu row da stable.
6. Sau refresh, gia tri da sua con ton tai.
7. `snapshot_time`, `hour_label`, chronology khong thay doi.
8. Approved treatment van khoa hoan toan.
9. Audit metadata duoc cap nhat day du.
10. Role/state gating dung o UI va backend.

## 17. Blockers

Neu mot trong cac loi sau xay ra, QA phai chan release:

- UI mo edit tren stable row nhung save fail do backend van khoa `IN_PROGRESS`
- live row van edit duoc
- gap row co edit affordance
- structural button tai xuat hien trong clinical UI
- telemetry field sua duoc
- row bi nhay chronology sau khi save
- approved treatment sua duoc ma khong unlock

## 18. Implementation guidance

De giam bug va tranh heurstic mong manh, uu tien:

1. backend xac dinh `can_edit` hoac `stable_at`
2. frontend render dua tren flag tu backend
3. save path dung command/service phu hop voi stable-row policy
4. khong dua vao "row cuoi cua mang render" neu model row co the co `OC_XX` hoac placeholder

## 19. Rollout recommendation

Thu tu khuyen nghi:

1. chot spec nay lam source of truth
2. align backend gate voi stable-row policy
3. align frontend row lock voi active data row that su
4. QA chay full suite trong document QA di kem
5. moi sign-off feature

## 20. Final statement

Feature nay khong mo rong quyen sua Journal mot cach tuy tien.

No chi cho phep mot luong an toan hon va hop ly hon:

- row cu, da ton tai, da stable -> co the dien manual
- row dang live, row thieu, row cau truc -> van bi khoa

Day la can bang dung giua:

- an toan lâm sang
- do tin cay chronology
- kha nang su dung thuc te cua dieu duong
