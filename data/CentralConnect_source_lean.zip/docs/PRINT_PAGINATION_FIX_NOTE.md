﻿# Print Pagination Fix Note

## Symptom
The print preview leaves unnecessary blank space at the bottom of pages 1 and 2.

## Root Cause
`MAX_ROWS_PER_PAGE = 22` was calculated using the layout budget for the last page, which includes:
- the `TỔNG` row
- the signature footer

However, the renderer applies the same row limit to every page.

That means non-final pages also reserve space for elements that only appear on the last page.

## Current Behavior
- Page 1: too much empty space at the bottom
- Page 2: too much empty space at the bottom
- Last page: spacing is closer to correct because it actually renders totals + signatures

## Files
- `frontend/app/components/CrrtPrintPreview.tsx`

## Fix Direction
### 1. Split row capacity into two constants
Use separate capacities:
- `MAX_ROWS_NORMAL_PAGE`
- `MAX_ROWS_LAST_PAGE`

Example direction:
- normal page: more rows
- last page: fewer rows because it must reserve space for `TỔNG` and signatures

### 2. Change pagination strategy
`chunkRows()` should not use one fixed size for all pages.

Instead:
- paginate with normal-page capacity first
- keep the final chunk within last-page capacity
- if the final chunk overflows last-page capacity, rebalance by moving rows from the previous page

### 3. Reserve footer space only on the last page
The current implementation correctly renders:
- `renderTotalRow()` only on the last page
- `renderSignatureFooter()` only on the last page

But the row budgeting still assumes those elements exist on all pages.
That assumption must be removed.

## Acceptance Criteria
- Page 1 and intermediate pages are filled more tightly, with no obvious wasted bottom space.
- Last page still has enough room for:
  - `TỔNG`
  - nurse signature
  - doctor signature
- No rows are clipped in Chrome print preview / Save as PDF.
- Pagination remains stable for both short and long treatments.

## QA Cases
1. A 1-page treatment: confirm layout still fits.
2. A 2-page treatment: confirm page 1 becomes denser and page 2 still fits totals/signatures.
3. A 3+ page treatment: confirm only the last page reserves footer space.
4. Save as PDF and compare page density before/after.
