# Backfill Hourly + Order Change + Timestamp Fix Spec

> Updated: 2026-04-06
> Target branch: `cto/task-106-treatment-overhaul`
> Scope: fix historical replay semantics so backfill produces the same clinical journal shape expected from the old system, while preserving the new `LIVE/BACKFILL` split architecture

## Goal

Fix the remaining backfill journal bugs:

- `H00` must be captured at treatment start, not at the end of the first hour.
- `H01/H02/...` must continue every hour from the real treatment start.
- `OC_XX` rows must also be generated during backfill, not only during live ingest.
- Displayed times must reflect the real clinical timeline of the replayed packets.
- Replay mode must not be destabilized by live-oriented recovery or ghost-session cleanup logic.

## Clinical Rules That Must Stay True

- `H00` means the first hourly clinical snapshot of the treatment.
- `H00.snapshot_time` is the timestamp of the first valid packet of that treatment.
- `H01/H02/...` are based on fixed hourly slots from treatment start, not on processing speed.
- `OC_XX` is an event row based on the real packet time when a clinical order changed.
- `OC_XX` must never replace or suppress hourly rows.
- Gaps must remain gaps. Backend must not auto-fill missing hourly slots during backfill.
- Backfill speed must not change clinical output.

## Confirmed Symptoms

Observed behavior from current replay results:

- Data replay from roughly `15:00 -> 19:00` is displayed starting around `17:00`.
- `H00` appears at `05:00` / `05:01` style times instead of the actual treatment start.
- `H01/H02/...` are shifted because slot timing is anchored incorrectly.
- `OC_XX` rows are missing entirely on backfill runs.
- Replay logs show repeated open/discard behavior, suggesting treatment boundaries are unstable during historical replay.

## Root Causes

## 1. Hourly backfill snapshots are anchored to the wrong packet

Current backfill logic effectively uses the last packet of a slot when flushing `H00/H01/H02`, instead of locking the slot to the first packet of that slot.

That creates two bugs:

- `H00` looks like a "one hour running average" instead of a baseline at treatment start.
- displayed hourly labels drift because `snapshot_time` is shifted later than it should be.

Required semantic model:

- treatment start = first packet time of the treatment
- slot start = first packet time observed inside that slot
- row label = derived from `floor((packet_time - treatment_start) / 3600)`
- `snapshot_time` = slot start, not slot end

## 2. Historical replay has no dedicated `ORDER_CHANGE` projector

The live path already detects order changes from clinical order PIDs. The backfill path currently rebuilds hourly rows only.

That means:

- DB has no `OC_XX` rows for replayed treatments
- frontend has nothing to render
- timeline looks incomplete and clinically misleading

## 3. Timestamp semantics are still unstable

There are two risks mixed together:

- machine timestamps may be local time mislabeled as `"UTC"`
- replay boundary logic may reopen or discard sessions in a way that shifts `start_time`

If backfill keeps re-opening or discarding "ghost" sessions, then the effective treatment start drifts, and all hour labels drift with it.

## 4. Live-oriented replay cleanup is interfering with historical mode

Backfill should be deterministic:

- consume packets in packet-time order
- derive treatment boundaries
- derive hourly rows
- derive order changes

It should not rely on:

- websocket pacing
- live recovery heuristics
- ghost-session discard behavior intended for online operation

## Required Fixes

## Fix A: Rebuild hourly snapshots from slot-first semantics

Target modules on overhaul branch:

- `backend/services/treatment/historical_backfill_importer.py`
- `backend/services/treatment/treatment_snapshot_service.py`
- any repository/service used to persist journal rows

Required behavior:

1. For each treatment, keep:
   - `treatment_start_time`
   - current `hour_slot`
   - `slot_first_pkt_time`
   - `slot_last_pkt_time`
   - `slot_values`

2. When the first packet of a treatment arrives:
   - open treatment if needed
   - set `treatment_start_time = pkt_time`
   - initialize slot `0`
   - set `slot_first_pkt_time = pkt_time`

3. For every packet:
   - compute `hour_slot = floor((pkt_time - treatment_start_time) / 3600)`
   - if packet stays in the same slot:
     - update cached values only
     - do not move `slot_first_pkt_time`
   - if packet enters a new slot:
     - flush the previous slot
     - start a new slot with `slot_first_pkt_time = pkt_time`

4. Flush rule for hourly rows:
   - row label = `H{slot:02d}`
   - `snapshot_time = slot_first_pkt_time`
   - values = latest values seen inside that slot

5. On replay end or handoff:
   - flush the last open slot

This gives the clinically expected semantics:

- `H00` captured at treatment start
- `H01` exactly one hour later in slot numbering
- displayed timeline no longer shifted by "end-of-slot" saves

## Fix B: Add a historical `ORDER_CHANGE` projector

Target modules on overhaul branch:

- `backend/services/treatment/historical_backfill_importer.py`
- or a new dedicated service such as `historical_order_change_projector.py`

Required behavior:

1. Track the same order-change PIDs used by live mode.

Minimum set:

- `QB`
- `QD`
- `QS_PRE`
- `QS_POST`
- `QPBP`
- `UF_RATE_TARGET`

2. Maintain per-treatment previous order state.

3. For every replay packet:
   - extract order-change-relevant values
   - compare to the previous order state
   - if a real change is detected:
     - create `OC_XX`
     - `snapshot_time = pkt_time`
     - persist the current full journal view for that moment

4. `OC_XX` counter:
   - per treatment
   - monotonic
   - independent from hourly rows

5. `OC_XX` must not affect hourly slot numbering.

Acceptance requirement:

- replaying a historical treatment that contains prescription changes must show `OC_01`, `OC_02`, ... between the correct hourly rows on the frontend.

## Fix C: Stabilize timestamp parsing for replay

Target modules on overhaul branch:

- `backend/main.py`
- `backend/services/treatment/treatment_recorder.py`
- `backend/services/treatment/treatment_snapshot_service.py`
- any shared timestamp parsing helper

Required behavior:

1. Define one parsing contract for backfill packets:

Timestamp precedence:

- `meta.timestamp_unix` if present
- else `meta.timestamp`
- else `header.timestamp`

2. Do not silently mix:

- true UTC
- local time mislabeled as UTC

3. Introduce one explicit replay timestamp policy:

- either convert all replay packets to Asia/Saigon before treatment logic
- or normalize everything to timezone-aware UTC first, then convert for display only

4. The same packet must produce the same logical `pkt_time` regardless of whether it is processed fast or slow.

5. Log the chosen source once per replay session:

- `timestamp_source`
- parsed timezone
- first packet time
- treatment start time

Acceptance requirement:

- if replay input spans `15:00 -> 19:00`, the journal must also show hourly progression anchored to that real interval, not offset by server time or parser assumptions.

## Fix D: Isolate replay session logic from live cleanup heuristics

Target modules on overhaul branch:

- `backend/services/treatment/treatment_recorder.py`
- `backend/main.py`

Required behavior:

1. Backfill mode must use its own session map and lifecycle rules.

2. During backfill, do not apply live-only heuristics that can fragment or discard sessions unexpectedly, including:

- ghost-session discard
- aggressive recovery conflict cleanup
- live resumption shortcuts

3. Closing a treatment in backfill should happen only from explicit replay boundary logic:

- patient change
- `END` boundary if clinically intended by the new design
- `RUN_TIME reset = 0` if this is part of the approved split logic
- explicit end-of-replay flush

4. Replay shutdown must flush all remaining importer caches before process exit.

Acceptance requirement:

- one replay run over the same input must deterministically produce the same treatment count and the same `Hxx/OC_XX` rows every time.

## Treatment Stop Mechanisms Inventory

For clarity, the implementation must document which mechanisms are allowed to close a treatment during replay.

Primary business boundaries:

1. patient change
2. `END` boundary
3. `RUN_TIME` reset to zero
4. long no-data timeout, only if explicitly allowed for replay

Technical cleanup paths must not masquerade as business boundaries:

- ghost discard
- recovery conflict cleanup
- live/backfill handoff cleanup

Replay output must be driven by business boundaries, not by technical cleanup heuristics.

## Frontend Expectations

Target touchpoints:

- `frontend/app/(main)/treatments/DetailPanel.tsx`
- any review/export/print timeline component

Expected behavior after backend fix:

- `H00/H01/H02/...` are shown in true clinical order
- `OC_XX` rows are interleaved by `snapshot_time`
- GAP rows appear only when hourly slots are missing
- no synthetic backend gap-fill is required

Frontend should not need new workaround logic for these bugs. The backend should produce the correct row set.

## Implementation Order

1. Fix hourly backfill slot anchoring (`slot_first_pkt_time`, not `last_pkt_time`)
2. Flush final open slot at replay end
3. Add historical `ORDER_CHANGE` projector
4. Normalize timestamp parsing contract
5. Disable replay-breaking live cleanup heuristics
6. Re-run replay on the known `11-02 -> 20-02` dataset

## Acceptance Criteria

- `H00` timestamp equals the first packet time of the treatment.
- `H01/H02/...` progress from the true treatment start without drift.
- Replaying `15:00 -> 19:00` data does not display a shifted start like `17:00`.
- `OC_XX` rows appear during backfill when order PIDs change.
- GAP remains visible where no hourly slot exists.
- Replaying the same dataset twice yields the same treatment rows.
- Backfill logic does not depend on replay speed.

## QA Scenario Matrix

## Scenario A: clean 4-hour replay

Input:

- continuous packets from `15:00 -> 19:00`
- no prescription changes

Expected:

- `H00` at treatment start
- `H01`, `H02`, `H03`, `H04` as applicable by slot boundaries
- no `OC_XX`

## Scenario B: 4-hour replay with prescription changes

Input:

- same hourly coverage
- QD / QB / QS changes inside the treatment

Expected:

- hourly rows still present
- `OC_XX` inserted chronologically
- no missing hourly rows caused by OC logic

## Scenario C: replay with a real gap

Input:

- packets for `15:00 -> 16:00`
- no packets for `16:00 -> 18:00`
- packets resume after `18:00`

Expected:

- backend stores only real `Hxx`
- frontend shows GAP for missing slots
- backend does not auto-fill gap hours

## Scenario D: replay repeated twice

Expected:

- same treatment count
- same row labels
- same hourly timestamps
- same OC numbering

## Scenario E: replay shutdown

Expected:

- final open slot is flushed
- last hour is not lost on process stop or replay completion

## Notes For OPUS

- Do not slow down backfill to hide bugs.
- Do not patch the frontend first to compensate for wrong backfill rows.
- Do not reintroduce automatic gap fill in backend.
- The safe target is deterministic replay semantics, not live-behavior imitation.
