# Treatment Journal Permission Matrix

Updated: 2026-04-04T23:08+07:00  
Owner: CTO  
Status: **APPROVED** — Ban hanh cho dev/QA thuc thi  
Source: `TREATMENT_JOURNAL_MVP_POLICY.md`

## 1. Muc dich

Tai lieu nay chot phan quyen MVP cho Treatment Journal de:

- dev biet action nao duoc phep hay bi cam
- QA co 1 bang duy nhat de test
- tranh tranh cai do mo giua UI, backend, va review workflow

## 2. Nguyen tac ngan gon

- May tao timeline.
- Nurse bo sung noi dung.
- Doctor duyet va hieu chinh.
- Admin/Maintenance moi sua cau truc.

## 3. Permission Matrix

| Action                                                              | Nurse               | Doctor | Admin / Maintenance | Dieu kien / ghi chu                                     | QA ky vong                                   |
| ------------------------------------------------------------------- | ------------------- | ------ | ------------------- | ------------------------------------------------------- | -------------------------------------------- |
| Xem list/history treatments                                         | Allow               | Allow  | Allow               | Read-only                                               | Tat ca role xem duoc                         |
| Xem detail journal                                                  | Allow               | Allow  | Allow               | Read-only                                               | Timeline hien dung chronology                |
| Xem compare current vs original                                     | Deny                | Allow  | Allow               | Thuong dung cho review                                  | Nurse khong thay compare tools               |
| Sua manual fields tren existing stable row                          | Allow               | Allow  | Allow               | Chi row da ton tai, da stable, dung allowlist           | Nurse/Doctor sua duoc dung field cho phep    |
| Sua telemetry fields (`QB`, `QD`, `QS`, `TMP`, `PA`, `PV`, `UF...`) | Deny                | Deny   | Deny by default     | Muon mo sau nay phai co policy moi                      | Moi request sua telemetry field deu bi chan  |
| Sua `snapshot_time`                                                 | Deny                | Deny   | Deny                | Bat bien sau khi row da tao                             | Edit/restore khong lam row nhay chronology   |
| Them clinical notes append-only                                     | Allow               | Allow  | Allow               | Chi them moi, khong edit/xoa                            | Notes co author + timestamp                  |
| Submit for review                                                   | Allow               | Deny   | Allow               | Chi Nurse submit. Treatment khong duoc `IN_PROGRESS`    | Doctor submit phai bi chan                   |
| Approve treatment                                                   | Deny                | Allow  | Allow               | Doctor/Admin only                                       | Nurse approve phai bi chan                   |
| Reject treatment                                                    | Deny                | Allow  | Allow               | Doctor/Admin only. **Reject -> DRAFT**. Ly do bat buoc. | Nurse reject phai bi chan. Ho so ve DRAFT.   |
| Unlock approved treatment                                           | Deny                | Allow  | Allow               | Doctor/Admin only                                       | Approved treatment chi mo khoa boi role dung |
| Restore existing row to original machine values                     | Deny                | Allow  | Allow               | Chi row da ton tai, co original, giu chronology         | Restore existing row khong tao row moi       |
| Restore missing row                                                 | Deny                | Deny   | Allow               | Khong nam trong clinical UI MVP                         | UI thuong quy khong duoc co nut nay          |
| Fill gap thoi gian                                                  | Deny                | Deny   | Allow               | Khong nam trong clinical UI MVP                         | UI thuong quy khong duoc co nut nay          |
| Add next hour / Add row                                             | Deny                | Deny   | Allow               | Khong nam trong clinical UI MVP                         | UI thuong quy khong duoc co nut nay          |
| Delete single row                                                   | Deny                | Deny   | Allow               | Chi Admin/Maintenance path                              | Neu lo ra clinical UI thi tinh la bug        |
| Bulk update rows                                                    | Deny                | Deny   | Allow               | Chi maintenance/admin tooling                           | Khong duoc expose cho clinical UI            |
| Delete entire treatment                                             | Deny                | Deny   | Allow               | Approved treatment mac dinh khong duoc xoa              | Chi admin dung, co guard va audit            |
| Export JSON report                                                  | Allow               | Allow  | Allow               | Read/export only                                        | File dung noi dung treatment                 |
| Export Excel                                                        | Allow               | Allow  | Allow               | Read/export only                                        | Thu tu row va cot dung                       |
| Export raw data                                                     | Allow if policy cho | Allow  | Allow               | Can xem la forensic/export, khong phai mutation         | Dung treatment owner, file ton tai dung      |

## 4. Rule bat buoc cho backend

Backend phai enforce cac dieu sau, khong duoc chi dua vao frontend:

- operator required cho moi mutation
- role check
- stable row check
- treatment lock check
- field allowlist
- audit log
- chronology preservation

## 5. Rule bat buoc cho UI

Clinical UI MVP:

- duoc hien edit icon chi tren manual fields hop le
- khong duoc hien nut `Fill Gap`
- khong duoc hien nut `Add Next Hour`
- khong duoc hien nut `Add Row`
- khong duoc hien nut `Restore Missing`
- khong duoc hien nut `Delete Row`
- duoc hien `Restore Existing Row` chi o review flow cho role phu hop

## 6. Rule bat buoc cho QA

QA can test 2 nhom:

### 6.1 Positive tests

- Nurse sua duoc manual fields tren row da ton tai
- Nurse them notes duoc
- Nurse submit review duoc khi treatment da dung
- Doctor approve/reject/unlock duoc
- Doctor restore existing row duoc

### 6.2 Negative tests

- Nurse khong duoc approve/reject/unlock
- Nurse khong duoc fill gap hay tao row moi
- Doctor trong clinical UI MVP khong duoc delete row thuong quy
- Khong role nao sua duoc `snapshot_time`
- Khong ai sua duoc telemetry fields
- Approved treatment bi khoa dung cho toi khi unlock

## 7. Ban chot cho team

Neu can mot cau ngan de thong nhat team:

- `Nurse = edit content`
- `Doctor = review and correction`
- `Admin = structural repair`

Do la permission model chuan cho MVP Treatment Journal.
