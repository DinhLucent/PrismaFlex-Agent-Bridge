# Runtime QA Checklist And Testcases

Updated: 2026-04-14

Important:

- This file is now a legacy summary.
- Use [V3_7_8_MASTER_RUNTIME_TEST_PACK.md](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\docs\V3_7_8_MASTER_RUNTIME_TEST_PACK.md)
  as the primary runtime source of truth.
- Use [V3_7_8_DASHBOARD_TEST_PACK.md](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\docs\V3_7_8_DASHBOARD_TEST_PACK.md)
  for dashboard/trend/TMP/DeltaP validation.

This older checklist is still useful as a short runbook, but it does not carry
the full current rules for:

- `RUN_TIME` continuity after `END`
- backend-hydrated detail trend history
- TMP / DeltaP chart full-range and outlier safety

## Purpose

This document is the QA pack for validating:

- live treatment continuity
- backfill chronology
- hourly snapshots
- order-change snapshots
- raw data continuity
- restart/recovery behavior
- device isolation

It is designed so QA can:

1. run the test
2. capture evidence
3. report the bug clearly
4. give engineering a likely module to inspect first

## Ground Rules

- Do not infer success only from the UI.
- Always verify 3 layers:
  - UI timeline
  - database rows
  - backend logs
- Every failed case must capture:
  - `device_id`
  - `patient_id`
  - `treatment_id`
  - packet time window
  - screenshot
  - SQL output
  - relevant log lines

## Required Evidence Paths

- Backend logs:
  - [backend.log](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/backend/logs/backend.log)
  - [errors.log](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/backend/logs/errors.log)
  - [replay_status.log](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/backend/logs/replay_status.log)
- Main QA doc:
  - [RUNTIME_QA_CHECKLIST_AND_TESTCASES.md](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/docs/RUNTIME_QA_CHECKLIST_AND_TESTCASES.md)

## Core SQL Checks

### Treatments

```sql
SELECT id, device_id, patient_id, start_time, end_time, outcome, close_reason,
       total_packets, last_packet_time, last_run_time_sec, continuity_source
FROM treatments
ORDER BY start_time DESC;
```

### Journal rows

```sql
SELECT treatment_id, row_code, row_kind, hour_slot, snapshot_time, source, reason
FROM treatment_journal_rows
WHERE treatment_id = '<treatment_id>'
ORDER BY snapshot_time, row_code;
```

### Raw manifest

```sql
SELECT treatment_id, chunk_index, status, first_timestamp, last_timestamp, packet_count, size_bytes
FROM raw_packet_manifest
WHERE treatment_id = '<treatment_id>'
ORDER BY chunk_index;
```

### Device checkpoint

```sql
SELECT *
FROM device_state
WHERE device_id = '<device_id>';
```

### Projection checkpoint

```sql
SELECT *
FROM treatment_projection_checkpoint
WHERE treatment_id = '<treatment_id>';
```

## QA Checklist

### Pre-run

- Confirm backend is the expected build.
- Confirm Mirth route in use:
  - `LIVE`
  - `BACKFILL`
- Confirm database was reset or intentionally preserved.
- Confirm no stale replay/live mode conflict on the same device.
- Confirm logs are cleared or timestamped for the run.

### During run

- Note the first packet time seen by backend.
- Note treatment start time shown in UI.
- Note first `H00`.
- Note first `OC_XX`, if any.
- Note whether `treatment_id` changes unexpectedly.
- Note whether raw file/chunk ownership changes unexpectedly.

### Post-run

- Compare UI chronology with SQL chronology.
- Compare SQL chronology with expected case.
- Check raw manifest continuity.
- Check `device_state` and `treatment_projection_checkpoint`.
- Save one screenshot of the full timeline.

## Severity Guide

- `P0`: data corruption, wrong treatment identity, raw split, lost chronology
- `P1`: wrong hourly/OC order, wrong snapshot time, missing/extra rows
- `P2`: restart/recovery mismatch, wrong checkpoint value, stale status
- `P3`: UI formatting only, display-only mismatch

## Testcases

## Group A - Live Continuity

### TC-L01 Fresh start by RUN

Goal:

- verify new treatment opens correctly
- verify `H00` starts on the new treatment

Setup:

- no active treatment for the device
- valid `patient_id`
- first true start packet has `therapy_status_id = RUN`

Steps:

1. Start live feed for one device.
2. Send first valid RUN packet with `RUN_TIME = 0`.
3. Continue for at least 10 minutes.

Expected:

- one new `treatment_id`
- one active row in `device_state`
- `continuity_source = NEW`
- raw packets belong to that treatment
- `H00` exists for that treatment

Likely module if fail:

- `treatment_recorder.py`
- `treatment_snapshot_service.py`
- `raw_streamer.py`

### TC-L02 Same patient reconnect after 4h gap

Goal:

- verify same treatment continues
- verify gap does not force a split

Setup:

- active treatment already exists
- same `device_id`
- same `patient_id`
- reconnect packet has `RUN_TIME > 0`

Steps:

1. Run live for a few hours or simulate logical gap.
2. Stop packets for about 4 hours.
3. Resume packets with same patient and `RUN_TIME > 0`.

Expected:

- same `treatment_id` before and after reconnect
- treatment not closed by 4h gap alone
- `had_interruption` may be set
- raw manifest still belongs to same treatment
- `Hxx` continues on same treatment

Hard fail:

- treatment UUID changes
- raw ownership changes to a new treatment
- `H00` restarts

Likely module if fail:

- `treatment_recorder.py`
- `treatment_snapshot_service.py`

### TC-L03 END then same patient with `RUN_TIME > 0`

Goal:

- verify simple continuity rule works after END

Steps:

1. Run a treatment.
2. Send `END`.
3. Later send same patient on same device with start gate satisfied and `RUN_TIME > 0`.

Expected:

- same treatment may continue
- timeline remains on same treatment
- raw remains on same treatment

Hard fail:

- treatment splits when continuity should have been preserved
- raw switches to new UUID unexpectedly

Likely module if fail:

- `treatment_recorder.py`
- `raw_streamer.py`

### TC-L04 END then same patient with `RUN_TIME = 0`

Goal:

- verify fresh start creates a new treatment only when start gate is true

Steps:

1. Run a treatment.
2. Send `END`.
3. Send later packets for same patient with `RUN_TIME = 0`.
4. Run once with start status.
5. Run once without start status.

Expected:

- with start status:
  - new treatment created
- without start status:
  - no new treatment created

Hard fail:

- infinite fake treatments while machine is idle

Likely module if fail:

- `treatment_recorder.py`

### TC-L05 Same patient on different device

Goal:

- verify device-scoped continuity

Steps:

1. Start treatment on device A with patient X.
2. Start packets on device B with same patient X.

Expected:

- device B does not reuse device A treatment
- separate treatment IDs
- separate raw manifests

Hard fail:

- any cross-device resume

Likely module if fail:

- `treatment_recorder.py`
- `postgres_treatment_db.py`

## Group B - Live Hourly And OC Snapshots

### TC-S01 Hourly continuity on active treatment

Goal:

- verify hourly rows stay on same treatment

Steps:

1. Run one treatment across several hours.
2. Observe `H00`, `H01`, `H02`, etc.

Expected:

- all `Hxx` belong to same `treatment_id`
- row times are monotonic
- no duplicate hour label on one treatment

Likely module if fail:

- `treatment_snapshot_service.py`
- `postgres_treatment_db.py`

### TC-S02 Order change interleave in live path

Goal:

- verify `OC_XX` appears between correct hourly rows

Steps:

1. Start treatment.
2. Change QD or QB while treatment continues.
3. Continue sending packets.

Expected:

- `OC_XX` row exists
- `reason` matches the change
- `OC_XX` timestamp sits between adjacent hourly rows
- `OC_XX` auto values reflect the new post-change state

Hard fail:

- OC row shows stale values equal to the previous hourly row

Likely module if fail:

- `event_service`
- `treatment_snapshot_service.py`

### TC-S03 Gap rendering after live interruption

Goal:

- verify backend does not fabricate hourly rows for missing hours

Steps:

1. Run one treatment.
2. Stop packets long enough to miss one or more hourly boundaries.
3. Resume same treatment.

Expected:

- missing hours remain missing in SQL
- frontend may render GAP virtually
- backend must not synthesize fake `Hxx`

Likely module if fail:

- `treatment_snapshot_service.py`
- frontend timeline rendering

## Group C - Backfill Chronology

### TC-B01 Golden chronology replay

Goal:

- verify replay matches expected clinical order

Use one known golden treatment with expected timeline.

Expected checks:

- `H00` timestamp = slot/baseline anchor
- `Hxx` timestamps follow correct chronology
- `OC_XX` inserted at the correct moment
- no fake gap-fill rows

Likely module if fail:

- `historical_backfill_importer.py`

### TC-B02 Restart during backfill

Goal:

- verify checkpoint-based restart behavior

Steps:

1. Start backfill.
2. Stop backend mid-run.
3. Restart backend.
4. Continue replay.

Expected:

- no duplicate `Hxx`
- no duplicate `OC_XX`
- projection checkpoint is advanced consistently
- result is deterministic

Likely module if fail:

- `historical_backfill_importer.py`
- `treatment_projection_checkpoint`

### TC-B03 Missing-data backfill

Goal:

- verify downtime remains downtime

Steps:

1. Replay dataset with a known missing period.
2. Check SQL and UI.

Expected:

- backend does not create fake hourly rows for the missing window
- frontend shows the gap based on missing `Hxx`

Likely module if fail:

- `historical_backfill_importer.py`

## Group D - Raw Data Integrity

### TC-R01 Raw continuity on resume

Goal:

- verify raw does not split when treatment continuity is preserved

Steps:

1. Start live treatment.
2. Resume same treatment after a reconnect or END + `RUN_TIME > 0`.
3. Inspect raw manifest.

Expected:

- all new packets stay under same `treatment_id`
- chunk rotation is allowed
- treatment ownership must not switch

Hard fail:

- analyzer would see two treatments where timeline still shows one

Likely module if fail:

- `treatment_recorder.py`
- `raw_streamer.py`
- lifecycle hook wiring in `main.py`

### TC-R02 Raw close on true new treatment

Goal:

- verify old raw stream closes when a real new treatment starts

Steps:

1. End one treatment.
2. Start a real fresh treatment.
3. Inspect raw manifest for both.

Expected:

- old treatment raw chunk is closed
- new treatment gets its own raw ownership
- no overlap ambiguity in active chunk ownership

Likely module if fail:

- `raw_streamer.py`
- `main.py`
- `treatment_recorder.py`

### TC-R03 Ghost/short treatment cleanup

Goal:

- verify short/noise sessions do not poison raw ownership

Steps:

1. Create a short live session below cleanup threshold.
2. End or interrupt it.

Expected:

- if cleanup rule applies, treatment is removed cleanly
- raw files/chunks do not remain orphaned

Likely module if fail:

- `treatment_recorder.py`
- `raw_streamer.py`

## Group E - Restart And Recovery

### TC-X01 Restart with active live treatment

Goal:

- verify recovery restores only the correct live session

Steps:

1. Start live treatment.
2. Restart backend.
3. Continue packets.

Expected:

- exactly one active session restored
- same `treatment_id`
- no duplicate active sessions on same device

Likely module if fail:

- `treatment_recorder.py`
- `device_state`

### TC-X02 Restart after backfill

Goal:

- verify backfill state does not bleed into live state

Steps:

1. Run backfill.
2. Restart backend.
3. Start live packets on the same device.

Expected:

- no stale backfill session promoted into live accidentally
- device state is correct

Likely module if fail:

- `treatment_recorder.py`
- `device_state`
- handoff logic

## Group F - Review/Approval Runtime Safety

### TC-A01 Approved treatment continues

Goal:

- verify current intended behavior: approval does not block continuity

Steps:

1. End treatment.
2. Approve it.
3. Resume same patient same device with `RUN_TIME > 0`.

Expected:

- runtime may continue same treatment if that is the chosen policy
- report this explicitly as "expected policy"

Likely module if fail:

- `treatment_recorder.py`
- review integration

## Bug Report Template

### Header

- Case ID:
- Date/time:
- Tester:
- Environment:
- Backend build/branch:
- Channel used:
  - `LIVE`
  - `BACKFILL`

### Context

- Device ID:
- Patient ID:
- Treatment ID(s):
- Approx packet window:

### Expected

- one short paragraph

### Actual

- one short paragraph

### Evidence

- UI screenshot:
- SQL screenshot/output:
- log excerpt:

### SQL Attached

- treatments query:
- journal query:
- raw manifest query:
- checkpoint query:

### Severity

- `P0`
- `P1`
- `P2`
- `P3`

### Suspected Modules

- `treatment_recorder.py`
- `treatment_snapshot_service.py`
- `historical_backfill_importer.py`
- `raw_streamer.py`
- `main.py`
- `postgres_treatment_db.py`
- frontend timeline

### Fix Direction Hint

Use one line only:

- lifecycle
- snapshot timing
- OC timing
- restart recovery
- raw close/open wiring
- checkpoint read/write mismatch

## Symptom To Module Mapping

### Symptom: same treatment suddenly becomes a new UUID

Check first:

- `treatment_recorder.py`

### Symptom: `H00` or `Hxx` time is wrong

Check first:

- `treatment_snapshot_service.py`
- `historical_backfill_importer.py`

### Symptom: `OC_XX` shows stale values

Check first:

- `historical_backfill_importer.py`
- `treatment_snapshot_service.py`

### Symptom: UI looks continuous but analyzer/raw sees split

Check first:

- `raw_streamer.py`
- `main.py`
- lifecycle hook wiring

### Symptom: restart changes the result

Check first:

- `device_state`
- `treatment_projection_checkpoint`
- `_recover_from_db()`

## Exit Criteria

QA can call a scenario "passed" only if:

- UI is correct
- SQL is correct
- logs do not show conflicting lifecycle behavior
- raw manifest ownership matches treatment continuity

If only UI looks correct but SQL/raw is wrong, the case must still be marked **FAIL**.
