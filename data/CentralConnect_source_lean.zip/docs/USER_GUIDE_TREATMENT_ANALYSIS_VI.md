# HƯỚNG DẪN SỬ DỤNG: CÔNG CỤ PHÂN TÍCH ĐIỀU TRỊ (TREATMENT ANALYZER)

_Phiên bản: 1.1 — Cập nhật: 2026-04-03_
_Phạm vi áp dụng: Bác sĩ, Trưởng khoa, Chuyên viên nghiên cứu lâm sàng_

---

## 1. TỔNG QUAN

**Treatment Analyzer** là một công cụ phân tích độc lập (standalone), hoạt động ở chế độ **Chỉ đọc (Read-Only)**, cho phép hồi cứu toàn bộ dữ liệu gốc (Raw Telemetry) từ mỗi phiên lọc máu liên tục (CRRT) trên nền tảng PrismaFlex với độ phân giải vi mô (~10 giây/gói dữ liệu).

### Đặc điểm kỹ thuật:

- Tích hợp trên cổng kết nối riêng biệt (`http://localhost:5555`), **tuyệt đối không ảnh hưởng** đến hệ thống vận hành chính (Production Environment).
- Truy xuất dữ liệu ở chế độ chỉ đọc — loại bỏ hoàn toàn rủi ro can thiệp hay hiệu đính vào cơ sở dữ liệu gốc (Raw DB).
- Hỗ trợ đánh giá cả các phiên điều trị đang diễn tiến (`.jsonl`) lẫn các phiên đã hoàn tất lưu trữ (`.jsonl.gz`).

### Khác biệt so với Dashboard và Treatment Journal:

| Tiêu chí phân tích  | Dashboard                         | Treatment Journal                | Treatment Analyzer                       |
| :------------------ | :-------------------------------- | :------------------------------- | :--------------------------------------- |
| Chức năng           | Giám sát thời gian thực           | Hồ sơ bệnh án đánh mốc giờ       | Hồi cứu số liệu gốc chi tiết chuyên sâu  |
| Mật độ lấy mẫu      | Gói dữ liệu hiện tại (Real-time)  | Trích xuất mỗi giờ (H00, H01...) | Toàn bộ gói dữ liệu phân giải cao (~10s) |
| Đặc quyền hiệu đính | Không vi phạm                     | Khả thi (Sau khi kết thúc phiên) | Từ chối hoàn toàn — Chỉ Đọc              |
| Phân hệ truy cập    | Tích hợp trong hệ thống điều hành | Tích hợp trong ứng dụng nội bộ   | Nền tảng ứng dụng độc lập (Port 5555)    |

---

## 2. CÁC NHÓM DỮ LIỆU PHÂN TÍCH

Treatment Analyzer cấu trúc phân tích dữ liệu thành các trường phái sau:

### 2.1. Thông Số Áp Lực (Pressure — 7 tham số)

Toàn bộ dữ liệu huyết động và áp lực từ mạch ngoài cơ thể, truy suất mẫu mỗi ~60 giây:

| Chỉ số | Cơ sở lý thuyết y khoa                       | Phân vị |
| :----- | :------------------------------------------- | :------ |
| PA     | Access Pressure (Áp lực đường vào tĩnh mạch) | mmHg    |
| PV     | Return Pressure (Áp lực đường về tĩnh mạch)  | mmHg    |
| PBE    | Filter Pressure (Áp lực quả lọc)             | mmHg    |
| PEff   | Effluent Pressure (Áp lực dịch thải)         | mmHg    |
| TMP    | Transmembrane Pressure (Áp lực xuyên màng)   | mmHg    |
| ΔP     | Delta P (Chênh áp đi qua quả lọc)            | mmHg    |
| ARPS   | Bơm hồi áp tĩnh (ARPS Pressure)              | mmHg    |

### 2.2. Chỉ Định Y Lệnh (Prescription — Lưu lượng và Cấu hình)

Ghi nhận mọi hiệu chỉnh y lệnh được thực thi trong thời gian điều trị:

- Thư viện huyết động: **Lưu lượng máu (QB)**, Dịch bù trước/sau quả lọc (QS Pre, QS Post), Dịch thẩm tách (QD), Dịch thải (QEff).
- Các chỉ số vi lọc: **Siêu lọc thực (Net UF)**, Liều Effluent (Eff Dose), Tỷ số thanh thải (Filt Frac).
- Danh mục Chống đông: Phác đồ chống đông (Anticoag Type), Tốc độ truyền Heparin (Hep Rate), Liều Citrate (Cit Dose), Tốc độ bù Calcium (Ca Rate).
- Y lệnh tổng quan: Cân nặng định danh (Weight), Quả lọc (Filter Set), Tỷ lệ HCT Port/Pre.

> Từng biến thiên y lệnh sẽ được hệ thống theo dấu thay đổi song song: thời điểm, giá trị ghi nhận cũ và giá trị vận hành mới — tối ưu hóa hệ thống kiểm chứng diễn tiến lâm sàng của bệnh nhân.

### 2.3. Cân Trọng Lượng Dịch (Scale — Khối lượng các túi dịch)

Hàng rào 4 cân điện cơ chuyên biệt trên thân máy:

| Hệ thống | Chức năng túi dịch         | Đơn vị |
| :------- | :------------------------- | :----- |
| Scale 1  | Pre-Blood (Dịch pha loãng) | gram   |
| Scale 2  | Replacement (Dịch bù)      | gram   |
| Scale 3  | Dialysate (Dịch thẩm tách) | gram   |
| Scale 4  | Effluent (Dịch thải)       | gram   |

### 2.4. Công Suất Bơm (Pump Speed)

Phát tín hiệu truy suất 4 bơm cơ học PrismaFlex:

| Động cơ | Hoạt động chuyên biệt | Phân vị |
| :------ | :-------------------- | :------ |
| Pump 1  | Bơm Pre-Blood         | rpm     |
| Pump 2  | Bơm Dịch bù           | rpm     |
| Pump 3  | Bơm Dịch thẩm tách    | rpm     |
| Pump 4  | Bơm Dịch thải         | rpm     |

### 2.5. Lịch Sử Thể Tích Dịch Vào/Ra (I/O History)

Trích xuất báo cáo số liệu thể tích chất lỏng trao đổi tích lũy đi qua hệ thống bơm:

- Pre Infusion, Post Infusion, Dialysate, Pre-Blood, Effluent, Bilan dịch ròng của bệnh nhân (Excess Patient Fluid), Syringe (bơm tiêm).
- Run Time (Thời gian vận hành tính bằng giây).

### 2.6. Khảo Báo Động Lâm Sàng (Alarm Timeline)

Lịch sử toàn vẹn của các sự kiện cảnh báo y khoa:

- Chu kỳ báo động: Bùng phát đến thời điểm được xử trí lâm sàng (PRESENT → CLEARED).
- Đánh giá hiện trạng: Cảnh báo liên tục (PRESENT), Chấp nhận bỏ qua (OVERRIDDEN), Đã giải quyết (CLEARED).
- Chiếu dẫn kho tư liệu (Reference database) để diễn giải danh pháp, ý nghĩa học thuật và phân loại rủi ro (severity) của mỗi mã báo động.
- Bảng thống kê (Summary): Cường độ báo động lặp lại, mốc thời gian khởi phát đầu tiên và lần ghi nhận muộn nhất.

---

## 3. HƯỚNG DẪN THAO TÁC CÔNG CỤ

### Bước 1: Khởi động công cụ

- Chạy mã thực thi `start_analyzer.bat` (hoặc câu lệnh `python app.py` trực tiếp tại directory `tools/treatment_analyzer`).
- Thiết lập trình duyệt hiển thị, điều hướng về cổng: **http://localhost:5555**

### Bước 2: Chỉ định ca lâm sàng

- Trung tâm hiển thị tập hợp các lịch sử điều trị (Mặc định 100 phiên lưu trữ gần đây), cung cấp các góc nhìn tổng quan:
  - Mã serial thiết bị, Tên bệnh nhân, Phân hệ điều trị áp dụng, Chronology chu kỳ.
  - Tình trạng phê duyệt bệnh án (Approval Status).
  - Dung lượng cơ sở dữ liệu gốc của phiên chạy (Raw File Size).
- Lựa chọn phiên cụ thể cần đối chiếu.

### Bước 3: Diễn giải đồ thị

Phân hệ bao gồm 6 không gian truy suất thông tin:

1. **Biểu đồ biến thiên áp lực (Pressure Charts):** Ghi dấu dữ liệu 7 cấu phần áp lực. Cho phép bật/tắt đồ thị động nhằm lược bỏ các dao động không liên quan.
2. **Đồ thị Y lệnh (Parameter Timeline):** Diễn giải lịch sử biến thiên cài đặt máy (Order Changes) dưới dạng chỉ mục trên trục thời gian ngang.
3. **Bảng định lượng I/O (IO History):** Số liệu tích lũy thể tích chất lỏng, phân chia mẫu đồ mỗi 60 giây.
4. **Hệ số áp lực (Pressure Table):** Giá trị số học của áp lực, tần suất trích mẫu mỗi 60 giây.
5. **Hệ số bơm (Pump Table):** Bảng chuyển động rpm của 4 mô tơ chuyên biệt.
6. **Lịch sử sự cố (Alarm Log):** Tòa thư viện sự kiện cảnh báo kèm phụ đề lý giải và phân bậc.

### Bước 4: Hiệu chỉnh tự động (Đặc biệt với phiên Running)

Sử dụng phím chức năng **Refresh** giúp làm mới gói dữ liệu, trích dẫn bản cập nhật theo thời gian thực từ đầu ghi.

---

## 4. ỨNG DỤNG LÂM SÀNG & NGHIÊN CỨU

| Bối cảnh y học                  | Thao tác trên Analyzer                                                                                                          |
| :------------------------------ | :------------------------------------------------------------------------------------------------------------------------------ |
| **Đông quả lọc sớm tái diễn**   | Phân tích tương quan biểu đồ TMP và ΔP với điểm mốc điều chỉnh hạ/cắt liều Heparin trên trục thời gian.                         |
| **Đánh giá hiệu suất màng**     | Đối chiếu tham số Effluent Rate (QEff) được chỉ định y lệnh so với khối lượng Effluent thực tế đo lường ở bảng I/O History.     |
| **Điều tra sự cố thất thoát**   | Giám sát sự cố lưu ở Alarm Log đồng thời truy soát biểu đồ áp lực Access/Return để định danh vấn đề do đường truyền hay cather. |
| **Công tác rút siêu lọc**       | Kiểm tra bảng I/O History: Khử nhiễu để đối chiếu tổng khối lượng dịch đi vào so với khối lượng siêu lọc rút ra (Effluent).     |
| **Kết xuất dữ liệu định lượng** | Ứng dụng chức năng _Export Raw CSV_ thu thập biểu đồ độ mịn cao trích xuất cho các phần mềm khoa học chuyên sâu.                |

---

_Tài liệu thuộc hệ thống ICU-B Connect — PrismaFlex Device Manager._
