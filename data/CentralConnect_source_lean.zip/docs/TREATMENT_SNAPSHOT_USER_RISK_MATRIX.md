# Treatment Snapshot User Risk Matrix

> Updated: 2026-04-03
> Scope: user-facing Treatment Journal flows, feature risk review, keep/remove recommendations

## Executive Summary

Treatment Snapshot has a clinically strong core:

- auto `H00`
- hourly `H01/H02/...`
- `OC_XX` capture
- originals + restore
- review/approval workflow

But the user-facing editing layer has grown in a patchwork way and now has conflict risk between:

- chronology
- manual gap filling
- restore
- delete
- print/export/review ordering

The biggest design conclusion is:

- keep the clinical snapshot model
- simplify the manual editing model
- restrict synthetic row creation
- remove any UX that can create rows beyond trustworthy clinical boundaries

## Feature Decision Matrix

| Feature | Current Value | Current Risk | Recommendation |
|---|---|---|---|
| Auto `H00` capture | Very high | Low | Keep |
| Auto `H01/H02/...` hourly capture | Very high | Low | Keep |
| Auto `OC_XX` capture | High | Medium if chronology sorting breaks | Keep |
| Edit existing row | High | Medium if chronology mutates | Keep with strict chronology fix |
| Restore existing row from originals | High | Medium if original metadata is lost | Keep with full metadata restore |
| Restore missing row from originals | Medium-High | High if row time is rebuilt incorrectly | Keep only after restore metadata fix |
| Fill gap inside existing timeline | Medium | Medium | Keep, but guard strongly |
| Add next row after last hour | Low-Medium | High | Hide or remove for now |
| Delete row | Medium | High medico-legal risk | Restrict heavily |
| Bulk update all rows | Low | High audit/conflict risk | Hide unless there is a real clinical need |

## Recommended Product Policy

### 1. Keep

- Auto snapshots
- Order-change snapshots
- Manual edit of an existing row
- Restore an existing row from originals
- Restore a missing row from originals, but only after metadata-preserving restore is fixed

### 2. Keep with restrictions

- Gap fill for missing `Hxx` rows only if:
  - the row is inside the known treatment timeline
  - the treatment is not approved
  - the action is auditable
  - the row is clearly marked as manual

### 3. Hide or remove for now

- `Add Next Hour` / arbitrary "add row after the last one"

Reason:

- it can invent future or non-observed clinical structure
- it is easy to create a row beyond real treatment duration
- it collides with restore, export, review, and chronology rules
- its clinical value is weaker than its data-integrity risk

If the hospital truly needs it later, redesign it as a controlled workflow:

- explicit modal
- explicit reason
- explicit target hour
- bounds checking against treatment duration
- audit log

## User Scenario Matrix

## A. Normal telemetry-driven care

### A1. Treatment starts normally

User flow:

- machine starts
- telemetry arrives
- system creates `H00`
- later creates `H01`, `H02`

Expected:

- no manual actions needed
- chronology stable
- review/export stable

Risk:

- low

### A2. Order change between hourly rows

User flow:

- `H01` exists
- clinician changes a key setting
- system creates `OC_01`
- later `H02` appears

Expected:

- `OC_01` appears between `H01` and `H02`

Current risk:

- high if sorting forces all `Hxx` rows first and all `OC_XX` rows later

## B. Manual correction of an existing row

### B1. Nurse edits `H00`

User flow:

- `H00`, `H01`, `H02` already exist
- nurse edits one field in `H00`

Expected:

- `H00` stays in first clinical position
- only values change
- `updated_at` changes

Current risk:

- previously confirmed chronology bug
- mostly fixed in backend update path

### B2. Doctor restores `H00` from originals

User flow:

- row was manually edited
- doctor clicks restore

Expected:

- values revert to original machine values
- chronology stays unchanged

Current risk:

- medium-high if frontend drops original `snapshot_time`

## C. Missing telemetry / gap management

### C1. Missing `H03` inside an otherwise valid timeline

User flow:

- `H00`, `H01`, `H02`, `H04` exist
- user fills `H03`

Expected:

- `H03` inserted at `start_time + 3h`
- row marked manual
- chronology remains valid

Risk:

- acceptable if the row is inside a known timeline

### C2. User adds "next hour" after the last observed row

User flow:

- last real row is `H04`
- user clicks add row for `H05`

Expected if feature exists:

- system should know whether `H05` is clinically justified

Current reality:

- current feature can create synthetic future structure with weak validation

Risk:

- high

Recommendation:

- hide/remove this action for now

### C3. Missing row restored from originals

User flow:

- current detail is missing `H03`
- originals still contain `H03`
- user clicks restore missing rows

Expected:

- row comes back with original values and original clinical time

Current risk:

- high if only `orig.data` is restored and original time metadata is lost

## D. Review / approval workflow

### D1. Nurse submits treatment

Expected:

- originals frozen once
- later compare/restore has a trusted baseline

Risk:

- low if originals are complete

### D2. Doctor reviews differences

Expected:

- compare view shows actual value changes only
- chronology is already stable

Current risk:

- medium if row ordering differs between detail/review/print/export

### D3. Approved treatment

Expected:

- no further edits
- no row insert
- no delete

Risk:

- low if all write endpoints honor approval lock

## E. Destructive actions

### E1. Delete an hourly row

Expected:

- only very privileged roles can do it
- action must be auditable
- chronology must remain understandable afterward

Clinical risk:

- high

Recommendation:

- keep only for doctor/admin
- preferably require reason
- consider soft-delete instead of hard-delete in the future

### E2. Delete then restore

Expected:

- restored row comes back at original clinical position

Current risk:

- high if restore lacks original timestamp metadata

## Potential System Conflicts

## 1. Chronology conflict

If any user action rewrites `snapshot_time`, then:

- detail panel breaks
- review table breaks
- print breaks
- export breaks

## 2. `OC_XX` placement conflict

If the system forces:

- all `Hxx` first
- all `OC_XX` later

then the chart/journal loses the real intervention timeline.

## 3. Synthetic row conflict

If users can freely add future rows:

- duration can be exceeded
- exports can imply care that never existed in telemetry
- restore and review become harder to trust

## 4. Restore metadata conflict

If originals only keep `data` and not timing context:

- restore can recover numbers
- but not chronology

That is not a safe clinical restore.

## 5. Multi-view inconsistency

If each screen sorts differently:

- detail panel
- review page
- print preview
- Excel export

then the same treatment may show different journal order depending on where the user looks.

## Keep/Remove Recommendation For "Add Row"

## Recommendation: remove the bottom "Add Next Hour" action for now

Reason:

- it is the weakest clinical feature
- it has the highest structural risk
- it encourages synthetic documentation outside observed telemetry
- it overlaps with safer tools:
  - edit existing row
  - fill an internal gap
  - restore from originals

## Recommendation: keep controlled gap fill only

Allowed case:

- filling a missing internal `Hxx` row inside an already-known timeline

Not allowed:

- creating arbitrary new trailing hours after the current last row without clinical bounds

## Suggested OPUS Follow-up

1. Fix chronology ordering so `OC_XX` is interleaved correctly again.
2. Fix restore flow to keep full original metadata, not just `data`.
3. Remove or hide `Add Next Hour` UI for now.
4. Keep internal gap-fill only for `Hxx`.
5. Consider adding a required reason for delete and manual row creation.
6. Ensure detail, review, print, and export use one shared chronology rule.

## One-Line CTO Guidance

Treatment Snapshot should behave like a clinical journal, not like a spreadsheet: preserve time, preserve auditability, and avoid creating synthetic rows unless the system can prove where they belong.
