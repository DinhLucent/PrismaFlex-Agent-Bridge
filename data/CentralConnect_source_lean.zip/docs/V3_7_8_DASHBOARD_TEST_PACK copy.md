# v3.7.8 Dashboard Test Pack

Updated: 2026-04-14

This document isolates Dashboard validation from the broader treatment-runtime
pack.

Use this when the goal is specifically to verify:

- realtime device tiles
- trend persistence / reload behavior
- patient-boundary clearing
- alarm/event display
- device isolation
- offline/reconnect behavior
- TMP / DeltaP chart rendering safety

Reference master runtime spec:

- [V3_7_8_MASTER_RUNTIME_TEST_PACK.md](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\docs\V3_7_8_MASTER_RUNTIME_TEST_PACK.md)

---

## 1. Scope

This Dashboard pack covers:

- home dashboard list
- device detail view
- websocket ingest into frontend state
- pressure trend retention
- event list / "Was" change data
- alarm state display
- patient-change clearing
- device online/offline status

It does not decide treatment continuity by itself, but it must stay consistent
with treatment identity rules from the master pack.

---

## 2. Important Note For OPUS

Older review findings may mention `TrendProvider.tsx`.

In the current repo state, there is no:

- `frontend/app/providers/TrendProvider.tsx`

The current frontend aggregation path is centered on:

- [WebSocketProvider.tsx](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\providers\WebSocketProvider.tsx)

Do not waste time searching for a removed provider and then drawing conclusions
from stale assumptions.

---

## 3. Dashboard Architecture

### 3.1 Frontend modules

Main frontend modules relevant to dashboard behavior:

- [WebSocketProvider.tsx](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\providers\WebSocketProvider.tsx)
- [types.ts](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\types.ts)
- [page.tsx](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\(main)\page.tsx)
- [monitor\[id]\page.tsx](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\(main)\monitor\[id]\page.tsx)
- [DeviceCard.tsx](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\components\DeviceCard.tsx)

### 3.2 Backend modules

Main backend modules relevant to dashboard behavior:

- [event_service.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\services\event_service.py)
- [database.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\services\database.py)
- [alarm_service.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\services\alarm_service.py)
- [ws_manager.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\services\ws_manager.py)
- [main.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\main.py)

### 3.3 Persistence layers

Dashboard data is not only in memory.

Relevant persistence:

- backend trend/event/alarm DB:
  - [database.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\services\database.py)
- browser localStorage:
  - key `known_devices`
  - keys `threshold_tmp_${deviceId}`
  - keys `threshold_dp_${deviceId}`

Expected meaning:

- backend `pressure_trends` is the canonical source of detail-chart history
- backend stores trends, events, alarms, and last patient session for reset logic
- frontend localStorage stores lightweight UI preferences only, not the complete
  trend history

### 3.4 Detail trend hydration flow

Current intended flow:

1. backend keeps writing `pressure_trends` per device
2. user opens device detail
3. detail page fetches `/api/v1/devices/{device_id}/trends`
4. chart hydrates from backend rows
5. websocket packets then append new live points

Expected:

- chart history does not depend on the detail page staying open
- chart history does not depend on a browser-side `history_${deviceId}` cache
- closing the browser should not destroy trend history already retained by backend

---

## 4. Data Structures OPUS Must Understand

### 4.1 `DeviceData`

Current frontend type shape:

- `id`
- `name`
- `ip`
- `status`
- `lastUpdate`
- `packetNum`
- `data`
- `active_alarms`
- optional `quality`

Reference:

- [types.ts](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\types.ts)

### 4.2 WebSocket message types

Dashboard currently consumes these relevant message types:

- `HEARTBEAT`
- `TELEMETRY_FAST_UPDATE`
- `TELEMETRY_UPDATE`
- `EVENT_UPDATE`

Expected roles:

- `HEARTBEAT`: sync server time and connection health
- `TELEMETRY_FAST_UPDATE`: fast incremental vitals refresh
- `TELEMETRY_UPDATE`: fuller device state payload
- `EVENT_UPDATE`: parameter-change events for "Was" logic

### 4.3 Trend storage shape

Backend stores pressure trends in SQLite table:

- `pressure_trends`

Fields currently inserted:

- `device_id`
- `timestamp`
- `access`
- `filter`
- `effluent`
- `return`
- `tmp`
- `delta_p`

Meaning:

- one trend row per device per incoming packet cadence
- rolling retention capped to 1000 rows per device

### 4.4 Event storage shape

Backend stores parameter-change events in:

- `parameter_events`

Fields:

- `device_id`
- `timestamp`
- `param_id`
- `old_value`
- `new_value`

### 4.5 Alarm storage shape

Backend stores alarm history in:

- `alarm_history`

Fields:

- `device_id`
- `alarm_id`
- `title`
- `severity`
- `start_time`
- `end_time`
- `patient_id`

### 4.6 Session reset signal

Dashboard-clearing logic is ultimately driven by patient identity changes.

Important backend logic:

- `EventService.track_parameter_changes(...)`
- on patient change, `_purge_session(device_id, reason)` is called

Effects:

- trend history purged for that device
- event history purged for that device
- alarm history purged for that device
- session cache reset for that device

Expected frontend consequence:

- new patient should not inherit old dashboard history

---

## 5. Canonical Dashboard Rules

### 5.1 Trend persistence rule

Backend must keep accumulating device trend data even when:

- device detail page is not open
- user is on another screen
- the browser is closed

Detail page must then recover that history from backend when the user comes
back.

Expected:

- opening detail later shows already-retained backend points
- once detail is open, new live packets append on top of the hydrated history
- backend remains the source of truth for trend chronology

Hard fail:

- chart starts moving only after opening device detail
- chart depends on a stale browser cache to recover history

### 5.2 Patient-boundary clear rule

Dashboard state for a device must clear when:

- `patient_id` changes for that device

Expected after patient change:

- old pressure history gone
- old "Was" event history gone
- old alarm state/history for that device session gone
- new patient starts from a clean dashboard context

Hard fail:

- new patient points append to old patient chart
- old patient alarms remain visible under new patient
- old patient "Was" values remain visible under new patient

### 5.3 Device isolation rule

Dashboard state is device-scoped.

Expected:

- device A trend does not appear under device B
- device A alarms do not appear under device B
- device A events do not appear under device B

### 5.4 Offline rule

If device receives no packet for more than the offline timeout window, it should
appear offline.

Current frontend logic:

- if no update for about 45 seconds, status becomes `OFFLINE`

Expected:

- stale device goes offline
- a later packet returns it to live state

### 5.5 Retention cap rule

Pressure trend history should be capped.

Current backend target:

- latest 1000 rows per device

Expected:

- oldest rows trimmed
- latest rows preserved
- ordering remains chronological
- no UI freeze from unbounded growth

### 5.6 Status mapping rule

Frontend device card status should map consistently from therapy/alarm state.

Current behavior in frontend:

- running-like statuses map to `RUNNING`
- `therapy_status_id = 9` maps to `ALARM`
- stopped-like statuses map to `STOPPED`
- missing/stale device may become `OFFLINE`

QA focus:

- state transitions should be plausible and stable
- no flapping caused by stale packet order alone

---

## 6. Dashboard Oracle

A dashboard testcase is `PASS` only if all of these are true:

- visible chart behavior is correct
- backend trend/event/alarm storage is consistent
- no patient or device bleed occurs
- backend trend accumulation and later detail hydration both work correctly
- offline/online status transitions are plausible

If the chart looks correct but DB/session state is mixed, the case is still
`FAIL`.

---

## 7. Core Checks

### 7.1 Backend SQL - pressure trends

```sql
SELECT device_id, count(*) AS trend_rows, min(timestamp) AS first_ts, max(timestamp) AS last_ts
FROM pressure_trends
GROUP BY device_id
ORDER BY device_id;
```

### 7.2 Backend SQL - parameter events

```sql
SELECT device_id, count(*) AS event_rows, min(timestamp) AS first_ts, max(timestamp) AS last_ts
FROM parameter_events
GROUP BY device_id
ORDER BY device_id;
```

### 7.3 Backend SQL - alarm history

```sql
SELECT device_id, count(*) AS alarm_rows, min(start_time) AS first_start, max(start_time) AS last_start
FROM alarm_history
GROUP BY device_id
ORDER BY device_id;
```

### 7.4 Backend SQL - last patient session

```sql
SELECT device_id, last_patient_id
FROM device_sessions
ORDER BY device_id;
```

### 7.5 Frontend inspection

OPUS should inspect:

- browser console errors
- websocket message flow
- visible chart continuity
- localStorage key `known_devices`

Important:

- `known_devices` is a registry helper, not the canonical trend store
- threshold keys are UI preferences only
- do not infer trend correctness only from localStorage

---

## 8. Smoke Test Pack

### DT-ST01 Dashboard opens

Expected:

- dashboard page loads
- device cards render
- no frontend crash

### DT-ST02 Device detail opens

Expected:

- detail view opens
- chart renders
- no crash when entering or leaving detail

### DT-ST03 WebSocket connected

Expected:

- connection status becomes `CONNECTED`
- heartbeat updates server time

### DT-ST04 Device goes offline when silent

Expected:

- after silence timeout, status becomes `OFFLINE`

### DT-ST05 Device comes back online

Expected:

- first later packet returns the device from `OFFLINE` to a live state

### DT-ST06 Detail reloads retained trend

Expected:

- open detail, leave it, let packets continue, open detail again
- chart shows retained backend history before new live points arrive

---

## 9. Detailed Dashboard Test Matrix

## Group D1 - Realtime Trend Behavior

### DT-01 Detail reloads trend retained while detail is closed

Goal:

- verify backend trend persistence is not tied to an open detail view

Steps:

1. Keep live packets arriving for one device.
2. Stay on dashboard list or another screen.
3. Wait long enough for several new points.
4. Open device detail.

Expected:

- chart already contains the missing interval from backend history
- trend does not start only after detail is opened
- after hydration, new packets continue to append live

Hard fail:

- chart only begins updating from the moment detail is opened

### DT-02 Detail reloads trend after browser refresh / reopen

Goal:

- verify chart history survives browser lifecycle because backend retains it

Steps:

1. Open device detail while live packets are arriving.
2. Close the tab or refresh the page.
3. Wait for more packets.
4. Reopen the same device detail.

Expected:

- chart is rebuilt from backend trend rows
- previously retained points are visible again
- no dependency on a browser-side history cache

### DT-03 Trend chronology stays ordered

Goal:

- verify points stay time-ordered after accumulation

Expected:

- visible chart has no obvious backward time jumps caused by frontend ordering

### DT-04 Retention cap is enforced

Goal:

- verify trend rows do not grow unbounded

Expected:

- per-device backend trend rows eventually cap at about 1000
- newest rows preserved
- old rows trimmed

Hard fail:

- trend rows grow without cap
- chart becomes visibly laggy due to unbounded growth

## Group D2 - Patient Boundary

### DT-05 Patient change clears pressure trend

Goal:

- verify new patient starts from clean chart

Setup:

- one device with existing chart history
- later packet changes `patient_id`

Expected:

- old trend cleared for that device
- new patient starts from a clean chart state

Hard fail:

- first new patient points append onto previous patient's chart

### DT-06 Patient change clears "Was" events

Expected:

- old parameter-change event history is removed
- new patient does not inherit old "Was" context

### DT-07 Patient change clears alarm context

Expected:

- old patient alarm state/history no longer appears as active under the new patient

## Group D3 - Device Isolation

### DT-08 Pressure trend isolation across devices

Setup:

- 2 or more active devices

Expected:

- device A chart shows only device A data
- device B chart shows only device B data

### DT-09 Event isolation across devices

Expected:

- device A events never appear under device B

### DT-10 Alarm isolation across devices

Expected:

- device A alarm badges/history never appear under device B

## Group D5 - TMP / DeltaP Chart Safety

These cases are mandatory whenever `DualPressureChart.tsx` changes.

### DT-11 TMP / DeltaP can switch between short window and full history

Goal:

- verify the user can inspect both recent behavior and the full retained range

Expected:

- short window mode still works for near-realtime inspection
- full-history mode shows the whole retained backend buffer
- switching modes does not reorder points

Hard fail:

- chart is permanently locked to one short slice and cannot inspect full range

### DT-12 Threshold does not flatten TMP / DeltaP lines

Goal:

- verify danger thresholds do not dominate Y-axis scaling

Expected:

- normal TMP / DeltaP variation remains readable
- threshold/reference lines can be shown without collapsing the clinical line

Hard fail:

- raising threshold makes the line appear almost flat or disappear visually

### DT-13 Impossible TMP / DeltaP outliers do not destroy chart scaling

Setup:

- inject or replay a packet where TMP or DeltaP is clearly impossible, e.g.
  several thousand or negative several thousand

Expected:

- outlier sample is rejected, sanitized, or rendered as a gap
- surrounding valid points remain readable
- chart domain is not blown out by the invalid sample

Hard fail:

- one invalid point makes the entire chart unreadable
- tooltip / axis / smoothing is dominated by impossible values

### DT-14 Outlier handling does not hide valid adjacent points

Expected:

- only the suspect sample is suppressed
- valid points before and after remain visible in order
- chart recovers immediately after the invalid point

## Group D4 - Status / Connection

### DT-15 Status becomes OFFLINE after timeout

Expected:

- device status changes to `OFFLINE` after about 45s with no updates

### DT-16 Status recovers after new packet

Expected:

- first later packet restores live state

### DT-17 No false OFFLINE during healthy live stream

Expected:

- continuously updated device should not flicker to `OFFLINE`

Hard fail:

- device flips offline while packets still arrive normally

## Group D5 - Alarm / Audio

### DT-18 New critical alarm triggers critical state

Expected:

- device enters visible alarm condition
- critical alarm presence is reflected in active alarms

### DT-19 New warning alarm does not masquerade as critical

Expected:

- warning stays warning
- no escalation to critical unless actual critical category appears

### DT-20 Alarm state clears cleanly

Expected:

- when backend clears alarm, frontend no longer shows it as active

Note:

- audio playback can be browser-permission dependent
- if audio does not play due to browser blocking but alarm state is correct,
  treat it as a separate lower-level issue, not necessarily a dashboard data bug

## Group D6 - Persistence / Refresh

### DT-21 Browser refresh keeps device registry

Expected:

- known devices still appear after refresh
- no corrupted `known_devices` structure

### DT-22 Browser refresh does not fabricate trend history

Expected:

- device registry survives
- trend/event history should reload from backend behavior, not be invented from
  stale frontend state

### DT-23 Forget device removes registry entry

Expected:

- forgotten device removed from local registry
- localStorage updated accordingly

## Group D7 - Mixed Operational Scenarios

### DT-24 Same patient continuation does not clear dashboard

Setup:

- same device
- same patient
- later valid continuation with `RUN_TIME > 0`

Expected:

- dashboard remains on same patient context
- no unnecessary clear just because END happened earlier

### DT-25 Fresh new treatment with same device and same patient but `RUN_TIME = 0`

Expected:

- if runtime treats this as a new treatment but patient ID stays the same, the
  dashboard should not clear solely on treatment split; it should clear only on
  patient boundary

This is an important distinction:

- treatment identity may reset
- dashboard trend history rule is still patient-based, not treatment-based

### DT-26 BACKFILL on one device does not corrupt another device's LIVE dashboard

Expected:

- device-specific dashboard state remains isolated
- one device replaying data does not pollute another device's chart

---

## 10. Data Sources For Dashboard Testing

Preferred data sources:

1. real LIVE feed from a device
2. recent replay for one device using known raw bundle
3. gold datasets:
   - `TRAN VAN VU`
   - `g12 recent`
4. synthetic sandbox only after real-data tests

Relevant local references:

- [backend\data\treatments\raw](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\data\treatments\raw)
- [TRAN_VAN_VU_continuity_report.json](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports\TRAN_VAN_VU_continuity_report.json)
- [g12_recent_continuity_report.json](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports\g12_recent_continuity_report.json)

---

## 11. Expected Modules If Dashboard Fails

Use this mapping when triaging failures.

### Symptom: chart updates only when detail is open

Check first:

- [WebSocketProvider.tsx](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\providers\WebSocketProvider.tsx)
- [page.tsx](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\(main)\page.tsx)

### Symptom: patient change mixes old and new points

Check first:

- [event_service.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\services\event_service.py)
- [database.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\services\database.py)
- [WebSocketProvider.tsx](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\providers\WebSocketProvider.tsx)

### Symptom: alarms bleed across patients or devices

Check first:

- [alarm_service.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\services\alarm_service.py)
- [event_service.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\services\event_service.py)
- [WebSocketProvider.tsx](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\providers\WebSocketProvider.tsx)

### Symptom: device status flickers offline while packets are arriving

Check first:

- [WebSocketProvider.tsx](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\frontend\app\providers\WebSocketProvider.tsx)
- websocket heartbeat / packet cadence

### Symptom: trend retention broken or UI slows down

Check first:

- [database.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\services\database.py)
- backend insert/prune cadence

---

## 12. Bug Report Template For Dashboard

### Header

- Case ID:
- Date/time:
- Environment:
- Source: `LIVE` or `BACKFILL`
- Device ID:
- Patient ID:

### Expected

- short paragraph

### Actual

- short paragraph

### Evidence

- UI screenshot:
- browser console:
- SQL output:
- backend log excerpt:

### Likely module

- `WebSocketProvider.tsx`
- `page.tsx`
- `monitor/[id]/page.tsx`
- `event_service.py`
- `database.py`
- `alarm_service.py`

### Severity

- `P0` patient/device bleed causing clinically wrong dashboard state
- `P1` wrong trend/alarm/event chronology
- `P2` offline/status/persistence mismatch
- `P3` display-only issue

---

## 13. Dashboard Signoff Criteria

Dashboard is acceptable for rollout only if all of these are true:

- device list loads reliably
- detail view opens reliably
- chart keeps updating even while detail is closed
- patient change clears chart/event/alarm context cleanly
- no cross-device bleed
- offline/online status transitions are plausible
- retention cap behaves correctly

If any one of these fails, dashboard should not be considered signed off.
