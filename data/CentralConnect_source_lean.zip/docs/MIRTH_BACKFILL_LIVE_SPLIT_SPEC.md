# Mirth Backfill / Live Split Spec

## Muc tieu

Tai lieu nay ghi lai quyet dinh kien truc de OPUS sua code theo dung huong:

- tach `BACKFILL` va `LIVE` thanh 2 che do van hanh ro rang
- tranh viec du lieu lich su va du lieu live di chung mot pipeline stateful
- giam bug lien quan den:
  - treatment session bi lan state
  - hourly snapshot bi mat `H01/H02/...`
  - recovery/resume can nham vao backfill
  - UI/live alarm bi anh huong boi replay lich su

Tai lieu nay la spec de code, chua phai trang thai da implement.

---

## 1. Ket luan kien truc

### Quyet dinh chot

He thong phai co **2 pipeline tach biet**:

1. `BACKFILL`
2. `LIVE`

Khong duoc chi tach o Mirth transform roi van do vao mot logic backend chung.

Neu chi dung `meta.mode = "BACKFILL"` nhung van dung cung:

- recorder
- active session map
- recovery logic
- snapshot cache
- websocket/alarm path

thi nguy co bug van rat cao.

---

## 2. Van de cua thiet ke hien tai

Hien tai pipeline con mang dac diem:

- packet backfill va live deu di vao cung ingest path
- logic session/treatment co state in-memory theo `device_id`
- snapshot projector co cache theo `device_id`
- startup recovery va auto-close duoc thiet ke cho live runtime

Khi backfill chay rat nhanh, cac dac diem nay de gay ra:

1. `treatment_id` tao/close/resume khong on dinh
2. packet dau cua `H01/H02/H03` co the save fail, roi cache lai troi tiep
3. logic live nhu websocket/alarm/health khong co gia tri voi replay lich su
4. state cua backfill co the va cham voi state cua live neu cutover khong sach

---

## 3. De xuat kien truc moi

```mermaid
flowchart LR
    A["Decoded Raw Packet"] --> B["Mirth Backfill Channel"]
    A --> C["Mirth Live Channel"]

    B --> D["POST /api/v1/telemetry/backfill"]
    C --> E["POST /api/v1/telemetry/live"]

    D --> F["Backfill Ingest Service"]
    E --> G["Live Ingest Service"]

    F --> H["Treatment Builder"]
    F --> I["Hourly Snapshot Projector"]
    F --> J["Order Change Projector"]

    G --> K["Live Recorder"]
    G --> I
    G --> J
    G --> L["Realtime Broadcast / Alarm"]
```

### Nguyen tac

- `BACKFILL` la che do replay du lieu lich su
- `LIVE` la che do van hanh thoi gian thuc
- ca hai co the dung chung mot so ham projection nghiep vu, nhung **khong dung chung stateful runtime path**

---

## 4. Trach nhiem cua tung che do

## 4.1. BACKFILL

`BACKFILL` duoc dung khi:

- do lai du lieu cu tu Mirth
- rebuild treatment journal
- can replay tu raw source theo trinh tu thoi gian

### BACKFILL duoc phep lam

- tao treatment lich su
- ghi raw packet ledger
- project hourly snapshots
- project order-change rows
- cap nhat projection/list history

### BACKFILL khong duoc lam

- khong broadcast websocket realtime cho UI live
- khong bat alarm realtime
- khong goi startup recovery/session recovery theo kieu live
- khong tranh chap voi `LIVE` tren cung `device_id`

---

## 4.2. LIVE

`LIVE` duoc dung khi:

- he thong dang nhan packet moi tu may
- can cap nhat UI theo thoi gian thuc
- can xu ly alarm/trend/session dang hoat dong

### LIVE duoc phep lam

- recorder session live
- realtime websocket
- alarm/trend processing
- project hourly snapshot va OC cho treatment dang chay

### LIVE khong duoc lam

- khong can replay importer behavior
- khong duoc resume/merge session backfill mot cach ngam dinh

---

## 5. De xuat thay doi o Mirth

Mirth nen co **2 channel** hoac **2 route forwarding** tach biet:

### Channel 1: Backfill

- doc du lieu lich su
- transform thanh payload backfill
- gui toi:
  - `POST /api/v1/telemetry/backfill`

### Channel 2: Live

- doc du lieu live
- transform thanh payload live
- gui toi:
  - `POST /api/v1/telemetry/live`

### Tai sao nen tach o Mirth

- van hanh ro rang hon
- de bat/tat theo dot
- de huan luyen nguoi van hanh
- tranh gui nham payload lich su vao live channel

---

## 6. De xuat thay doi o backend

Backend phai tach **route** va **service path**.

### 6.1. Route de xuat

- `POST /api/v1/telemetry/backfill`
- `POST /api/v1/telemetry/live`

Neu tam thoi chua tach route duoc, thi it nhat phai tach ngay sau khi vao route:

- `mode == BACKFILL` -> backfill service
- `mode == LIVE` -> live service

Nhung muc tieu cuoi cung van la 2 ingest path ro rang.

### 6.2. Service path de xuat

#### `BackfillIngestService`

Trach nhiem:

- validate payload backfill
- dung `packet_time` lich su lam nguon su that
- tao/lay treatment builder context
- project hourly snapshot theo logic deterministic
- project order change
- ghi raw manifest/chunk neu can

Khong su dung:

- live session map
- live recovery
- websocket realtime
- alarm realtime

#### `LiveIngestService`

Trach nhiem:

- xu ly packet live
- duy tri live session
- websocket/alarm/trend
- project snapshot cho live treatment

---

## 7. Rule quan trong bat buoc

## 7.1. One device, one mode

Tai mot thoi diem, moi `device_id` chi duoc phep o mot mode:

- `BACKFILL`
hoac
- `LIVE`

Khong duoc cho phep:

- PF_004 vua dang backfill vua dang nhan live

### De xuat guard

Backend duy tri `device_mode_lock`:

- `PF_004 -> BACKFILL`
- `PF_004 -> LIVE`

Neu packet vao sai mode:

- reject ro rang
- log ro rang
- khong co fallback ngam dinh

---

## 7.2. Backfill phai deterministic

Backfill khong duoc phu thuoc vao:

- wall clock hien tai
- heartbeat
- websocket pacing
- worker timing
- startup recovery

Backfill phai la phep chieu:

`ordered historical packets -> deterministic treatments + snapshots + OC rows`

Neu replay cung mot tap packet 2 lan tren DB sach, ket qua phai giong nhau.

---

## 7.3. Hourly snapshot rule khong doi

Hourly snapshot phai duoc tinh theo:

`hour_slot = floor((packet_time - treatment_start_time) / 3600)`

Hien thi:

- `0 -> H00`
- `1 -> H01`
- `2 -> H02`

Hourly logic khong duoc bi anh huong boi:

- OC events
- replay speed nhanh/cham
- live mode

---

## 7.4. GAP la display concern

Backend khong auto-fill GAP.

Backend chi luu:

- cac `Hxx` thuc su co row
- cac `OC_XX` thuc su xay ra

Frontend tu suy ra GAP tu cac `hour_slot` bi thieu.

---

## 8. Contract payload de xuat

## 8.1. BACKFILL payload

```json
{
  "meta": {
    "device_id": "PF_007",
    "timestamp": "2026-01-30 08:37:09 UTC",
    "packet_num": 169,
    "mode": "BACKFILL",
    "transform_version": "mirth_backfill_v2"
  },
  "header": {},
  "body": {}
}
```

## 8.2. LIVE payload

```json
{
  "meta": {
    "device_id": "PF_007",
    "timestamp": "2026-01-30 08:37:09 UTC",
    "packet_num": 169,
    "mode": "LIVE",
    "transform_version": "mirth_live_v1"
  },
  "header": {},
  "body": {}
}
```

Khuyen nghi:

- giu chung schema
- chi khac `mode`
- backend route co the tach rieng, nhung payload contract nen giong nhau de don gian hoa

---

## 9. Quy trinh van hanh de xuat

## 9.1. Dot backfill

1. tat live channel
2. mo backfill channel
3. backend dat device vao `BACKFILL` mode
4. replay du lieu lich su
5. verify treatment/snapshot/OC/GAP
6. dong backfill mode

## 9.2. Chuyen sang live

1. xac nhan backfill da xong
2. tat backfill channel
3. mo live channel
4. backend dat device vao `LIVE` mode
5. bat websocket/alarm/trend

---

## 10. Acceptance criteria

Sau khi implement, he thong phai dat:

1. Packet backfill khong chay qua live recorder path
2. Packet live khong chay qua backfill importer path
3. Cung mot `device_id` khong the vua backfill vua live
4. Replay cung mot bo packet tren DB sach cho ra cung ket qua
5. Backfill xong roi chuyen sang live khong lam vo treatment da replay
6. Hourly snapshot `H00/H01/H02/...` khong phu thuoc vao toc do replay
7. OC van chen theo `snapshot_time`
8. UI chi hien GAP khi thieu `Hxx`, khong can backend fill

---

## 11. Viec OPUS can lam

1. Tach Mirth config thanh `backfill` va `live`
2. Tach backend ingest path thanh `backfill` va `live`
3. Them `device_mode_lock`
4. Dua snapshot projector ve logic deterministic theo `hour_slot`
5. Dam bao backfill khong goi websocket/alarm/live recovery
6. Viet test cho:
   - replay historical nhanh
   - handoff tu backfill sang live
   - live sau backfill

---

## 12. Ket luan

Tach `BACKFILL` va `LIVE` la mot thay doi **rat nen lam**.

No khong phai meo de ne bug tam thoi, ma la chinh sua dung ban chat kien truc:

- `BACKFILL` la importer du lieu lich su
- `LIVE` la runtime theo thoi gian thuc

Neu khong tach, he thong se tiep tuc de bi bug do:

- mot pipeline stateful dang phai gan qua nhieu trach nhiem khac nhau.

