# Treatment Snapshot Chronology Fix Spec

> Updated: 2026-04-03
> Scope: fix chronology drift in Treatment Journal after manual edit or restore

## Goal

Fix the confirmed bug where editing or restoring an existing snapshot row changes its clinical order in the Treatment Journal.

Example of the bug:

- `H00`, `H01`, `H02` already exist.
- User edits `H00` at a later time.
- Backend overwrites `snapshot_time` with `now`.
- `H00` moves to the bottom of the table even though it is still the first clinical hour.

## Clinical Rule

These rules must stay true after the fix:

- `snapshot_time` means the clinical sample time of that row.
- `updated_at` means when a human last edited or restored that row.
- Editing data must never mutate clinical chronology.
- `H00 -> H01 -> H02 ...` must remain stable after edit, restore, review, print, and export.
- `OC_XX` rows can still appear between hourly rows based on real clinical time.

## Do Not Change

- Do not change the current runtime algorithm for auto-capturing `H00`.
- Do not change the current hourly snapshot creation logic.
- Do not change the current order-change (`OC_XX`) trigger logic.
- Do not remove snapshot originals or restore capability.
- Do not rewrite the feature into a new storage model in this fix.

## Root Cause

### Backend

Current manual update path rewrites `snapshot_time` for an existing row:

- [treatment_router.py](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/backend/routers/treatment_router.py)
- [treatment_database.py](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/backend/services/treatment/treatment_database.py)

Current behavior:

1. `PUT /api/v1/treatments/{id}/snapshots/{hourLabel}` calls `update_snapshot_manual(...)`.
2. `update_snapshot_manual(...)` passes `snapshot_time = now`.
3. `upsert_snapshot(...)` overwrites the existing row's `snapshot_time`.
4. All later reads sort by `snapshot_time`.

### Frontend

The UI reinforces the bug because it trusts chronological order from `snapshot_time`:

- [DetailPanel.tsx](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/frontend/app/(main)/treatments/DetailPanel.tsx)
- [review/page.tsx](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/frontend/app/(main)/treatments/review/page.tsx)
- [CrrtPrintPreview.tsx](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/frontend/app/components/CrrtPrintPreview.tsx)

Restore also loses chronology context because the frontend only keeps original `data` and drops the original `snapshot_time`.

## Required Fix

## 1. Backend: preserve `snapshot_time` on edit

Target files:

- [treatment_database.py](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/backend/services/treatment/treatment_database.py)
- [treatment_router.py](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/backend/routers/treatment_router.py)

Required behavior:

- If a snapshot row already exists, `PUT` edit must update only:
  - `data`
  - `manual_data`
  - `is_manual`
  - `updated_at`
- It must not overwrite:
  - `snapshot_time`
  - `hour_label`
  - `treatment_id`

Implementation direction:

- In `update_snapshot_manual(...)`, first read the existing row by `treatment_id + hour_label`.
- If the row exists, preserve its current `snapshot_time`.
- Pass that preserved value into `upsert_snapshot(...)`, or better, split update vs insert so update does not touch `snapshot_time` at all.

## 2. Backend: restore must preserve original clinical time

Required behavior:

- When restoring from snapshot originals, the original row's `snapshot_time` must be kept.
- If the original payload does not contain a recoverable timestamp:
  - for `Hxx`, derive `snapshot_time = treatment.start_time + hour_number`
  - for `OC_XX`, use the original snapshot row time if available; do not replace with `now`

This means `restore` is a data reset, not a chronology reset.

## 3. Backend: split clinical time from audit time

Required behavior:

- `snapshot_time` remains the clinical timestamp.
- `updated_at` records edit/restore time.
- Any API response used by the frontend must expose both fields clearly.

If schema already has `updated_at`, reuse it.
If not reliably populated, populate it on every manual update/restore.

## 4. Frontend: do not sort hourly timeline purely by `snapshot_time`

Target files:

- [DetailPanel.tsx](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/frontend/app/(main)/treatments/DetailPanel.tsx)
- [review/page.tsx](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/frontend/app/(main)/treatments/review/page.tsx)
- [CrrtPrintPreview.tsx](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/frontend/app/components/CrrtPrintPreview.tsx)

Required ordering rule:

- Hourly rows must be ordered by clinical hour sequence:
  - `H00`, `H01`, `H02`, ...
- `OC_XX` rows should be interleaved by real `snapshot_time`.

Recommended approach:

- Parse rows into two categories:
  - hourly rows: `H\d+`
  - order-change rows: `OC_\d+`
- Primary order for hourly rows:
  - numeric hour index from `hour_label`
- Secondary order:
  - `snapshot_time`
- `OC_XX` rows:
  - keep ordered by clinical `snapshot_time`

Minimum acceptable fix:

- At least ensure editing `H00` cannot move it below `H01/H02`.

## 5. Frontend: restore flow must keep full original metadata

Required behavior:

- When loading snapshot originals, frontend must keep:
  - `data`
  - `snapshot_time`
  - `hour_label`
  - any identifier needed for safe restore
- Restore action must send enough information for backend to preserve chronology.

Do not reduce originals to only the raw measurement payload.

## Runtime Scenario Matrix

### Scenario A: edit existing `H00`

Input:

- `H00`, `H01`, `H02` already exist
- user edits `H00`

Expected:

- `H00` remains first row
- `snapshot_time(H00)` unchanged
- `updated_at(H00)` changes

### Scenario B: edit existing `H01`

Expected:

- `H01` stays between `H00` and `H02`
- print/review/export keep same chronology

### Scenario C: restore `H00` from originals

Expected:

- restored row keeps original clinical hour
- row does not jump to the bottom

### Scenario D: add missing `H03`

Expected:

- `snapshot_time = start_time + 3h`
- row appears after `H02`
- not treated like a row edited "now"

### Scenario E: `OC_01` between `H01` and `H02`

Expected:

- hourly rows remain in hour order
- `OC_01` stays at its true clinical time between them

### Scenario F: restart app, reload treatment detail

Expected:

- chronology remains identical after reload
- no hidden resort due to edit history

## Acceptance Criteria

- Editing `H00` does not move it below `H01/H02`.
- Restoring `H00` does not move it below later rows.
- `updated_at` changes after edit; `snapshot_time` does not.
- Review page, detail panel, print preview, and export all show the same row order.
- `OC_XX` rows still appear at the correct clinical positions.
- No regression to `H00` auto-capture, `H01+` hourly creation, or order-change detection.

## QA Cases To Run

- Edit `H00` after `H02` already exists.
- Edit `H01` after `H03` already exists.
- Restore `H00` from originals.
- Restore `H02` from originals.
- Add missing `H03`.
- Print preview after manual edits.
- Excel/export after manual edits.
- Reload browser and re-open treatment after manual edits.
- Submit for review after manual edits.

## Out of Scope

- Redesign of snapshot storage model
- Historical migration for already-corrupted rows
- UI redesign of Treatment Journal
- Changes to treatment boundary or raw data logic

## Short Instruction For OPUS

Fix Treatment Journal chronology by preserving `snapshot_time` as immutable clinical time for existing snapshot rows, moving all human edit timing to `updated_at`, and ordering hourly rows by `hour_label` semantics instead of trusting mutated `snapshot_time`.
