# QA Checklist — Treatment Journal Fixes (2026-04-05)

> **Tester**: ******\_\_\_******  
> **Ngày test**: ******\_\_\_******  
> **Build**: ******\_\_\_******  
> **Môi trường**: ☐ Local ☐ Staging ☐ Production

---

## 1. Cột Mốc (Milestone/Snapshot Count)

| #   | Test Case                                    | Bước thực hiện                                            | Kết quả mong đợi                                                            | ☐   |
| --- | -------------------------------------------- | --------------------------------------------------------- | --------------------------------------------------------------------------- | --- |
| 1.1 | Hiển thị cột mốc cho treatment đã hoàn thành | Mở danh sách Treatment Journal → chọn treatment COMPLETED | Cột "Cột mốc" hiển thị số lượng dòng journal (vd: 5, 10...), không để trống | ☐   |
| 1.2 | Hiển thị cột mốc cho treatment đang ghi      | Mở treatment đang IN_PROGRESS                             | Cột mốc hiển thị số row hiện tại và tăng khi có row mới                     | ☐   |
| 1.3 | Cột mốc = 0 khi treatment mới tạo            | Tạo treatment mới, chưa có snapshot                       | Cột mốc hiển thị 0 hoặc "—"                                                 | ☐   |

---

## 2. Kháng Đông (Anticoagulant Type)

| #   | Test Case                          | Bước thực hiện                               | Kết quả mong đợi                              | ☐   |
| --- | ---------------------------------- | -------------------------------------------- | --------------------------------------------- | --- |
| 2.1 | Hiển thị "None" khi PID 409 = 0    | Xem treatment với máy gửi anticoag value = 0 | Cột "Kháng đông" hiển thị "None"              | ☐   |
| 2.2 | Hiển thị "Heparin" khi PID 409 = 1 | Xem treatment với máy gửi anticoag value = 1 | Cột "Kháng đông" hiển thị "Heparin"           | ☐   |
| 2.3 | Hiển thị "Citrate" khi PID 409 = 2 | Xem treatment với máy gửi anticoag value = 2 | Cột "Kháng đông" hiển thị "Citrate"           | ☐   |
| 2.4 | Hiển thị "Citrate" khi PID 409 = 3 | Xem treatment với máy gửi anticoag value = 3 | Cột "Kháng đông" hiển thị "Citrate"           | ☐   |
| 2.5 | Dữ liệu cũ đã backfill đúng        | Xem treatment cũ (trước ngày fix)            | Kháng đông hiển thị đúng giá trị, không trống | ☐   |

---

## 3. Stable-Row Partial Lock (Edit khi đang Record)

### 3.1 Cho phép edit dòng ổn định

| #     | Test Case                                 | Bước thực hiện                                                      | Kết quả mong đợi                                 | ☐   |
| ----- | ----------------------------------------- | ------------------------------------------------------------------- | ------------------------------------------------ | --- |
| 3.1.1 | Edit ô QB trên dòng H00 khi IN_PROGRESS   | Treatment đang ghi → click vào ô QB dòng H00 → nhập giá trị → lưu   | Lưu thành công, toast "Đã lưu", giá trị cập nhật | ☐   |
| 3.1.2 | Edit ô QB trên dòng OC cũ khi IN_PROGRESS | Treatment đang ghi → click vào ô QB dòng OC_01 → nhập giá trị → lưu | Lưu thành công                                   | ☐   |
| 3.1.3 | Edit nhiều cột trên cùng 1 dòng ổn định   | Chỉnh QB, QD, rồi Kali trên H00                                     | Tất cả đều lưu thành công                        | ☐   |
| 3.1.4 | Edit dòng ổn định với role Nurse          | Đăng nhập role=nurse → edit dòng H00                                | Cho phép edit bình thường                        | ☐   |
| 3.1.5 | Edit dòng ổn định với role Doctor         | Đăng nhập role=doctor → edit dòng OC_05                             | Cho phép edit bình thường                        | ☐   |

### 3.2 Chặn edit dòng đang stream (active row)

| #     | Test Case                       | Bước thực hiện                                                                                         | Kết quả mong đợi                              | ☐   |
| ----- | ------------------------------- | ------------------------------------------------------------------------------------------------------ | --------------------------------------------- | --- |
| 3.2.1 | Chặn edit dòng cuối đang stream | Treatment đang ghi → click vào ô QB dòng **cuối cùng** (đang nhận dữ liệu từ máy) → nhập giá trị → lưu | Toast lỗi "ACTIVE_ROW_LOCKED", không lưu được | ☐   |

### 3.3 Các chế độ lock khác vẫn hoạt động

| #     | Test Case                               | Bước thực hiện                                       | Kết quả mong đợi                      | ☐   |
| ----- | --------------------------------------- | ---------------------------------------------------- | ------------------------------------- | --- |
| 3.3.1 | Chặn edit khi APPROVED                  | Treatment đã APPROVED → thử edit bất kỳ ô nào        | Tất cả ô bị disable, không click được | ☐   |
| 3.3.2 | Chặn nurse edit khi PENDING_REVIEW      | Treatment đang PENDING_REVIEW, role=nurse → thử edit | Tất cả ô bị disable cho nurse         | ☐   |
| 3.3.3 | Doctor vẫn edit được khi PENDING_REVIEW | Treatment đang PENDING_REVIEW, role=doctor → edit    | Cho phép edit bình thường             | ☐   |

### 3.4 Clinical Notes luôn cho phép

| #     | Test Case                        | Bước thực hiện                                         | Kết quả mong đợi       | ☐   |
| ----- | -------------------------------- | ------------------------------------------------------ | ---------------------- | --- |
| 3.4.1 | Ghi chú lâm sàng khi IN_PROGRESS | Treatment đang ghi → mở phần ghi chú → nhập text → lưu | Lưu thành công mọi lúc | ☐   |

---

## 4. Banner thông báo trạng thái ghi

| #   | Test Case                       | Bước thực hiện             | Kết quả mong đợi                                                                          | ☐   |
| --- | ------------------------------- | -------------------------- | ----------------------------------------------------------------------------------------- | --- |
| 4.1 | Banner hiển thị khi IN_PROGRESS | Mở treatment đang ghi      | Banner vàng hiện: "⚠ Đang ghi dữ liệu — row cuối bị khóa, các row trước có thể chỉnh sửa" | ☐   |
| 4.2 | Banner ẩn khi COMPLETED         | Mở treatment đã hoàn thành | Không hiện banner ghi dữ liệu                                                             | ☐   |

---

## 5. Compression Error (Backend Stability)

| #   | Test Case                             | Bước thực hiện                               | Kết quả mong đợi                                                                      | ☐   |
| --- | ------------------------------------- | -------------------------------------------- | ------------------------------------------------------------------------------------- | --- |
| 5.1 | Không còn lỗi compress_treatment_file | Restart backend → xem log liên tục 5 phút    | Không xuất hiện `'RawDataStreamer' object has no attribute 'compress_treatment_file'` | ☐   |
| 5.2 | Auto-close treatment không crash      | Để treatment chạy > 6h → kiểm tra auto-close | Treatment đóng thành công, không lỗi compression                                      | ☐   |

---

## 6. Regression Tests

| #   | Test Case                     | Bước thực hiện                                 | Kết quả mong đợi                                 | ☐   |
| --- | ----------------------------- | ---------------------------------------------- | ------------------------------------------------ | --- |
| 6.1 | Tạo treatment mới             | Bắt đầu treatment mới từ device → chờ data vào | Treatment tạo thành công, journal rows hiện đúng | ☐   |
| 6.2 | Xuất Excel journal            | Mở treatment → bấm "EXCEL"                     | File Excel tải về đầy đủ dữ liệu                 | ☐   |
| 6.3 | In phiếu Treatment            | Mở treatment → bấm "IN PHIẾU"                  | Preview in hiển thị đúng, có đầy đủ cột          | ☐   |
| 6.4 | Xem Raw Data                  | Mở treatment → bấm "DỮ LIỆU RAW"               | Raw data hiển thị JSON packets                   | ☐   |
| 6.5 | Danh sách treatment load đúng | Mở trang Treatment Journal                     | Danh sách hiện đầy đủ, filter/search hoạt động   | ☐   |

---

## Tổng kết

| Mục                | Tổng TC | Pass | Fail | Skip |
| ------------------ | ------- | ---- | ---- | ---- |
| 1. Cột Mốc         | 3       |      |      |      |
| 2. Kháng Đông      | 5       |      |      |      |
| 3. Stable-Row Lock | 9       |      |      |      |
| 4. Banner          | 2       |      |      |      |
| 5. Compression     | 2       |      |      |      |
| 6. Regression      | 5       |      |      |      |
| **TỔNG**           | **26**  |      |      |      |

> **Ghi chú**: Nếu bất kỳ test case Fail → ghi rõ screenshot + log tại phần dưới.  
> **Ngày hoàn thành QA**: ******\_\_\_******  
> **Kết luận**: ☐ PASS ☐ FAIL — cần fix lại
