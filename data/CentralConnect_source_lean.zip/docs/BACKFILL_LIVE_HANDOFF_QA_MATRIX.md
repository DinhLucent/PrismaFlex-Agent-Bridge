# Backfill -> Live Handoff QA Matrix

## Muc dich

Tai lieu nay tap trung test dung 2 nhom tinh huong de gay loi nhat cua he thong Treatment:

1. **Backfill historical packets** tu Mirth Connect voi toc do rat nhanh, nhung van dung thu tu thoi gian
2. **Handoff sang live** sau khi backfill xong, roi tiep tuc quy trinh live binh thuong

Muc tieu khong chi la "khong crash", ma con la:

- treatment boundary dung
- raw telemetry khong split sai
- journal chronology dung
- handoff backfill -> live khong tao duplicate treatment
- state machine dung cho SAME PATIENT va fresh start

---

## Luu y quan trong ve worker model

Gia dinh nghiep vu anh dua ra la:

- backfill duoc day truoc
- sau khi backfill xong moi den current/live
- 1 worker xu ly tuan tu

Nhung code hien tai dang duoc thiet ke voi:

- `4` telemetry workers
- khoa theo `device_id` de giu order tren cung mot may

Noi tham chieu:

- `backend/main.py`

Y nghia cho QA:

- Neu moi truong test thuc su dang de `1 worker`, matrix nay van dung nguyen
- Neu moi truong dang chay `4 workers`, phai test them kha nang khong bi leak state giua devices

---

## Dinh nghia ket qua mong doi

### Treatment-level

- Khong duplicate treatment sai
- Khong close/open churn bat thuong
- `same patient + RUN_TIME > 0` -> tiep tuc `T1`
- `same patient + RUN_TIME = 0` -> dong `T1`, mo `T2`
- `patient doi` -> dong `T1`, mo `T2`

### Raw-level

- Raw chunk/manifest dung `treatment_id`
- Khong split sai raw truoc/sau handoff
- Khong co FK violation khi register manifest

### Journal-level

- `H00/H01/H02...` dung treatment
- `OC_XX` chen dung theo `snapshot_time`
- Khong mat chronology sau handoff

### Review/Projection-level

- `treatment_list_projection` phan anh dung `outcome`, `approval_status`, `snapshot_count`
- UI history/list khong hien duplicate treatment sai

---

## Preconditions

Truoc khi chay matrix nay, can xac nhan:

1. PostgreSQL schema da duoc migrate day du
2. `alembic_version` ton tai
3. Recorder dang ghi raw manifest binh thuong
4. Treatment Journal da bat chronology fix
5. Payload vao backend van theo contract:
   - `s_header`
   - `s_body.parameters[]`

---

## Nhom A - Backfill nhanh, dung thu tu thoi gian

### A1. Backfill 1 treatment lien tuc, khong handoff

**Input**

- Replay toan bo 1 ca cu
- Cung `device_id`
- Cung `patient_id`
- Packet theo thu tu thoi gian tang dan

**Expected**

- Tao dung 1 treatment `T1`
- Raw chunks deu thuoc `T1`
- Journal tao `H00/H01/...` dung
- Neu co doi y lenh trong packet replay thi co `OC_XX`
- Khong duplicate treatment

### A2. Backfill co `END -> same patient -> RUN_TIME > 0`

**Input**

- Replay packet cu co:
  - `RUN`
  - `END`
  - sau do cung `patient_id`
  - PID `461` (`RUN_TIME`) > 0

**Expected**

- Van la `T1`
- Khong sinh `T2`
- Raw truoc/sau `END` van noi vao `T1`
- Journal truoc/sau `END` van thuoc `T1`

### A3. Backfill co `END -> same patient -> RUN_TIME = 0`

**Input**

- Replay packet cu co:
  - `RUN`
  - `END`
  - sau do cung `patient_id`
  - PID `461` = 0

**Expected**

- Dong `T1`
- Tao `T2`
- Raw moi vao `T2`
- Journal moi vao `T2`
- Khong resume nham `T1`

### A4. Backfill co patient change

**Input**

- Replay packet cu:
  - `patient_id` doi giua stream

**Expected**

- Dong treatment cu
- Tao treatment moi
- Raw va Journal khong dinh cheo 2 patient

### A5. Backfill stress toc do cao

**Input**

- Replay rat nhanh, packet den sat nhau
- Van giu dung order timestamp

**Expected**

- Khong vo chronology
- Khong mat packet
- Khong duplicate session
- Queue/worker khong tao split treatment sai

---

## Nhom B - Backfill xong roi handoff sang live

### B1. Backfill xong -> live same patient -> RUN_TIME > 0

**Input**

- Replay historical cho device A den gan hien tai
- Sau do packet live den cho cung device A
- Cung `patient_id`
- `RUN_TIME > 0`

**Expected**

- Handoff giu `T1`
- Session backfill duoc promote sang live
- Raw live tiep tuc ghi vao `T1`
- Journal live tiep tuc ghi vao `T1`
- Khong sinh `T2`

**Can check them**

- Log co thong diep promote
- Khong co auto-close bat thuong

### B2. Backfill xong -> live same patient -> RUN_TIME = 0

**Input**

- Replay historical cho device A
- Sau do packet live den cho cung patient
- `RUN_TIME = 0`

**Expected**

- Backfill `T1` duoc close/finalize
- Live mo `T2`
- Raw live vao `T2`
- Journal live vao `T2`
- Khong resume `T1`

### B3. Backfill xong -> live patient khac

**Input**

- Replay historical cho device A patient `P1`
- Sau do live cho device A patient `P2`

**Expected**

- `T1` cua `P1` ket thuc ro rang
- `T2` cua `P2` duoc mo moi
- Khong co contamination patient

### B4. Backfill xong -> live same treatment roi co `OC_XX`

**Input**

- B1 xay ra thanh cong
- Sau handoff live co doi y lenh

**Expected**

- `OC_XX` moi van thuoc `T1`
- `OC_XX` chen dung theo `snapshot_time`
- Khong vi handoff ma `OC_XX` roi xuong cuoi

### B5. Backfill xong -> live same treatment roi submit/review sau do

**Input**

- B1 xay ra thanh cong
- treatment sau do dung that su
- user vao review

**Expected**

- Journal chronology van dung
- Review/approve khong gap duplicate treatment
- Projection row duy nhat cho `T1`

---

## Nhom C - Live sau khi backfill da xong

### C1. Device B dang live trong khi device A vua handoff xong

**Input**

- Device A backfill -> live handoff
- Device B dang chay live binh thuong

**Expected**

- State tung device doc lap
- Device B khong lam Device A bi close sai
- Device A khong lam Device B bi split treatment

### C2. Live fresh start sau mot treatment backfill da ket thuc

**Input**

- Backfill xong treatment cu
- Sau do mot ca live moi bat dau that su

**Expected**

- Treatment moi duoc tao sach se
- Khong "inherit" nham run_time/session state cu

### C3. App restart giua handoff

**Input**

- Backfill den sat hien tai
- Restart app
- Live packet tiep tuc den

**Expected**

- Same-patient logic van dung
- Khong duplicate treatment
- OC counter va H00 recovery van hop ly

---

## Nhom D - Journal / Chronology checks bat buoc

Ap dung cho tat ca case A/B/C:

1. `H00` co tao dung va freeze dung khong
2. `H01/H02...` co dung treatment khong
3. `OC_XX` co chen dung theo `snapshot_time` khong
4. Sau reload UI, chronology co giu nguyen khong
5. Neu co edit/review sau do, row co bi nhay vi tri khong

---

## Nhom E - Raw / Manifest checks bat buoc

Ap dung cho tat ca case A/B/C:

1. Khong co FK violation trong log
2. `raw_packet_manifest` dung `treatment_id`
3. `chunk_index` tang dung
4. Khong co chunk gan nham qua treatment khac
5. Sau handoff, raw live noi tiep treatment dung

---

## Nhom F - Projection / List / UI checks bat buoc

1. `treatment_list_projection` chi co 1 dong cho 1 treatment dung
2. History/list khong hien duplicate treatment gia
3. Duration khong bi tach sai vi backfill/live handoff
4. Approval status van dung treatment can review

---

## Query goi y de kiem tra nhanh

### Kiem tra tables

```sql
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;
```

### Kiem tra treatment theo device

```sql
SELECT id, device_id, patient_id, start_time, end_time, outcome, created_at
FROM treatments
WHERE device_id = 'PF_004'
ORDER BY start_time;
```

### Kiem tra journal chronology

```sql
SELECT treatment_id, row_code, row_kind, snapshot_time, created_at, updated_at
FROM treatment_journal_rows
WHERE treatment_id = '<TREATMENT_ID>'
ORDER BY snapshot_time ASC, row_code ASC;
```

### Kiem tra raw manifest

```sql
SELECT treatment_id, chunk_index, first_timestamp, last_timestamp, packet_count, status
FROM raw_packet_manifest
WHERE treatment_id = '<TREATMENT_ID>'
ORDER BY chunk_index ASC;
```

### Kiem tra projection

```sql
SELECT treatment_id, patient_id, device_id, outcome, approval_status, snapshot_count, updated_at
FROM treatment_list_projection
ORDER BY updated_at DESC;
```

---

## Tieu chi PASS / FAIL

### PASS neu

- Khong duplicate treatment sai
- Khong split raw sai
- Khong chronology regression
- Handoff backfill -> live dung semantics
- Same-patient va fresh-start phan tach dung
- UI list/review/detail deu thong nhat

### FAIL neu

- `same patient + RUN_TIME > 0` ma sinh `T2`
- `RUN_TIME = 0` ma van resume `T1`
- Raw manifest gan nham treatment
- `OC_XX` tut xuong cuoi hoac sai chronology
- Projection hien duplicate treatment
- Device A/B lam nhiem cheo state nhau

---

## Thu tu thuc thi goi y cho QA

1. Chay A1, A2, A3 de khoa treatment boundary trong backfill
2. Chay B1, B2, B3 de khoa handoff backfill -> live
3. Chay B4 va D de khoa chronology
4. Chay C1 de khoa cross-device isolation
5. Chay E va F de khoa DB/projection
6. Cuoi cung moi chay browser smoke voi FLASH

---

## Mot cau chot

Backfill -> live handoff khong phai chi la van de ingest packet.
No la bai test cua ca 4 tang cung luc:

- recorder state machine
- raw manifest ledger
- journal chronology
- treatment projection/list
