# MASTER QA TEST SUITE: Treatment Data Platform

**Updated:** 2026-04-05
**Role:** QA Lead / Tester
**Status:** APPROVED (Unified Master Document)

Tài liệu này tổng hợp **130+ Test Cases** từ 6 tài liệu QA rời rạc trước đây (Runtime Checklist, Logic QA Sheet, Backfill Matrix, Closure Checklist, Permission Matrix, Postgres Audit).
Mỗi khi có thay đổi kiến trúc hoặc release lớn, team QA bắt buộc phải chạy bộ Suite này.

---

## 1. SMOKE TESTS (Cơ bản)

Đảm bảo hệ thống không bị crash vặt ngáng đường test các luồng sâu.

| ID    | Area       | Action / Kịch bản                      | Expected Result                                              | Pass/Fail |
| ----- | ---------- | -------------------------------------- | ------------------------------------------------------------ | --------- |
| M-S01 | List       | Mở trang `/treatments`                 | Danh sách load nhanh, phân trang đúng, không crash.          | [ ]       |
| M-S02 | Detail     | Click chi tiết 1 ca lọc                | Journal timeline (Hxx, OC) render đủ, không lỗi trắng trang. | [ ]       |
| M-S03 | Chronology | Kiểm tra thứ tự Hxx và OC_xx           | Được sắp xếp chuẩn theo `snapshot_time`.                     | [ ]       |
| M-S04 | Check-in   | Sửa tay 1 field khi chưa nhập tên      | Bật popup yêu cầu nhập Operator Name.                        | [ ]       |
| M-S05 | Edit       | Sửa 1 manual field trên row đã ổn định | Save thành công, row KHÔNG nhảy xuống cuối bảng.             | [ ]       |
| M-S06 | Reload     | Refresh (F5) trang sau khi edit        | Giá trị vừa sửa giữ nguyên, thứ tự dòng không đổi.           | [ ]       |
| M-S07 | Submit     | Bấm Submit for Review                  | Chuyển sang PENDING_REVIEW, UI báo lock.                     | [ ]       |
| M-S08 | Review     | Mở trang Review Compare                | Render màn hình so sánh Current vs Original không lỗi.       | [ ]       |
| M-S09 | Doctor     | Thử Approve bằng quyền Doctor          | Chuyển trạng thái APPROVED thành công.                       | [ ]       |
| M-S10 | Export     | Bấm in (Print) hoặc lưu Excel          | Layout và dữ liệu xuất ra khớp hoàn toàn với màn hình.       | [ ]       |

---

## 2. TREATMENT LIFECYCLE & CLOSURE

Đảm bảo luồng ngắt/mở ca lọc tự động (Machine-Driven) hoạt động tuyệt đối chính xác.

| ID    | Feature             | Kich ban                                | Expected Result                                          | Pass/Fail |
| ----- | ------------------- | --------------------------------------- | -------------------------------------------------------- | --------- |
| M-C01 | Explicit END        | Máy gửi packet `END`                    | Ghi END vào Raw ca cũ, ca cũ `outcome=COMPLETED`.        | [ ]       |
| M-C02 | Same Patient Resume | Chạy tiếp `same patient + RUN_TIME > 0` | Tiếp tục ghi vào T1, không mở T2.                        | [ ]       |
| M-C03 | Phase Reset         | `same patient + RUN_TIME = 0`           | Đóng T1 (`RUNTIME_RESET`), mở ca T2 mới.                 | [ ]       |
| M-C04 | Patient Change      | Máy gửi packet của Bệnh nhân mới        | Đóng T1 (`PATIENT_CHANGED`), mở ca T2 cho bệnh nhân mới. | [ ]       |
| M-C05 | Auto Timeout        | Rút dây mạng quá 15-24h                 | Đóng T1 tự động (`outcome=TIMEOUT`).                     | [ ]       |
| M-C06 | Ghost Session       | Session kết thúc `< 300s`               | Hệ thống discard session rác này khỏi index.             | [ ]       |
| M-C07 | Legacy Fallback     | Chạy vượt ngưỡng 6h, 12h                | Không tự ý cắt ca thành T2 nếu `RUN_TIME` vẫn tăng đều.  | [ ]       |
| M-C08 | UI Validate         | Tìm nút "End Treatment" trên WebApp     | TUYỆT ĐỐI KHÔNG có nút End/Close thủ công nào trên UI.   | [ ]       |
| M-C09 | Late Packet Race    | Packet rớt mạng đến sau lệnh END        | Bị drop/reject thay vì mở khóa ca đã đóng.               | [ ]       |

---

## 3. JOURNAL CHRONOLOGY & INTEGRITY

Cốt lõi y khoa: Chronology không bao giờ được phép sai lệch (không như spreadsheet).

| ID    | Feature        | Kich ban                               | Expected Result                                                      | Pass/Fail |
| ----- | -------------- | -------------------------------------- | -------------------------------------------------------------------- | --------- |
| M-J01 | H00 Baseline   | Lưu `H00` sau 60s khởi động            | `H00` cố định, không bị overwrite lung tung.                         | [ ]       |
| M-J02 | Hourly Rows    | Tạo `H01, H02...` theo mốc máy         | Mỗi giờ 1 row đúng label, không trùng mã.                            | [ ]       |
| M-J03 | OC Insert      | `OC_XX` được chèn khi đổi y lệnh       | Chèn ĐÚNG vào giữa các Hxx theo `snapshot_time`.                     | [ ]       |
| M-J04 | OC De-dup      | Máy nhiễu tín hiệu chớp nháy (flicker) | Gom nhóm `OC` hoặc chặn `OC` giả, không spam hàng trăm dòng.         | [ ]       |
| M-J05 | Immutable Time | Sửa/Restore dữ liệu trên existing row  | Dữ liệu cập nhật nhưng `snapshot_time` bị khóa cứng, row không nhảy. | [ ]       |
| M-J06 | Gap Visibility | Có khoảng trống mốc giờ do mất kết nối | Frontend render nhãn `GAP` để minh bạch, không cần row giả trong DB. | [ ]       |
| M-J07 | Restore Order  | Restore 1 dòng về giá trị gốc của máy  | Giữ thiết lập Chronology cũ, Frontend lọc bỏ meta `_` keys.          | [ ]       |

---

## 4. BACKFILL & LIVE HANDOFF

Đảm bảo Import lượng lớn dữ liệu cũ không làm hỏng ca đang chạy Live.

| ID    | Feature         | Kich ban                                                 | Expected Result                                                  | Pass/Fail |
| ----- | --------------- | -------------------------------------------------------- | ---------------------------------------------------------------- | --------- |
| M-H01 | Fast Replay     | Backfill lịch sử 5000 packet liên tục                    | Tốc độ nhanh nhưng Chronology (Hxx/OC) và Raw Boundary vẫn đúng. | [ ]       |
| M-H02 | Out-of-Order    | Packet cũ đến sau packet mới                             | Packet không gây nhiễu boundary ca hiện tại.                     | [ ]       |
| M-H03 | Handoff Resume  | Backfill T1 xong -> nhận packet Live T1 (`RUN_TIME > 0`) | Thăng hạng (promote) T1 lên Live, tiếp tục ghi bình thường.      | [ ]       |
| M-H04 | Handoff Reset   | Backfill T1 xong -> Live `RUN_TIME = 0`                  | Chốt sổ T1, mở T2 Live.                                          | [ ]       |
| M-H05 | Handoff Patient | Backfill T1 xong -> Live Bệnh nhân khác                  | Đóng T1, mở T2 Live.                                             | [ ]       |
| M-H06 | Cross-Device    | Máy A đang Backfill, Máy B đang Live                     | Session isolation tuyệt đối, Máy A không làm close nhầm Máy B.   | [ ]       |
| M-H07 | Delay Handoff   | App bị kill/restart khi đang backfill dở                 | Resume backfill an toàn, không trùng session.                    | [ ]       |

---

## 5. OPERATOR IDENTITY & EDIT POLICY (MVP)

Đảm bảo tính pháp lý (Medico-legal) và phân quyền chặt chẽ.

| ID    | Feature         | Kich ban                                               | Expected Result                                                                         | Pass/Fail |
| ----- | --------------- | ------------------------------------------------------ | --------------------------------------------------------------------------------------- | --------- |
| M-P01 | Check-in Logic  | Thực hiện mutation đầu tiên                            | Bắt buộc hiện modal Identity, lưu cache session browser.                                | [ ]       |
| M-P02 | Tab Reset       | Đóng trình duyệt mở lại                                | Cache xóa, đòi nhập lại Identity.                                                       | [ ]       |
| M-P03 | Field Allowlist | Nurse thử sửa các cột QS, QD, TMP                      | KHÔNG CÓ input (Read-only), chỉ mở trên các cột Allowlist (ghi chú, liều lượng manual). | [ ]       |
| M-P04 | Stable Rule     | Sửa 1 row đang chờ dữ liệu (chưa stable)               | Nút save bị vô hiệu hoặc Backend chặn báo lỗi (409 Conflict).                           | [ ]       |
| M-P05 | Note Policy     | Bấm Ghi chú (Notes) lúc đang IN_PROGRESS               | Luôn được phép (Append-only), kể cả khi timeline chính bị lock.                         | [ ]       |
| M-P06 | API Guard       | Bypass giao diện bắn Postman/Curl 1 API cấm            | Backend bắt buộc chặn và trả về lỗi quyền.                                              | [ ]       |
| M-P07 | UI Clean-up     | Quét tìm các nút cấu trúc timeline (Fill gap, add row) | TUYỆT ĐỐI KHÔNG xuất hiện trên giao diện Nurse/Doctor hằng ngày.                        | [ ]       |

---

## 6. REVIEW WORKFLOW & GOVERNANCE

Luồng phê duyệt từ DRAFT -> APPROVED.

| ID    | Feature       | Kich ban                            | Expected Result                                                        | Pass/Fail |
| ----- | ------------- | ----------------------------------- | ---------------------------------------------------------------------- | --------- |
| M-R01 | Submit Lock   | Submitted -> PENDING_REVIEW         | Doctor/Nurse không được edit trực tiếp nữa. Chờ duyệt.                 | [ ]       |
| M-R02 | Original Diff | Bác sĩ vào màn Review Compare       | Bản gốc lúc Submit (Originals) hiện chính xác so với bản đã sửa.       | [ ]       |
| M-R03 | Reject Flow   | Doctor Reject kèm lý do             | Trạng thái lui về `DRAFT` cho Nurse sửa tiếp.                          | [ ]       |
| M-R04 | Approve Flow  | Doctor Approve hồ sơ đúng           | Trạng thái lên `APPROVED`. Trở thành Lock vĩnh viễn (thuần Read-only). | [ ]       |
| M-R05 | Unlock Flow   | Doctor Unlock 1 ca đã APPROVED      | Trạng thái lùi về `DRAFT` để sửa sai. Đi kèm Audit Log.                | [ ]       |
| M-R06 | Role Block    | Nurse thử Submit, Bác sĩ thử Submit | Nurse được Submit. Doctor BỊ CHẶN Submit (Doctor chỉ Approve/Reject).  | [ ]       |
| M-R07 | Nurse Block   | Nurse thử Approve hoặc Reject       | BỊ CHẶN không có quyền.                                                | [ ]       |

---

## 7. EXPORT, RAW DATA & ANALYZER

Luồng dữ liệu xuất ra ngoài.

| ID    | Feature       | Kich ban                              | Expected Result                                                   | Pass/Fail |
| ----- | ------------- | ------------------------------------- | ----------------------------------------------------------------- | --------- |
| M-E01 | Excel Export  | Xuất ca lọc ra file Excel/CSV         | File khớp 100% cột, thứ tự row và giá trị trên màn hình.          | [ ]       |
| M-E02 | JSON Report   | Xuất file JSON bệnh án                | Cấu trúc phân cấp có đủ timeline, audit log, notes.               | [ ]       |
| M-E03 | Raw JSONL     | Bấm Raw Data Export                   | Lấy được nguyên si stream telemetry gốc của session đó.           | [ ]       |
| M-E04 | Compression   | Parquet/GZ compress background worker | Analyzer vẫn đọc xuyên suốt qua Manifest DB mà không bị đứt đoạn. | [ ]       |
| M-E05 | Analyzer View | DuckDB Analyzer quét file đang nén    | Không bị lock file đụng độ với luồng Write (`WinError 32`).       | [ ]       |

---

## 8. POSTGRESQL SANITY (Database Check)

Danh sách query cho DBA / Codex xác nhận sau migration.

| ID    | Feature        | Kich ban                               | Expected Result                                                                                                                                | Pass/Fail |
| ----- | -------------- | -------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- | --------- |
| M-D01 | Alembic        | Query `SELECT * FROM alembic_version;` | Có bản ghi phiên bản mới nhất.                                                                                                                 | [ ]       |
| M-D02 | Tables Guard   | List Schema `public`                   | Có đủ: `treatments`, `treatment_journal_rows`, `raw_packet_manifest`, `snapshot_originals`, `snapshot_audit_log`, `treatment_list_projection`. | [ ]       |
| M-D03 | FK Integrity   | Kiểm tra bảng `raw_packet_manifest`    | Không phát sinh Foreign Key Violation giữa lúc Backfill.                                                                                       | [ ]       |
| M-D04 | Projection     | Update 1 row bất kỳ                    | Bảng `treatment_list_projection` phải thay đổi tức thì qua trigger.                                                                            | [ ]       |
| M-D05 | Legacy Cleanup | Check query path trong code            | API `/v2/` và Command Services không còn dính líu SQLite adapter cũ.                                                                           | [ ]       |

---

## 9. QUY TRÌNH EXECUTING

1. Chuẩn bị Môi trường Simulator (Device A & B).
2. Xóa sạch Log cũ (nếu môi trường Local).
3. Chạy từ trên xuống dưới (Nhấn mạnh nhóm #2, #3, #4).
4. Nếu FAIL 1 điểm thuộc Chronology (Nhóm #3) hoặc Lifecycle (Nhóm #2) -> **Dừng Test, Đánh FAIL NGIÊM TRỌNG, yêu cầu Code Fix ngay.**
5. Mọi BUG phải đính kèm: Timestamp, Treatment ID, Raw Packet (nếu có), Ảnh chụp màn hình.

_(Bản tổng hợp này thay thế mọi file QA Matrix cũ thuộc vùng Treatment Journal)._
