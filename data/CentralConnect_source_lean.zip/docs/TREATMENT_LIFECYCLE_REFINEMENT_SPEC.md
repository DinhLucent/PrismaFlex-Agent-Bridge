# Treatment Lifecycle Refinement Spec

Updated: 2026-04-14

This document supersedes older continuity assumptions that said:

- same device
- same patient
- `RUN_TIME > 0`

always means "resume the same treatment".

That rule is not clinically correct once the machine has already emitted `END`.

## Core Clinical Truth

### Hard boundary

`therapy_status_id = 8 (END)` is a hard treatment boundary.

After a treatment has received `END`:

- the old treatment must close
- the next true start (`WAITINGSTART` or `RUN`) must open a new treatment
- this remains true even if:
  - device is the same
  - patient is the same
  - machine `RUN_TIME` is still greater than zero

### Soft continuity

`RUN_TIME > 0` is still useful, but only for soft continuity cases:

- disconnect/reconnect
- backend restart
- delayed packet arrival
- soft timeout and reopen

`RUN_TIME > 0` may resume the previous treatment only when the previous close
was not a hard boundary.

## Signal Priority

Signals must be interpreted in this priority order:

1. `END`
2. patient change
3. true start gate (`WAITINGSTART` or `RUN`)
4. `RUN_TIME > 0` continuity

In practice:

- `END` beats `RUN_TIME`
- patient change beats `RUN_TIME`
- `RUN_TIME > 0` is only a resume hint, not the source of truth

## Start Gate

A treatment may open only when all of these are true:

- `therapy_status_id` is `4` or `5`
- `patient_id` is valid

`RUN_TIME = 0` alone must never create a treatment.

This prevents fake treatments while the machine is powered on but not actually
running a filter.

## Raw Ownership vs Snapshot Ownership

The backend must treat raw recording and snapshot projection as two related but
separate routing decisions.

### Raw ownership

Every packet must be assigned to at most one raw treatment stream.

Rules:

- normal active packet -> current treatment raw
- `END` packet -> old treatment raw
- patient-change packet that opens a new treatment -> new treatment raw

Raw finalization must happen only after the current packet has already been
written, otherwise compression/delete can race with the last packet append.

### Snapshot ownership

Snapshots belong to the treatment journal, not just the raw file.

Rules:

- active packet -> current treatment snapshot cache
- `END` packet -> old treatment snapshot cache, then flush immediately
- patient-change packet that opens a new treatment -> new treatment snapshot cache
- packet with no active treatment -> no snapshot update

## LIVE Rules

### Continue same treatment

Continue the same treatment when:

- the device already has an active session
- patient is unchanged
- no hard boundary was seen

### Resume closed treatment

Resume a closed treatment only when:

- same device
- same patient
- packet passes the start gate
- previous close reason is soft
- and `RUN_TIME > 0` or recent-close fallback says it is a reconnect

### Never resume after END

If the previous close reason starts with:

- `END received`
- `Patient change`
- `Backfill closed on live handoff`
- `Replaced by promoted backfill session`

then that treatment must not be resumed.

## BACKFILL Rules

Backfill runs faster, but the treatment identity rules stay the same:

- `END` still creates a hard boundary
- next `WAITINGSTART` or `RUN` after `END` must create a new treatment
- `RUN_TIME > 0` may only reconnect soft splits

Backfill differs from LIVE mainly in pacing and wall-clock behavior:

- packet timestamps are historical
- replay is high-speed
- auto-close must not use real wall clock for backfill sessions

## What This Fix Must Protect

### Snapshots

- no false resume across `END`
- final cache flush on the closing packet
- no stale cache surviving into the next treatment

### Raw records

- no split for soft reconnects
- no false merge across `END`
- no compression/delete race before the last packet is written

### Treatment metadata

When a soft-resumed treatment reopens:

- `end_time` must be cleared
- `close_reason` must be cleared
- index outcome must return to `IN_PROGRESS`

Otherwise UI and analyzer can still read the treatment as closed even though
continuity logic reused the same `treatment_id`.

## Known Scope Limit

This refinement makes the current SQLite runtime much safer, but it is not yet
the full "device checkpoint + projection checkpoint" architecture from the
larger Postgres design.

The next step after this patch should still be:

- persistent device state
- explicit live/backfill route split
- deterministic backfill importer separate from live runtime path

## Minimum Verification Matrix

### Case 1

- start by `RUN`, `RUN_TIME = 0`
- expect new treatment

### Case 2

- same device/patient, no `END`, reconnect with `RUN_TIME > 0`
- expect same treatment id
- expect same raw treatment id

### Case 3

- receive `END`
- later same device/patient starts again with `RUN_TIME > 0`
- expect new treatment id
- expect old raw closed, new raw opened

### Case 4

- patient change on same device
- expect old treatment closed
- expect new treatment only if packet also passes the start gate

### Case 5

- closing packet is the last packet in its hour slot
- expect snapshot flush to use the last packet time, not server `now()`
