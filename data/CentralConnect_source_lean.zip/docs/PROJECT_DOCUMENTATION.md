# ICU-B Connect — Tài liệu Chi tiết Dự án & Data Workflow

> **Phiên bản**: v3.7.2 · **Cập nhật**: 2026-04-02  
> **Mục đích**: Cung cấp bức tranh toàn diện để bất kỳ AI agent nào cũng hiểu được kiến trúc, luồng dữ liệu, các phân nhánh xử lý, quy tắc lâm sàng, và mối quan hệ giữa các module.

---

## 1. Tổng quan Hệ thống

**ICU-B Connect** là hệ thống giám sát thời gian thực cho máy lọc máu liên tục (CRRT — Continuous Renal Replacement Therapy) **PrismaFlex**, triển khai tại Khu ICU-B, Bệnh viện Chợ Rẫy (TP.HCM).

### Bối cảnh lâm sàng

- Mỗi máy PrismaFlex kết nối với **một bệnh nhân** tại một thời điểm
- Ca lọc máu kéo dài **20–100+ giờ** liên tục
- Máy phát dữ liệu **mỗi ~10 giây** khi đang chạy (KHÔNG phát khi tắt)
- Dữ liệu gốc là **gói nhị phân** (binary packet) theo giao thức S-record độc quyền

### Stack công nghệ

| Layer               | Công nghệ                           | File chính                                         |
| ------------------- | ----------------------------------- | -------------------------------------------------- |
| Protocol Decoder    | Python, struct                      | `prismaflex_lib/unpacker.py`, `decoder.py`         |
| Integration         | Mirth Connect (ngoài repo)          | —                                                  |
| Backend API         | Python 3.10+, FastAPI, asyncio      | `backend/main.py`                                  |
| Storage (Trends)    | SQLite WAL mode                     | `backend/services/database.py`                     |
| Storage (Treatment) | SQLite WAL mode                     | `backend/services/treatment/treatment_database.py` |
| Storage (Raw)       | JSONL files trên disk               | `backend/services/treatment/raw_streamer.py`       |
| Frontend            | Next.js 15, TypeScript, Tailwind v4 | `frontend/app/`                                    |
| Process Manager     | PM2                                 | `ecosystem.config.js`                              |

---

## 2. Nguồn Dữ liệu Vật lý

### 2.1. Máy PrismaFlex

Máy PrismaFlex phát binary packet qua cổng TCP/Serial. Mỗi packet chứa:

```
┌─────────────────────────────────────────────────────────┐
│ Header (124 bytes, little-endian)                       │
│ ├── STX (2B) + CRC (2B)                                │
│ ├── machine_id (2B) — ID duy nhất của máy              │
│ ├── patient_id (80B) — 4-byte stride UTF-32LE          │
│ ├── therapy_type_id (4B) — loại liệu pháp (CVVH, etc)│
│ ├── therapy_status_id (4B) — trạng thái máy ★         │
│ ├── timestamp_unix (4B) — giờ máy (GMT+7 gắn nhãn UTC)│
│ └── body_length (4B)                                    │
├─────────────────────────────────────────────────────────┤
│ Body (N * 12 bytes per parameter record)                │
│ └── Mỗi record:                                        │
│     ├── param_code (4B) — ID + type flags (bit mask)   │
│     ├── record_time (4B)                                │
│     └── value (4B, signed int)                          │
└─────────────────────────────────────────────────────────┘
```

### 2.2. Therapy Status ID — Bảng trạng thái máy (Critical)

| ID  | Tên          | Ý nghĩa lâm sàng              |
| --- | ------------ | ----------------------------- |
| 0   | IDLE         | Máy bật, không có ca          |
| 4   | WAITINGSTART | Chuẩn bị chạy, có patient_id  |
| 5   | RUN          | Đang chạy ca lọc máu          |
| 6   | PAUSED       | Tạm dừng (đổi túi, can thiệp) |
| 7   | STOPPED      | Dừng bởi người dùng           |
| 8   | END          | Kết thúc ca ★                 |
| 9   | ALARM        | Có cảnh báo nghiêm trọng      |

> [!IMPORTANT]
> **`END` (8) KHÔNG có nghĩa là chấm dứt vĩnh viễn**. Bác sĩ có thể chọn "SAME PATIENT" trên máy để tiếp tục ca mới cho cùng bệnh nhân. Khi đó `RUN_TIME` (PID 461) KHÔNG reset về 0 mà tiếp tục đếm — đây là tín hiệu xác nhận continuity từ máy.

### 2.3. Parameter Record Type (Bit Masking)

Unpacker tách `param_code` (4 bytes) bằng bit mask:

```python
if param_code & 0x80000000:   # Bit 31 set
    record_type = "Alarm"
    true_param_id = param_code & 0x7FFFFFFF
elif param_code & 0x40000000: # Bit 30 set
    record_type = "Set"       # Giá trị cài đặt (y lệnh)
    true_param_id = param_code & 0x3FFFFFFF
else:
    record_type = "Actual"    # Giá trị đo thực tế
    true_param_id = param_code & 0x00FFFFFF
```

Mỗi packet chứa **hàng trăm** parameter records (Actual + Set + Alarm), tổng size ~36KB.

### 2.4. Timestamp Quirk (Critical)

Máy PrismaFlex ghi timestamp Unix theo **giờ local (GMT+7)** nhưng decoder gắn nhãn `" UTC"`. Toàn bộ backend **PHẢI** strip suffix `" UTC"` hoặc `"Z"` rồi treat giá trị đó như đã là GMT+7. Nếu convert thêm +7h sẽ bị **lệch 7 tiếng**.

---

## 3. Pipeline Xử lý Dữ liệu

### 3.1. Tầng 1: Bộ Thu Thập (ngoài repo)

Một chương trình riêng chạy trên máy tính kết nối vật lý với PrismaFlex, đọc binary packet từ cổng TCP/Serial, và chuyển cho Mirth Connect.

### 3.2. Tầng 2: Mirth Connect (Integration Middleware)

Mirth Connect nhận binary hex string, dùng `PrismaFlexUnpacker` để giải mã thành JSON cấu trúc, sau đó POST vào backend:

```
Binary hex → PrismaFlexUnpacker.unpack() → JSON {s_header, s_body}
                                                    │
                Mirth giữ nguyên timestamp gốc      │
                gắn thêm device_id vào meta          │
                                                    ▼
              POST /api/v1/telemetry  ─────────►  Backend
```

> [!WARNING]
> **Backfill mode**: Khi đổ lại dữ liệu cũ, Mirth bắn JSON với **tốc độ rất cao** (không có delay 10s giữa các packet). Backend phải xử lý được mà không mất data.

### 3.3. Tầng 3: Backend Ingestion — Dual Path Architecture

File: [main.py](file:///d:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/main.py)

Endpoint `POST /api/v1/telemetry` là điểm vào duy nhất. Nó tách thành **2 đường**:

```
POST /api/v1/telemetry
        │
        ├── 1. Data Quality Check ──► LIVE (≤25s lag) hoặc DELAYED
        │
        ├── 2. ★ FAST PATH (chỉ khi LIVE) ──────────────────────┐
        │   │                                                     │
        │   │   TelemetryFilter.extract_dashboard_packet()        │
        │   │   → Trích ~14 vital PIDs + header nhẹ              │
        │   │   → asyncio.create_task(broadcast)                  │
        │   │   → Message type: "TELEMETRY_FAST_UPDATE"           │
        │   │                                                     │
        │   └─────────────────────────────► WebSocket Clients     │
        │                                                         │
        └── 3. ★ HEAVY PATH (always) ──► Push to telemetry_queue │
            │                                                     │
            │   asyncio.Queue(maxsize=10000)                      │
            │   4 workers xử lý song song                        │
            │                                                     │
            └──► telemetry_worker() ──────────────────────────────┘
```

- **Fast Path**: Sub-millisecond, fire-and-forget broadcast chỉ vital signs cho Dashboard. Bỏ qua khi data là backfill (DELAYED).
- **Heavy Path**: Luôn chạy (cả LIVE và DELAYED). Đẩy vào `asyncio.Queue` cho worker xử lý background.

### 3.4. Tầng 4: Heavy Path Worker — Fan-out 5 nhánh

File: [main.py#telemetry_worker](file:///d:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/main.py#L244-L401)

Mỗi packet trong queue được xử lý tuần tự qua 5 nhánh:

```
telemetry_worker(app)
    │
    ├── Bước 1: ENRICHMENT ──────────────────────────────────────
    │   │   ReferenceDatabase (in-memory)
    │   │   → Enrich header: therapy_type_id → name, status → name
    │   │   → Enrich body params: pid → label, enum value → text
    │   │   → Extract active_alarms (type="Alarm" & value=1,2)
    │   │
    │   └── Output: enriched packet + active_alarms list
    │
    ├── Bước 2: DASHBOARD BROADCAST (Paced) ─────────────────────
    │   │   Chỉ broadcast FULL update mỗi 10s/device
    │   │   Lần đầu thấy device → broadcast ngay (Bootstrap)
    │   │   → Message type: "TELEMETRY_UPDATE"
    │   │   → Contains: full enriched payload + quality_status
    │   │
    │   └──► WebSocket Clients
    │
    ├── Bước 3: TREATMENT RECORDING ★ ───────────────────────────
    │   │   TreatmentRecorderService.process_packet()
    │   │   → Quyết định OPEN/RECORD/CLOSE session
    │   │   → Ghi raw packet vào JSONL file (RawDataStreamer)
    │   │   → Return treatment_id cho Snapshot
    │   │
    │   │   TreatmentSnapshotService.process_packet()
    │   │   → Cache parameter values trong RAM
    │   │   → Ghi snapshot vào SQLite khi cross hour boundary
    │   │
    │   └── (Chi tiết xem Section 4)
    │
    ├── Bước 4: TREND & EVENT STORAGE ───────────────────────────
    │   │   EventService.save_trend_point()
    │   │   → Ghi 6 pressure values vào trends table (rolling 1000/device)
    │   │
    │   │   SmartAlarmService.process()
    │   │   → Debounced alarm tracking (5-min cooldown)
    │   │   → Ghi alarm start/end vào DB
    │   │
    │   │   EventService.track_parameter_changes()
    │   │   → So sánh values với cache → phát hiện thay đổi
    │   │   → Ghi changes vào events table (hiển thị "Was" trên UI)
    │   │   → Broadcast EVENT_UPDATE qua WebSocket
    │   │
    │   └── Order-Change Snapshot (khi QB/QD/QS/QPBP/UF thay đổi)
    │
    └── Bước 5: AUTO-PRUNE (1/250 chance per packet) ────────────
            db.prune() → xóa trends >1000/device, events >48h, alarms >90d
```

---

## 4. Treatment Recording — Chi tiết các nhánh lưu trữ

### 4.1. Tổng quan 3 luồng lưu trữ

```
Mỗi telemetry packet
    │
    ├── ① Dashboard (WebSocket broadcast)
    │     → Transient, không lưu
    │     → Fast Path: chỉ 14 PIDs, real-time only
    │     → Full Path: enriched packet, paced 10s/device
    │
    ├── ② Snapshot (SQLite: treatment_hourly_snapshots)
    │     → Cache PIDs liên tục trong RAM
    │     → Ghi vào DB mỗi khi cross hour boundary (H00, H01, ...)
    │     → Ghi Order-Change snapshot (OC_01, OC_02, ...) khi y lệnh thay đổi
    │     → Phục vụ "Nhật ký điều trị" cho bác sĩ review
    │
    └── ③ RawData (JSONL file trên disk)
          → Ghi TOÀN BỘ packet gốc (s_header + s_body + meta)
          → File: data/treatments/raw/treatment_{uuid}.raw.jsonl
          → Mục đích: Forensic analysis, replay, audit trail
          → Nén .gz khi treatment đóng hẳn
```

### 4.2. TreatmentRecorderService — State Machine

File: [treatment_recorder.py](file:///d:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/services/treatment/treatment_recorder.py)

```
                    ┌──────────────────────┐
     Packet đầu     │    NO ACTIVE SESSION │
     tiên           │   (session is None)  │
                    └──────────┬───────────┘
                               │
                    status ∈ {4,5} AND patient_id valid?
                               │
                    ┌──── YES ─┴── NO ────┐
                    ▼                     ▼
            ┌──────────────┐        (bỏ qua packet)
            │   _open()    │
            │   → SAME PT? │
            │   → Resume?  │
            │   → New UUID │
            └──────┬───────┘
                   │
                   ▼
            ┌──────────────┐
            │  RECORDING   │◄──────────────────────────────┐
            │  (active)    │                               │
            └──────┬───────┘                               │
                   │                                       │
          Mỗi packet tiếp theo                             │
                   │                                       │
        ┌──────────┼──────────────────────┐                │
        │          │                      │                │
   status=8    patient_id       gap > 24h │   gap > 5min   │
   (END)       thay đổi        (timeout)  │   (reconnect)  │
        │          │                      │        │       │
        ▼          ▼                      ▼        │       │
  ┌──────────┐ ┌──────────┐       ┌──────────┐    │       │
  │ _close() │ │ _close() │       │ _close() │    │       │
  │ "END"    │ │ "Patient │       │ "AUTO_   │    │       │
  │          │ │  change" │       │  TIMEOUT"│    │       │
  └────┬─────┘ └────┬─────┘       └────┬─────┘    │       │
       │             │                  │          │       │
       │             │   Re-open if     │          │       │
       │             │   status ∈ {4,5} │          │       │
       │             └──────────────────┼──────────┘       │
       │                                │                  │
       │    Next packet: SAME PATIENT?  │                  │
       │    RUN_TIME > 300s?            │                  │
       │    Same device + patient?      │                  │
       │                                │                  │
       ├── YES → _open() resumes       │                  │
       │         same treatment_id ─────┼──────────────────┘
       │                                │
       └── NO  → stays closed          │
                  (waits 6h, then       │
                   compress raw file)   │
```

### 4.3. Quy tắc Boundary Lâm sàng

```
OPEN   = therapy_status ∈ {WAITINGSTART(4), RUN(5)} + valid patient_id
RECORD = mọi status (STOP, CHANGE_BAG, END, RETURN, IDLE...) đều ghi
CLOSE trigger 1 = END (status_id = 8) → nhưng CÓ THỂ resume
CLOSE trigger 2 = patient_id thay đổi → đây mới là split thật
CLOSE trigger 3 = gap > 24h → AUTO_TIMEOUT
```

#### SAME PATIENT Detection

Khi `_open()` được gọi, nó kiểm tra **2 cơ chế resume** trước khi tạo UUID mới:

1. **RUN_TIME Signal** (mạnh nhất): `PID 461 (RUN_TIME) > 300s` → máy xác nhận đây là continuation → tìm treatment closed gần nhất (48h) cho cùng device+patient → resume cùng `treatment_id`

2. **Resumption Window** (6 giờ): treatment closed < 6h trước cho cùng device+patient → resume cùng `treatment_id` (tránh phân mảnh do restart/update)

### 4.4. Live vs Backfill Sessions

```python
session_map = self._sessions if is_live else self._backfill_sessions
```

- `is_live = True`: data quality = "LIVE" (latency ≤ 25s) → dùng `_sessions` map
- `is_live = False`: data quality = "DELAYED" → dùng `_backfill_sessions` map riêng

Hai map **độc lập**, cùng một device có thể có 2 sessions song song (1 live, 1 backfill).

### 4.5. RawDataStreamer — Forensic Storage

File: [raw_streamer.py](file:///d:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/services/treatment/raw_streamer.py)

```
stream_packet(device_id, treatment_id, packet)
    │
    ├── Lock per device_id (async)
    │
    ├── Nếu .jsonl KHÔNG tồn tại nhưng .gz CÓ → decompress
    │   (Case: END → compress → SAME PATIENT resume)
    │
    ├── JSON serialize packet → 1 dòng JSONL
    │
    └── Append vào file + flush + fsync
        File: data/treatments/raw/treatment_{uuid}.raw.jsonl
```

**Compression**: sau khi `_close()`, file KHÔNG nén ngay nếu reason = "END received". Chỉ nén khi:

- Close reason khác (patient change, timeout) → nén ngay
- `enforce_auto_close()` phát hiện treatment đã closed > 6h và chưa resume → deferred compress

### 4.6. TreatmentSnapshotService — Hourly Snapshots

File: [treatment_snapshot_service.py](file:///d:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/services/treatment/treatment_snapshot_service.py)

**26 PIDs được theo dõi** (CRRT-specific):

| Nhóm       | PIDs                                                                                | Ý nghĩa            |
| ---------- | ----------------------------------------------------------------------------------- | ------------------ |
| Flow rates | QB(17), QD(21), QS_PRE(18), QS_POST(19), QPBP(22), Effluent(23)                     | Tốc độ dòng        |
| Pressures  | PA(1), PV(4), PBE(2), TMP(6)                                                        | Áp lực             |
| UF         | UF_total(100), UF_hourly(24), UF_rate_target(25)                                    | Siêu lọc           |
| Heparin    | Heparin_rate(38)                                                                    | Kháng đông         |
| Citrate    | Citrate_dose(400), Citrate_conc(401), Citrate_load(403), Ca_rate(404), Ca_comp(406) | Kháng đông citrate |
| Meta       | RunTime(461), BloodVol(60), PtWeight(26), AnticoagType(409)                         | Thông tin ca       |

**Cơ chế snapshot**:

```
Mỗi packet → _extract_values() cập nhật RAM cache
          → Tính elapsed = (pkt_time - start_time)
          → hour_label = H{elapsed/3600:02d}

H00 (Baseline):
  → Ghi liên tục trong 60s đầu, sau đó lock

H01, H02, ... (Hourly):
  → Ghi 1 lần khi cross hour boundary

OC_01, OC_02, ... (Order Change):
  → Khi QB/QD/QS/QPBP/UF thay đổi
  → Anti-flicker: bỏ qua Δ < 1
  → 60s cooldown: gộp nhiều thay đổi
  → Revert check: so sánh cache hiện tại
```

---

## 5. Frontend — WebSocket Consumer

### 5.1. WebSocketProvider

File: [WebSocketProvider.tsx](file:///d:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/frontend/app/providers/WebSocketProvider.tsx)

Frontend connect `ws://localhost:8000/ws` và xử lý **4 loại message**:

| Message Type            | Nguồn                  | Tần suất           | Xử lý                                                |
| ----------------------- | ---------------------- | ------------------ | ---------------------------------------------------- |
| `HEARTBEAT`             | Heartbeat task (1s)    | 1/s                | Cập nhật `serverTime`                                |
| `TELEMETRY_FAST_UPDATE` | Fast Path (chỉ LIVE)   | ~10s/device        | Merge vitals vào device state, KHÔNG replace toàn bộ |
| `TELEMETRY_UPDATE`      | Heavy Path (paced 10s) | ~10s/device        | Replace toàn bộ device state (full payload)          |
| `EVENT_UPDATE`          | Event tracking         | Khi param thay đổi | Merge vào `deviceEvents` (hiển thị "Was" indicator)  |

### 5.2. Device State Management

```typescript
deviceMap: Record<string, DeviceData>
  │
  ├── Khởi tạo từ localStorage (known_devices)
  │
  ├── TELEMETRY_FAST_UPDATE:
  │   → Chỉ merge vitals vào existing parameters
  │   → Giữ nguyên data cũ nếu không có trong vitals
  │   → Dùng browser time cho lastUpdate
  │
  ├── TELEMETRY_UPDATE:
  │   → Replace toàn bộ s_header + s_body
  │   → Set active_alarms
  │   → Trigger audio nếu có alarm mới (Critical/Warning)
  │   → Freshness check: bỏ packet cũ hơn 10s so với current
  │
  └── Offline detection:
      → setInterval 5s, nếu lastUpdate > 45s → status = 'OFFLINE'
```

### 5.3. Audio Alert System

- Yêu cầu user click "Enable Audio" trước (browser policy)
- **Critical** (ALARM/MALFUNCTION category): `beep-critical.wav`
- **Warning**: `beep-warning.wav`
- Chỉ phát khi severity level MỚI xuất hiện (không lặp)

---

## 6. Storage Architecture

### 6.1. SQLite Databases

| Database  | File                                     | Vai trò                                             | Mode                       |
| --------- | ---------------------------------------- | --------------------------------------------------- | -------------------------- |
| Trends    | `backend/trends.db`                      | Pressure trends, events, alarm history, feedback    | WAL                        |
| Treatment | `backend/services/treatment_records.db`  | Treatment records, snapshots, status log, approval  | WAL                        |
| Reference | `prismaflex_lib/prismaflex_reference.db` | Parameter definitions, therapy types, alarm catalog | Read-only, loaded into RAM |

### 6.2. File Storage

```
backend/data/treatments/raw/
├── treatment_{uuid}.raw.jsonl      ← JSONL forensic stream (đang ghi hoặc chưa nén)
├── treatment_{uuid}.raw.jsonl.gz   ← Đã nén (treatment đóng hẳn)
│
backend/archive/{year}/{month}/
├── {treatment_id}.json             ← Archived treatment report
└── {treatment_id}.raw.jsonl        ← Archived raw packets
│
backend/logs/
├── backend.log                     ← Main system log (rotating 5MB × 5)
├── errors.log                      ← Error-only log
├── audit.log                       ← Clinical actions audit trail (10MB × 10)
├── frontend.log                    ← Client-side crash reports
├── performance.log                 ← Telemetry processing metrics (async)
└── replay_status.log               ← Backfill/replay status
│
backend/ALARM_LOGS/{device_id}/
└── alarms_{YYYY-MM-DD}.log         ← Daily alarm event log per device
```

---

## 7. Alarm Processing — State Machine

File: [alarm_service.py](file:///d:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/services/alarm_service.py)

```
                    ┌──────────────┐
    First packet    │ INIT DEVICE  │
    from device     │ Load orphans │
                    │ from DB      │
                    └──────┬───────┘
                           │
                ┌──────────▼──────────┐
                │   Process Packet    │◄─── Mỗi packet
                │   current_alarms =  │
                │   [alarms in packet]│
                └──────────┬──────────┘
                           │
            ┌──────────────┼──────────────┐
            │              │              │
     Alarm đang     Alarm vẫn      Alarm MỚI
     active nhưng   PRESENT        (chưa tracked)
     MISSING                              │
            │              │              ▼
            ▼              ▼         insert_alarm()
     Start 5-min     Cancel          + file log
     cooldown timer  pending clear
            │
            │  5 min elapsed?
            │  (or reconnection)
            │
            ▼
     CONFIRMED CLEAR
     → close_alarm()
     → file log
```

- **Debounce 5 phút**: Alarm phải "biến mất" liên tục 5 phút mới xác nhận cleared
- **Blackout resilience**: Nếu reconnect sau >5 phút im lặng → clear ngay (không chờ thêm)
- **Server restart recovery**: Load alarm records chưa close từ DB → so sánh với packet đầu tiên

---

## 8. Event & Trend Tracking

File: [event_service.py](file:///d:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/services/event_service.py)

### 8.1. Parameter Change Detection ("Was" indicator)

- Cache per device: `{param_id: display_value}`
- **18 tracked PIDs** (clinical flows, anticoag settings — **KHÔNG** track pressures vì quá volatile)
- Khi value thay đổi → log `(pid, old_value, new_value)` vào DB + broadcast `EVENT_UPDATE`
- Frontend hiển thị "Was: 150" bên cạnh giá trị hiện tại

### 8.2. Session Reset

Khi `patient_id` thay đổi → purge toàn bộ:

- Trends DB cho device
- Parameter cache
- Alarm cache (thông qua callback `on_session_reset`)

### 8.3. Trend Storage

- 6 pressures: Access(1), Filter(2), Effluent(3), Return(4), TMP(6), ΔP(7)
- Rolling buffer: max 1000 points/device (~4-6 giờ ở tần suất 10s/packet)
- Phục vụ biểu đồ áp lực trên Dashboard

---

## 9. Reference Database — Parameter Enrichment

File: [reference_db.py](file:///d:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/prismaflex_lib/reference_db.py)

SQLite database `prismaflex_reference.db` chứa catalog đầy đủ của PrismaFlex, loaded **toàn bộ vào RAM** khi startup:

| Table                    | Nội dung                                                          |
| ------------------------ | ----------------------------------------------------------------- |
| `numerical_parameters`   | id, name, unit, min, max (vd: PID 17 = BLOOD_FLOW, ml/min, 0-450) |
| `enumerative_parameters` | id, name, description                                             |
| `enumerative_values`     | parameter_id, value, meaning (vd: therapy_type 1 = "CVVH")        |
| `therapy_types`          | id, name                                                          |
| `therapy_statuses`       | id, name                                                          |
| `alarms`                 | id, title, description, severity (WARNING/ALARM/MALFUNCTION)      |

Lookup cost: **O(1) dict access** — critical cho tần suất ~100 packets/second khi backfill.

---

## 10. Approval Workflow (Clinical Governance)

File: [treatment_router.py](file:///d:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/routers/treatment_router.py)

```
  IN_PROGRESS ──(close)──► COMPLETED ──(nurse submit)──► PENDING_REVIEW
       │                                                       │
       │                                               ┌───────┤
       │                                               │       │
       │                                          (doctor)  (doctor)
       │                                          approve   reject
       │                                               │       │
       │                                               ▼       ▼
       │                                          APPROVED   DRAFT
       │                                               │       │
       │                                          (doctor)  (nurse)
       │                                          unlock   re-submit
       │                                               │       │
       │                                               ▼       ▼
       │                                        PENDING_REVIEW ─┘
       │
   Freeze snapshots on Submit
   Lock edits on APPROVED
   Audit trail for all transitions
```

RBAC: `X-User-Role` header (`nurse`, `doctor`, `admin`)

---

## 11. Deployment & Process Management

File: [ecosystem.config.js](file:///d:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/ecosystem.config.js)

```
PM2
├── icub-backend  (pythonw main.py, port 8000, 1 instance, autorestart)
└── icub-frontend (next start, port 3000, 1 instance, autorestart)
```

- `pythonw` = no console window (production Windows)
- Max memory: 1GB cho backend
- Scripts: `START_SYSTEM.bat`, `STOP_SYSTEM.bat`, `safe_update.bat`

> 📖 **Xem thêm**: [Quy trình Vận hành, Sao lưu & Cập nhật](QUY_TRINH_VAN_HANH.md) (Hướng dẫn chi tiết các bước backup, đóng gói, update và cứu hộ hệ thống).

---

## 12. Tóm tắt Data Flow — End to End

```
PrismaFlex Machine (Binary S-record, ~10s/packet)
        │ TCP/Serial
        ▼
Bộ Thu Thập Tín Hiệu → Raw Hex String
        │
        ▼
Mirth Connect
  ├── PrismaFlexUnpacker.unpack() → JSON {s_header, s_body}
  ├── Gắn device_id vào meta
  ├── Giữ nguyên timestamp gốc (GMT+7 labeled UTC)
  └── POST /api/v1/telemetry → Backend
        │
        ▼
FastAPI Backend (main.py)
  │
  ├── Data Quality Check: LIVE (≤25s) or DELAYED
  │
  ├── ★ FAST PATH (LIVE only)
  │   └── TelemetryFilter → 14 vitals → WebSocket "TELEMETRY_FAST_UPDATE"
  │
  └── ★ HEAVY PATH (always) → asyncio.Queue → 4 workers
      │
      ├── ① ReferenceDB Enrichment (in-memory O(1))
      ├── ② Paced WebSocket Broadcast "TELEMETRY_UPDATE" (10s/device)
      ├── ③ Treatment Recording
      │   ├── TreatmentRecorder (session lifecycle)
      │   ├── RawDataStreamer (JSONL forensic append)
      │   └── SnapshotService (hourly + order-change)
      ├── ④ Trend/Event/Alarm Processing
      │   ├── save_trend_point (6 pressures → SQLite)
      │   ├── SmartAlarmService (debounced state machine)
      │   └── track_parameter_changes ("Was" indicator + EVENT_UPDATE)
      └── ⑤ Auto-Prune (1/250 probability)
        │
        ▼
Next.js Frontend (WebSocket consumer)
  ├── HEARTBEAT → Server time sync
  ├── TELEMETRY_FAST_UPDATE → Merge vitals (low latency)
  ├── TELEMETRY_UPDATE → Full device state + alarm audio
  └── EVENT_UPDATE → "Was" indicator display
```

---

_Tài liệu này mô tả toàn bộ hệ thống tính đến commit `b2a3fdb` (2026-04-01)._
