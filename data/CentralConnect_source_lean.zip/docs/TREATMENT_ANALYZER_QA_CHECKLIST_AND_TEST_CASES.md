# TREATMENT ANALYZER QA CHECKLIST AND TEST CASES

**Updated:** 2026-04-05  
**Scope:** Standalone `Treatment Analyzer` (`tools/treatment_analyzer`)  
**Audience:** QA Lead, Tester, Clinical Validator  
**Status:** Ready for QA execution

---

## 1. Objective

Tai lieu nay dung de QA kiem tra chuong trinh phu `Treatment Analyzer` theo dung hanh vi hien tai cua code:

- standalone, read-only, khong sua du lieu goc
- chay rieng voi WebApp chinh
- doc metadata treatment tu SQLite `treatment_records.db`
- doc raw files tu `backend/data/treatments/raw`
- phan tich va hien thi:
  - treatment list
  - unified analysis shell
  - alarm timeline
  - set parameters
  - pressure trends + pressure table
  - scale trends + IO history table
  - pump trends + pump table
  - CSV export
  - refresh / cache invalidation

---

## 2. Important Notes For QA

### 2.1. Current runtime behavior

- Analyzer hien tai dung Flask app tai [app.py](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/tools/treatment_analyzer/app.py).
- Port mac dinh trong code hien tai la `5555`.
- Tai lieu [INSTALL.md](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/tools/treatment_analyzer/INSTALL.md) van ghi `5001`, QA can xem day la mot implementation mismatch can bao cao.
- Tool nay hien van doc metadata tu SQLite `backend/services/treatment_records.db`, khong doc Postgres.
- Tool hien tai parse raw trong [app.py](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/tools/treatment_analyzer/app.py), chua su dung `duckdb_reader.py` cho runtime UI.

### 2.2. Supported raw formats

- Chunked `.jsonl`
- Chunked `.parquet`
- Legacy `.raw.jsonl.gz`
- Legacy `.raw.jsonl`

### 2.3. Read-only guarantee

QA phai xem day la tieu chi P0:

- Analyzer khong duoc ghi vao `treatment_records.db`
- Analyzer khong duoc ghi vao `prismaflex_reference.db`
- Analyzer khong duoc sua/xoa/rename raw files
- Analyzer khong duoc goi mutation endpoint cua WebApp chinh

### 2.4. Pump tab security

- Pump tab hien tai dung `prompt()` client-side voi mat khau `admin`
- Day la gate UI, khong phai security backend that su
- QA can test dung hanh vi hien tai, dong thoi ghi nhan day la residual risk

---

## 3. Entry Criteria

Truoc khi chay suite, QA can xac nhan:

- Python 3.8+ co san
- Flask co san
- Thu muc `tools/treatment_analyzer` nam dung vi tri
- Co file:
  - `backend/services/treatment_records.db`
  - `backend/prismaflex_reference.db`
  - `backend/data/treatments/raw/`
- Co it nhat 1 treatment co raw data
- Co it nhat 1 treatment khong co raw data hoac mo phong duoc tinh huong do

---

## 4. Recommended Data Scenarios

QA nen chuan bi toi thieu 6 kieu scenario sau:

| Scenario ID | Fixture type | Muc dich |
| --- | --- | --- |
| `AN-DATA-01` | Treatment co raw `.jsonl` chunked | Flow chinh, list -> analysis |
| `AN-DATA-02` | Treatment co raw `.jsonl.gz` legacy | Kiem tra legacy compatibility |
| `AN-DATA-03` | Treatment dang `IN_PROGRESS` | Test refresh va cache invalidation |
| `AN-DATA-04` | Treatment co raw nhung it/no alarms | Test empty alarm states |
| `AN-DATA-05` | Treatment co raw nhung khong co pump data | Test empty pump tab |
| `AN-DATA-06` | Treatment khong co raw data | Test disabled/no-raw behavior |

Neu moi truong khong du 6 loai, QA phai ghi ro scenario nao chua test duoc.

---

## 5. QA Checklist

Danh dau tung muc:

| ID | Priority | Area | Checklist item | Pass/Fail |
| --- | --- | --- | --- | --- |
| `AN-CL-01` | P0 | Startup | App khoi dong duoc bang `python app.py` | [ ] |
| `AN-CL-02` | P0 | Startup | App bind dung port runtime mong doi | [ ] |
| `AN-CL-03` | P1 | Docs parity | Ghi nhan port trong UI/code va `INSTALL.md` co thong nhat hay khong | [ ] |
| `AN-CL-04` | P0 | Data source | Treatment DB mo duoc o che do read-only | [ ] |
| `AN-CL-05` | P0 | Data source | Reference DB mo duoc va load alarm definitions | [ ] |
| `AN-CL-06` | P0 | Data source | Raw data dir truy cap duoc | [ ] |
| `AN-CL-07` | P0 | List | Load duoc treatment list toi da 100 items | [ ] |
| `AN-CL-08` | P1 | List | Treatment co raw hien thi badge kich thuoc file | [ ] |
| `AN-CL-09` | P1 | List | Treatment khong co raw bi dim/khong cho select | [ ] |
| `AN-CL-10` | P0 | Select | Chon treatment co raw se load analysis shell thanh cong | [ ] |
| `AN-CL-11` | P0 | Shell | Header hien patient, device, time range, packets, file size | [ ] |
| `AN-CL-12` | P0 | Alarm tab | Stats, summary, chart, event table render dung | [ ] |
| `AN-CL-13` | P1 | Alarm tab | Severity color/class dung cho warning/caution/advisory/malfunction | [ ] |
| `AN-CL-14` | P1 | Alarm tab | Export CSV Alarm hoat dong | [ ] |
| `AN-CL-15` | P0 | Params tab | Param cards render dung current value/min/max/change count | [ ] |
| `AN-CL-16` | P1 | Params tab | Enum params hien value text ngan gon dung | [ ] |
| `AN-CL-17` | P1 | Params tab | SET change table render theo chronology | [ ] |
| `AN-CL-18` | P1 | Params tab | Export CSV SET params hoat dong | [ ] |
| `AN-CL-19` | P0 | Pressure tab | Chart render, hover tooltip, legend toggle hoat dong | [ ] |
| `AN-CL-20` | P1 | Pressure tab | Alarm markers bat/tat duoc va khong crash | [ ] |
| `AN-CL-21` | P1 | Pressure tab | Zoom/pan/reset zoom hoat dong tren chart | [ ] |
| `AN-CL-22` | P1 | Pressure tab | Chuyen Chart/Table mode hoat dong | [ ] |
| `AN-CL-23` | P1 | Pressure tab | Export pressure table CSV hoat dong | [ ] |
| `AN-CL-24` | P0 | Scales tab | Scale chart va IO History table render dung | [ ] |
| `AN-CL-25` | P1 | Scales tab | Export scale CSV hoat dong | [ ] |
| `AN-CL-26` | P0 | Pump tab | Prompt password xuat hien khi mo tab lan dau | [ ] |
| `AN-CL-27` | P1 | Pump tab | Nhap sai password thi khong vao duoc tab | [ ] |
| `AN-CL-28` | P1 | Pump tab | Nhap dung `admin` thi chart/table pump render dung | [ ] |
| `AN-CL-29` | P1 | Pump tab | Export pump CSV hoat dong | [ ] |
| `AN-CL-30` | P0 | Refresh | Nut refresh force re-parse du lieu treatment dang chay | [ ] |
| `AN-CL-31` | P1 | Cache | Refresh khi file raw khong doi khong lam sai ket qua | [ ] |
| `AN-CL-32` | P1 | Empty state | Empty state hien ro rang khi khong co alarm/param/pressure/scale/pump | [ ] |
| `AN-CL-33` | P0 | Error state | Loi DB/raw hien thong bao ro, khong treo trang | [ ] |
| `AN-CL-34` | P0 | Read-only | Sau khi su dung Analyzer, DB/raw khong bi thay doi | [ ] |
| `AN-CL-35` | P2 | Performance | Treatment raw lon van load duoc trong thoi gian chap nhan duoc | [ ] |
| `AN-CL-36` | P2 | Browser UX | Scroll, sticky header, table overflow, zoom 100-150% khong vo layout | [ ] |

---

## 6. Detailed Test Cases

## 6.1. Smoke and Startup

### `AN-TC-01` Start analyzer successfully

- Priority: P0
- Precondition: Co day du file DB va raw
- Steps:
  1. Mo terminal tai `tools/treatment_analyzer`
  2. Chay `python app.py`
  3. Mo browser vao `http://localhost:5555`
- Expected result:
  - App khoi dong khong crash
  - Header `Treatment Analyzer` hien thi
  - Khong co traceback tren console ngay khi start

### `AN-TC-02` Verify data source dependency report

- Priority: P1
- Steps:
  1. Quan sat log startup
  2. Xac nhan treatment DB, reference DB, raw dir duoc check
- Expected result:
  - Log hien trang thai dependency ro rang
  - Neu thieu reference/raw dir thi canh bao dung loai, app khong crash vo dieu kien

### `AN-TC-03` Confirm runtime port and installation doc parity

- Priority: P1
- Steps:
  1. Doc [INSTALL.md](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/tools/treatment_analyzer/INSTALL.md)
  2. So voi port startup thuc te trong `app.py`
- Expected result:
  - QA ghi nhan mismatch neu co
  - Mismatch tai lieu khong duoc bo qua khi release

## 6.2. Treatment List

### `AN-TC-04` Load treatment list

- Priority: P0
- Steps:
  1. Mo Analyzer
  2. Cho danh sach treatment load
- Expected result:
  - Danh sach hien duoc toi da 100 treatment
  - Moi card co patient, outcome, device, duration, start time

### `AN-TC-05` Raw badge on treatment cards

- Priority: P1
- Steps:
  1. Tim 1 treatment co raw data
  2. Kiem tra badge file size
- Expected result:
  - Badge hien so MB raw
  - Gia tri khong am, khong rong

### `AN-TC-06` No raw data treatment cannot be analyzed

- Priority: P1
- Steps:
  1. Tim 1 treatment khong co raw data
  2. Click treatment card
- Expected result:
  - Card bi dim/no-raw
  - Khong chay luong analysis
  - Khong crash UI

## 6.3. Unified Analysis Loading

### `AN-TC-07` Select treatment with raw data

- Priority: P0
- Steps:
  1. Click 1 treatment card co raw data
- Expected result:
  - Right panel hien skeleton loading
  - Sau do hien analysis shell
  - Treatment dang chon duoc highlight active

### `AN-TC-08` Validate analysis shell metadata

- Priority: P0
- Steps:
  1. Sau khi load xong, doi chieu metadata shell
- Expected result:
  - Hien patient/device
  - Hien time range start -> end
  - Hien tong packets
  - Hien dung file size
  - Hien therapy type

### `AN-TC-09` Handle raw parse failure gracefully

- Priority: P0
- Steps:
  1. Chon treatment co file raw loi hoac tam doi ten file raw
  2. Load analysis
- Expected result:
  - Hien thong bao loi ro rang trong panel
  - Khong treo UI
  - Khong lam hong left panel

## 6.4. Alarm Tab

### `AN-TC-10` Alarm tab renders summary and chart

- Priority: P0
- Steps:
  1. Chon treatment co alarm events
  2. Xem tab `Alarms`
- Expected result:
  - Stats cards render
  - Alarm summary render
  - Alarm chart render
  - Alarm event table render

### `AN-TC-11` Severity mapping and state display

- Priority: P1
- Steps:
  1. Kiem tra 1 vai event trong table
- Expected result:
  - Severity va mau the hien dung voi `MALFUNCTION/WARNING/CAUTION/ADVISORY`
  - State `PRESENT/OVERRIDDEN/CLEARED` hien dung

### `AN-TC-12` Alarm empty state

- Priority: P1
- Steps:
  1. Chon treatment khong co alarm
- Expected result:
  - Table hien `No alarm events`
  - Khong co JS error

### `AN-TC-13` Export alarm CSV

- Priority: P1
- Steps:
  1. Bam `Export CSV` o Alarm tab
  2. Mo file CSV
- Expected result:
  - File duoc download
  - Header va dong du lieu khop voi table dang hien
  - UTF-8/BOM doc duoc trong Excel

## 6.5. SET Parameters Tab

### `AN-TC-14` Parameter cards and stats

- Priority: P0
- Steps:
  1. Mo tab `SET Parameters`
- Expected result:
  - Hien `SET Params`, `SET Changes`, `Packets`
  - Param cards chia theo group dung
  - Current value, min, max, change count hop ly

### `AN-TC-15` Enum parameter rendering

- Priority: P1
- Steps:
  1. Kiem tra param enum nhu `Anticoag`, `Filter`, `PrismaLung`
- Expected result:
  - Hien `current_value_text` hoac short text thay vi so kho doc
  - Khong hien `undefined`

### `AN-TC-16` Zero-value collapse logic

- Priority: P1
- Steps:
  1. Chon treatment co group `anticoag` hoac `citrate_adv` toan 0
- Expected result:
  - Group duoc collapse theo thong diep "All values at zero"
  - Khong lam mat thong tin quan trong o cac group khac

### `AN-TC-17` SET change table chronology

- Priority: P1
- Steps:
  1. Kiem tra bang `SET Parameter Changes`
- Expected result:
  - Changes sap xep tang theo `elapsed_minutes`
  - Cot old/new dung logic
  - PID, unit, label khop parameter

### `AN-TC-18` Export SET params CSV

- Priority: P1
- Steps:
  1. Bam export CSV trong tab params
- Expected result:
  - CSV down duoc
  - Table data trong file khop voi man hinh

## 6.6. Pressure Tab

### `AN-TC-19` Pressure charts render by groups

- Priority: P0
- Steps:
  1. Mo tab `Pressures`
- Expected result:
  - Cac chart group render neu co data
  - Khong render chart rong vo nghia

### `AN-TC-20` Pressure legend toggle

- Priority: P1
- Steps:
  1. Click legend item tren chart
- Expected result:
  - Dataset an/hien dung
  - Khong lam vo chart khac

### `AN-TC-21` Pressure zoom/pan/reset

- Priority: P1
- Steps:
  1. Scroll zoom tren pressure chart
  2. Drag pan ngang
  3. Bam `Reset Zoom`
  4. Double-click chart
- Expected result:
  - Zoom/pan hoat dong
  - Reset dua chart ve khung ban dau
  - Khong co canvas desync

### `AN-TC-22` Alarm markers overlay

- Priority: P1
- Steps:
  1. Bat/tat nut `Alarms`
  2. Hover gan vi tri marker
- Expected result:
  - Marker bat/tat dung
  - Tooltip alarm marker hien noi dung gan dung timestamp
  - Khong che hoan toan pressure tooltip

### `AN-TC-23` Pressure chart/table mode switch

- Priority: P1
- Steps:
  1. Chuyen `Chart` -> `Table`
  2. Chuyen lai `Table` -> `Chart`
- Expected result:
  - UI switch mode ngay
  - Khong goi lai API
  - Export button chi hien o table mode

### `AN-TC-24` Pressure table content

- Priority: P1
- Steps:
  1. O table mode, kiem tra cot `RUN_TIME`, `PA`, `PV`, `PBE`, `PEff`, `TMP`, `ΔP`, `ARPS`
- Expected result:
  - Header dung ten va unit
  - Gia tri null hien `—`
  - Sticky header va scroll dung

### `AN-TC-25` Pressure CSV export

- Priority: P1
- Steps:
  1. Export pressure table CSV
- Expected result:
  - File tai ve thanh cong
  - Noi dung khop bang table hien tai

## 6.7. Scales Tab

### `AN-TC-26` Scales chart and IO table render

- Priority: P0
- Steps:
  1. Mo tab `Scales`
- Expected result:
  - Neu co data thi chart scale render
  - IO History table render
  - Cot scale va I/O co du gia tri/null marker ro rang

### `AN-TC-27` Scales empty state

- Priority: P1
- Steps:
  1. Chon treatment khong co scale data
- Expected result:
  - Hien `No scale data found in raw data`
  - Khong crash

### `AN-TC-28` Scales zoom and export

- Priority: P1
- Steps:
  1. Zoom chart scale
  2. Export scale CSV
- Expected result:
  - Zoom hoat dong
  - CSV tai ve va doc duoc

## 6.8. Pump Tab

### `AN-TC-29` Pump tab password prompt

- Priority: P0
- Steps:
  1. Click tab `Pumps` lan dau
- Expected result:
  - Hien prompt nhap password

### `AN-TC-30` Wrong pump password

- Priority: P1
- Steps:
  1. Nhap password sai
- Expected result:
  - Hien thong bao sai password
  - Van o tab hien tai, khong vao pump tab

### `AN-TC-31` Correct pump password

- Priority: P1
- Steps:
  1. Nhap `admin`
- Expected result:
  - Vao duoc pump tab
  - Khong hoi lai password trong cung session tab

### `AN-TC-32` Pump chart and table mode

- Priority: P1
- Steps:
  1. O pump tab, kiem tra chart
  2. Chuyen `Chart` -> `Table`
  3. Chuyen nguoc lai
- Expected result:
  - Chart hien du lieu pump neu co
  - Table mode hien lich su RPM
  - Export button chi hien o table mode

### `AN-TC-33` Pump empty state

- Priority: P1
- Steps:
  1. Chon treatment khong co pump data
- Expected result:
  - Hien `No pump data found in raw data`
  - Khong crash

## 6.9. Refresh and Cache

### `AN-TC-34` Refresh active treatment

- Priority: P0
- Steps:
  1. Chon treatment dang `IN_PROGRESS`
  2. Ghi nhan packets/time range
  3. Bam `Lam moi du lieu`
- Expected result:
  - Goi API voi `?refresh=1`
  - Cache treatment bi force-evict
  - Ket qua parse moi duoc dung lai
  - Neu raw thay doi, packets/time range cap nhat

### `AN-TC-35` Cached re-open without refresh

- Priority: P1
- Steps:
  1. Chon 1 treatment
  2. Quay ra chon treatment khac
  3. Chon lai treatment dau tien
- Expected result:
  - Khong co sai lech data
  - Neu file khong doi, ket qua co the den tu cache nhung UI van dung

### `AN-TC-36` Auto invalidate when file mtime changes

- Priority: P1
- Steps:
  1. Dung treatment dang chay
  2. Lam raw file thay doi mtime
  3. Refresh hoac reload phan tich
- Expected result:
  - Cache cu bi bo
  - Data parse moi duoc hien

## 6.10. Export, Read-Only, and Resilience

### `AN-TC-37` CSV filenames

- Priority: P1
- Steps:
  1. Export file o cac tab co ho tro
- Expected result:
  - Ten file dung prefix `patientId_deviceId`
  - Khong co ky tu loi he thong file

### `AN-TC-38` Read-only verification

- Priority: P0
- Steps:
  1. Ghi nhan timestamp/modification cua:
     - `treatment_records.db`
     - `prismaflex_reference.db`
     - raw file duoc analyze
  2. Mo Analyzer, refresh, export CSV, chuyen tab
  3. Kiem tra lai timestamps
- Expected result:
  - Analyzer khong thay doi DB/raw goc
  - Chi file CSV moi duoc tao o phia client/download

### `AN-TC-39` Missing reference DB

- Priority: P1
- Steps:
  1. Mo phong reference DB khong truy cap duoc
  2. Khoi dong lai Analyzer
- Expected result:
  - App van len duoc
  - Alarm co the hien ID/UNKNOWN thay vi title day du
  - Khong crash startup

### `AN-TC-40` Large raw file behavior

- Priority: P2
- Steps:
  1. Chon treatment raw lon
  2. Do thoi gian load danh sach
  3. Do thoi gian parse analysis
  4. Scroll va chuyen tab
- Expected result:
  - App khong treo vo han
  - Browser van tuong tac duoc
  - Neu cham, QA ghi lai thoi gian va symptom cu the

---

## 7. Release Blockers

Khong duoc sign-off neu gap bat ky muc nao sau day:

- `P0`: Analyzer khong khoi dong duoc
- `P0`: Chon treatment co raw ma analysis khong load duoc
- `P0`: Alarm/params/pressure/scales/pumps crash JS khi co du lieu hop le
- `P0`: Refresh khong re-parse du lieu treatment dang chay
- `P0`: Analyzer ghi/sua vao DB hoac raw data goc
- `P0`: Pump tab bo qua gate hoac vao sai trang thai nghiêm trọng

---

## 8. Known Risks / Residual Notes For QA Report

QA nen ghi rieng cac diem sau trong report neu xac nhan dung:

- Runtime port trong code la `5555`, nhung [INSTALL.md](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/tools/treatment_analyzer/INSTALL.md) van huong dan `5001`
- Analyzer hien doc metadata tu SQLite `treatment_records.db`, chua dong bo voi huong Postgres moi
- Password tab Pump la client-side prompt `admin`, khong phai access control backend
- Runtime UI hien chua su dung `duckdb_reader.py`; performance thuc te van phu thuoc parser trong [app.py](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/tools/treatment_analyzer/app.py)
- Startup dependency check dem raw files theo `.jsonl/.jsonl.gz`, trong khi detector file thuc te con co `.parquet`

---

## 9. Suggested QA Execution Order

Thu tu chay de tiet kiem thoi gian:

1. `AN-TC-01` -> `AN-TC-09`
2. `AN-TC-10` -> `AN-TC-18`
3. `AN-TC-19` -> `AN-TC-33`
4. `AN-TC-34` -> `AN-TC-40`

Neu can smoke nhanh truoc:

1. `AN-TC-01`
2. `AN-TC-04`
3. `AN-TC-07`
4. `AN-TC-10`
5. `AN-TC-14`
6. `AN-TC-19`
7. `AN-TC-26`
8. `AN-TC-29`
9. `AN-TC-34`
10. `AN-TC-38`

