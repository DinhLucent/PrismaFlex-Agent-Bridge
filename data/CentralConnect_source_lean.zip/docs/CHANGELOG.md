v3.4.2_UI_Refinement
- Implemented latest UI updates and visual refinements.
- Consolidated build system improvements from v3.4.1.
- Fixed `start_frontend.bat` to use production mode (`npm run start`) instead of `dev` mode.

v3.4.1_Clinical_Continuity_Fix
- Verified Session Continuity logic: Resumes treatments automatically upon restart.
- Fixed Build Failures: Restored root-level build system and PM2 configuration.
- Enhanced reliability: Confirmed data persistence during server outages.

v3.4.0_Clinical_Safety_Final
- Implemented Full Rejection Workflow (Doctor Notes -> Nurse View).
- Translation fixes for Clinical Treatment Columns.
- Integrated Clinical Safety Safeguards (Skill-based system protection).
- Finalized professional Clinical PDF Documentation (v3.3.0 Standard).
- Enhanced `apply_update.bat` with automatic clinical data backup.

v3.3.5_Visual_Refinement
- Premium Gradient Fading for Hemodynamic Charts (TMP & Delta P).
- Extended Danger Zone coverage with 10% soft-feathering.
- Scaled Y-axis headrooms for better critical threshold visibility.

v3.1.0_SignatureBrand_Release
- Integrated Clinical-Grade Signature Assets (Medical SVGs).
- Signature Visual ID: Rhythmic Heartbeat Pulse for running devices.
- Digital Identity: SIG_XXXX hex trace identification on cards.
- Refined Dashboard & Navigation iconography (Clinical-specific).
- Minimalist Header Radar with pure scanning animation.
