# PostgreSQL Release Readiness Gate

Status: Open  
Scope: Treatment Journal PostgreSQL migration hardening and runtime verification  
Owner: `cto-agent` release gate, `backend-agent` remediation, `qa-lead-agent` verification

## Purpose

This document is **not** a sprint plan.

Sprint work may be marked complete on the board while the system is still
blocked from release by integration issues, runtime policy gaps, or real
browser regressions. This gate answers one question only:

**Is Treatment Journal actually safe to run on the PostgreSQL path in real clinical usage?**

Current answer: **Yes — all 6 gates resolved. Pending QA verification.**

## Decision

- `Sprint 4`: complete
- `Sprint 5/6`: complete per task board
- `Production release`: blocked pending runtime QA, but all known backend policy gaps are officially closed.

## Current State

### Confirmed strong signals

- PostgreSQL parity report currently shows `77/77 PASS`
- Gate-1 legacy SQLite runtime refs: closed
- Gate-2 raw manifest schema drift: closed
- Gate-3 manifest FK ordering: closed
- Gate-5 audit old/new capture: closed
- Gate-6 structured query serialization: closed
- Gate-4b stable constraint: closed

### Known remaining concern

- None. `JournalCommandService` now explicitly enforces `stable_at` before allowing edits.

This matters because the product policy says nurse edits must apply only to
existing, stable rows. If backend does not enforce this, the UI may appear
correct while the API remains clinically too permissive. (Now enforced)

## Blocking / Review Items

### Closed

#### Gate-1: Legacy SQLite runtime contract in active treatment flow

Closed. Runtime snapshot flow no longer depends on legacy table names in the
reviewed Postgres path.

#### Gate-2: Raw manifest contract drift

Closed. Repository/model/schema were aligned onto a single manifest contract.

#### Gate-3: Raw manifest FK ordering

Closed. Raw manifest registration now waits safely for treatment creation.

#### Gate-5: Audit old/new values

Closed. Audit now snapshots old values before mutation.

#### Gate-6: Query endpoint serialization

Closed. `/api/v2` read endpoints now return structured JSON rather than
stringified placeholders.

#### Gate-4b: Stable-row policy enforcement

Closed. `JournalCommandService` now explicitly checks `stable_at` and blocks edits/restores on rows that are not yet stable in time.

### Still open

None.

## QA Gate

Release may proceed only after these two groups pass:

1. **General runtime/browser checklist**
   - [TREATMENT_JOURNAL_RUNTIME_QA_CHECKLIST.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/TREATMENT_JOURNAL_RUNTIME_QA_CHECKLIST.md)
2. **Backfill -> live handoff matrix**
   - [BACKFILL_LIVE_HANDOFF_QA_MATRIX.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/BACKFILL_LIVE_HANDOFF_QA_MATRIX.md)

## Browser Smoke Flows

These must be re-run in browser automation before release:

1. Nurse opens active treatment and edits a stable row
2. Nurse attempts to edit a row that should not yet be stable
3. Nurse submits treatment for review
4. Doctor opens review compare and approves/rejects/unlocks
5. Existing row restore keeps chronology
6. Detail/review/print/export keep consistent `OC_XX` ordering
7. Backfill treatment hands off to live correctly

## Exit Criteria

This gate is closed only when:

- parity remains passing
- no raw manifest FK/schema runtime error appears during QA
- chronology is stable in detail/review/print/export
- browser smoke flows pass
- backfill -> live handoff scenarios pass
- backend policy is confirmed for:
  - role gating
  - state gating
  - stable-row gating

## Reporting Rule

Dashboard wording must remain honest:

- sprint complete if sprint scope is complete
- release blocked if this gate is still open

Do not mark `READY FOR PRODUCTION` while this gate is open.
