# Schema Mapping Note: SQLite → PostgreSQL

> TASK-107 deliverable. Maps current SQLite tables to new PostgreSQL tables.
> Reference: BACKEND_POSTGRES_PHASE1_HANDOFF.md Section 4-5

## Table Mapping

| #   | SQLite Table                 | PostgreSQL Table            | Mapping Type           | Notes                                                                                               |
| --- | ---------------------------- | --------------------------- | ---------------------- | --------------------------------------------------------------------------------------------------- |
| 1   | `treatments`                 | `treatments`                | Direct                 | Added `version`, `fsm_state`, explicit outcome CHECK                                                |
| 2   | `treatment_phases`           | `treatment_phases`          | Direct                 | Added `created_at`, `updated_at`                                                                    |
| 3   | `treatment_status_log`       | `treatment_status_events`   | **Renamed**            | `timestamp` → `event_time`, added `event_code`                                                      |
| 4   | `treatment_hourly_snapshots` | `treatment_journal_rows`    | **Renamed + Extended** | Added `row_kind`, `stable_at`, `version`, `is_deleted`, `source`, soft-delete columns, `created_by` |
| 5   | `treatment_config`           | `treatment_config`          | Direct                 | Added JSONB `config_json` for forward compat                                                        |
| 6   | `treatment_notes`            | `treatment_notes`           | Direct                 | Added `author_role`                                                                                 |
| 7   | `snapshot_originals`         | `snapshot_originals`        | Direct                 | `snapshot_json` as JSONB                                                                            |
| 8   | _(embedded in treatments)_   | `treatment_review_state`    | **New**                | Extracted approval workflow into own table                                                          |
| 9   | `treatment_index`            | `treatment_list_projection` | **Renamed + Extended** | Added `approval_status`, `journal_row_count`, `note_count`                                          |
| 10  | `treatment_raw_packets`      | `raw_packet_manifest`       | **Metadata only**      | Per ADR-3: no row-by-row packet data in PG OLTP                                                     |

## Key Differences From SQLite

1. **UUID primary keys** on `treatments`, `treatment_phases`, `treatment_config` (was TEXT in SQLite)
2. **BIGSERIAL** for high-volume tables: journal_rows, status_events, notes, audit_log, originals, manifest
3. **TIMESTAMPTZ** everywhere (SQLite used TEXT/ISO strings)
4. **JSONB** for `snapshot_originals.snapshot_json`, `treatment_config.config_json`, audit `old_value`/`new_value`
5. **CHECK constraints** on `outcome`, `row_kind`, `source`, `approval_status`
6. **Partial index** on `treatment_journal_rows` for non-deleted rows
7. **FK CASCADE** on all child tables → treatments

## What Is NOT Migrated

- Raw packet bodies (stay in local chunked JSONL per ADR-3)
- No EAV or per-cell schema (ADR-2)
- No generic CRUD endpoints (ADR-6)
