# Backfill Input Order Contract

## Purpose

This document defines the ordering contract between the data source (Mirth / replay preprocessor) and the `HistoricalBackfillImporter`.

## Contract

For a given `treatment_id`, all packets fed to `importer.process_packet()` **MUST** arrive in **monotonic non-decreasing order by `packet_time`**.

```
packet_time[i] <= packet_time[i+1]   ∀ i
```

## Rationale

The importer uses `hour_num = floor((packet_time - treatment_start) / 3600)` to assign packets to hourly slots. Forward-only progression means:

- **H00** is frozen at first ~10 packets
- Hour transitions only fire when `hour_num > current_hour`
- Late packets (`hour_num < current_hour`) are absorbed into the current cache

If this contract is violated:

| Violation | Consequence |
|---|---|
| Mild jitter (±1 pkt) | Absorbed safely — values merge into current hour |
| Significant reorder (minutes) | OC detection may use wrong baseline; hourly values may be polluted |
| Large reorder (hours) | Late packets absorbed into wrong hour silently |

## Enforcement

The importer **detects** out-of-order packets and:

1. Logs a WARNING with treatment_id, expected vs actual time
2. Increments `out_of_order_count` per treatment
3. Does NOT reject the packet (absorbed into current hour)
4. At flush/close, logs total OOO count for diagnostics

## Source Responsibility

| Source | Requirement |
|---|---|
| **Mirth BACKFILL channel** | Sort by timestamp before sending to `/ingest/backfill` |
| **Replay preprocessor** | Pre-sort NDJSON by timestamp per device before feeding |
| **Backend** | Detect + warn, do not sort (memory-bounded) |

## QA Classification

When a QA test fails, classify the root cause:

| Category | Evidence |
|---|---|
| **Algorithm bug** | Sorted input still produces wrong output |
| **Data ordering bug** | OOO count > 0, sorted input produces correct output |
| **Raw lifecycle bug** | Snapshot correct but raw manifest/chunk is wrong |
