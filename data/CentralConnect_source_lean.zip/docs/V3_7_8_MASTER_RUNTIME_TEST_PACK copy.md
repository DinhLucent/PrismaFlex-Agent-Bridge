# v3.7.8 Master Runtime Test Pack

Updated: 2026-04-14

This document is the current QA source of truth for ICU-B Connect v3.7.8.

It is written for an agent or tester to execute directly without guessing
clinical intent from older documents.

It supersedes older continuity assumptions such as:

- `END` always forces a new treatment
- same device + same patient + `RUN_TIME > 0` only means continuity before `END`

For v3.7.8, the canonical runtime rule is:

- valid later start with `RUN_TIME = 0` means **new treatment**
- valid later start with same `device_id` + same `patient_id` + `RUN_TIME > 0`
  means **continue the same treatment**, even if an earlier `END` packet exists

This rule matches the actual PrismaFlex operator workflow when staff choose
`SAME PATIENT` on the machine after an `END`.

---

## 1. Purpose

This pack exists to validate all clinically important runtime layers together:

- LIVE ingest
- BACKFILL ingest
- Dashboard trend state
- Treatment identity / continuity
- Hourly snapshots (`H00`, `H01`, ...)
- Order-change snapshots (`OC_01`, `OC_02`, ...)
- Raw packet ownership
- Restart / reconnect / outage handling
- Multi-device isolation
- Update and rollout readiness

The main objective is not only to make the UI look right. It is to ensure:

- treatment identity is correct
- snapshots are chronologically coherent
- raw data stays attached to the correct treatment
- dashboard patient boundaries are clean

If only the UI looks correct but SQL/raw identity is wrong, the system still
fails QA.

---

## 2. How OPUS Should Use This Document

OPUS should follow this exact order:

1. Use this file as the primary rule set.
2. Do not reuse older continuity expectations unless explicitly told to compare.
3. Run the smoke test pack first.
4. Validate the gold datasets first:
   - `TRAN VAN VU`
   - `g12 recent`
5. Then run the broader scenario matrix.
6. For every fail, capture:
   - screenshot
   - SQL
   - log excerpt
   - suspected module
7. Mark the case `FAIL` if any one of these layers disagrees:
   - UI
   - SQL
   - raw ownership
   - backend logs

---

## 3. Operational Truth

This section describes the real-world PrismaFlex behavior the code must follow.

### 3.1 End-to-end data flow

Actual path:

- PrismaFlex machine
- Receiver service
- Decode service
- Mirth transform
- App backend
- Postgres projections / raw store / frontend

LIVE cadence is normally around 10 seconds per packet.

BACKFILL may arrive much faster and may carry extra Mirth metadata, but the
same clinical identity rules must still hold.

### 3.2 Physical operator workflows

#### Workflow A - True new treatment

- previous treatment is clinically done
- machine may idle
- filter may be changed
- patient may be same or different
- later valid start has `RUN_TIME = 0`

Expected:

- new treatment

#### Workflow B - Same patient continuation after END

- treatment receives `END`
- operator keeps same patient
- machine may idle / prime briefly
- later valid start has same patient and `RUN_TIME > 0`

Expected:

- same treatment

#### Workflow C - Disconnect / reconnect

- no true treatment end
- packets disappear temporarily
- later packets return with same patient and same device
- `RUN_TIME > 0`

Expected:

- same treatment

#### Workflow D - Machine powered but not clinically started

- packets may still appear
- `RUN_TIME = 0`
- status is not a valid start status

Expected:

- no treatment opens

---

## 4. Canonical Runtime Rules

### 4.1 Device identity

Canonical App-layer device IDs should look like:

- `PF_003`
- `PF_004`
- `PF_007`

QA must treat `4` and `PF_004` for the same stream as a normalization bug or
data hygiene issue.

Expected:

- one physical device maps to one logical device ID at the App layer

Hard fail:

- same clinical stream duplicated only because one path used numeric device ID
  and another path used normalized `PF_xxx`

### 4.2 Start gate

A treatment may open only when all of these are true:

- valid `patient_id`
- `therapy_status_id` is a start status

Current important start statuses:

- `4 = WAITINGSTART`
- `5 = RUN`

### 4.3 Continuation rule

If all of these are true:

- same `device_id`
- same `patient_id`
- packet satisfies start gate
- `RUN_TIME > 0`

then the system should continue the same treatment.

This remains true even if an earlier `END` packet exists.

### 4.4 Fresh start rule

If all of these are true:

- same `device_id`
- same `patient_id`
- packet satisfies start gate
- `RUN_TIME = 0`

then the system should create a new treatment.

This is the strongest new-treatment signal.

### 4.5 Idle safety rule

`RUN_TIME = 0` alone must never create a treatment unless the start gate is
also satisfied.

This prevents infinite fake treatments while the machine is:

- powered on
- idle
- priming
- sitting after a previous END

### 4.6 Device isolation rule

Continuity is always device-scoped:

- same patient on a different device is a different treatment
- no cross-device resume

### 4.7 Secondary continuity hints

These hints can support continuity but must not override the main rule:

- `UF_TOTAL`
- stable patient ID
- same device
- continuous packet time
- continuous machine counters

Expected use:

- help confirm continuity when `RUN_TIME` is sparse or absent temporarily
- never override a valid later start with `RUN_TIME = 0`

### 4.8 Therapy status interpretation

For this QA pack, treat these statuses as clinically meaningful:

- `0`: idle / non-start / not enough by itself
- `4`: `WAITINGSTART`
- `5`: `RUN`
- `8`: `END`

Meaning in v3.7.8:

- `END` closes the current writable segment
- `END` alone does not force the next valid later run into a new treatment
- later valid start with `RUN_TIME > 0` can continue same treatment
- later valid start with `RUN_TIME = 0` must start a new treatment

If OPUS sees another repeated status pattern in raw that looks important, it
should document it as an observation, not silently change the acceptance rule.

---

## 5. Dashboard Rules

Dashboard trend state is per device.

For detail-chart history, backend `pressure_trends` is the canonical source.
The detail page should hydrate from backend history on open, then append live
points afterward.

### 5.1 Clear rule

Dashboard trend data should clear when:

- `patient_id` changes on that device

Dashboard should not clear only because:

- `END` is seen
- the device detail drawer is closed
- packets are delayed
- device is temporarily idle

### 5.2 Trend persistence rule

Expected:

- backend keeps writing trend rows while detail is closed
- reopening detail later shows the retained interval from backend
- browser refresh / reopen does not lose retained trend history
- frontend localStorage is not required for chart recovery

Hard fail:

- chart starts only from the moment detail is opened
- trend recovery depends on a browser-side `history_${device}` cache

### 5.3 Retention rule

Trend storage is capped.

Expected:

- newest points retained
- old points trimmed
- no unbounded memory growth
- no ordering corruption after trimming

### 5.4 Pressure chart rendering safety rule

For TMP / DeltaP charts, verify:

- short-window view remains usable for realtime inspection
- full-history view is available when the feature is in scope
- impossible outliers do not destroy chart scaling
- threshold/reference lines do not flatten the actual clinical line

Expected handling of impossible TMP / DeltaP values:

- reject, sanitize, or render as a gap
- keep neighboring valid points readable
- do not let a single impossible sample dominate smoothing or axis domain

Hard fail:

- one impossible point makes the chart unreadable
- threshold scaling hides the real line variation

### 5.5 Dashboard oracle

For each dashboard testcase, verify all:

- backend trend rows keep accumulating while detail is closed
- opening detail later hydrates already-retained points from backend
- patient change clears prior patient history
- no mixed points across patients
- no mixed points across devices
- cap is enforced without broken chronology
- TMP / DeltaP charts stay readable under thresholds and outliers

Hard fail:

- first packets of new patient append into previous patient's cache
- dashboard updates only while detail drawer is open
- impossible TMP / DeltaP values destroy the chart for the whole window

---

## 6. Snapshot Rules

### 6.1 H00

`H00` must freeze from the first valid packet of the treatment.

It must not:

- wait until the end of the first hour
- stretch over the whole first hour
- drift to server wall clock

### 6.2 H01 / H02 / H03 ...

Each hourly snapshot freezes once per hour slot.

Current runtime behavior:

- `H01` uses the first packet that lands in slot 1
- `H02` uses the first packet that lands in slot 2
- and so on

Therefore the labels are slot-correct, but `snapshot_time` may be a few seconds
after the exact anchor.

Example:

- `H00 = 11:01:09`
- `H01 = 12:01:22`
- `H02 = 13:01:21`

This is currently acceptable as long as:

- labels are monotonic
- no label is duplicated on the same treatment
- row freezes once and stays frozen

### 6.3 GAP behavior

If an entire hour slot has no packet:

- backend must not create a fake `Hxx`
- frontend may render a GAP virtually

### 6.4 Hourly snapshot oracle

For every treatment, verify:

- `H00` exists exactly once
- `H00` comes from first valid packet
- `H01+` labels are monotonic
- `snapshot_time` values are monotonic
- no duplicate `Hxx`
- no backward labels
- no frozen row later mutates
- no `H00` restart unless there is a true new treatment

Hard fail:

- `H00` appears roughly 1 hour late
- `H01` keeps changing inside slot 1
- backend fabricates missing hours

### 6.5 OC snapshots

OC rows must:

- appear only on real order changes
- use post-change values
- contain a populated `reason`
- be chronologically interleaved between hourly rows
- avoid stale pre-change values

Expected examples:

- `qd:1000->800`
- `qb:160->150`

### 6.6 OC oracle

For each treatment with real order changes, verify:

- `OC_01` appears only after first real change
- each OC has a non-empty `reason`
- row values match the changed state
- repeated stable packets do not create extra OCs
- short flicker/revert behavior does not create OC storms
- OC order matches clinical order

Hard fail:

- `reason` says value changed but row still shows old value
- OC row lands after the wrong hourly boundary

---

## 7. Raw Recording Rules

Raw ownership must follow treatment continuity.

### 7.1 Same treatment

If the scenario says continuity is preserved:

- raw packets must stay under one `treatment_id`
- chunk rotation is allowed
- clinical identity split is not allowed

### 7.2 True new treatment

If the scenario says a new treatment begins:

- old raw stream must close once
- new raw stream must start once
- new treatment gets new raw ownership

### 7.3 Idle-after-END

For the current direction, idle packets outside the clinically meaningful run
do not need to be preserved as raw.

Therefore:

- post-END idle packets may be excluded
- later same-patient continuation with `RUN_TIME > 0` must still map back to
  the same treatment if the rule says it is a continuation

### 7.4 Raw oracle

For every continuity testcase, verify:

- packet count is plausible for the run window
- only one treatment owns the raw stream when continuity is preserved
- chunk rotation stays under the same treatment
- final chunk state is correct after close
- no orphan active chunk remains after restart

Hard fail:

- UI looks continuous but raw switched to another `treatment_id`

---

## 8. LIVE vs BACKFILL

### 8.1 Shared rules

These must match in both LIVE and BACKFILL:

- treatment identity rules
- raw ownership rules
- `H00/Hxx` freeze rules
- OC post-change value rules
- no fake GAP-fill rows

### 8.2 Differences

LIVE:

- near-real-time
- usually one packet every 10 seconds
- may involve reconnects, backend restarts, temporary outages

BACKFILL:

- high-speed replay
- historical timestamps must drive chronology
- no use of real wall clock to infer treatment order
- deterministic replay expected

### 8.3 Mirth transform considerations

Mirth may decorate LIVE and BACKFILL packets differently.

QA should focus on the clinically meaningful fields:

- device identity
- patient identity
- therapy status
- packet timestamp
- `timestamp_unix` when available
- `RUN_TIME`

Expected:

- wrapper metadata may differ
- treatment identity and chronology must still converge to the same result

---

## 9. Evidence Required For Every Failure

For every failed case, capture:

- `device_id`
- `patient_id`
- `treatment_id`
- packet time window
- source: `LIVE` or `BACKFILL`
- UI screenshot
- SQL output
- relevant backend log excerpt
- short note explaining why the result is clinically wrong

---

## 10. Core SQL Queries

### 10.1 Treatments

```sql
SELECT id, device_id, patient_id, start_time, end_time, outcome, close_reason,
       total_packets, last_packet_time, last_run_time_sec, continuity_source
FROM treatments
ORDER BY start_time DESC;
```

### 10.2 Journal rows

```sql
SELECT treatment_id, row_code, row_kind, hour_slot, snapshot_time, source, reason
FROM treatment_journal_rows
WHERE treatment_id = '<treatment_id>'
ORDER BY snapshot_time, row_code;
```

### 10.3 Journal values

```sql
SELECT treatment_id, row_code, snapshot_time, reason,
       qb_ml_min, qd_ml_h, qs_ml_h, qpbp_ml_h, uf_total_ml, uf_hourly_ml_h
FROM treatment_journal_rows
WHERE treatment_id = '<treatment_id>'
ORDER BY snapshot_time, row_code;
```

### 10.4 Duplicate hourly rows

```sql
SELECT treatment_id, row_code, count(*)
FROM treatment_journal_rows
WHERE row_kind = 'H'
GROUP BY treatment_id, row_code
HAVING count(*) > 1;
```

### 10.5 Raw manifest

```sql
SELECT treatment_id, chunk_index, status, first_timestamp, last_timestamp, packet_count, size_bytes
FROM raw_packet_manifest
WHERE treatment_id = '<treatment_id>'
ORDER BY chunk_index;
```

### 10.6 Device state

```sql
SELECT *
FROM device_state
WHERE device_id = '<device_id>';
```

### 10.7 Projection checkpoint

```sql
SELECT *
FROM treatment_projection_checkpoint
WHERE treatment_id = '<treatment_id>';
```

### 10.8 Projection identity view

```sql
SELECT patient_id, device_id, start_time, end_time, outcome, close_reason, id
FROM treatment_list_projection
ORDER BY start_time DESC;
```

---

## 11. Update Checklist

### 11.1 Before update

- confirm target root is the real app root
- confirm `backend\main.py` exists there
- backup database if needed
- stop `icub-backend`
- confirm no active backfill is still writing

### 11.2 Update

- overwrite backend files from lean package
- run `python -m pip install -r requirements.txt` in `backend`
- restart `icub-backend`

### 11.3 Post-update smoke

- backend API responds
- dashboard opens
- treatment journal opens
- old data still loads
- no new backend exception appears when packets arrive

### 11.4 Immediate rollback triggers

Pause rollout immediately if any of these happen:

- backend startup crash
- dashboard fails to load
- journal fails to load
- same live treatment suddenly gets a new UUID
- raw manifest begins switching treatment IDs unexpectedly
- snapshots duplicate `H00` or `H01`

---

## 12. Smoke Test Pack

### ST-01 Backend startup

Expected:

- no import error
- no schema error
- no raw-stream wiring error

### ST-02 API health

Expected:

- `GET /api/v1/treatments/pending-count` returns
- `GET /api/v1/devices/mode` returns

### ST-03 Dashboard load

Expected:

- dashboard list renders
- opening a device detail does not crash

### ST-04 Treatment Journal load

Expected:

- journal list renders
- expanding a treatment works
- historical rows still readable

---

## 13. Detailed Test Matrix

## Group A - LIVE Treatment Identity

### TC-L01 Fresh start by WAITINGSTART

Setup:

- no active treatment
- valid patient
- first valid packet has `status=4`
- `RUN_TIME=0`

Expected:

- one new treatment opens
- `H00` created
- raw starts
- one active `device_state`

Hard fail:

- no treatment opens
- more than one treatment opens

Likely modules:

- `treatment_recorder.py`
- `raw_streamer.py`

### TC-L02 Fresh start by RUN

Setup:

- no active treatment
- valid patient
- first valid packet has `status=5`
- `RUN_TIME=0`

Expected:

- one new treatment opens
- `H00` created
- raw starts

Hard fail:

- RUN packet is ignored even though it passes start gate

### TC-L03 Same treatment steady run

Setup:

- active treatment exists
- same patient
- same device
- packets keep arriving

Expected:

- one treatment only
- no UUID change
- raw stays on same treatment
- hourly rows belong to same treatment

### TC-L04 Disconnect / reconnect without END

Setup:

- active treatment exists
- same patient
- same device
- no packets for a while
- later reconnect packet has `RUN_TIME > 0`

Expected:

- same treatment continues
- no raw split
- no `H00` restart
- missing hours remain missing if no packets existed

Hard fail:

- treatment UUID changes
- raw changes owner
- `H00` restarts

### TC-L05 END then same patient with continuing counters

Setup:

- treatment receives `END`
- later same patient same device satisfies start gate
- `RUN_TIME > 0`

Expected:

- same treatment continues
- raw continues under same treatment
- hourly and OC labels continue under same treatment

This is the critical v3.7.8 continuity rule.

Detailed checks:

- treatment analyzer should show one clinical treatment stream
- no second treatment row should appear only because of END

### TC-L06 END then same patient fresh start

Setup:

- treatment receives `END`
- later same patient same device satisfies start gate
- `RUN_TIME = 0`

Expected:

- new treatment opens
- old raw closes
- new raw starts
- `H00` resets for new treatment

Detailed SQL check:

- two treatment rows must exist
- later row must start at the fresh start packet

### TC-L07 END then idle only

Setup:

- treatment receives `END`
- later packets are idle or non-start
- `RUN_TIME = 0`

Expected:

- no new treatment opens
- no fake raw stream opens

Hard fail:

- idle packets create a new treatment row

### TC-L08 Patient change on same device

Setup:

- active treatment exists
- patient changes on same device

Expected:

- old treatment closes
- new treatment opens only if packet also passes start gate
- dashboard clears for new patient

Hard fail:

- patient changes but old trend data remains mixed into new patient dashboard

### TC-L09 Same patient on another device

Setup:

- patient X is active on device A
- same patient X later appears on device B

Expected:

- no cross-device reuse
- separate treatments
- separate raw ownership

Hard fail:

- any shared `treatment_id` across different devices

### TC-L10 Backend restart during active treatment

Setup:

- active live treatment exists
- backend is restarted
- packets resume with same patient same device

Expected:

- same treatment continues
- no duplicate active sessions
- raw still belongs to same treatment

### TC-L11 Backend restart after END then continuation

Setup:

- treatment received `END`
- backend restarted
- later same patient same device starts with `RUN_TIME > 0`

Expected:

- same treatment continues under v3.7.8 rule
- restart must not turn this into a false new treatment

### TC-L12 RUN_TIME zero noise without start status

Setup:

- device emits packets with `RUN_TIME = 0`
- status is not `4` or `5`

Expected:

- no treatment opens

Hard fail:

- idle noise creates fake treatment rows

## Group B - Dashboard

### TC-D01 Trend updates while detail is closed

Expected:

- trend keeps accumulating
- opening detail later shows already accumulated data

### TC-D02 Patient change clears trend

Expected:

- old patient points removed
- new patient starts from clean state
- no mixed points

Hard fail:

- first packets of new patient append to old patient's trend cache

### TC-D03 Device isolation

Expected:

- device A trends never appear under device B

### TC-D04 Retention cap

Expected:

- total points capped
- newest points retained
- no broken ordering after trim
- no UI freeze

## Group C - Hourly Snapshots

### TC-S01 H00 baseline

Expected:

- `H00` comes from first valid packet
- not from end of first hour
- frozen once

Hard fail:

- `H00` appears about one hour late
- `H00` keeps drifting with incoming first-hour packets

### TC-S02 H01/H02/H03 freeze cadence

Expected:

- one `Hxx` per hour slot
- labels monotonic
- no duplicate `H01`
- no backward labels
- row remains frozen after creation

### TC-S03 Missing hour

Expected:

- no fabricated `Hxx`
- frontend may show GAP

### TC-S04 Continuation across END

Setup:

- same treatment continues because later valid start has `RUN_TIME > 0`

Expected:

- hourly labels continue on same treatment
- no reset to `H00`

### TC-S05 Out-of-order stress check

Setup:

- replay a dataset known to contain slightly out-of-order packets

Expected:

- no duplicate hourly labels on one treatment
- no backward chronology in saved rows

## Group D - OC Snapshots

### TC-O01 Single QD change

Expected:

- one `OC_XX`
- `reason` like `qd:1000->800`
- row values show the new QD

Hard fail:

- reason says QD changed but row still shows old QD

### TC-O02 Multiple changes in short window

Expected:

- grouped or merged according to OC policy
- no stale values
- no OC storm on flicker

### TC-O03 OC between hourly rows

Expected:

- OC timestamp sits between the correct neighboring `Hxx`

Hard fail:

- OC lands after the wrong next hour row

### TC-O04 Stable values do not generate OCs

Expected:

- repeated stable packets create no extra OC rows

## Group E - BACKFILL

### TC-B01 Golden replay for g12 recent

Expected:

- one treatment
- stable chronology
- monotonic `H00/H01/H02`
- correct OC reasons
- no fake GAP rows

### TC-B02 Golden replay for TRAN VAN VU

Expected:

- one treatment under v3.7.8 rule
- raw stays attached to one treatment
- snapshots remain in one treatment
- OC rows remain in one treatment

This is the key regression test for the new continuity rule.

### TC-B03 Replay determinism

Steps:

- replay the same dataset twice into clean databases

Expected:

- same number of treatments
- same number of journal rows
- same raw/treatment identity result

### TC-B04 Backfill restart mid-run

Expected:

- no duplicate hourly rows
- no duplicate OC rows
- checkpoint advances correctly

### TC-B05 BACKFILL vs LIVE identity parity

Setup:

- use equivalent packet content through both paths if possible

Expected:

- same treatment identity outcome
- same snapshot identity outcome

## Group F - Raw Data

### TC-R01 Continuity without split

Expected:

- continuity means one raw treatment owner
- chunk rotation allowed
- no UUID switch

Analyzer check:

- analyzer must not show two treatments when the rule says one

### TC-R02 True new treatment split

Expected:

- old raw closes once
- new raw opens once

### TC-R03 Post-END idle exclusion

Expected:

- idle packets after END may be excluded
- later same-patient continuation with `RUN_TIME > 0` still resumes same treatment

### TC-R04 Restart does not orphan active chunk

Expected:

- after backend restart, raw owner resumes correctly
- no orphan chunk remains marked active forever

## Group G - Failure / Recovery

### TC-X01 High queue / delayed processing

Expected:

- queue delay alone does not corrupt treatment identity
- chronology still follows packet timestamps

### TC-X02 Backend restart after backfill

Expected:

- no stale BACKFILL mode blocks LIVE incorrectly
- no old backfill session bleeds into live continuity

### TC-X03 Multi-device concurrency

Setup:

- at least devices `PF_003`, `PF_004`, `PF_007`
- overlapping time windows
- different patients

Expected:

- device states remain isolated
- one device does not block or rewrite another

Hard fail:

- one device's BACKFILL mode blocks another device's LIVE path

### TC-X04 Mixed source timing

Setup:

- one device in LIVE
- another device replaying BACKFILL

Expected:

- modes stay isolated per device
- journal rows stay attached to the correct device and treatment

## Group H - Exact case studies

### TC-GOLD-01 TRAN VAN VU continuity

Question:

- is this one treatment or multiple?

Expected under v3.7.8:

- one treatment

Why:

- same device
- same patient
- later valid starts continue with `RUN_TIME > 0`
- counters such as `UF_TOTAL` and later visible `RUN_TIME` continue

Required checks:

- treatment count
- raw ownership
- `Hxx` continuity
- `OC_XX` continuity
- analyzer view

### TC-GOLD-02 g12 recent chronology

Question:

- are snapshots and OC rows clinically ordered?

Expected:

- one treatment
- monotonic `Hxx`
- OC interleaved correctly
- no fake GAP fill

Required checks:

- treatment row
- journal row ordering
- raw ownership
- UI screenshot

---

## 14. Recommended Execution Order

OPUS should run in this order:

1. ST-01 to ST-04
2. TC-L01, TC-L02, TC-L12
3. TC-D01 to TC-D04
4. TC-S01 to TC-S05
5. TC-O01 to TC-O04
6. TC-R01 to TC-R04
7. TC-X01 to TC-X04
8. TC-B01, TC-B02
9. TC-B03 to TC-B05
10. TC-GOLD-01 and TC-GOLD-02 for final signoff

Reason:

- start simple
- validate runtime gates first
- validate patient/device separation next
- validate snapshots and OC chronology next
- validate raw ownership before final replay signoff

---

## 15. Gold Datasets For Focused Validation

Prioritize these first:

- `TRAN VAN VU`
- `g12 recent`

Reason:

- they reflect the most recent operational truth
- they are more valuable than older noisy historical datasets captured during
  unstable fix periods

Older datasets can still be used for regression stress, but not as the primary
acceptance oracle.

---

## 16. Pass / Fail Rules

A testcase is `PASS` only if all of these are true:

- UI result is correct
- SQL result is correct
- backend logs do not contradict the result
- raw ownership matches treatment continuity

If UI looks correct but SQL/raw is wrong, the case is still `FAIL`.

If SQL looks correct but raw ownership split is wrong, the case is still `FAIL`.

If raw and SQL look correct but dashboard crosses patient boundaries, the case
is still `FAIL`.

OPUS should not use `PASS with caveat` unless the caveat is explicitly
non-blocking and does not affect:

- treatment identity
- raw ownership
- snapshot chronology
- dashboard patient isolation

---

## 17. Bug Report Template

Use this template for every failure.

### Header

- Case ID:
- Date/time:
- Environment:
- Source: `LIVE` or `BACKFILL`
- Backend build:

### Context

- Device ID:
- Patient ID:
- Treatment ID(s):
- Packet window:

### Expected

- short paragraph

### Actual

- short paragraph

### Evidence

- UI screenshot:
- SQL output:
- backend log excerpt:

### Suspected module

- `treatment_recorder.py`
- `treatment_snapshot_service.py`
- `historical_backfill_importer.py`
- `raw_streamer.py`
- `main.py`
- frontend dashboard / timeline

### Root cause guess

Use one when possible:

- lifecycle boundary logic
- snapshot slot freeze logic
- OC stale-value capture
- raw close/open routing
- device normalization
- restart recovery
- backfill chronology
- frontend patient-cache clear

### Severity

- `P0` data corruption / wrong treatment identity / raw split
- `P1` wrong chronology / wrong Hxx / wrong OC
- `P2` restart-recovery / checkpoint / stale mode issue
- `P3` display only

---

## 18. Current Known Tradeoff

Current hourly rows are slot-correct, but `snapshot_time` is the actual first
packet time inside that slot, not a synthesized exact anchor like `start + 1h`.

Example:

- if `H00 = 11:01:09`
- then `H01` may be `12:01:22`

QA should not fail a run only because `H01` is slightly later than the exact
hour anchor, unless the business rule later changes to require storing exact
anchor timestamps in the row itself.

QA should fail only if:

- hourly labels duplicate
- hourly labels go backward
- row mutates after freeze
- a missing hour is fabricated

---

## 19. Signoff Criteria For v3.7.8

v3.7.8 is rollout-ready only if all of these are true:

- smoke tests pass
- `TRAN VAN VU` validates as one treatment
- `g12 recent` validates as one treatment with coherent hourly and OC chronology
- dashboard patient-change clearing works
- same-patient continuation does not split raw
- `RUN_TIME = 0` idle noise does not create fake treatments
- same patient on another device does not merge
- at least 2 to 3 concurrent devices remain isolated

If any one of these fails, rollout should pause until the failure is explained
and triaged.

---

## Appendix A - Data Structure Primer For OPUS

OPUS must understand the packet structure before testing continuity, snapshots,
or raw ownership.

Do not guess field names or PID meaning from screenshots alone.

### A.1 Source packet shape before Mirth

Decoded PrismaFlex packets generally look like this before Mirth normalization:

```json
{
  "packet_num": 5736,
  "timestamp": "2026-03-24T04:24:15.082345",
  "packet_length": 2188,
  "s_header": {
    "machine_id": 4,
    "patient_id": "g21",
    "therapy_type_id": 3,
    "therapy_status_id": 5,
    "timestamp": "2026-03-24 18:21:05 UTC",
    "timestamp_unix": 1774376465
  },
  "s_body": {
    "total_records": 172,
    "parameters": [
      { "type": "Actual", "id": 1, "value": -88, "record_time": 1774376465 },
      { "type": "Set", "id": 21, "value": 1000, "record_time": 1774376465 }
    ]
  }
}
```

Key points:

- clinical identity is not stored as ready-made `qb`, `qd`, `uf_total`, etc.
- journal values are derived from `s_body.parameters[]`
- `therapy_status_id` lives in `s_header`
- `patient_id` lives in `s_header`
- `machine_id` lives in `s_header`
- packet timestamps may exist both as string and unix epoch

### A.2 Mirth-normalized packet shape at App ingress

After Mirth, the backend may receive a normalized wrapper like:

```json
{
  "meta": {
    "device_id": "PF_004",
    "timestamp": "2026-03-24 18:21:05 UTC",
    "timestamp_unix": 1774376465,
    "mode": "LIVE",
    "transform_version": "mirth_backfill_v1",
    "ingest_profile": "realtime",
    "timestamp_source": "s_header.timestamp",
    "replay_source": "mirth_channel_reader"
  },
  "header": { ...copy of s_header... },
  "body": { ...copy of s_body... }
}
```

Important:

- LIVE and BACKFILL wrappers may differ
- the clinically important information must still survive:
  - device identity
  - patient identity
  - therapy status
  - packet time
  - `RUN_TIME`

### A.3 Canonical ingest contract

The runtime normalization layer is implemented in:

- [telemetry_contract.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\services\telemetry_contract.py)

Key rules OPUS must remember:

- `meta.timestamp_unix` has highest timestamp priority when present
- device IDs are normalized to `PF_xxx`
- packet times are interpreted as clinical GMT+7 times
- wrapper differences should not change treatment identity outcome

### A.4 Packet-to-column mapping

The journal does not read ready-made UI columns directly.

It maps PID values from `s_body.parameters[]`.

Reference:

- [TREATMENT_JOURNAL_PACKET_TO_PID_MAPPING.md](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\docs\TREATMENT_JOURNAL_PACKET_TO_PID_MAPPING.md)

Critical PIDs for runtime QA:

- `17` -> `qb`
- `18` -> `qs_pre`
- `19` -> `qs_post`
- `21` -> `qd`
- `22` -> `qpbp`
- `23` -> `effluent_flow`
- `24` -> `uf_hourly`
- `25` -> `uf_rate_target`
- `38` -> `heparin_rate`
- `60` -> `blood_vol`
- `100` -> `uf_total`
- `409` -> `anticoag_type_id`
- `461` -> `run_time_sec`

Important:

- `RUN_TIME` is PID `461`
- `UF_TOTAL` is PID `100`
- `qs` is derived from `qs_pre + qs_post`
- the journal currently maps by `id` and `value`, not by `record_num`
- repeated same PID entries in one packet may overwrite earlier values

### A.5 Fields OPUS must extract first in any replay

Before deciding pass/fail, OPUS should extract at least:

- `device_id` or `machine_id`
- `patient_id`
- `therapy_status_id`
- authoritative packet timestamp
- `RUN_TIME` from PID `461`
- `UF_TOTAL` from PID `100`
- order-related PIDs:
  - `17`
  - `18`
  - `19`
  - `21`
  - `22`
  - `25`

If OPUS does not verify these first, it risks drawing the wrong conclusion
about treatment boundaries.

### A.6 Common structure mistakes OPUS must avoid

Do not:

- assume `packet.timestamp` is always authoritative
- assume string time labeled `UTC` is true UTC
- assume `END` alone means new treatment in v3.7.8
- assume `RUN_TIME` is a top-level field
- assume LIVE and BACKFILL wrapper shape are byte-for-byte identical
- assume UI columns are present directly in raw packet JSON

---

## Appendix B - Sample Data Sources For OPUS

OPUS should use real raw data before synthetic simulation whenever possible.

### B.1 Highest-priority gold datasets

Use these first:

- `TRAN VAN VU`
- `g12 recent`

Reason:

- they are the most recent and clinically relevant validation targets for the
  current continuity rule

### B.2 Local repo sample raw files

Available in this repo at:

- [backend\data\treatments\raw](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\data\treatments\raw)

Known useful local file:

- [treatment_359730fc-68ed-4d2d-9f18-3dbe8fc259d2.raw.jsonl.gz](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\data\treatments\raw\treatment_359730fc-68ed-4d2d-9f18-3dbe8fc259d2.raw.jsonl.gz)

This file was used for the recent `g12` continuity replay.

### B.3 Local sandbox reports

Validated replay outputs already available in:

- [backend\tools\_sandbox_reports](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports)

Important files:

- [TRAN_VAN_VU_continuity_report.json](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports\TRAN_VAN_VU_continuity_report.json)
- [g12_recent_continuity_report.json](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports\g12_recent_continuity_report.json)
- [lifecycle_sandbox_report.txt](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports\lifecycle_sandbox_report.txt)

These are not raw data sources, but they are baseline expected results for
comparison.

### B.4 Recommended replay tools

OPUS should prefer these tools:

- [check_treatment_continuity.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\check_treatment_continuity.py)
- [lifecycle_sandbox.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\lifecycle_sandbox.py)
- [replay_raw.py](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\replay_raw.py)

Recommended order:

1. replay real raw bundles with `check_treatment_continuity.py`
2. run `lifecycle_sandbox.py` for synthetic edge cases
3. use `replay_raw.py` only when deeper historical replay is needed

### B.5 External sample sources mentioned by the user

If OPUS is working on the operator machine or on the copied customer dataset,
these user-provided paths are also valid data sources:

- `D:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\backend\tools\done`
- `D:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\backend\tools\_exports`
- `D:\Block\DecodedData\backup\May3`
- `D:\Block\DecodedData\backup\May4`
- exported patient bundles created from:
  - `export_latest_raw_for_analysis.py`
  - `export_patient_raw_bundle.py`

OPUS should prefer exported patient bundles over broad mixed folders when
investigating one continuity bug, because they reduce device/patient noise.

### B.6 Exact data-source strategy for this release

Use this order:

1. `TRAN VAN VU` exported raw bundle
2. `g12 recent` raw file or exported bundle
3. local raw files under `backend\data\treatments\raw`
4. user-supplied decoded backfill folders (`May3`, `May4`) for stress and
   replay parity
5. synthetic sandbox scenarios only after real-data checks pass

### B.7 What OPUS should report with each dataset

For each dataset it uses, OPUS should explicitly state:

- exact source path
- source type:
  - raw file
  - exported bundle
  - decoded folder
  - synthetic sandbox
- replay mode used:
  - `LIVE`
  - `BACKFILL`
- whether the result is treated as:
  - acceptance oracle
  - regression stress
  - exploratory only

---

## Appendix C - Known `therapy_status_id` Map For QA

This is the current working status map derived from project documentation and
runtime assumptions.

Known statuses:

- `0` = `IDLE`
- `4` = `WAITINGSTART`
- `5` = `RUN`
- `6` = `PAUSED`
- `7` = `STOPPED`
- `8` = `END`
- `9` = `ALARM`

QA meaning for v3.7.8:

- `4` and `5` are valid start-gate statuses
- `0` alone must not open a treatment
- `8` closes the current writable segment but is not a guaranteed fresh-start
  boundary
- `6` and `7` should not by themselves create a new treatment
- `9` should be treated as an alarm state, not an identity split signal by
  itself

Important note for OPUS:

- only `0`, `4`, `5`, and `8` are central to current acceptance logic
- if `6`, `7`, or `9` show up in a case, they should be logged and observed, but
  they should not silently override the continuity rules in this document

---

## Appendix D - Exact Replay Commands For OPUS

These are the preferred commands for reproducible verification in this repo.

Run them from:

- [backend](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend)

### D.1 Lifecycle sandbox

```bat
cd /d C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend
python -m tools.lifecycle_sandbox
```

Expected artifact:

- [lifecycle_sandbox_report.txt](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports\lifecycle_sandbox_report.txt)

### D.2 Replay `g12 recent`

```bat
cd /d C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend
python -m tools.check_treatment_continuity --name g12_recent --mode live data\treatments\raw\treatment_359730fc-68ed-4d2d-9f18-3dbe8fc259d2.raw.jsonl.gz
```

Expected artifact:

- [g12_recent_continuity_report.json](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports\g12_recent_continuity_report.json)

### D.3 Replay `TRAN VAN VU`

If OPUS is working in the operator project copy and the export bundle exists:

```bat
cd /d C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend
python -m tools.check_treatment_continuity --name TRAN_VAN_VU --mode live "D:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\backend\tools\_exports\TRAN_VAN_VU__ALL_DEVICES__bundle\01__2026-04-05_040827+0700__PF_003__79ce390d\treatment_79ce390d-b08a-46a7-bf86-3acf6b73188f_chunk001.jsonl" "D:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\backend\tools\_exports\TRAN_VAN_VU__ALL_DEVICES__bundle\01__2026-04-05_040827+0700__PF_003__79ce390d\treatment_79ce390d-b08a-46a7-bf86-3acf6b73188f_chunk002.jsonl" "D:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\backend\tools\_exports\TRAN_VAN_VU__ALL_DEVICES__bundle\02__2026-04-05_132714+0700__PF_003__2ce08914\treatment_2ce08914-6383-44a1-ac70-e981a20250b2_chunk001.jsonl" "D:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\backend\tools\_exports\TRAN_VAN_VU__ALL_DEVICES__bundle\03__2026-04-05_230418+0700__PF_003__be60f1b7\treatment_be60f1b7-c0f3-477c-b9aa-15b0000da0ae_chunk001.jsonl" "D:\PrismaFlexProject\PrismaFlexDeviceManager - v2\PrismaFlexWebApp\backend\tools\_exports\TRAN_VAN_VU__ALL_DEVICES__bundle\04__2026-04-06_062742+0700__PF_003__9a9be6e3\treatment_9a9be6e3-10f2-4183-a3bb-07a7f7e3f361_chunk001.jsonl"
```

Expected artifact:

- [TRAN_VAN_VU_continuity_report.json](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports\TRAN_VAN_VU_continuity_report.json)

### D.4 SQL validation after replay

Use these queries after each replay:

```sql
SELECT id, device_id, patient_id, start_time, end_time, outcome, close_reason, total_packets
FROM treatments
ORDER BY start_time DESC;
```

```sql
SELECT treatment_id, row_code, row_kind, snapshot_time, reason
FROM treatment_journal_rows
ORDER BY snapshot_time, row_code;
```

```sql
SELECT treatment_id, chunk_index, status, packet_count, first_timestamp, last_timestamp
FROM raw_packet_manifest
ORDER BY first_timestamp;
```

---

## Appendix E - Gold Expected Outputs

These are the expected replay outcomes currently validated in local sandbox.

### E.1 `TRAN VAN VU`

Source type:

- exported raw bundle

Expected replay result:

- treatment count: `1`
- mode: `LIVE`
- device: `PF_003`
- patient: `TRAN VAN VU`
- start time: `2026-04-05T18:08:27+07:00`
- end time: `2026-04-07T03:54:14+07:00`
- outcome: `COMPLETED`
- close reason: `END received`
- total packets: `9442`
- snapshot count: `48`

Expected report reference:

- [TRAN_VAN_VU_continuity_report.json](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports\TRAN_VAN_VU_continuity_report.json)

### E.2 `g12 recent`

Source type:

- local raw file

Expected replay result:

- treatment count: `1`
- mode: `LIVE`
- device: `PF_004`
- patient: `g12`
- start time: `2026-02-11T11:01:09+07:00`
- end time: `2026-02-11T22:46:27+07:00`
- outcome: `COMPLETED`
- close reason: `END received`
- total packets: `4223`
- snapshot count: `18`

Expected report reference:

- [g12_recent_continuity_report.json](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports\g12_recent_continuity_report.json)

### E.3 Lifecycle sandbox baseline

Expected:

- report says `PASS 19/19`

Reference:

- [lifecycle_sandbox_report.txt](C:\Users\ADMIN\.codex\worktrees\09de\PrismaFlexWebApp\backend\tools\_sandbox_reports\lifecycle_sandbox_report.txt)

If OPUS gets materially different results from the above on the same code and
same source data, it should treat that as a hard investigation point.
