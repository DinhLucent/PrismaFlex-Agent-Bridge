# Treatment Journal Stable-Row Partial Lock QA Suite

Updated: 2026-04-05  
Owner: CTO / QA Lead  
Status: READY FOR QA  
Priority: P0 - Release gate

Related:

- `TREATMENT_JOURNAL_STABLE_ROW_PARTIAL_LOCK_SPEC.md`
- `TREATMENT_JOURNAL_MVP_POLICY.md`
- `TREATMENT_JOURNAL_PERMISSION_MATRIX.md`

## 1. Muc tieu test

Xac minh feature `stable-row partial lock` dung o ca 4 lop:

- nghiep vu
- UI/UX
- backend permission
- chronology integrity

QA khong chi test "co edit duoc khong".
QA phai test ca:

- row nao duoc edit
- row nao bi khoa
- field nao duoc edit
- save co thanh cong that khong
- chronology co bi anh huong khong

## 2. Pham vi can test

Trong scope:

- `IN_PROGRESS` row-level lock
- `H00` freeze va edit sau freeze
- stable `Hxx` editing
- role/state gating
- field allowlist / denylist
- audit / refresh / persistence
- khong hien structural actions

Ngoai scope:

- fill gap maintenance tool
- raw packet replay
- treatment rebuild tool

## 3. QA fixture scenarios can chuan bi

QA nen co it nhat 6 treatment scenario:

### F1 - Active basic

- Treatment `IN_PROGRESS`
- Co `H00`, `H01` da stable
- Co 1 row dang live hien tai, vi du `H02`

### F2 - H00 freeze window

- Treatment moi tao
- `H00` vua duoc tao trong cua so freeze ban dau

### F3 - Active with OC row

- Treatment `IN_PROGRESS`
- Co `H00`, `H01`
- Co `OC_01`
- Co 1 active data row sau do

### F4 - Pending review

- Treatment `PENDING_REVIEW`
- Co it nhat 3 row data

### F5 - Approved

- Treatment `APPROVED`
- Co row da edit truoc do de kiem tra khoa

### F6 - Unlocked correction

- Treatment da `APPROVED`, sau do duoc `unlock`

## 4. Release checklist

Danh dau `PASS/FAIL/NA` cho tung muc.

| ID    | Checklist item                                                              | Priority | Status |
| ----- | --------------------------------------------------------------------------- | -------- | ------ |
| CL-01 | Nurse co the mo edit tren stable row khi treatment `IN_PROGRESS`            | P0       | PASS   |
| CL-02 | Active streaming row van read-only                                          | P0       | PASS   |
| CL-03 | `H00` trong freeze window van read-only                                     | P0       | PASS   |
| CL-04 | `H00` sau freeze duoc edit manual                                           | P0       | PASS   |
| CL-05 | Gap row khong co editable cell                                              | P0       | PASS   |
| CL-06 | Khong co button `Fill Gap` trong clinical UI                                | P0       | PASS   |
| CL-07 | Khong co button `Add Row` / `Add Next Hour`                                 | P0       | PASS   |
| CL-08 | Khong co button `Restore Missing`                                           | P0       | PASS   |
| CL-09 | Khong co button `Delete Row` trong luong nurse/doctor thuong quy            | P0       | PASS   |
| CL-10 | Telemetry fields nhu `QB/QD/QS/TMP/PA/PV/PBE/UF` khong sua duoc             | P0       | PASS   |
| CL-11 | Manual allowlist sua duoc tren stable row                                   | P0       | PASS   |
| CL-12 | Save stable row trong `IN_PROGRESS` thanh cong, khong fail 409 blanket lock | P0       | PASS   |
| CL-13 | Gia tri da sua con ton tai sau refresh                                      | P0       | PASS   |
| CL-14 | `snapshot_time` va `hour_label` khong doi sau khi save                      | P0       | PASS   |
| CL-15 | Row khong bi nhay vi tri chronology sau khi save                            | P0       | PASS   |
| CL-16 | Audit metadata `updated_by/updated_at` duoc cap nhat                        | P1       | PASS   |
| CL-17 | `PENDING_REVIEW`: nurse read-only                                           | P0       | PASS   |
| CL-18 | `APPROVED`: tat row read-only                                               | P0       | PASS   |
| CL-19 | Sau `unlock`, edit quay lai theo dung policy                                | P1       | PASS   |
| CL-20 | UI banner dien dat dung: row dang ghi bi khoa, row cu co the sua            | P1       | PASS   |
| CL-21 | UI khong mo edit cho row placeholder / gap                                  | P1       | PASS   |
| CL-22 | `OC_XX` khong lam sai co che xac dinh active row                            | P0       | PASS   |
| CL-23 | Truong hop stale tab / refresh van dung permission moi nhat                 | P1       | PASS   |
| CL-24 | Loi quyen han / lock tra thong diep hop ly                                  | P1       | PASS   |

## 5. Test cases chi tiet

Format:

- Precondition
- Steps
- Expected result

## 5A. Smoke and core workflow

### TC-SRP-001 - Edit stable old row during `IN_PROGRESS`

Priority: P0

Precondition:

- Dung fixture `F1`
- Login role `Nurse`
- `H00` va `H01` da stable
- `H02` la active streaming row

Steps:

1. Mo treatment journal.
2. Tim row `H00`.
3. Click vao 1 manual cell duoc phep edit, vi du `heparin_rate`.
4. Nhap gia tri moi.
5. Save / blur cell.

Expected result:

- Cell mo edit duoc.
- Save thanh cong.
- Khong co `409 Conflict` blanket lock.
- Gia tri moi hien tren row `H00`.
- Row `H00` van o dung vi tri chronology.

### TC-SRP-002 - Active streaming row bi khoa

Priority: P0

Precondition:

- Dung fixture `F1`
- `H02` la active streaming row

Steps:

1. Mo treatment journal.
2. Tim row dang live hien tai.
3. Thu click vao 1 manual cell tren row nay.

Expected result:

- Khong mo edit mode.
- UI the hien read-only.
- Neu co tooltip/message, thong diep phai cho biet row dang ghi du lieu.

### TC-SRP-003 - `H00` trong freeze window bi khoa

Priority: P0

Precondition:

- Dung fixture `F2`
- `H00` vua moi duoc tao, chua qua cua so freeze

Steps:

1. Mo treatment journal ngay sau khi treatment bat dau.
2. Tim row `H00`.
3. Thu edit mot manual field.

Expected result:

- `H00` van read-only.
- Khong duoc mo edit.
- Khong co save request hop le cho row nay.

### TC-SRP-004 - `H00` sau freeze duoc edit

Priority: P0

Precondition:

- Treatment qua cua so freeze `H00`
- `H00` da stable

Steps:

1. Refresh treatment journal sau khi het freeze.
2. Thu edit `heparin_bolus` hoac field manual khac tren `H00`.

Expected result:

- `H00` mo edit duoc.
- Save thanh cong.
- Khong sinh row moi.

### TC-SRP-005 - Transition active row sau 1 moc gio

Priority: P1

Precondition:

- Treatment dang live
- Co mot row active hien tai

Steps:

1. Ghi nhan row active hien tai.
2. Cho treatment sang moc tiep theo hoac dung fixture da chuyen active row.
3. Refresh UI.
4. Thu edit row vua khong con active nua.

Expected result:

- Row cu tro thanh editable neu no la stable row.
- Row active moi bi khoa.

## 5B. Field allowlist and denylist

### TC-SRP-006 - Manual allowlist duoc edit

Priority: P0

Precondition:

- Stable row ton tai
- Role `Nurse`

Steps:

1. Lan luot thu edit cac field trong allowlist:
2. `heparin_bolus`
3. `heparin_rate`
4. `duosol_count`
5. `prismasol_count`
6. `filter_type`
7. `kali`

Expected result:

- Cac field trong allowlist mo edit duoc tren stable row.
- Save thanh cong cho tung field hop le.

### TC-SRP-007 - Citrate allowlist duoc edit

Priority: P1

Precondition:

- Treatment o mode citrate
- Stable row ton tai

Steps:

1. Thu edit `calcium_comp`.
2. Thu edit `citrate_dose`.

Expected result:

- Cac field citrate manual edit duoc neu mode cho phep.

### TC-SRP-008 - Telemetry fields read-only

Priority: P0

Precondition:

- Stable row ton tai

Steps:

1. Thu edit lan luot cac field telemetry:
2. `qb`
3. `qd`
4. `qs`
5. `qpbp`
6. `uf_total`
7. `uf_hourly`
8. `pa`
9. `pv`
10. `pbe`
11. `tmp`

Expected result:

- Khong field nao mo edit duoc.
- Khong co request save hop le cho cac field nay.

### TC-SRP-009 - Backend reject field ngoai allowlist

Priority: P0

Precondition:

- Co cach goi API truc tiep hoac devtools

Steps:

1. Goi request save cho 1 telemetry field tren stable row.

Expected result:

- Backend tu choi.
- Tra ma loi phu hop.
- Du lieu journal khong thay doi.

## 5C. Row type and chronology integrity

### TC-SRP-010 - Gap row khong editable

Priority: P0

Precondition:

- Treatment co gap row placeholder

Steps:

1. Mo journal.
2. Tim gap row.
3. Thu click vao cac o tren gap row.

Expected result:

- Khong co o nao editable.
- Khong co action fill/create.

### TC-SRP-011 - Edit stable row khong doi chronology

Priority: P0

Precondition:

- Stable row co san

Steps:

1. Ghi lai thu tu hien tai cua `H00/H01/OC_01/H02...`
2. Edit mot manual field tren `H01`.
3. Save.
4. Refresh.

Expected result:

- Thu tu row giu nguyen.
- `H01` van o dung vi tri.
- `snapshot_time` khong doi.

### TC-SRP-012 - Edit nhieu lan van khong day row xuong cuoi

Priority: P0

Precondition:

- Stable row `H01` ton tai

Steps:

1. Edit `H01` lan 1.
2. Edit `H01` lan 2.
3. Edit `H01` lan 3.
4. Moi lan deu refresh / sync lai.

Expected result:

- `H01` van dung vi tri chronology.
- Khong lan nao nhay xuong cuoi bang.

### TC-SRP-013 - `OC_XX` khong lam sai active-row lock

Priority: P0

Precondition:

- Dung fixture `F3`
- Co `OC_01` trong timeline
- Co 1 active data row sau do

Steps:

1. Mo journal.
2. Xac dinh row dang live theo nghiep vu.
3. Thu edit `OC_01`.
4. Thu edit stable `H01`.
5. Thu edit active data row that su.

Expected result:

- `OC_01` xu ly theo dung state cua no.
- `H01` stable row edit duoc neu hop le.
- Active data row that su van bi khoa.
- Co che lock khong duoc chi dua vao "phan tu render cuoi" mot cach sai.

### TC-SRP-014 - Save khong tao row moi

Priority: P0

Precondition:

- Stable row ton tai

Steps:

1. Dem tong so row truoc khi edit.
2. Edit mot field manual.
3. Save va refresh.

Expected result:

- Tong so row giu nguyen.
- Khong xuat hien row moi.

## 5D. State and role gating

### TC-SRP-015 - `PENDING_REVIEW` nurse read-only

Priority: P0

Precondition:

- Dung fixture `F4`
- Login `Nurse`

Steps:

1. Mo journal treatment `PENDING_REVIEW`.
2. Thu edit bat ky cell manual nao.

Expected result:

- Tat ca cell read-only.
- Khong save duoc.

### TC-SRP-016 - `PENDING_REVIEW` doctor chi co action review theo policy

Priority: P1

Precondition:

- Dung fixture `F4`
- Login `Doctor`

Steps:

1. Mo journal treatment `PENDING_REVIEW`.
2. Kiem tra cac action hien co.

Expected result:

- Chi hien cac action review duoc phep theo policy hien hanh.
- Khong tu y mo structural actions.

### TC-SRP-017 - `APPROVED` khoa hoan toan

Priority: P0

Precondition:

- Dung fixture `F5`
- Login `Nurse` hoac `Doctor`

Steps:

1. Mo treatment `APPROVED`.
2. Thu edit stable row bat ky.

Expected result:

- Khong edit duoc.
- UI hien ro record da approved / locked.

### TC-SRP-018 - `UNLOCK` mo lai dung policy

Priority: P1

Precondition:

- Dung fixture `F6`

Steps:

1. Unlock treatment theo quyen hop le.
2. Mo lai journal voi role duoc phep.
3. Thu edit stable row.

Expected result:

- Quyen edit quay lai dung policy correction.
- Khong mo structural actions.

## 5E. Backend and API parity

### TC-SRP-019 - UI mo edit va save thanh cong tren stable row `IN_PROGRESS`

Priority: P0

Precondition:

- Stable row ton tai
- Treatment `IN_PROGRESS`

Steps:

1. Mo edit tren stable row.
2. Save gia tri moi.
3. Theo doi response request.

Expected result:

- Response thanh cong.
- Khong xay ra `409 Conflict` chi vi treatment van `IN_PROGRESS`.

Ghi chu:

- Neu UI mo edit duoc nhung save fail do blanket lock backend, day la blocker.

### TC-SRP-020 - Live row save bi backend tu choi

Priority: P0

Precondition:

- Co cach force request vao active streaming row

Steps:

1. Thu goi save cho active streaming row.

Expected result:

- Backend tu choi.
- Khong thay doi du lieu.

### TC-SRP-021 - Missing operator bi tu choi

Priority: P1

Precondition:

- API can operator metadata

Steps:

1. Thu save stable row ma khong gui operator name.

Expected result:

- Backend tu choi theo policy.
- UI hien loi ro rang neu duong save yeu cau operator.

## 5F. Persistence, refresh, and audit

### TC-SRP-022 - Refresh khong mat du lieu vua sua

Priority: P0

Precondition:

- Da save thanh cong mot stable row

Steps:

1. Refresh page.
2. Mo lai treatment journal.

Expected result:

- Gia tri vua sua van ton tai.

### TC-SRP-023 - Audit metadata duoc cap nhat

Priority: P1

Precondition:

- Da save thanh cong mot stable row

Steps:

1. Kiem tra badge / metadata / history neu UI co hien.

Expected result:

- Co `updated_by` / `updated_at` hoac dau vet audit tuong duong.

### TC-SRP-024 - Multi-tab / stale page

Priority: P1

Precondition:

- Mo cung treatment o 2 tab

Steps:

1. Tab A edit stable row va save.
2. Tab B khong refresh, tiep tuc thao tac.
3. Dong bo lai.

Expected result:

- He thong khong gay mat chronology.
- Tab B khong duoc ghi de sai state ma khong co canh bao hop ly.

## 5G. UI and UX detail

### TC-SRP-025 - Banner dien dat dung policy moi

Priority: P1

Precondition:

- Treatment `IN_PROGRESS`

Steps:

1. Mo journal.
2. Doc banner lock.

Expected result:

- Banner noi ro rang row dang ghi bi khoa, row truoc do co the sua.
- Khong dung wording "toan bo journal locked" neu feature da bat.

### TC-SRP-026 - Chi field editable moi co affordance

Priority: P1

Precondition:

- Co stable row

Steps:

1. Quan sat toan bo row.

Expected result:

- Chi cac field hop le moi co affordance edit.
- UI khong gay hieu nham tat ca cell deu co the click.

### TC-SRP-027 - Khong co structural control trong UI thuong quy

Priority: P0

Precondition:

- Role `Nurse`
- Role `Doctor`

Steps:

1. Mo journal page.
2. Mo review page neu can.

Expected result:

- Khong thay `Fill Gap`
- Khong thay `Add Row`
- Khong thay `Add Next Hour`
- Khong thay `Restore Missing`
- Khong thay `Delete Row`

## 6. Exploratory test guide

QA nen test them cac tinh huong sau:

- edit stable row trong luc backend van tiep tuc nhan live telemetry
- edit 2 field lien tiep tren cung 1 row
- sua row sat ben active row
- submit for review ngay sau khi vua save stable row
- approve sau khi row da edit va refresh nhieu lan
- browser back/forward sau khi save

## 7. Blocker criteria

Dung test va chan release ngay neu gap mot trong cac loi sau:

1. Stable row `IN_PROGRESS` mo edit duoc nhung save that bai do backend van hard-lock.
2. Active streaming row edit duoc.
3. Gap row edit duoc hoac co action fill.
4. Telemetry field edit duoc.
5. Edit lam row nhay chronology.
6. Save tao row moi.
7. `APPROVED` van edit duoc ma khong unlock.
8. UI message gay hieu nham rang feature partial-lock da bat nhung hanh vi backend lai khac.

## 8. Ket qua QA can bao cao

Moi run QA nen bao cao:

- pass/fail theo checklist `CL-01` -> `CL-24`
- danh sach test case fail
- screenshot / video cho loi P0
- request/response cua save API neu co mismatch UI/backend
- treatment id, hour label, role, state o thoi diem loi

## 9. Final note for QA

Day la mot feature P0 cua Journal.

QA khong duoc sign-off chi dua vao:

- build pass
- UI mo edit mode
- demo tay tren mot treatment don le

Dieu kien sign-off bat buoc la:

- edit dung row
- khoa dung row
- save dung API
- chronology van nguyen ven
