# Live Cutover Release Checklist

Scope: validate the highest-risk runtime scenario before release:

- historical `BACKFILL` finishes on a device
- operator switches that device to `LIVE`
- the PrismaFlex machine continues the same patient/treatment
- hourly snapshots, order-change snapshots, and raw data all remain clinically coherent

This checklist is intentionally narrow. It is not a full QA matrix. It is the cutover gate for:

- same `device_id`
- same `patient_id`
- `RUN_TIME > 0`
- no clinical split unless the machine truly starts a new treatment

## 1. Expected Runtime Rule

For the cutover case, the intended rule is:

- `same device_id + same patient_id + RUN_TIME > 0` => continue the same treatment
- `BACKFILL` session may be promoted or safely handed off into `LIVE`
- `Hxx` must continue on the same `treatment_id`
- `OC_XX` must continue on the same `treatment_id`
- raw stream may open a new chunk, but it must remain under the same `treatment_id`

Not required for this gate:

- approved/reviewed treatment locking
- backfill chronology validation
- cross-device behavior

## 2. Preconditions

Before running this checklist:

- `BACKFILL` route is enabled and working
- `LIVE` route is enabled and working
- device under test is a single machine, for example `PF_004`
- one known replay dataset exists for that device
- operator/tester can call the handoff endpoint or equivalent UI action

Recommended evidence to collect:

- backend console logs
- `backend/logs/backend.log`
- `backend/logs/replay_status.log`
- screenshots of treatment detail before and after handoff

## 3. Core Risk Questions

This checklist answers 5 release questions:

1. Does `LIVE` continue the same treatment after `BACKFILL`?
2. Does the handoff avoid creating an unnecessary new `treatment_id`?
3. Does raw data stay attached to the same treatment, even if a new chunk starts?
4. Do `Hxx` and `OC_XX` continue after handoff without chronology corruption?
5. Does the device mode switch cleanly from `BACKFILL` to `LIVE`?

## 4. SQL Checks

Run these against the release database.

### 4.1 Latest treatment for device

```sql
SELECT id, device_id, patient_id, start_time, end_time, outcome, continuity_source,
       total_packets, last_packet_time, last_run_time_sec
FROM treatments
WHERE device_id = 'PF_004'
ORDER BY created_at DESC
LIMIT 5;
```

### 4.2 Journal rows for the active treatment

```sql
SELECT treatment_id, row_code, row_kind, hour_slot, snapshot_time, source, reason
FROM treatment_journal_rows
WHERE treatment_id = '<treatment_id>'
ORDER BY snapshot_time, row_code;
```

### 4.3 Raw manifest for the treatment

```sql
SELECT treatment_id, chunk_index, status, first_timestamp, last_timestamp,
       packet_count, size_bytes, file_path
FROM raw_packet_manifest
WHERE treatment_id = '<treatment_id>'
ORDER BY chunk_index;
```

### 4.4 Device checkpoint

```sql
SELECT device_id, active_mode, active_treatment_id, last_patient_id,
       last_seen_time, last_run_time_sec, active_chunk_index, updated_at
FROM device_state
WHERE device_id = 'PF_004';
```

## 5. Cutover Test Cases

### TC-C01: Backfill session exists before handoff

Steps:

1. Replay historical data for one device in `BACKFILL` mode.
2. Open treatment detail in UI.
3. Record current `treatment_id`, last visible `Hxx`, and last visible `OC_XX`.

Expected:

- exactly one target treatment is clearly active for the device
- journal is visible
- device mode reports `BACKFILL`

Fail means:

- handoff test is invalid because setup is incomplete

### TC-C02: Handoff changes mode from BACKFILL to LIVE

Steps:

1. Trigger the handoff endpoint or UI control for `BACKFILL -> LIVE`.
2. Inspect API response or logs.
3. Query `device_state`.

Expected:

- mode becomes `LIVE`
- no `DEVICE_MODE_CONFLICT`
- `device_state.active_mode = 'LIVE'`

Fail means:

- issue in mode lock or handoff endpoint
- likely modules: `backend/main.py`, `device_state` write-through

### TC-C03: Same patient + RUN_TIME > 0 continues same treatment

Steps:

1. After handoff, send live packets for the same `device_id`.
2. Ensure packet stream carries the same `patient_id`.
3. Ensure packet stream shows `RUN_TIME > 0`.
4. Query `treatments` and inspect UI.

Expected:

- no new treatment UUID is created for the continuation
- live packets append to the same historical treatment
- `continuity_source` is reasonable for resumed flow

Fail means:

- live continuity is splitting incorrectly
- likely modules: `treatment_recorder.py`, handoff flow, open/resume logic

### TC-C04: Hourly snapshots continue on same treatment

Steps:

1. Note the last backfill hourly row before handoff.
2. Let live continue long enough to cross at least one new hourly boundary.
3. Query `treatment_journal_rows`.

Expected:

- new `Hxx` rows continue on the same `treatment_id`
- no restart from `H00`
- no duplicate hour rows caused by the handoff itself
- hourly chronology remains increasing

Fail means:

- handoff lost snapshot cache or treatment continuity
- likely modules: `treatment_snapshot_service.py`, recorder close/open lifecycle

### TC-C05: Order changes continue on same treatment after handoff

Steps:

1. During live continuation, change at least one order PID clinically represented by:
   - `qb`
   - `qd`
   - `qpbp`
   - `uf_rate_target`
2. Inspect UI and DB.

Expected:

- a new `OC_XX` row appears on the same `treatment_id`
- `reason` is populated
- OC appears in chronological position between surrounding hourly rows

Fail means:

- live event tracking or OC snapshot save is broken
- likely modules: `event_service.py`, `treatment_snapshot_service.py`, `main.py`

### TC-C06: Raw data stays under the same treatment after handoff

Steps:

1. Record manifest rows before handoff.
2. Perform handoff.
3. Send live data for the same continued treatment.
4. Query `raw_packet_manifest`.

Expected:

- manifest may show a new chunk
- but all chunks remain under the same `treatment_id`
- there is a clear closure/opening sequence, not a treatment split

Acceptable:

- old chunk closed during handoff
- new chunk opened for live continuation

Not acceptable:

- raw data starts writing under a new treatment UUID without a real clinical split

Fail means:

- analyzer-risk is still present
- likely modules: `raw_streamer.py`, `main.py` on-close wiring, recorder ownership

### TC-C07: Raw manifest timestamps are populated and monotonic

Steps:

1. Query `raw_packet_manifest` for the treatment.
2. Compare chunk timestamps against journal chronology.

Expected:

- `first_timestamp` and `last_timestamp` are not null
- chunk timestamps move forward logically
- manifest chronology roughly matches journal chronology

Fail means:

- raw streamer is reading timestamp from the wrong packet field
- likely module: `raw_streamer.py`

### TC-C08: No accidental new treatment on same-patient continuation

Steps:

1. After handoff, continue live for several minutes without patient change.
2. Query latest 5 treatments for the device.

Expected:

- still one active/continued treatment for the cutover session
- no stray new treatment row appears just because live started

Fail means:

- live handoff or reopen logic is too aggressive
- likely module: `treatment_recorder.py`

## 6. Failure Mapping

Use this quick map when QA reports a failure.

### Symptom: LIVE created a new treatment after handoff

Likely modules:

- `backend/services/treatment/treatment_recorder.py`
- `backend/main.py`

### Symptom: Handoff succeeded but no new Hxx appears in live

Likely modules:

- `backend/services/treatment/treatment_snapshot_service.py`
- `backend/main.py`

### Symptom: OC rows stop appearing after handoff

Likely modules:

- `backend/services/event_service.py`
- `backend/services/treatment/treatment_snapshot_service.py`
- `backend/main.py`

### Symptom: raw data split into a different treatment UUID

Likely modules:

- `backend/services/treatment/treatment_recorder.py`
- `backend/services/treatment/raw_streamer.py`
- `backend/main.py`

### Symptom: manifest timestamps null or nonsense

Likely modules:

- `backend/services/treatment/raw_streamer.py`

### Symptom: handoff blocked by device still in BACKFILL

Likely modules:

- `backend/main.py`
- mode lock logic

## 7. Release Gate

This cutover scenario is release-ready only if all are true:

- `BACKFILL -> LIVE` handoff succeeds without manual DB repair
- same patient continuation keeps the same `treatment_id`
- `Hxx` continues after handoff
- `OC_XX` continues after handoff
- raw manifest stays on the same `treatment_id`
- raw manifest timestamps are populated and sensible

If any of the above fails, do not sign off cutover continuity.

