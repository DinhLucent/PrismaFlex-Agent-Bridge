# Step 01 - Raw Packet -> Mirth Backfill Transform

## Muc tieu cua buoc nay

Tai buoc 01, Mirth Connect chua xu ly nghiep vu backend, chua tao treatment, chua tao snapshot.
Muc tieu duy nhat cua buoc nay la:

- nhan raw packet da decode
- kiem tra packet co hop le de replay hay khong
- giu nguyen timestamp lich su
- chuan hoa payload thanh format ma backend mong doi
- danh dau packet nay la `BACKFILL`

Buoc nay dung lai o payload sau transform. Khong di tiep vao luong backend.

---

## 1. Raw data di vao Mirth co dang gi

Input ma Mirth nhan vao la mot JSON packet da decode tu PrismaFlex.
Payload nay co 4 phan chinh:

- `packet_num`
- `timestamp`
- `s_header`
- `s_body`

Trong do:

- `s_header` chua thong tin may, benh nhan, therapy, timestamp
- `s_body.parameters[]` chua danh sach PID/value cua packet

Vi du toi gian:

```json
{
  "packet_num": 169,
  "timestamp": "2026-01-30T08:37:13.347598",
  "s_header": {
    "machine_id": 7,
    "patient_id": "g7",
    "therapy_type_id": 3,
    "therapy_status_id": 5,
    "timestamp": "2026-01-30 08:37:09 UTC"
  },
  "s_body": {
    "total_records": 172,
    "parameters": [
      { "record_num": 1, "type": "Actual", "id": 1, "value": -40 },
      { "record_num": 2, "type": "Actual", "id": 2, "value": 235 }
    ]
  }
}
```

---

## 2. Mirth doc raw data

Transform bat dau bang viec doc `connectorMessage.getRawData()` va parse JSON:

```javascript
var rawData = connectorMessage.getRawData();
var input = (rawData && rawData != '') ? JSON.parse(rawData) : {};
```

Y nghia:

- neu raw data rong -> `input = {}`
- neu raw data co noi dung -> parse thanh object JSON

Tai diem nay, Mirth van dang lam viec voi format raw ban dau.

---

## 3. Validation bat buoc

Transform hien tai co 2 rule reject quan trong.

### 3.1. `machine_id` la bat buoc

Neu khong co:

```javascript
if (!input.s_header || !input.s_header.machine_id) {
    channelMap.put('skipMessage', true);
    return false; 
}
```

Y nghia:

- packet khong duoc gui tiep
- Mirth bo packet nay ngay tai transform

### 3.2. Khong duoc fabricate timestamp

Transform uu tien lay timestamp lich su tu:

1. `input.s_header.timestamp`
2. neu khong co thi moi thu `input.timestamp`

Code:

```javascript
var originalTime = input.s_header.timestamp;
if (!originalTime && input.timestamp) {
    originalTime = input.timestamp;
}
```

Neu van khong co timestamp:

```javascript
if (!originalTime) {
    channelMap.put('skipMessage', true);
    logger.error('[STRESS_TEST] REJECTED: Packet from machine ' + machineId + 
                 ' has no original timestamp. Cannot use wall clock for clinical data.');
    return false;
}
```

Y nghia nghiep vu:

- backfill phai ton trong thoi gian lich su goc
- tuyet doi khong duoc thay bang `new Date()` hoac wall clock hien tai
- neu packet mat timestamp thi packet do khong du dieu kien de replay lam du lieu lam sang

---

## 4. Mirth chuan hoa payload ra format backend mong doi

Sau khi packet pass validation, transform tao object moi ten la `output`.

### 4.1. `output.meta`

```javascript
output.meta.device_id = "PF_" + ("000" + machineId).slice(-3);
output.meta.timestamp = originalTime;
output.meta.packet_num = input.packet_num;
output.meta.mode = "BACKFILL";
```

Ket qua:

- `machine_id = 7` -> `device_id = "PF_007"`
- timestamp duoc giu nguyen tu packet lich su
- packet duoc gan co `mode = "BACKFILL"`

`meta.mode = "BACKFILL"` la tin hieu rat quan trong de backend biet:

- day la replay du lieu lich su
- khong phai live stream hien tai

### 4.2. `output.header`

```javascript
output.header = input.s_header;
output.header.timestamp = originalTime;
```

Y nghia:

- copy nguyen `s_header`
- dong bo lai `header.timestamp` theo `originalTime`
- dam bao `meta.timestamp` va `header.timestamp` khong lech nhau

### 4.3. `output.body`

```javascript
output.body = input.s_body;
```

Y nghia:

- copy nguyen `s_body`
- danh sach `parameters[]` duoc giu nguyen
- Mirth chua map PID, chua tinh snapshot, chua tinh order-change

---

## 5. Output sau transform co dang gi

Payload sau transform se co dang:

```json
{
  "meta": {
    "device_id": "PF_007",
    "timestamp": "2026-01-30 08:37:09 UTC",
    "packet_num": 169,
    "mode": "BACKFILL"
  },
  "header": {
    "stx": "0x0002",
    "crc": "0xF783",
    "machine_id": 7,
    "patient_id": "g7",
    "therapy_type_id": 3,
    "therapy_status_id": 5,
    "timestamp": "2026-01-30 08:37:09 UTC"
  },
  "body": {
    "total_records": 172,
    "parameters": [
      { "record_num": 1, "type": "Actual", "id": 1, "value": -40 },
      { "record_num": 2, "type": "Actual", "id": 2, "value": 235 }
    ]
  }
}
```

Luu y quan trong:

- Mirth da doi ten tu `s_header` -> `header`
- Mirth da doi ten tu `s_body` -> `body`
- Mirth them `meta`
- Mirth khong sua danh sach PID/value trong `parameters[]`

---

## 6. Mirth KHONG lam gi o buoc nay

De tranh nham lan, buoc transform nay khong lam cac viec sau:

- khong tao treatment
- khong quyet dinh live hay completed
- khong tao `H00/H01/H02`
- khong tao `OC_XX`
- khong map PID thanh `qb`, `qd`, `tmp`, `uf_total`...
- khong tinh GAP
- khong ghi database

Tat ca phan nay thuoc ve backend sau khi Mirth gui payload di.

---

## 7. So do buoc 01

```mermaid
flowchart LR
    A["Raw decoded packet\n(packet_num, timestamp, s_header, s_body)"] --> B["Mirth Transformer"]
    B --> C{"Co machine_id?"}
    C -- "Khong" --> X["Reject packet"]
    C -- "Co" --> D{"Co original timestamp?"}
    D -- "Khong" --> Y["Reject packet"]
    D -- "Co" --> E["Tao output.meta"]
    E --> F["Copy s_header -> header\nDong bo header.timestamp"]
    F --> G["Copy s_body -> body"]
    G --> H["Gan mode = BACKFILL"]
    H --> I["JSON sau transform\nsan sang gui sang backend"]
```

---

## 8. Ket luan buoc 01

Tai cuoi buoc nay, ta co mot payload da duoc chuan hoa de gui sang backend:

- co `device_id` chuan hoa theo `PF_XXX`
- co `timestamp` lich su goc
- co `mode = BACKFILL`
- van giu nguyen `header` va `body.parameters[]`

Day la diem dung cua note nay.

Buoc tiep theo moi la:

- backend nhan payload nay nhu the nao
- live/backfill duoc tach logic ra sao
- treatment/session duoc mo ra the nao
- snapshot va order-change duoc sinh tu `body.parameters[]` ra sao

