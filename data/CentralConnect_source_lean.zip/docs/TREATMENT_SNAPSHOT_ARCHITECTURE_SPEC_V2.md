# Treatment Snapshot Architecture Spec v2.1

> **Status:** APPROVED-A — CTO Directive (Grade A)
> **Date:** 2026-04-05T21:22+07:00
> **Authors:** CTO Codex (v1) + CTO Antigravity (v2 amendments + v2.1 hardening)
> **Supersedes:** `TREATMENT_SNAPSHOT_SIMPLIFIED_ARCHITECTURE_SPEC.md` (v1 Proposed)
> **Scope:** Snapshot generation, backfill/live separation, GAP semantics, hour_slot determinism

---

## 1. Executive Summary

The current snapshot pipeline is too stateful. Mutable in-memory cache (`last_hour_label`, `h00_saved`, `last_pkt_time`) acts as source of truth instead of derived state. This causes a recurring class of bugs where one failed save corrupts all subsequent snapshots.

**This spec replaces that with a deterministic model:**

- `hour_slot = floor((pkt_time - treatment_start_time) / 3600)` — every packet independently resolves to the correct slot
- `ORDER_CHANGE` = separate timestamped event, never coupled to hourly logic
- `GAP` = frontend display of missing hourly slots, never auto-filled by backend
- `Backfill` = dedicated importer, not the normal live path

---

## 2. Problem Summary

Observed bug classes in current `treatment_snapshot_service.py`:

| Bug Class                                     | Root Cause                                                         |
| --------------------------------------------- | ------------------------------------------------------------------ |
| H00 infinite clamp during fast backfill       | `h00_saved` flag lost on cache reset                               |
| FK timing race (journal row before treatment) | No transaction boundary between treatment create and journal write |
| OC rows appearing without hourly rows         | OC projector shares cache state with hourly projector              |
| Auto gap-fill erasing true downtime           | Backend creating fake rows for missing hours                       |
| Recovery contaminating replay                 | `_initialize_cache()` recovery runs in backfill context            |
| Backfill affecting live behavior              | Single `process_packet()` path for both modes                      |

**Root cause:** All of these stem from mutable cache being treated as correctness primitive instead of performance optimization.

---

## 3. Clinical Semantics (MUST Preserve)

| Label           | Meaning                                      | Immutable?                                                 |
| --------------- | -------------------------------------------- | ---------------------------------------------------------- |
| `H00`           | Baseline hour bucket at treatment start      | `snapshot_time` yes, values accumulate for 60s then freeze |
| `H01..H99`      | Hourly clinical buckets                      | `snapshot_time` = clinical sample time                     |
| `OC_XX`         | Order-change events between hourly rows      | `snapshot_time` = packet time of change                    |
| `GAP`           | Missing hourly rows between actual snapshots | Display-only, never stored                                 |
| `snapshot_time` | Clinical sample time                         | **IMMUTABLE** after first write                            |
| `updated_at`    | Human or system mutation time                | Mutable                                                    |

---

## 4. Non-Goals

- Do not change PID value decoding from packets
- Do not redesign the UI review workflow
- Do not bring back backend smart gap-fill
- Do not couple hourly snapshot generation to order-change generation

---

## 5. Target Data Model

### 5.1 Schema Changes to `treatment_journal_rows`

**New columns:**

| Column      | Type          | Nullable             | Description                                       |
| ----------- | ------------- | -------------------- | ------------------------------------------------- |
| `hour_slot` | `INTEGER`     | Yes                  | Required for `HOUR` rows, NULL for `ORDER_CHANGE` |
| `source`    | `VARCHAR(20)` | No, default `'LIVE'` | Origin of the data                                |

**`source` enum values:**

```
LIVE      — from real-time telemetry ingest
BACKFILL  — from historical file import
MANUAL    — from nurse/doctor edit (Journal UI)
RECOVERY  — from startup recovery rebuild
```

### 5.2 Constraints

```sql
-- Deterministic hourly uniqueness (partial index)
CREATE UNIQUE INDEX uix_journal_hour_slot
ON treatment_journal_rows (treatment_id, hour_slot)
WHERE row_kind = 'HOUR' AND hour_slot IS NOT NULL;

-- Chronological query index
CREATE INDEX ix_journal_timeline
ON treatment_journal_rows (treatment_id, snapshot_time);

-- Compatibility index (retain during transition)
CREATE UNIQUE INDEX uix_journal_row_code
ON treatment_journal_rows (treatment_id, row_code);
```

### 5.3 Row Kind & Slot Derivation

```
row_kind = 'HOUR':
    hour_slot = floor((packet_time - treatment_start_time).total_seconds() / 3600)
    hour_slot = max(hour_slot, 0)
    row_code  = f"H{hour_slot:02d}"

row_kind = 'ORDER_CHANGE':
    hour_slot = NULL
    row_code  = f"OC_{counter:02d}"
```

---

## 6. Target Runtime Rules

### 6.1 Hourly Snapshot Projector

For each packet:

1. Resolve `treatment_start_time` (from DB, cached after first lookup)
2. Compute `hour_slot = max(0, floor((pkt_time - start_time) / 3600))`
3. Extract CRRT PID values into cache
4. **H00 Stabilization Rule:** If `hour_slot == 0`:
   - Always `UPSERT` the H00 row (accumulate latest values)
   - If `elapsed >= 60s`: set `stable_at = now()` on next write (freeze baseline)
   - If `elapsed < 60s`: `stable_at` remains NULL (still accumulating)
5. **H01+ Write Policy:** `UPSERT` by `(treatment_id, hour_slot)` with **write-coalescing**:
   - Buffer in-memory, flush to DB every **15 seconds** OR on hour boundary transition
   - This preserves fault-tolerance (if one write fails, next packet recreates correct slot) while reducing write amplification (~4 writes/hour instead of ~120)
6. Update `last_hour_label` as **read-only cache** for OC dedup — NOT as correctness input

**Critical invariant:** Packet N and packet N+1 from the same hour MUST resolve to the same `hour_slot` regardless of cache state. If cache is cleared between them, behavior MUST be identical.

### 6.2 Order Change Projector

For each packet:

1. Detect order PID changes (PID 17, 18, 19, 21, 22, 25)
2. Apply anti-flicker filter (numeric Δ ≥ 1)
3. Apply 60-second cooldown grouping
4. Store as `row_kind = 'ORDER_CHANGE'`, `snapshot_time = pkt_time`
5. OC creation **never** suppresses hourly creation
6. Hourly creation **never** depends on OC logic

### 6.3 FK Race Condition Mitigation

```
Rule: Snapshot projector MUST NOT write journal rows until treatment row
      is confirmed to exist.

Implementation:
  - Add "treatment_confirmed" flag to DeviceCache
  - Set True after first successful treatment lookup from DB
  - If not confirmed: buffer packets in memory (max 5s / 50 packets)
  - Flush buffer when treatment row appears
  - If buffer exceeds limit: log warning + drop oldest packets
  - NEVER silently discard the current packet on FK error
```

---

### 6.4 `flush_device()` Must Use Clinical Time

**Bug found in current code (L168-174):**

```python
def flush_device(self, device_id):
    now = datetime.now(...)  # ← WRONG: wall clock, not clinical time
    self._save_snapshot(device_id, cache, now)
```

**Rule:**

```
flush_device() MUST use cache.last_pkt_time as snapshot_time.
If cache.last_pkt_time is None → do NOT flush (no valid clinical data).
NEVER use datetime.now() as snapshot_time for any journal row.
```

**Rationale:** During backfill, `now()` = 2026-04-05 21:00 but clinical data is from 2025. Using `now()` creates a snapshot in the future relative to the treatment → corrupts chronology.

### 6.5 Concurrency Contract

**Current state:** `treatment_snapshot_service.py` uses a plain `Dict[str, DeviceCache]` with no thread-safety.

**Rule:**

```
Constraint: Snapshot projector is SINGLE-WRITER per device_id.

Current architecture (asyncio single-thread): SAFE — no action needed.

Future multi-worker: MUST partition by device_id (hash-based routing).
Do NOT use round-robin or random assignment.
Do NOT add locks — partition instead.
```

### 6.6 Backfill→Live Promote Baseline Rule

**Scenario:** Backfill creates treatment T1 with start_time=08:00. Live PROMOTE happens at 21:00. The promoted treatment has `hour_slot = floor((21:00-08:00)/3600) = 13` → H13 is correct, but there's no new baseline (H00) for the live phase.

**Rule:**

```
After PROMOTE, if gap between last backfill packet and first live packet > 2 hours:
  → Create a LIVE_BASELINE snapshot:
    - row_code = current hour label (e.g. H13)
    - source = 'LIVE'
    - Logged as: "LIVE_BASELINE after promote gap"

This ensures clinical staff can see when live monitoring resumed.
It does NOT create a fake H00 — it uses the correct hour_slot.
```

### 6.7 OC Row Uniqueness Constraint

**Risk:** OC counter is in-memory. If service restarts and counter recovery fails, duplicate OC rows may be created.

**Mitigation:**

```sql
CREATE UNIQUE INDEX uix_journal_oc_code
ON treatment_journal_rows (treatment_id, row_code)
WHERE row_kind = 'ORDER_CHANGE';
```

With this constraint, duplicate OC writes fail safely at DB level → the application can catch and skip.

### 6.8 Write-Coalescing Crash Safety

**Risk:** 15-second buffer may lose data on hard crash.

**Rules:**

```
Write-coalescing buffer MUST flush immediately on:
  1. Hour boundary transition (e.g. H01 → H02)
  2. Treatment close (flush_device)
  3. Backend graceful shutdown (SIGTERM handler)
  4. OC event (ensures OC has correct hourly context)

Acceptable loss on hard crash:
  - Maximum = 15 seconds of parameter updates within the SAME hour
  - Next packet after restart recreates the correct hour_slot (deterministic!)
  - This is the core architectural win: crash recovery is free
```

---

## 7. Backfill Architecture

### 7.1 Dedicated `HistoricalBackfillImporter`

Backfill MUST NOT run through the live runtime path. Create a dedicated importer:

**Responsibilities:**

- Create or resume treatment deterministically
- Write packets in time order for one device
- Project hourly rows using same `hour_slot` formula
- Project OC rows deterministically
- Update raw manifest
- Update list projection
- Set `source = 'BACKFILL'` on all created rows

**MUST NOT:**

- Trigger startup recovery logic
- Depend on current wall clock (`now()`)
- Use live heartbeat assumptions
- Trigger WebSocket fanout
- Share in-memory cache with live sessions

### 7.2 Live Runtime (Unchanged, Stay Lean)

Live path does only:

1. Resolve active treatment for packet
2. Persist raw chunk
3. Update treatment heartbeat/state
4. Project hourly row for packet's hour slot
5. Project order-change events
6. Set `source = 'LIVE'`

No smart gap-fill. No replay heuristics. No packet-arrival-speed decisions.

### 7.3 Recovery Rules

- Recovery only applies in **live runtime mode**
- Backfill importer **ignores** recovery state
- Before historical replay: clear any residual `IN_PROGRESS` session for that device (unless intentionally resuming)

---

## 8. GAP Display Rules (Frontend)

Backend stores only the hourly rows that actually exist. Frontend renders GAP:

```
If stored rows = [H00, H01, H04]:
  Display: H00, H01, GAP(H02), GAP(H03), H04

Rules:
  - GAP computed only from missing HOUR slots (not ORDER_CHANGE)
  - OC_XX between H01 and H04 does NOT fill the hourly gap
  - GAP rows are virtual — never persisted
```

---

## 9. Implementation Phases

### Phase 0: Stop Digging (Immediate, zero-risk)

- [ ] Audit codebase: confirm no backend auto gap-fill remains
- [ ] Remove any replay-speed-dependent logic
- [ ] Verify GAP is already display-only in frontend

### Phase 1: Schema Migration

- [ ] Add `hour_slot INTEGER` column (nullable)
- [ ] Add `source VARCHAR(20) DEFAULT 'LIVE'` column
- [ ] Backfill `hour_slot` from existing `row_code`:
  ```sql
  UPDATE treatment_journal_rows
  SET hour_slot = CAST(SUBSTRING(row_code FROM 2) AS INTEGER)
  WHERE row_code ~ '^H\d{2,}$';
  ```
- [ ] Add partial unique index `uix_journal_hour_slot`
- [ ] Verify: `SELECT COUNT(*) FROM treatment_journal_rows WHERE row_code ~ '^H' AND hour_slot IS NULL` = 0

### Phase 2: Projector Refactor

- [ ] Refactor `process_packet()` to compute `hour_slot` deterministically
- [ ] Implement H00 stabilization window (60s accumulate → freeze via `stable_at`)
- [ ] Implement write-coalescing buffer (flush every 15s or on hour transition)
- [ ] Implement FK race mitigation (treatment_confirmed flag + packet buffer)
- [ ] Demote `last_hour_label` to read-only cache for OC dedup only
- [ ] Remove `h00_saved` flag (replaced by `stable_at` mechanism)

### Phase 3: Backfill Importer

- [ ] Extract `HistoricalBackfillImporter` class
- [ ] Reuse projector math, isolate orchestration from live path
- [ ] Set `source = 'BACKFILL'` on all created rows
- [ ] Disable recovery during backfill runs

### Phase 4: Hardening & QA

- [ ] Fast replay: 6h+ raw file at max speed → H00-H06 correct
- [ ] Replay with intentional packet gaps → GAP rendered correctly
- [ ] Replay with device downtime → no fake rows
- [ ] Repeated order changes in single hour → single OC or cooldown-grouped
- [ ] Forced snapshot save failure → next packet recreates correct slot
- [ ] Live ingest immediately after backfill → no contamination
- [ ] Startup with stale `IN_PROGRESS` rows vs clean replay mode

---

## 10. Acceptance Criteria

| Scenario                        | Expected                                                 | Source of Truth               |
| ------------------------------- | -------------------------------------------------------- | ----------------------------- |
| 6h replay at max speed          | H00-H06 created, no H00 clamp                            | `hour_slot` formula           |
| Telemetry spans H00, H01, H04   | Only those 3 rows stored, frontend shows GAP for H02/H03 | DB rows + frontend render     |
| Order change between H02-H03    | OC_XX appears, does NOT fill hourly gap                  | Separate projector            |
| First hourly write FK fails     | Next packet still creates correct slot                   | Deterministic `hour_slot`     |
| Backfill completes, live starts | Live path unaffected by backfill state                   | Separate importer             |
| Backend restart mid-treatment   | Recovery rebuilds correct state from DB                  | `hour_slot` + `source` column |

---

## 11. Backward Compatibility

If full implementation cannot ship immediately, apply this **minimum safety patch**:

1. Keep `pkt_time` fallback instead of `now()` ✅ (already done)
2. Remove all backend gap-fill ✅ (verify)
3. Ensure hourly creation uses **computed** `hour_label` every packet (not cache)
4. Never let OC logic overwrite hourly state ✅ (already separated)
5. Disable recovery during backfill runs

This is weaker than the full design but significantly safer than the current mixed pipeline.

---

## 12. Mirth Transform Integration Analysis

### 12.1 Current Mirth Stress Test Transform

The Mirth channel uses a "MAX SPEED" transform that:

1. Extracts `machine_id` from `s_header`
2. Preserves **original timestamp** from data (`s_header.timestamp`)
3. Formats `device_id` as `PF_XXX`
4. Sends at maximum TPS (`Thread.sleep` removed)

### 12.2 Impact on Snapshot Architecture

| Aspect                               | Impact                                | Spec Coverage |
| ------------------------------------ | ------------------------------------- | ------------- |
| Max speed = all packets in seconds   | `hour_slot` deterministic → ✅ Safe   | §6.1          |
| Original timestamp preserved         | `pkt_time` = clinical time → ✅ Safe  | §6.1          |
| No delay between packets             | No arrival-speed dependency → ✅ Safe | §4 Non-goals  |
| `is_live` flag in `process_packet()` | Backend separates sessions → ✅ Safe  | §7.1          |

### 12.3 🔴 CRITICAL: `originalTime` Fallback Risk

```javascript
output.meta.timestamp = originalTime || new Date().toISOString();
```

**Problem:** If `s_header.timestamp` is missing/null, Mirth falls back to `new Date().toISOString()` (wall clock). During max-speed replay:

- 1000 packets arrive within 2 seconds
- All get `timestamp = 2026-04-05T21:22:xx`
- `hour_slot = floor((21:22 - treatment_start) / 3600)` → ALL map to **same slot**
- Treatment gets ONE hourly row instead of H00-H06

**Severity:** 🔴 HIGH — silently destroys historical snapshot accuracy.

**Fix required in Mirth transform:**

```javascript
if (!originalTime) {
  channelMap.put("skipMessage", true);
  logger.error("REJECTED: No original timestamp — cannot use wall clock");
  return false;
}
output.meta.timestamp = originalTime;
output.header.timestamp = originalTime;
```

**Rule:** Mirth MUST reject packets without original timestamps during stress test / backfill. Fabricating wall-clock timestamps for historical data is a **clinical data integrity violation**.

### 12.4 🟡 Backfill Mode Detection

**Current flow:**

```
Mirth Channel → HTTP POST /api/packet → recorder.process_packet(is_live=???)
```

**Question:** How does backend distinguish stress-test backfill from live?

**Required:** Add explicit mode signal in Mirth output:

```javascript
output.meta.mode = "BACKFILL"; // ← ADD to Mirth stress test transform
```

Backend should read this and route to `_backfill_sessions`:

```python
is_live = meta.get("mode", "LIVE") != "BACKFILL"
```

Without this, stress test packets enter the LIVE path → contaminate live session state → causes bugs that look like "random" snapshot corruption.

### 12.5 Mirth Transform Compliance Checklist

- [ ] Remove `new Date().toISOString()` fallback → reject if no `originalTime`
- [ ] Add `output.meta.mode = "BACKFILL"` for stress test channel
- [ ] Verify `s_header.timestamp` format matches backend `_parse_time()` expectations
- [ ] Test: replay 6h file at max TPS → verify H00-H06 created (not just H00)

---

_Approved and issued by CTO Agent — 2026-04-05T21:22+07:00_
_Grade: A — All known edge cases and Mirth integration risks covered._
