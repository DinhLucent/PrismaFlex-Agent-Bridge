# Data Pipeline Codebase As-Built

Last reviewed on branch: `cto/task-106-treatment-overhaul`

This document describes the current end-to-end telemetry pipeline as it is implemented in the overhaul branch, not just the intended target architecture.

It is written as a handoff map for backend, QA, and future AI agents.

---

## 1. High-Level Pipeline

There are now two ingestion modes:

1. `LIVE`
2. `BACKFILL`

Both start from Mirth-normalized telemetry JSON and end in PostgreSQL journal/projection tables plus raw chunk files.

```mermaid
flowchart TD
    A["Decoded PrismaFlex packet"] --> B["Mirth LIVE channel"]
    A --> C["Mirth BACKFILL channel"]

    B --> D["POST /api/v1/telemetry/live"]
    C --> E["POST /api/v1/telemetry/backfill"]

    D --> F["live_queue"]
    E --> G["backfill_queue"]

    F --> H["live_worker x4"]
    G --> I["backfill_worker x2"]

    H --> J["TreatmentRecorderService (live sessions)"]
    H --> K["TreatmentSnapshotService"]
    H --> L["EventService / SmartAlarmService / TrendDatabase / WebSocket"]

    I --> M["TreatmentRecorderService (backfill sessions)"]
    I --> N["HistoricalBackfillImporter"]

    J --> O["PostgresTreatmentDB"]
    K --> O
    M --> O
    N --> O

    J --> P["RawDataStreamer"]
    M --> P

    O --> Q["treatments / treatment_journal_rows / projection / review / audit"]
    P --> R["raw chunk files + raw_packet_manifest"]
```

---

## 2. Mirth Layer

### 2.1. Exported channels

- `channels_MIRTH/PrisInfoSys_BACKFILL.xml`
- `channels_MIRTH/PismaInfoSys_LIVE.xml`

### 2.2. What Mirth does

Mirth is currently a transport normalizer, not a clinical logic engine.

It should:

- parse raw JSON
- require `machine_id`
- require original timestamp
- normalize `device_id`
- preserve `header/body/parameters`
- tag mode metadata
- forward to backend HTTP endpoint

### 2.3. Current BACKFILL channel

BACKFILL channel currently posts to:

- `/api/v1/telemetry/backfill`

And adds metadata such as:

- `meta.mode = "BACKFILL"`
- `meta.transform_version = "mirth_backfill_v2"`
- `meta.ingest_profile = "historical_replay"`
- `meta.timestamp_source`
- `meta.replay_source`

### 2.4. Current LIVE channel

LIVE channel currently posts to:

- `/api/v1/telemetry/live`

And adds:

- `meta.mode = "LIVE"`
- `meta.ingest_profile = "realtime"`

Current note:

- LIVE metadata naming still appears to contain copy-paste traces from backfill naming and should be cleaned for operational clarity.

---

## 3. Backend Entry Point

### 3.1. Main router

File:

- `backend/main.py`

This file now owns:

- application startup/shutdown
- queue creation
- worker startup
- telemetry route split
- mode lock
- handoff API

### 3.2. Startup objects in `lifespan()`

`backend/main.py` creates:

- `app.state.live_queue`
- `app.state.backfill_queue`
- `app.state.treat_db`
- `app.state.streamer`
- `app.state.recorder`
- `app.state.snapshot_svc`
- `app.state.backfill_importer`
- `app.state.live_workers`
- `app.state.backfill_workers`

### 3.3. Device mode lock

In-memory registry:

- `device_mode_registry: Dict[str, str]`

Purpose:

- same `device_id` cannot be in `LIVE` and `BACKFILL` simultaneously
- live endpoint rejects when device is locked to backfill
- backfill endpoint rejects when device is locked to live

This is operationally important during cutover.

---

## 4. Live Path

### 4.1. Route

- `POST /api/v1/telemetry/live`

Responsibilities:

- validate mode conflict
- mark device as `LIVE`
- compute quality metadata
- enqueue packet into `live_queue`
- send fast dashboard broadcast packet

### 4.2. Worker

Function:

- `live_worker()` in `backend/main.py`

Responsibilities:

1. read packet from `live_queue`
2. enrich header/parameters using reference DB
3. collect active alarms
4. broadcast websocket updates
5. call `TreatmentRecorderService.process_packet(..., is_live=True)`
6. call `TreatmentSnapshotService.process_packet(...)`
7. save trends
8. process alarms
9. detect parameter changes using `EventService`
10. if order-related PIDs changed, call `save_order_change_snapshot()`

### 4.3. Live-only side effects

These happen only in live path:

- websocket broadcast
- fast dashboard packet
- alarm processing
- trend storage
- event tracking
- order-change trigger from event engine

---

## 5. Backfill Path

### 5.1. Route

- `POST /api/v1/telemetry/backfill`

Responsibilities:

- validate mode conflict
- mark device as `BACKFILL`
- enqueue packet into `backfill_queue`

### 5.2. Worker

Function:

- `backfill_worker()` in `backend/main.py`

Responsibilities:

1. read packet from `backfill_queue`
2. reject if packet has no timestamp
3. call `TreatmentRecorderService.process_packet(..., is_live=False)` to resolve treatment/session ownership
4. derive `start_time` from recorder backfill session
5. call `HistoricalBackfillImporter.process_packet(...)`

### 5.3. Backfill-only design intent

Backfill path intentionally avoids:

- websocket broadcast
- alarm processing
- trend storage
- event tracking
- live `DeviceCache`

### 5.4. Important current reality

Backfill path is not fully stateless:

- it still depends on `TreatmentRecorderService`
- recorder still owns `_backfill_sessions`
- importer owns its own `_batch_cache`

So the current implementation is separated from live, but not purely functional/deterministic yet.

---

## 6. Treatment Session Layer

### 6.1. Module

- `backend/services/treatment/treatment_recorder.py`

### 6.2. Core role

This is the session/treatment boundary engine.

It decides:

- when a treatment opens
- when a treatment resumes
- when it closes
- whether the packet belongs to old or new treatment
- whether same patient should continue same record

### 6.3. In-memory maps

- `_sessions`: live sessions
- `_backfill_sessions`: backfill sessions

### 6.4. Main entry

- `process_packet(device_id, timestamp, header, body, meta, is_live)`

It returns the `treatment_id` that owns the packet.

That return value is then used by:

- raw streaming
- snapshot projection

### 6.5. Core rules implemented here

- open on therapy statuses `{4, 5}`
- close on different patient
- close on `END`
- close on runtime reset
- support same-patient resume
- support recent-session resumption
- support backfill-to-live promotion

### 6.6. Startup recovery

Method:

- `_recover_from_db()`

This restores `IN_PROGRESS` treatments into live session memory on server restart.

Important:

- this recovery logic is for live sessions
- backfill behavior is still routed through the same recorder class, just with a separate in-memory map

---

## 7. Hourly Snapshot Projection

### 7.1. Live snapshot service

Module:

- `backend/services/treatment/treatment_snapshot_service.py`

### 7.2. Role

This is the live path projector from telemetry packets to journal rows.

It maintains:

- per-device `DeviceCache`
- latest PID-derived values
- live H00/Hxx progression
- order-change snapshots

### 7.3. Important concepts

- `CRRT_PID_MAP`: PID -> journal column map
- `ORDER_CHANGE_PIDS`: PIDs that can trigger `OC_XX`
- `PID_SCALE_MAP`: numeric scaling for telemetry values

### 7.4. Live cache object

`DeviceCache` stores:

- `values`
- `last_hour_label`
- `treatment_id`
- `start_time`
- `last_pkt_time`
- `h00_saved`

### 7.5. Live snapshot responsibilities

- extract relevant PIDs from telemetry
- compute treatment-relative hour label
- keep H00 baseline logic
- save H01+ on hour change
- save `OC_XX` for order changes

### 7.6. Current live semantics

- no backend smart gap fill
- missing `Hxx` should be rendered as gap by frontend
- `snapshot_time` is persisted in journal rows

---

## 8. Historical Backfill Projection

### 8.1. Module

- `backend/services/treatment/historical_backfill_importer.py`

### 8.2. Current role

This is the dedicated historical hourly projector.

It owns:

- `_batch_cache`
- `_device_map`

### 8.3. Current algorithm

For each packet:

1. compute `elapsed = packet_time - treatment_start`
2. compute `hour_num = floor(elapsed / 3600)`
3. accumulate PID-derived values into cache for that hour slot
4. when hour slot changes, flush previous slot as one `Hxx` row

### 8.4. Flush behavior

`flush_treatment()` writes one journal row through:

- `PostgresTreatmentDB.upsert_snapshot(...)`

with:

- `row_code = Hxx`
- `hour_slot = hour_num`
- `source = BACKFILL`

### 8.5. Important current limitation

Backfill importer currently projects hourly rows only.

It does not currently own a historical order-change projection engine.

That means the new backfill path is not yet a full semantic replacement for the combined live journal path if historical `OC_XX` reconstruction is required.

---

## 9. Raw Telemetry Storage

### 9.1. Module

- `backend/services/treatment/raw_streamer.py`

### 9.2. Role

This module writes raw packets to append-only chunk files and registers chunk metadata in PostgreSQL.

### 9.3. Core responsibilities

- open/rotate `treatment_{id}_chunkNNN.jsonl`
- append JSONL packet lines
- register manifest entries in `raw_packet_manifest`
- mark chunks `ACTIVE` or `CLOSED`

### 9.4. Important coupling

Both live and backfill currently stream raw packets through `TreatmentRecorderService`, which calls `RawDataStreamer`.

So raw storage is shared by both modes.

### 9.5. Current implementation note

Manifest timestamps are derived from top-level packet fields in `RawDataStreamer`, while recorder currently streams packets shaped as:

- `meta`
- `s_header`
- `s_body`

This should be reviewed carefully because chunk manifest timestamps can be lost if the streamer does not read `meta.timestamp`.

---

## 10. Postgres Adapter Layer

### 10.1. Module

- `backend/services/treatment/postgres_treatment_db.py`

### 10.2. Role

This is the bridge between legacy service code and SQLAlchemy/PostgreSQL.

It still presents many methods using the old `TreatmentDatabase` mental model.

### 10.3. Responsibilities

- create/update/delete treatment
- log status events
- upsert list projection
- upsert journal rows
- fetch snapshots
- recover latest snapshot / H00 existence
- support raw SQL compatibility with `fetch_one/fetch_all/execute`

### 10.4. Journal row upsert

Method:

- `upsert_snapshot(...)`

It now supports:

- `hour_slot`
- `source`
- `row_kind`
- immediate stabilization for `BACKFILL` and `ORDER_CHANGE`

### 10.5. Legacy compatibility still present

Methods:

- `fetch_one()`
- `fetch_all()`
- `execute()`

These convert SQLite-style `?` placeholders to named SQL params for PostgreSQL.

This helps migration, but also means parts of the codebase still think in "legacy adapter" terms.

---

## 11. Database Models Relevant to Pipeline

Core SQLAlchemy models used directly in this pipeline:

- `backend/db/postgres/models/treatments.py`
- `backend/db/postgres/models/treatment_journal_rows.py`
- `backend/db/postgres/models/treatment_status_events.py`
- `backend/db/postgres/models/treatment_list_projection.py`
- `backend/db/postgres/models/raw_packet_manifest.py`
- `backend/db/postgres/models/treatment_review_state.py`
- `backend/db/postgres/models/snapshot_originals.py`
- `backend/db/postgres/models/snapshot_audit_log.py`
- `backend/db/postgres/models/treatment_notes.py`

### Most critical table

- `treatment_journal_rows`

Important columns:

- `row_code`
- `row_kind`
- `hour_slot`
- `snapshot_time`
- `stable_at`
- `source`
- wide-row telemetry/manual fields

---

## 12. Frontend Touchpoint

The backend pipeline ultimately feeds the treatment journal UI.

Key frontend file touched by this area:

- `frontend/app/(main)/treatments/DetailPanel.tsx`

Frontend expectations:

- rows arrive already merged and ordered
- missing hourly rows should be interpreted as display gaps
- hourly rows and OC rows must coexist in one timeline

---

## 13. Operational and QA Utilities

Observed helper scripts in this branch:

- `backend/scripts/check_backfill.py`
- `backend/scripts/db_check.py`
- `backend/tools/check_snapshots.py`
- `backend/scripts/reset_treatments.py` (used operationally elsewhere in the repo)

These are operational aids, not core runtime modules.

---

## 14. Current Review Notes

These are the most important "as-built" notes from this review pass.

### 14.1. Good progress

- Live/backfill route split exists in code
- Separate queues and workers exist
- Device mode lock exists
- Dedicated historical importer exists
- Journal schema now has `hour_slot` and `source`
- Exported Mirth channel files are present in repo

### 14.2. Important remaining gaps

1. Backfill path currently reconstructs hourly rows, but not a dedicated historical `ORDER_CHANGE` path.
2. Importer cache is flushed on handoff per device, but shutdown path does not currently flush importer cache globally.
3. `RawDataStreamer` should be checked carefully for chunk timestamp extraction because streamed packets store timestamps under `meta`, not necessarily top-level fields.
4. LIVE Mirth channel metadata naming should be cleaned so operational tracing is not confusing.

---

## 15. Suggested Reading Order For New Engineers

If you are onboarding into this pipeline, read in this order:

1. `docs/mirth/MIRTH_BACKFILL_STEP_01_RAW_TO_TRANSFORM.md`
2. `docs/mirth/MIRTH_BACKFILL_LIVE_SPLIT_SPEC.md`
3. `docs/mirth/MIRTH_BACKFILL_STEP_02_BACKEND_INGEST_SPLIT.md`
4. `backend/main.py`
5. `backend/services/treatment/treatment_recorder.py`
6. `backend/services/treatment/treatment_snapshot_service.py`
7. `backend/services/treatment/historical_backfill_importer.py`
8. `backend/services/treatment/raw_streamer.py`
9. `backend/services/treatment/postgres_treatment_db.py`
10. `backend/db/postgres/models/treatment_journal_rows.py`

---

## 16. One-Sentence System Summary

The overhaul branch now has a real split between `LIVE` and `BACKFILL` ingestion, but the backfill pipeline is currently a partial historical projector centered on hourly snapshot reconstruction and still needs final hardening to become a full semantic mirror of the live journal path.
