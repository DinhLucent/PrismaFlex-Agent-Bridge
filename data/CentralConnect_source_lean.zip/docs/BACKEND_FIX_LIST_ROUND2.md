# Backend Fix List — Round 2

**Owner:** `backend-agent`  
**Issued by:** `cto-agent` @ 2026-04-04T12:02  
**Rule:** Fix in this order. Do not skip. Return files changed + proof.

---

## Fix 1: Kill remaining `fetch_one` in snapshot service

**File:** `backend/services/treatment/treatment_snapshot_service.py`

Two raw SQL calls remain:

```
Line 390: self._db.fetch_one("SELECT start_time FROM treatments WHERE id = ?", (treatment_id,))
Line 425: self._db.fetch_one("SELECT start_time FROM treatments WHERE id = ?", (treatment_id,))
```

**Action:** Replace both with `self._db.get_treatment_by_id(treatment_id)` and extract `start_time` from the returned dict. Remove `_get_treatment_start()` method entirely if it becomes redundant.

---

## Fix 2: Audit old/new capture (Gate-5)

**File:** `backend/db/postgres/services/journal_command_service.py`

**Requirement:**

- In `edit_journal_row()`: read the row's current values BEFORE applying mutations.
- Write old_value (pre-mutation) and new_value (post-mutation intent) to `SnapshotAuditLog`.
- Restore actions must also produce correct audit deltas.

---

## Fix 3: Replace `str(result)` placeholders (Gate-6)

**File:** `backend/routers/treatment_command_router.py`

```
Line 238: return {"status": "ok", "data": str(result)}
Line 254: return {"status": "ok", "data": str(result)}
```

**Action:** Return structured JSON. At minimum: serialize `result` dict directly (it's already a dict from the service layer). Remove `str()` wrapper.

---

## Fix 4: V2 edit policy enforcement (Gate-4)

**File:** `backend/routers/treatment_command_router.py` or `journal_command_service.py`

**Requirements for `edit_snapshot_values`:**

- Verify target row exists → 404 if not
- Verify row is not frozen (belongs to a finalized/approved treatment) → 409 Conflict
- Enforce field allowlist (only manual clinical fields, reject telemetry field injection)

---

## After Fixes: Operational Verification

```bash
# 1. Bootstrap DB schema
cd backend
python setup_db.py
alembic upgrade head

# 2. Verify tables exist
psql -c "SELECT * FROM alembic_version;"
psql -c "SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name;"

# 3. Start backend, confirm zero errors
python -m uvicorn app:app --reload
```

## Deliverable

Return:

1. Files changed (list)
2. Which `fetch_one` / `str(result)` removed
3. Audit capture proof (before/after in audit log)
4. Any remaining risk
