# Prismaflex Communication Protocol Specification
> Extracted and cleaned from Prismaflex® Communication Programmer's Guide Program version 8.XX

## 1. Communications Interfaces
- **Ethernet network port**:
  - Port `3001`: Status-messages
  - Port `3002`: Service-messages
  - Timeout: Drops stalled TCP connection after `20 ± 10` seconds.
- **RS232 Settings**:
  - Baud rate: `9600`
  - Data bits: `8`
  - Parity: `None`
  - Stop bits: `1`
  - Flow control: `None`
  - Sends out **Status messages** only.

## 2. S-message Structure
All S-message instances share the same structure definition: `header` and `body`.
- **Endianness**: Little-endian (little-units-first, i.e. Intel x86-type representation)

### 2.1 S-message Header Definition
| Field name | Type | Description |
|---|---|---|
| STX | Unsigned short (16 bit) | Start of text marker `0x0002` |
| CRC | Unsigned short (16 bit) | CRC16 calculation |
| MachID | Unsigned short (16 bit) | Machine ID `[0x0000 ; 0xffff]` |
| ClinicalSWID | Unsigned short (16 bit) | `0x0064` |
| MsgCounter | Integer (32 bit) | `0x00000000` |
| CmdCode | Integer (32 bit) | `0x00000000` |
| MsgInfo | Integer (32 bit) | Number of S-records in the message body |
| Flags | Integer (32 bit) | Message flags (Bitwise OR) |
| PatID | Unicode chars (20x32 bit) | Patient identifier |
| SWRevision | Integer (32 bit) | Software revision code |
| TherapyType | Integer (32 bit) | Therapy type enum |
| TherapyStatus | Integer (32 bit) | Therapy status enum |
| Time | Integer (32 bit) | Timestamp in Epoch seconds |
| MBL | Unsigned integer (32 bit) | Message body length in bytes (`MsgInfo * 12`) |

### 2.2 Message Flags
- `0x00000001` : STATUS_MESSAGE_FROM_PRISMAFLEX
- `0x00000002` : SERVICE_MESSAGE_FROM_PRISMAFLEX
- `0x10000000` : PWRFAIL_MESSAGE_FROM_PRISMAFLEX (Ignore message body if set)

### 2.3 CRC16 Calculation
```c
#define STX_CRC_LENGTH 4
#define POLY 0x8408

unsigned short int crc = 0;
for (int i = STX_CRC_LENGTH; i < (sizeof(MsgHeader) + data->i_message.header.message_length); i++) {
    unsigned short int ch = (unsigned short int) data->c_message[i];
    for (int j = 1; j <= 8; j++) {
        unsigned short int Q = (crc & 0x0001) ^ (ch & 0x0001);
        if (Q == 0x0001) {
            crc = (crc >> 1) ^ POLY;
        } else {
            crc = (crc >> 1);
        }
        ch = ch >> 1;
    }
}
```

### 2.4 Message Body: S-record Structure
No separator or terminator. Sequence of S-records:
```c
typedef struct { 
    unsigned int Param_code;
    unsigned int Time;
    int Measure_value;
} SRecord;
```
- **Param_code Mapping**:
  - Actual Value: `ID`
  - Set Value: `0x40000000 + ID`
  - Alarm Parameter: `0x80000000 + ID`
- **Measure_value**: Mantissa only. Apply scaling by factors dictated by the parameter's accuracy rule (e.g., accuracy 2 means divide by 100).

## 3. General Coding Conventions

### 3.1 Therapy Type Enum
| Section | Field name | Type | Description | Allowed values |
|---|---|---|---|---|
| Header | STX | Unsigned short (16 bit) | Start of text marker | 0x0002 |
|  | CRC | Unsigned short (16 bit) | Cyclic redundancy check, computed applying the standard CRC16 algorithm to the message portion that starts from the subsequent field and that extends to the end of the message. See Section 3.3.2 “CRC Calculation” on page 14. | any |
|  | MachID | Unsigned short (16 bit) | Prismaflex control unit identifier. It can be set via the Prismaflex user interface, in the Service Mode section. See Section 2.2.1 “MachID” on page 7. | [0x0000 ; 0xffff] |
|  | ClinicalSWID | Unsigned short (16 bit) | Clinical software identifier. Currently not used. | 0x0064 |
|  | MsgCounter | Integer (32 bit) | Message counter. Currently not used. | 0x00000000 |
|  | CmdCode | Integer (32 bit) | Command code. Currently not used. | 0x00000000 |
|  | MsgInfo | Integer (32 bit) | Message information. The number of S-records in the message body. | See Section 3.3.3 “Message Body: S-record Structure Definition” on page 15 |
|  | Flags | Integer (32 bit) | Message flags | See Section 3.3.4 “Message Flags” on page 15 |
|  | PatID | Unicode chars (20 x 32 bit) | Patient identifier | See Section 3.3.5 “Patient Identifier” on page 16 |
|  | SWRevision | Integer (32 bit) | Software revision. Represents the Prismaflex software revision code. | See Section 3.3.6 “Software Revision Encoding Convention” on page 16 |
|  | TherapyType | Integer (32 bit) | Therapy type. Represents the therapy selected for the currently delivered treatment. | See Section 5.1.1 “Therapy Type” on page 20 |
|  | TherapyStatus | Integer (32 bit) | Therapy status. Contains information about the status of the treatment. | See Section 5.1.2 “Therapy Status” on page 20 |
|  | Time | Integer (32 bit) | Contains the timestamp associated to the message, expressed in seconds elapsed from the Jan, 01 1970 midnight. | [0; 0x7FFFFFF] |
|  | MBL | Unsigned integer (32 bit) | Message body length | [0; 0x000017f4] |
| Body |  | Sequence of S-records |  | 0 or moreSRecords. |

### 3.2 Therapy Status Enum
| Output | Value | Field name | Description |
|---|---|---|---|
| 02 00 | 00 02 | STX (Header) | Start of text marker. |
| FF D9 | D9 FF | CRC (Header) | Cyclic redundancy check. |
| 0A 00 | 00 0A | MachID (Header) | Machine identifier. Settable in service - Calibration screen - External Communication Interface. In this example the ID = 10. |
| 64 00 | 00 64 | ClinicalSwID | Clinical software identifier. Currently not used. |
| 00 00 00 00 | 00 00 00 00 | MsgCounter | Message counter. Currently not used. |
| 00 00 00 00 | 00 00 00 00 | CmdCode | Command code. Currently not used. |
| 60 00 00 00 | 00 00 00 60 | MsgInfo (Header) | Message information. In this example there are 96 s-records in the message body. |
| 01 00 00 00 | 00 00 00 01 | Flags (Header) | This Flag indicate that it is a status message. |
| 2A 00 00 00 | 00 00 00 2A | PatID | The Patient identifier is entered in Setup mode. The Patient identifier is hidden by default (determined by a parameter in service mode). Configuration can be done in the Calibration section in service mode, in the Service - External Communication Interface screen. |
| 2A 00 00 00 | 00 00 00 2A |  |  |
| 2A 00 00 00 | 00 00 00 2A |  |  |
| 2A 00 00 00 | 00 00 00 2A |  |  |
| 2A 00 00 00 | 00 00 00 2A |  |  |
| 2A 00 00 00 | 11 00 00 2A |  |  |
| 2A 00 00 00 | 11 00 00 2A |  |  |
| 2A 00 00 00 | 11 00 00 2A |  |  |
| 2A 00 00 00 | 11 00 00 2A |  |  |
| 2B 00 00 00 | 11 00 00 2A |  |  |
| 2B 00 00 00 | 11 00 00 2A |  |  |
| 2B 00 00 00 | 11 00 00 2A |  |  |
| 2B 00 00 00 | 11 00 | SWRevision (Header) | Conversion from hex. to dec. gives value 8100200. The Prismaflex SW version is 8.10V02R00. Can be found in fifth technical screen on the Prismaflex control unit or in Service - Diagnose - SW Configuration. |
| 68 99 78 00 | 00 78 99 68 |  |  |
| 06 00 00 00 | 00 00 00 06 | TherapyType (Header) | Selected Therapy is NOT_CHOOSE. See table 5.1. |
| 00 00 00 00 | 00 00 00 00 | TherapyStatus (Header) | The Prismaflex control unit is in state IDLE. See Table 5.2. |
| 10 F5 41 55 | 55 41 F5 10 | Time (Header) | The message timestamp, expressed in seconds elapsed from Jan, 01 1970 midnight, also called Epoch time. Time stamp corresponds to time displayed on the Prismaflex control unit. In this example the timestamp is 1430385936 and the conversion gives Thu, 30 Apr 2015 09:25:36 GMT. |
| 80 04 00 00 | 00 00 04 80 | MBL (Header) | The length of the S-message&#x27;s body is 1152 bytes. (3x32 bit) x MsgInfo (96 S-records) = 1152 bytes. |
| 01 00 00 00 | 00 00 00 01 | 1st S-record (Body) | Param_code: 1 (ACCESS PRESSURE) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 500 mmHg. |
| 10 F5 41 55 | 55 41 F5 10 |  |  |
| F4 01 00 00 | 00 00 01 F4 |  |  |
| 02 00 00 00 | 00 00 00 02 | 2nd S-record (Body) | Param_code: 2 (FILTER.pressURE) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 500 mmHg |
| 10 F5 41 55 | 55 41 F5 10 |  |  |
| F4 01 00 00 | 00 00 01 F4 |  |  |
| 03 00 00 00 | 00 00 00 03 | 3rd S-record (Body) | Param_code: 3 (EFFLUENT.pressURE) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 500 mmHg |
| 10 F5 41 55 | 55 41 F5 10 |  |  |
| F4 01 00 00 | 00 00 01 F4 |  |  |
| 04 00 00 00 | 00 00 00 04 | 4th S-record (Body) | Param_code: 4 (RETURN.pressURE) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: -500 mmHg |
| 10 F5 41 55 | 55 41 F5 10 |  |  |
| OC FE FF FF | FF FF FE OC |  |  |
| 06 00 00 00 | 00 00 00 06 | 5th S-record (Body) | Param_code: 6 (TMP) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: -500 mmHg |
| 10 F5 41 55 | 55 41 F5 10 |  |  |
| OC FE FF FF | FF FF FE OC |  |  |
| 07 00 00 00 | 00 00 00 07 | 6th S-record (Body) | Param_code: 7 (DP) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 500 mmHg |
| 10 F5 41 55 | 55 41 F5 10 |  |  |
| F4 01 00 00 | 00 00 01 F4 |  |  |
| 3C 00 00 00 | 00 00 00 3C | 7th S-record (Body) | Param_code: 60 (BLOOD_VOL_PROCESSED) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 0 l |
| 10 F5 41 55 | 55 41 F5 10 |  |  |
| 00 00 00 00 | 00 00 00 00 | 9 th S-record (Body) | Param_code: 59 (RUN_TIME) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 0 s |
| C6 00 00 00 | 00 00 00 C6 | 8 th S-record (Body) | Param_code: 198 (EXCESS_PATIENT_FLUID_SIGN) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 0 ml |
| 10 F5 41 55 | 55 41 F5 10 |  |  |
| 00 00 00 00 | 00 00 00 00 |  |  |
| 3B 00 00 00 | 00 00 00 3B | 9 th S-record (Body) | Param_code: 59 (RUN_TIME) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 0 s |
| 10 F5 41 55 | 55 41 F5 10 |  |  |
| 00 00 00 00 | 00 00 00 00 |  |  |
| 5E 00 00 00 | 00 00 00 5E | 10 th S-record (Body) | Param_code: 94 (REPLACEMENT_PRE_CUMULATED) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 0 ml |
| 10 F5 41 55 | 55 41 F5 10 |  |  |
| 00 00 00 00 | 00 00 00 00 |  |  |

## 4. Parameters Dictionary

### 4.1 Numerical Parameters
| Value | Therapy type |
|---|---|
| 0 | SCUF |
| 1 | CVVH |
| 2 | CVVHD |
| 3 | CVVHDF |
| 4 | TPE |
| 5 | HP |
| 6 | NOT_CHOOSE |

### 4.2 Enumerative Parameters
| ID | Name and Description | Accu-racy(4) | Unit | MAXValue | MINValue | StatusMSG | ServiceMSG | Type | Note |
|---|---|---|---|---|---|---|---|---|---|
| 1 | ACCESSPRESSURE: actual value of the pressure at the access pod | 0 | mmHg | 500 | -500 | X | X | ACT |  |
| 2 | FILTERPRESSURE: actual value of the pressure at the filter pod | 0 | mmHg | 500 | -500 | X | X | ACT |  |
| 3 | EFFLUENTPRESSURE: actual pressure at the effluent pod | 0 | mmHg | 500 | -500 | X | X | ACT |  |
| 4 | RETURN PRESSURE: actual pressure at the return pod | 0 | mmHg | 500 | -500 | X | X | ACT |  |
| 5 | FIFTHPRESSURE: actual pressure at the 5th pod | 0 | mmHg | 500 | -500 | X | X | ACT |  |
| 6 | TMP: actual value of the transmembrane pressure | 0 | mmHg | 500 | -500 | X | X | ACT |  |
| 7 | DP: actual value of the pressure drop | 0 | mmHg | 500 | -500 | X | X | ACT |  |
| 8 | PUMP1: actual value of the rpm of the pre-blood pump | 2 | rpm | 250 | -250 |  | X | ACT |  |
| 9 | PUMP2: actual value of the rpm of the replacement pump | 2 | rpm | 250 | -250 |  | X | ACT |  |
| 10 | PUMP3: actual value of the rpm of the dialysate pump | 2 | rpm | 250 | -250 |  | X | ACT |  |
| 11 | PUMP4: actual value of the rpm of the effluent pump | 2 | rpm | 250 | -250 |  | X | ACT |  |
| 12 | BLOOD_RPM: actual value of the rpm of the blood pump. | 2 | rpm | 90 | -90 |  | X | ACT |  |
| 13 | SCALE1: actual value of the weight on the pre-blood scale | 0 | g | 15000 | -50 |  | X | ACT | (5) |
| 14 | SCALE2: actual value of the weight on the replacement scale | 0 | g | 15000 | -50 |  | X | ACT | (5) |
| 15 | SCALE3: actual value of the weight on the dialysate scale | 0 | g | 15000 | -50 |  | X | ACT | (5) |
| 16 | SCALE4: actual value of the weight on the effluent scale | 0 | g | 15000 | -50 |  | X | ACT | (5) |
| 17 | BLOOD_FLOW: blood flow set by user | 0 | ml/min | (*) | (*) | X | X | SET |  |
| 18 | REPLACEMENT_PRE_FLOW: replacement pre flow set by user | 0 | ml/hr | (*) | (*) | X | X | SET |  |
| 19 | REPLACEMENT_POST_FLOW: replacement post flow set by user | 0 | ml/hr | (*) | (*) | X | X | SET |  |
| 21 | DIALYSATE_FLOW: dialysate flow set by user | 0 | ml/hr | (*) | (*) | X | X | SET |  |
| 22 | PRE_BLOOD_FLOW: pre-blood flow set by user | 0 | ml/hr | (*) | (*) | X | X | SET |  |
| 23 | EFFLUENT_FLOW: effluent flow set by the Prismaflex control unit software on the base of the other flows set | 0 | ml/hr | (*) | (*) | X | X | SET |  |
| 24 | PT_WEIGHTBalance: Patient fluid removal flow set by user. | 0 | ml/hr | (*) | (*) | X | X | SET |  |
| 26 | PT_WEIGHT: patient weight. Operator enters this value together with Patient ID and Pre-Hematocrit value during start up. | 0 | kg | 999 | 0 | X | X | SET |  |
| 34 | BLD_NORM: normalization value of the BLD | 0 | none | (/) | (/) |  | X | ACT |  |
| 35 | BLD_SIGNAL: value of the BLD signal | 0 | none | (/) | (/) |  | X | ACT |  |
| 36 | BOLUS_VOL: anticoagulant bolus volume set by user | 1 | ml | 5 | 0 | X | X | SET |  |
| 37 | BOLUS_INTERVAL: anticoagulant bolus interval set by user | 0 | hr | 24 | 1 | X | X | SET |  |
| 38 | HEPARIN_CONT_RATE: anticoagulant continuous rate set by user | 1 | ml/hr | 5 | 0 | X | X | SET |  |
| 44 | UFR: ultrafiltration ratio. Value is calculated by the Prismaflex software. | 0 | % | 5000 | 0 | X | X | SET |  |
| 47 | PRE_HCT: Pre-Hematocrit value. Operator enters this value together with Patient ID and Patient weight during start up. | 0 | % | 60 | 10 | X | X | SET |  |
| 59 | CAL Runs_TIME: actual run time of the therapy | 0 | s | 10 000 000 | 0 | X | X | ACT |  |
| 60 | BLOOD_VOL_PROCESSSED: actual blood volume processed | 0 | I | 780 | 0 | X | X | ACT |  |
| 92 | NEXT_INTERV_HOURS: field about the hour of the next intervention | 0 | hr | (/) | (/) | X | X | ACT |  |
| 93 | NEXT_INTERV_MINUTES: field about the minutes of the next intervention | 0 | min | (/) | (/) | X | X | ACT |  |
| 94 | IO_HIST_PRE_REPL_WITHOUT_PBP_TOT: actual cumulated volume for replacement PRE (excluding PBP). Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml | (/) | (/) | X | X | ACT |  |
| 95 | IO_HIST_POST_REPL_TOT: Total Replacement volume Post delivered. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml | (/) | (/) | X | X | ACT |  |
| 97 | IO_HIST_DIAL_TOT: actual cumulated volume for dialysate. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml | (/) | (/) | X | X | ACT |  |
| 98 | IO_HIST_PBP_TOT: actual cumulated volume for pre-blood. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml | (/) | (/) | X | X | ACT |  |
| 99 | IO_HIST_EFFL_TOT: actual cumulated volume for effluent. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml | (/) | (/) | X | X | ACT |  |
| 100 | IO_HIST_PFR_TOT: actual cumulated volume for patient fluid removal. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml | (/) | (/) | X | X | ACT |  |
| 120 | ADC_PBP_SCALE: actual ADC value of the weight on pre-blood scale | 0 | none | 2147483647 | -2147483647 |  | X | ACT | (1) |
| 121 | ADC_REPL_SCALE: actual ADC value of the weight on replacement scale | 0 | none | 2147483647 | -2147483647 |  | X | ACT | (1) |
| 122 | ADC_DIAL_SCALE: actual ADC value of the weight on dialysate scale | 0 | none | 2147483647 | -2147483647 |  | X | ACT | (1) |
| 123 | ADC_EFFL_SCALE: actual ADC value of the weight on effluent scale | 0 | none | 2147483647 | -2147483647 |  | X | ACT | (1) |
| 124 | ADC_ACCESS_POD: actual ADC value of the access pressure | 0 | none | 2147483647 | -2147483647 |  | X | ACT |  |
| 125 | ADC_FILTER_POD: actual ADC value of the filter pressure | 0 | none | 2147483647 | -2147483647 |  | X | ACT |  |
| 126 | ADC_RETURN_POD: actual ADC value of the return pressure | 0 | none | 2147483647 | -2147483647 |  | X | ACT |  |
| 127 | ADC_EFLUENT_POD: actual ADC value of the effluent pressure | 0 | none | 2147483647 | -2147483647 |  | X | ACT |  |
| 128 | ADC_5TH_POD: actual ADC value of the 5th pod pressure | 0 | none | 2147483647 | -2147483647 |  | X | ACT |  |
| 145 | COUNTS_BLOOD_PUMP | 0 | none | 2147483647 | -2147483647 |  | X | ACT | (2) |
| 146 | COUNTS_PBP_PUMP | 0 | none | 2147483647 | -2147483647 |  | X | ACT | (2) |
| 147 | COUNTS_REPLACE_PUMP | 0 | none | 2147483647 | -2147483647 |  | X | ACT | (2) |
| 148 | COUNTS_DIAL_PUMP | 0 | none | 2147483647 | -2147483647 |  | X | ACT | (2) |
| 149 | COUNTS_EFLUENT_PUMP | 0 | none | 2147483647 | -2147483647 |  | X | ACT | (2) |
| 151 | BLD_OFF_SIGNAL: value of signal when the BLD is OFF | 0 | none | (/) | (/) |  | X | ACT |  |
| 152 | BLD_DIFFERENCE: difference between the signal in ON and in OFF condition | 0 | none | (/) | (/) |  | X | ACT |  |
| 153 | BLD_AVERAGE: average of Transmitter ON signal and transmitter OFF signal | 0 | none | (/) | (/) |  | X | ACT |  |
| 154 | PWM_NORM: PWM normalization value | 1 | % | (/) | (/) |  | X | ACT |  |
| 155 | PWM: PWM actual value | 1 | % | (/) | (/) |  | X | ACT |  |
| 156 | SYRINGE_COUNT: meter value of the encoder pulses of the syringe pump received during UP manual operation | 0 | counts | (/) | (/) |  | X | ACT |  |
| 157 | SYRINGE_RATE: speed of the syringe pump | 3 | mm/s | (/) | (/) |  | X | ACT |  |
| 168 | ADC_SYRINGE: ADC value of the force applied to the syringe pump. | 0 | none | 2147483647 | -2147483647 |  | X | ACT |  |
| 170 | SYRINGE FORCE_apPLIED: value of the force applied to the syringe pump | 0 | N | (/) | (/) |  | X | ACT |  |
| 171 | SYRINGE_OVL_threshold: value of the overload threshold of the syringe pump | 0 | N | (/) | (/) |  | X | ACT | (3) |
| 176 | ARPS.Reference_1: AD value of the voltage | 0 | none | (/) | (/) |  | X | ACT |  |
| 177 | ARPS.Reference_2: AD value of the voltage | 0 | none | (/) | (/) |  | X | ACT |  |
| 178 | ARPS.Reference_3: AD value of the voltage | 0 | none | (/) | (/) |  | X | ACT |  |
| 183 | ADC_24_VOLT: AD value of the voltage +24V | 0 | none | (/) | (/) |  | X | ACT |  |
| 184 | ADC_5_VOLT_VP: AD value of the voltage +5Vp | 0 | none | (/) | (/) |  | X | ACT |  |
| 185 | ADC_5_VOLT_VD: AD value of the voltage +5Vd | 0 | none | (/) | (/) |  | X | ACT |  |
| 186 | ADC_12_VOLT: AD value of the voltage +12V | 0 | none | (/) | (/) |  | X | ACT |  |
| 187 | ADC_5NEG_VOLT: AD value of the voltage -5V | 0 | none | (/) | (/) |  | X | ACT |  |
| 188 | SLOPE_OVL: slope value of the syringe pump | 0 | none | (/) | (/) |  | X | ACT |  |
| 189 | LOADThreshold: load threshold of the syringe pump | 0 | N | (/) | (/) |  | X | ACT |  |
| 192 | MAX_GAIN: max value of volume gain set by user | 0 | ml | 2000 | 0 | X | X | SET |  |
| 196 | EXCESS.Patient_FLUID_LIMIT: limit value for excess patient fluid loss or gain, in CRRT, set by user | 0 | ml | 400 | 100 | X | X | SET |  |
| 198 | EXCESS.Patient_FLUID_SIGN: signed actual value for patient excess fluid loss or gain, in CRRT. Positive value = GAIN Negative value = LOSS | 0 | ml | (/) | (/) | X | X | ACT |  |
| 400 | CITRATE_DOSE: citrate dose set by user | 1 | mmol/l | 6 | 0 | X | X | SET |  |
| 401 | CITRATE_CONCENTRATION: citrate concentration (excl. citric acid) of the used citrate solution | 0 | mmol/l | 600 | 10 | X | X | SET |  |
| 402 | CITRATE_SOL_CITR_ACID_CONC: citric acid concentration of the used citrate solution | 0 | mmol/l | 100 | 0 | X | X | SET |  |
| 403 | CITRATE_LOAD: citrate load | 1 | mmol/h | () | () | X | X | SET |  |
| 404 | CALCIUM_SYRINGE_RATE: calcium syringe flow rate | 1 | ml/hr | 100 | 2 | X | X | SET |  |
| 405 | CALCIUM_CONCENTRATION: calcium concentration of the calcium solution in the syringe | 0 | mmol/l | 1000 | 80 | X | X | SET |  |
| 406 | CALCIUM_COMPENSATION: calcium compensation set by user | 0 | % | 200 | 5 | X | X | SET |  |
| 407 | IO_HIST_SYRINGE_TOT: actual cumulated volume for infused syringe solution | 0 | ml | 21474 83647 | -21474 83647 | X | X | ACT |  |
| 408 | REPL_SOL_CA_CONC: Calcium concentration in used Replacement solution. | 2 | mmol/l | 1.75 | 0.00 | X | X | SET |  |
| 410 | EFFL_DOSE: Calculated Total Effluent dose | 0 | ml/kg/h | 21474 83647 | -21474 83647 | X | X | ACT |  |
| 412 | Filtration_FRACT: Calculated Filtration fraction value | 0 | % | 100 | 0 | X | X | SET |  |
| 413 | REPL_PRE_PERCENT: Replacement solution pre infused in blood circuit. Includes Pre Blood pump solution. | 0 | % | 100 | 0 | X | X | ACT |  |
| 414 | REPL_POST_PERCENT: Replacement solution post infused in blood circuit | 0 | % | 100 | 0 | X | X | ACT |  |
| 415 | CURRENT_FILTER_TIME: Run time for the disposable set currently in use, displayed in the Status screen | 0 | sec | 21474 83647 | 0 | X | X | ACT |  |
| 416 | IO_HIST_PFR_1HR_CHART: Patient fluid removal value per 1 hour. Reset every hour. | 0 | ml | 21474 83647 | -21474 83647 | X | X | ACT |  |
| 417 | IO_HIST_PFR_24HR_CHART: Patient fluid removal volume presented per 24 hour from beginning of chart time setting in custome mode. Default start time is 00:00. | 0 | ml | 21474 83647 | -21474 83647 | X | X | ACT |  |
| 418 | IO_HIST_PFR_1HR: Patient Fluid Removal volume per 1 hour sliding window | 0 | ml | 21474 83647 | -21474 83647 | X | X | ACT |  |
| 419 | IO_HIST_PFR_24HR: Patient fluid removal volume presented per 24 hour sliding window | 0 | ml | 21474 83647 | -21474 83647 | X | X | ACT |  |
| 420 | IO_HIST_UF_1HR: Ultra filtration rate per 1 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| Ultrafiltration volume = Total Replacement volume + Pre Blood Pump volume + Patient Fluid Removal volume |
| 421 | IO_HIST_UF_24HR: Ultra filtration rate per 24 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| Ultrafiltration volume = Total Replacement volume + Pre Blood Pump volume + Patient Fluid Removal volume |
| 422 | IO_HIST_UF_TOT: Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| Ultrafiltration volume = Total Replacement volume + Pre Blood Pump volume + Patient Fluid Removal volume |
| 423 | IO_HIST_UF_DOSE_1HR: Ultrafiltration dose | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| Per 1 hour sliding window |
| 424 | IO_HIST_UF_DOSE_24HR: Ultrafiltration dose | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| Per 24 hour sliding window |
| 425 | IO_HIST_UF_DOSE_TOT: Total Ultrafiltration dose. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0 | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 426 | IO_HIST_TOT_REPL_WITH_PBP_1HR: Total replacement volume delivered. Includes PBP volume. | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| Per 1 Hour sliding window |
| 427 | IO_HIST_TOT_REPL_WITH_PBP_24HR: Total replacement volume delivered. Includes PBP volume. | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| Per 24 hour sliding window |
| 428 | IO_HIST_TOT_REPL_WITH_PBP_TOT: Total replacement volume delivered. Includes PBP volume. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| From beginning of treatment |
| 429 | IO_HIST_TOT_REPL_WITH_PBP_DOSE_1HR: Replacement (incl Pre Blood Pump) dosePer 1 hour sliding window | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 430 | IO_HIST_TOT_REPL_WITH_PBP_DOSE_24HR: Replacement (incl Pre Blood Pump) dosePer 24 hour sliding window | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 431 | IO_HIST_TOT_HIST_REPL_WITH_PBP_DOSE_TOT: Total Replacement (incl Pre Blood Pump) dose. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 432 | IO_HIST_PRE_REPL_WITH_PBP_1HR: Total Replacement volume pre delivered including PBPPer 1 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 433 | IO_HIST_PRE_REPL_WITH_PBP_24HR: Total Replacement volume pre delivered including PBPPer 24 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 434 | IO_HIST_PRE_REPL_WITH_PBP_TOT: Total Replacement volume pre delivered including PBP. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 435 | IO_HIST_PRE_REPL_WITH_PBP_DOSE_1HR: Total Replacement dose pre delivered including Pre Blood PumpPer 1 hour sliding window | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 436 | IO_HIST_PRE_REPL_WITH_PBP_DOSE_24HR: Total Replacement dose pre delivered including Pre Blood PumpPer 24 hour sliding window | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 437 | IO_HIST_PRE_REPL_WITH_PBP_DOSE_TOT: Total Replacement dose pre delivered including Pre Blood Pump. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 438 | IO_HIST_POST_REPL_1HR: Total Replacement volume Post deliveredPer 1 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 439 | IO_HIST_POST_REPL_24HR: Total Replacement volume Post deliveredPer 24 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 440 | IO_HIST_POST_REPL_TOT: Do not use this ID. Use ID95.Total Replacement volume Post delivered.Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 441 | IO_HIST_POST_REPL_DOSE_1HR: Total Replacement dose Post deliveredPer 1 hour sliding window | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 442 | IO_HIST_POST_REPL_DOSE_24HR: Total Replacement dose Post deliveredPer 24 hour sliding window | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 443 | IO_HIST_POST_REPL_DOSE_TOT: Total Replacement dose Post delivered. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 444 | IO_HIST_EFFL_1HR: Total effluent volume per 1 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 445 | IO_HIST_EFFL_24HR: Total effluent volume per 24 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 446 | IO_HIST_EFFL_DOSE_1HR: Total effluent dosePer 1 hour sliding window | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 447 | IO_HIST_EFFL_DOSE_24HR: Total effluent dosePer 24 hour sliding window | 0 | ml/kg/h | 2147483647 | -2147483647 | X | X | ACT |  |
| 448 | IO_HIST_PBP_1HR: Total PBP volumePer 1 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 449 | IO_HIST_PBP_24HR: Total PBP volumePer 24 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 450 | IO_HIST_DIAL_1HR: Total Dialysate volumePer 1 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 451 | IO_HIST_DIAL_24HR: Total Dialysate volumePer 24 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 452 | IO_HIST_TOT_REPL_1HR: Total Replacement volumePer 1 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 453 | IO_HIST_TOT_REPL_24HR: Total Replacement volumePer 24 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 454 | IO_HIST_TOT_REPL_TOT: Total Replacement volume. Total volume from beginning of treatment.Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0. | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 455 | IO_HIST_SYRINGE_1HR: Total syringe volumePer 1 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 456 | IO_HIST_SYRINGE_24HR: Total syringe volumePer 24 hour sliding window | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 457 | IO_HIST_NUMBER_OFSETS_USED: Total number of sets used in the current treatment | 0 | piece | 10 | 0 | X | X | ACT |  |
| 458 | IO_HIST_PFR_1HR_PERIODIC_CHART: Cumulative value over the last completed period. This value shall be the same as the last completed periodic value displayed on the PFR screen in History. | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 459 | IO_HIST_PFR_24HR_PERIODIC_CHART: Cumulative value starting at the "Chart Begin Time" and up to the last completed hour. This value shall be the same as the last completed total value displayed on the PFR screen in History. | 0 | ml | 2147483647 | -2147483647 | X | X | ACT |  |
| 460 | POST_HCT: Post-filter Hematocrit | 0 | % | (/) | (/) | X | X | ACT |  |
| 461 | RUN_TIME: Treatment time excluding recirculation and stop time | 0 | sec | 10000000 | 0 |  | X | ACT |  |
| 462 | IO_HIST_TOT_PLASMA_TOT: Total Plasma volumeTotal volume from beginning of treatment | 0 | ml | 2147483647 | -2147483647 |  | X | ACT |  |
| 463 | SERIAL_NUMBER: Prismaflex serial number. It can be set via the Prismaflex user interface, in Calibration section in service mode, in screen Service - Serial Number. | 0 | none | 99999 | 0 | X | X | SET |  |
| 464 | MONITOR_ID_PDMS: Monitor ID | 0 | none | 2147483647 | -2147483647 |  | X | SET | (6) |
| 465 | ARPS_PRESSURE: actual pressure at the ARPS pod | 0 | mmHg | 500 | -500 |  | X | ACT |  |
| 466 | ADC_ARPS_POD: actual ADC value of the ARPS pressure | 0 | none | 2147483647 | -2147483647 |  | X | ACT |  |

## 5. Alarms Dictionary
Status: 1 = Alarm present, 2 = Alarm overridden

### 5.1 Warnings
| ID | Name | Value allowed | MAX Value | MIN Value | Status MSG | Service MSG | Type | Note |
|---|---|---|---|---|---|---|---|---|
| 296 | NEXT_INTERV ENUM : type of next intervention, displayed on the Status screen on the Prismaflex control unit. | 0 = effluent bag full1 = replacement bag empty2 = dialysate bag empty3 = replacement 2 empty4 = pre-blood bag empty5 = suggestion to normalize BLD6 = time to change set cause of usage time7 = prescription delivered8 = syringe empty | 8 | 0 | X | X | ACT |  |
| 350 | SYRINGE_OVERLOAD D: syringe pump overload type. | 0 = normal1= absolute overload | 1 | 0 |  | X | ACT |  |
| 409 | ANTICOAG_METHOD: Anticoagulation method selected by the user. | 0 = None, (No Anticoagulation)1 = Systemic, (Systemic (e.g. Heparin), Prismaflex syringe pump)2 = Cit/Cal, (Citrate/Calcium, External pump)3 = Cit/Cal, (Citrate/Calcium, Prismaflex syringe pump) | 3 | 0 | X | X | SET |  |
| 411 | FILTRO Selected disposable set by the user. | 0 = M101 = M602 = ST603 = HF204 = M1005 = ST1006 = M1507 = ST1508 = Oxiris9 = HF100010 = HF140011 = Septex12 = TPE100013 = TPE200014 = TPE2015 = TPE6016 = HPX0117 = HPX0218 = HPX0319 = HPX0420 = HPX0521 = MarsFlux0622 = MarsFlux2123 = None | 23 | 0 | X | X | ACT |  |
| 467 | PRISMALUNG_supp LEMENT: CRRT with PrismaLung supplement, set by user. | 0= PrismaLung not used1= PrismaLung used | 1 | 0 | X | X | SET |  |

### 5.2 Cautions
| Alarm value | Description |
|---|---|
| 1 | alarm present |
| 2 | alarm overridden |

### 5.3 Advisories
| ID | Name | Title |
|---|---|---|
| 1 | ALMW_BUBBLE_DETECT | Air in Blood |
| 2 | ALMW_Z_RET_PRESSURE | Return Disconnection |
| 3 | ALMW_RETPRESSUNDER_OP | Return Pressure Dropping |
| 4 | ALMW_FILTER_ZERO | Set Disconnection |
| 6 | ALMW_CLOTTED_FILTER | Filter Clotted |
| 7 | ALMW_CLOTTED_PLASMAFILTER | Plasmafilter Clotted |
| 8 | ALMW_HP_CLOTTED_FILTER | HP Cartridge Clotted |
| 9 | ALMW_BLOOD_LEAK | Blood Leak Detected |
| 10 | ALMW_H_RET_PRESSURE / ALMW_H_RETPRESSURE_RECOVERY | Return Extremely Positive |
| 11 | ALMW_H_RETPRESSURE_NO_RECOVERY | Return Extremely Positive |
| 12 | ALMW_L_ACCRESSURE / ALMW_L_ACCRESSURE_RECOVERY | Access Extremely Negative |
| 13 | ALMW_L_ACCRESSURE_NO_RECOVERY | Access Extremely Negative |
| 14 | ALMW_H_ACCRESSURE | Access Extremely Positive |
| 15 | ALMW_H_FIL_PRESSURE | Filter Extremely Positive |
| 16 | ALMW Runs_POWER_FAIL | Power Failure |
| 18 | ALMW_W Bags_FULL_PRIME | Bag Full – Effluent (Prime) |
| 19 | ALMW_D Bags Empty_PRIME | Bag/Container Empty – Dialysate (Prime) |
| Bag/Container Empty – Replacement 2 (Prime) |
| 20 | ALMW_R Bags Empty_PRIME | Bag/Container Empty – Replacement (Prime) |
| 21 | ALMW_P Bags Empty_PRIME | Bag/Container Empty – PBP (Prime) |
| 22 | ALMW_R_INCORRECT_PRIME Bags_volume | Bag Volume Incorrect – Replacement (Prime) |
| 23 | ALMW_D_INCORRECT_PRIME Bags_volume | Bag Volume Incorrect – Dialysate (Prime) |
| Bag Volume Incorrect – Replacement 2 (Prime) |
| 24 | ALMW_W_INCORRECT_PRIME Bags_volume | Bag Volume Incorrect – Effluent (Prime) |
| 25 | ALMW_P_INCORRECT_PRIME Bags VOLUME | Bag Volume Incorrect - PBP (Prime) |
| 26 | ALMW_R_PRIME_scale_OPEN | Scale Open - Replacement (Prime) |
| 27 | ALMW_D_PRIME Scale_OPEN | Scale Open - Dialysate (Prime) |
| Scale Open - Replacement 2 (Prime) |
| 28 | ALMW_W_PRIME_SCALS_OPEN | Scale Open - Effluent (Prime) |
| 29 | ALMW_P_PRIME_SCALS_OPEN | Scale Open - PBP (Prime) |
| 30 | ALMW_PRIME_LINE_PPI_CLAMPED | Clamped Lines - PBP |
| 31 | ALMW_PRIME_LINE_D_CLAMPED | Clamped Lines - Dialysate |
| Clamped Lines - Replacement 2 |
| 32 | ALMW_PRIME_LINERep_CLAMPED | Clamped Lines - Replacement |
| 33 | ALMW_PRIME_LINE_RETURN_CLAMPED | Clamped Lines - Return |
| 34 | ALMW_PRIME_LINE_EFFLRET_CLAMPED | Access Line is Obstructed |
| 35 | ALMW_PRIME_SYNRINGE_LINE_CLAMPED | Syringe Clamped |
| 38 | ALMW_PRIME_SYNRINGE EMPTY | Syringe Empty |
| 39 | ALMW_RIC_TIME_ELAPSED | Recirculation Time Exceeded |
| 40 | ALMW_TOOWeight_PUMP_ALM | Weight Alarm Not Cleared |
| 63 | ALMW_EFFLUENT_PRIME Bags VOLUME | Effluent Bag Incorrect |
| 262 | ALMW_setup_ERROR | Set-up error |
| 263 | ALMW_LINE_CROSSED_PBP_DIALOG | Crossed Lines Dialysate and PBP |
| 264 | ALMW_LINE_CROSSED_PBP Replica | Crossed Lines PBP and Replacement |
| 265 | ALMW_LINE_CROSSED_DIALOG Replica | Crossed Lines Dialysate and Replacement |
| 266 | ALMW_LINE_CROSSED_PBP_DIALOG Replica | Crossed Lines PBP, Dialysate and Replacement |
| 267 | ALMW_LINE_CROSSED_PBP Replica | Crossed Lines Repl. 2 and PBP |
| 268 | ALMW_LINE_CROSSED Replica | Crossed Lines Repl. 2 and Replacement |
| 269 | ALMW_LINE_CROSSED_PBP Replica | Crossed Lines PBP, Repl. 2 and Replacement |
| 270 | ALMW_BP_SEG_SIZE_LF_DETECTED Replica | Wrong Set Selected |
| 271 | ALMW_BP_SEG_SIZE_HF Detective Replica | Wrong Set Selected |
| 281 | ALMW_INCORRECT_DISPOSABLE_BARCODE | Wrong Set Loaded - Wrong Bar Code |
| 282 | ALMW_INCORRECT_DISPOSABLE_RECognition | Wrong Set Loaded - No recognition |
| 292 | ALMW_PRIME_CALCIUM_SYNRINGE emptied | Calcium Syringe Empty |
| 293 | ALMW_PRIME_CALCIUMLine_CLAMPED | Calcium Line Clamped |
| 294 | ALMW_PRIME_CALCIUMLine_NOT_CONNECTED | Calcium Line Not Connected |
| 307 | ALMW_PINCHVALVES_POS_INCORRECT_LOAD | Loading Error - Pinch valves position |
| 308 | ALMW_PINCHVALVES_POS_INCORRECT_UNLOAD | Unloading Error - Pinch valves position |
| 316 | ALMW_BATTERY_LOW | Battery Low |
| 317 | ALMW_UNSUIT_CA.sol | Unsuitable Ca Solution |
| 319 | ALMW_NOLine_IN_BLD | Effluent line not in BLD (Check that the line is correctly inserted alteratively clean the BLD) |
| 332 | ALMW_FLUID_LEAK_DETECTED | Fluid Leak Detected |
| 335 | ALMW_SYRINGE_LATCH | Syringe Plunger Not Secured |
| 337 | ALMW Lines_NOT_CLAMPED | Lines Not Clamped |

### 5.4 Malfunctions
| ID | Name | Title |
|---|---|---|
| 193 | ALMC_TOOWeight_PUMP_ALM | Unresolved Flow Problem |
| 194 | ALMC_W_INCORRECT_CHANGES | Flow Problem (Effluent) |
| 195 | ALMC_R_INCORRECT_CHANGES | Flow Problem (Replacement) |
| 196 | ALMC_PPI_INCORRECT_CHANGES | Flow Problem (PBP) |
| 197 | ALMC_D_INCORRECT_CHANGES | Flow Problem (Dialysate) |
| 198 | ALMC_TPE_PRESCRIPTION | TPE Prescription Delivered |
| 199 | ALMC_W_BAG_FULL | Bag Full (Effluent) |
| 200 | ALMC_D_BAG_empty | Bag Empty (Dialysate, Replacement Bag 2 Empty) (Variable tare) |
| 201 | ALMC_R_BAG_empty | Bag Empty (Replacement) (Variable tare) |
| 202 | ALMC_R_TPE_BAG_empty | Replacement Container Empty |
| 203 | ALMC_P_BAG_empty | Bag Empty (PBP) (Variable tare) |
| 204 | ALMC_MAX_UFR | TMP Excessive |
| 205 | ALMC_TPE_MAX_UFR | TMPa Excessive |
| 207 | ALMC_R_INCORRECT BagsVolumes | Bag Volume Incorrect - Replacement |
| 208 | ALMC_D_INCORRECT BagsVolumes | Bag Volume Incorrect - Dialysate Bag Volume Incorrect - Replacement 2 |
| 209 | ALMC_W_INCORRECT BagsVolumes | Bag Volume Incorrect - Effluent |
| 210 | ALMC_P_INCORRECT BagsVolumes | Bag Volume Incorrect - PBP |
| 211 | ALMC_R Scale_OPEN | Scale Open - Replacement |
| 212 | ALMC_D Scale_OPEN | Scale Open - Dialysate Scale Open - Replacement 2 |
| 213 | ALMC_W Scale_OPEN | Scale Open - Effluent |
| 214 | ALMC_P Scale_OPEN | Scale Open - PBP |
| 217 | ALMC_EFFLUENT Bags_volume | Effluent Bag Incorrect |
| 218 | ALMC_MAX_PTGAIN | Patient Fluid Gain Excessive |
| 219 | ALMC_D_fix_BAG_empty | Bag Empty (Dialysate) |
| Replacement Bag 2 Empty (Fixed tare) |
| 220 | ALMC_R_fix_BAG_empty | Replacement Bag Empty (Fixed tare) |
| 221 | ALMC_P_fix_BAG_empty | PBP Bag Empty (Fixed tare) |
| 222 | ALMC_EXCESSPATIENT_FLUID | Loss/Gain Limit Reached |
| 273 | ALMC_R2_INCORRECT_CHANGE | Flow Problem (Replacement 2) |
| 295 | ALMC_ANTIICOAG_SUSPENDED | Anticoagulation suspended |
| 296 | ALMC_EFF_ON_CLAMPING | Flow Problem (Effluent) |
| 297 | ALMCRep_ON_CLAMPING | Flow Problem (Replacement) |
| 298 | ALMC_PBP_ON_CLAMPING | Flow Problem (PBP Flow) |
| 299 | ALMC_DIA_ON_CLAMPING | Flow Problem (Dialysate) |
| 300 | ALMC_REP2_ON_CLAMPING | Flow Problem (Replacement 2) |
| 323 | ALMC_EFF_CONTROL_ERROR | Flow Problem (Effluent) |
| 324 | ALMC_REP_CONTROL_ERROR | Flow Problem (Replacement) |
| 325 | ALMC_PBP_CONTROL_ERROR | Flow Problem (PBP) |
| 326 | ALMC_DIA_CONTROL_ERROR | Flow Problem (Dialysis) |
| 327 | ALMC_REP2_CONTROL_ERROR | Flow Problem (Replacement 2) |
| 333 | ALMC_FLUID_LEAK_DETECTED | Fluid Leak Detected |

