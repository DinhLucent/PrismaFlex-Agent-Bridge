# Treatment Journal PostgreSQL QA Checklist

Updated: 2026-04-04  
Author perspective: CTO  
Audience: QA, tester, backend, fullstack, product review

## 1. Muc dich

Tai lieu nay dung de QA va tester kiem tung hang muc cua Treatment Journal sau dot chuyen doi tu SQLite sang PostgreSQL.

Muc tieu:

- liet ke cac tinh nang va co che quan trong cua Treatment Journal
- mo ta cong dung nghiep vu cua tung muc
- mo ta cach user thuc hien hoac cach he thong kich hoat
- danh gia mot muc la:
  - chu yeu chi doc/truy van du lieu
  - hay co business rules
  - hay co logic thuat toan / chronology / state machine
- ghi ro cac diem can test ky sau migration
- neu co tinh nang da bi policy moi han che, danh dau ro de tranh tester test sai luong chuan

## 2. Pham vi hien tai

Can phan biet 2 lop:

### 2.1 Luong user dang thay hien tai

Day la luong frontend dang dung chu yeu:

- `frontend/app/(main)/treatments/*`
- `frontend/app/(main)/treatments/review/page.tsx`
- `backend/routers/treatment_router.py`
- `backend/services/treatment/postgres_treatment_db.py`

No van la luong `/api/v1`, mang tinh chat "legacy-compatible", dang chay tren du lieu PostgreSQL nhung van con mot so endpoint CRUD/cu.

### 2.2 Luong target sau migration

Day la luong command-driven da duoc dung de harden PostgreSQL path:

- `backend/routers/treatment_command_router.py`
- `backend/db/postgres/services/journal_command_service.py`
- `backend/db/postgres/services/review_service.py`
- `backend/db/postgres/services/journal_query_service.py`

Luong `/api/v2` phan tach ro:

- query
- command
- role policy
- stable-row policy
- audit log

## 3. Chu giai phan loai co che

Su dung cac nhan sau trong cot "Loai co che":

- `DBQ`: chu yeu la doc/truy van/projection/serialization
- `BR`: business rule / policy enforcement
- `ALG`: thuat toan / chronology / dedup / session ownership
- `WF`: workflow / state machine / lifecycle
- `AUD`: audit / traceability / identity
- `IO`: export file / print / raw file / jsonl / excel

Cot `DB-only?` duoc hieu:

- `Yes`: gan nhu chi la doc/truy van/tra ket qua
- `Mixed`: vua query DB vua co format/sort/UI logic
- `No`: co policy, state machine, audit hoac thuat toan ro rang

## 4. Checklist Tong Hop

| ID | Tinh nang / co che | Cong dung | Cach thuc hien / kich hoat | Loai co che | DB-only? | Trang thai mong doi | QA/Test can xac nhan |
| --- | --- | --- | --- | --- | --- | --- | --- |
| TJ-01 | Treatment list/history + filter | Tim nhanh ho so dieu tri theo patient, device, date, outcome, approval status | Vao trang `/treatments`, dung o tim patient/device, loc theo ngay va outcome | `DBQ` + projection | Yes | Active | Ket qua list dung so luong, filter dung, date-to bao gom het ngay, phan trang dung |
| TJ-02 | Projection table cho list view | Tang toc list/history, giam join nang, tach list UI khoi bang journal chi tiet | He thong doc `treatment_list_projection` de hien list | `DBQ` + `WF` | Mixed | Active | List van nhanh, thong tin approval/note_count/outcome khop treatment that |
| TJ-03 | Detail panel journal timeline | Bac si/dieu duong xem toan bo Hxx va OC_XX theo thu tu lam sang | Tu list mo chi tiet 1 treatment | `DBQ` + UI chronology | Mixed | Active | Row hien dung thu tu, khong mat row, khong nhay H00/OC xuong cuoi sau refresh |
| TJ-04 | Gap placeholders (`Hxx` thieu hien `GAP`) | Cho user thay timeline lien tuc, nhin ra gio nao thieu row | Trong DetailPanel, frontend tu chen `gap rows` giua cac Hxx | `DBQ` + UI transform | Mixed | Active | Chi la hien thi, khong tao row that trong DB, gio thieu hien ro rang |
| TJ-05 | Auto H00 baseline | Luu baseline dau ca, lam moc lam sang ban dau | `TreatmentSnapshotService.process_packet()` tich luy 60s dau va save `H00` | `ALG` + `BR` | No | Active | H00 tao dung luc, khoa sau 60s, khong bi overwrite sai khi edit sau do |
| TJ-06 | Auto H01/H02/... hourly rows | Tao journal dinh ky moi gio theo treatment time | Khi packet di qua boundary 1 gio tinh tu `start_time`, service tao `Hxx` | `ALG` | No | Active | Moi gio chi co 1 row dung label, row_code khong trung, `snapshot_time` dung boundary lam sang |
| TJ-07 | Auto `OC_XX` order-change rows | Ghi nhan thay doi y lenh giua 2 moc gio, giu duoc can thiep lam sang | `save_order_change_snapshot()` khi PID order-change thay doi | `ALG` | No | Active | `OC_XX` chen dung vi tri theo `snapshot_time`, counter dung, khong spam row do flicker |
| TJ-08 | Anti-flicker / cooldown / dedup cho `OC_XX` | Chan order-change gia do packet dao gia tri, gop cac thay doi qua gan nhau | Kich hoat trong `save_order_change_snapshot()` | `ALG` | No | Active | Thay doi that moi tao `OC`, thay doi ao khong tao; trong 60s co grouping hop ly |
| TJ-09 | Immutable `snapshot_time` | Bao ve thu tu lam sang, tranh row "nhay gio" sau khi sua tay | Model Postgres va specs coi `snapshot_time` la immutable; v2 command khong cho sua | `BR` + `ALG` | No | Active critical | Edit/restore khong doi thoi gian lam sang cua row co san |
| TJ-10 | Stable-row policy | Chi cho sua row da on dinh, tranh va cham voi telemetry dang ghi | V2 `journal_command_service` check `stable_at` truoc khi edit/restore | `BR` | No | Target-active | QA can test row chua stable bi chan; row da stable moi sua duoc |
| TJ-11 | Treatment ownership / continuation logic | Dam bao raw packet, snapshot va boundary thuoc dung treatment | `TreatmentRecorderService` quyet dinh open/continue/close theo patient, status, RUN_TIME | `ALG` + `WF` | No | Active critical | Same patient + RUN_TIME > 0 tiep tuc T1; RUN_TIME = 0 mo T2; END van thuoc T1 |
| TJ-12 | Backfill -> live handoff | Khong de replay/backfill pha luong live va treatment ownership | `_handoff_backfill_to_live()` trong recorder | `ALG` + `WF` | No | Active critical | Same patient + RUN_TIME > 0 promote T1; khac patient hoac RUN_TIME=0 thi close backfill |
| TJ-13 | Operator check-in | Bat buoc gan ten nguoi thao tac cho moi mutation | Frontend `ensureOperator()` + header `X-Operator-Name`; backend `require_operator_name()` | `AUD` + `BR` | No | Active | Lan dau sua phai hoi operator; request thieu operator phai bi 400 |
| TJ-14 | Edit patient info | Sua thong tin hanh chinh/lam sang cua treatment | Trong detail, sua patient info; backend allowlist field | `BR` + `AUD` | No | Active | Chi sua duoc field duoc phep, treatment khoa/approved thi bi chan dung rule |
| TJ-15 | Edit existing row values | Luong sua tay chinh cua dieu duong/bac si tren row da ton tai | Click vao cell editable trong DetailPanel/review page | `BR` + `AUD` + `WF` | No | Active | Chi field cho phep moi editable, update co `updated_by`, khong doi chronology |
| TJ-16 | Field allowlist theo anticoag | Gioi han dung cac cot co the sua bang tay | Frontend chi mo EditableCell tren mot so cot; v2 backend co `NURSE_EDITABLE_FIELDS` | `BR` | No | Active but must verify | Heparin/Citrate hien dung cot; field telemetry nhu QB/QD/TMP khong duoc sua |
| TJ-17 | Row-level audit badge | Cho user biet row nao la AUTO, MANUAL, EDITED, RESTORED | DetailPanel / review page hien badge va `updated_by`, `updated_at` | `AUD` + `DBQ` | Mixed | Active | Row auto khong gan badge sai; row sua tay phai hien nguoi sua va gio sua |
| TJ-18 | Frozen originals for compare/review | Dong bang phien ban goc de bac si so sanh va khoi phuc | Khi submit review, backend `freeze_snapshots()` copy journal sang `snapshot_originals` | `WF` + `AUD` | No | Active critical | Submit xong originals ton tai day du, thu tu giong journal tai thoi diem submit |
| TJ-19 | Compare current vs original | Cho bac si review chenh lech sau khi nursing cleanup | Vao trang review, bat Compare | `DBQ` + diff UI | Mixed | Active | Gia tri da sua duoc highlight, gia tri goc hien chinh xac, originals khong bi mat |
| TJ-20 | Restore existing row to original | Dua row ve gia tri may goc ma khong xay lai timeline moi | Review page bam restore; target v2 dung `restore_existing_snapshot()` | `BR` + `AUD` + `ALG` | No | Active but sensitive | Restore dung gia tri goc, giu `snapshot_time`, khong doi vi tri `OC_XX/Hxx` |
| TJ-21 | Clinical notes append-only log | Ghi chu ca dieu tri theo dong lich su, co tac gia va gio | Mo Notes modal, nhap ten + noi dung, luu | `AUD` + `WF` | No | Active | Ghi chu luu them moi, khong sua/xoa, co author va timestamp ro rang |
| TJ-22 | Notes/history drawer | Gom note lam sang va status log de xem lich su treatment | Trong detail bam nut lich su | `DBQ` + UI merge/sort | Mixed | Active | Thu tu moi nhat -> cu nhat dung, system log co the an/hien, note khong mat |
| TJ-23 | Submit for review | Chuyen tu DRAFT sang doctor review, dong bang originals | Trong detail bam Submit for review | `WF` + `AUD` | No | Active critical | Khong submit duoc khi treatment con `IN_PROGRESS`, submit xong status dung, originals duoc freeze |
| TJ-24 | Approve treatment | Khoa ho so sau khi bac si dong y | Review page bam Approve | `WF` + `AUD` + role policy | No | Active critical | Chi doctor/admin approve duoc, approve xong journal bi khoa |
| TJ-25 | Reject treatment | Tra ho so ve trang thai can sua bo sung | Review page bam Reject + ly do | `WF` + `AUD` + role policy | No | Active critical | Ly do reject duoc luu, nurse nhin thay ghi chu reject, khong cho approve/reject sai state |
| TJ-26 | Unlock approved treatment | Mo khoa ho so da approved de chinh sua lai khi can | Trong detail/review bam Unlock | `WF` + `AUD` + role policy | No | Active critical | Chi doctor/admin unlock duoc; sau unlock UI phai mo dung trang thai cho correction |
| TJ-27 | Print preview | Cho bac si/in ho so journal theo dang xem | Trong detail bam Print | `DBQ` + `IO` | Mixed | Active | Ban in khop chronology dang xem, khong mat `OC_XX` |
| TJ-28 | Export JSON report | Xuat full report treatment cho doi chieu/luu tru | Trong detail/list bam Export | `DBQ` + `IO` | Mixed | Active | JSON co treatment/config/snapshots/notes/status_log day du |
| TJ-29 | Export Excel | Xuat journal de doi chieu offline | Trong detail/list bam Excel | `DBQ` + `IO` | Mixed | Active | Cot, thu tu row, gia tri so va label khop man hinh |
| TJ-30 | Raw export | Xuat raw JSONL/GZ forensic de audit sau nay | Trong detail bam Raw | `DBQ` + `IO` | Mixed | Active | File ton tai, fallback DB hoat dong neu file raw khong con, dung treatment owner |
| TJ-31 | Delete snapshot row | Xoa mem row khoi journal | Review page co nut xoa row | `BR` + `WF` + `AUD` | No | Restricted / risk | Chi doctor/admin moi duoc; can xac nhan co con nen xuat hien trong UI lam sang hay khong |
| TJ-32 | Manual fill gap / manual snapshot insert | Tao row tay cho gio thieu | Backend v1 co `POST /snapshots/manual`; UI routine da an | `BR` + `ALG` + `WF` | No | Hidden / policy-sensitive | QA can xac nhan luong nay KHONG con o UI routine nurse/doctor, neu test API thi danh dau la maintenance-only |
| TJ-33 | Bulk update snapshots | Sua hang loat row | Backend v1 con endpoint `PUT /snapshots-bulk`; UI routine khong thay | `BR` + mutation | No | Hidden / policy-sensitive | Khong duoc lo ra UI routine; neu van con accessible can danh dau la risk cao |
| TJ-34 | Delete entire treatment | Xoa ca treatment va raw files | UI list co delete treatment cho admin | `WF` + `IO` + policy | No | Restricted | Approved treatment phai khong xoa duoc; xoa xong phai clear cache va file raw dung |

## 5. Cac co che co thuat toan / lam sang can test ky nhat

Day la cac muc khong phai "chi truy van DB". Day la phan de vo nhat sau migration.

### 5.1 Ownership cua treatment

Can coi day la engine lam sang, khong phai list query.

Rule dich:

- same device + same patient + `RUN_TIME > 0` -> tiep tuc treatment cu
- patient doi hoac `RUN_TIME = 0` -> dong treatment cu, mo treatment moi
- packet `END` van thuoc treatment cu
- backfill va live khong duoc dong treatment cua nhau

Tai sao quan trong:

- sai ownership se keo theo sai journal
- sai raw export
- sai chronology
- sai approval boundary

### 5.2 Chronology

Treatment Journal khong duoc hoat dong nhu spreadsheet.

Phai dam bao:

- `snapshot_time` la moc lam sang
- `Hxx` di theo treatment timeline
- `OC_XX` chen vao giua theo thoi diem xay ra thuc
- edit/restore khong duoc day row xuong cuoi

### 5.3 State machine review

Can test dung state transition:

- `DRAFT` -> `PENDING_REVIEW`
- `PENDING_REVIEW` -> `APPROVED`
- `PENDING_REVIEW` -> reject
- approved -> unlock -> correction

Khong duoc:

- submit khi con recording
- nurse sua khi dang `PENDING_REVIEW`
- edit khi da approved ma chua unlock

### 5.4 Audit / operator traceability

Moi thay doi tay phai co:

- operator
- role
- action
- old/new value neu la field mutation

Neu khong dat:

- rui ro medico-legal rat cao
- bac si khong biet gia tri nao la may, gia tri nao do nguoi sua

## 6. Cac diem lech giua policy moi va implementation hien tai

Day la muc QA nen danh dau "risk" thay vi chi test pass/fail.

### 6.1 UI hien tai van chu yeu di qua `/api/v1`

Thuc te:

- frontend treatments page va review page dang goi `api/v1`
- `api/v2` da co nhung chua la main path

Y nghia:

- migration PostgreSQL da co hardening, nhung user-facing path chua dong bo 100%

### 6.2 `reject` va `unlock` khong dong nghia giua v1 va v2

`v1`:

- reject -> tra ve `DRAFT`
- unlock -> tra ve `PENDING_REVIEW`

`v2`:

- reject -> `REJECTED`
- unlock -> `DRAFT`

Day la inconsistency nghiem trong can QA/PM chot lai.

Neu khong chot:

- frontend list / badge / filter / doctor review se mo ta sai state
- tester de nham giua "rejected but locked" va "returned for nursing correction"

### 6.3 Structural actions van con ton tai o v1 backend

Backend v1 van con:

- `POST /snapshots/manual`
- `PUT /snapshots-bulk`
- `DELETE /snapshots/{hourLabel}`

Trong khi policy moi noi:

- khong dua structural timeline actions vao routine clinical UI

Y nghia:

- QA can xac nhan chung da bi an khoi main workflow
- neu con duoc expose cho nurse/doctor o UI routine thi can coi la regression/policy breach

### 6.4 Hai loai notes dang cung ton tai

Co 2 lop:

- mutable `clinical_notes`
- append-only `treatment_notes`

UI hien tai dang dung chu yeu modal append-only notes.

Y nghia:

- tester can xac nhan product muon giu ca 2 hay chi 1
- neu de ca 2 ma khong giai thich ro se gay nham lan cho user

### 6.5 v1 update snapshot van co tinh chat generic hon policy moi

`PUT /api/v1/treatments/{id}/snapshots/{hourLabel}`:

- hien tai frontend chi mo mot so cot editable
- nhung endpoint v1 van chua "hard command" bang v2

Y nghia:

- tester can test tu UI binh thuong
- backend QA nen them test API level de chac rang field cam khong bi sua duoc qua request tay

## 7. Checklist de QA/tester danh dau

- [ ] TJ-01 Treatment list/history + filter
- [ ] TJ-02 Projection table cho list view
- [ ] TJ-03 Detail panel journal timeline
- [ ] TJ-04 Gap placeholders
- [ ] TJ-05 Auto H00 baseline
- [ ] TJ-06 Auto Hxx hourly rows
- [ ] TJ-07 Auto OC_XX order-change rows
- [ ] TJ-08 Anti-flicker / cooldown / dedup cho OC_XX
- [ ] TJ-09 Immutable `snapshot_time`
- [ ] TJ-10 Stable-row policy
- [ ] TJ-11 Treatment ownership / continuation logic
- [ ] TJ-12 Backfill -> live handoff
- [ ] TJ-13 Operator check-in
- [ ] TJ-14 Edit patient info
- [ ] TJ-15 Edit existing row values
- [ ] TJ-16 Field allowlist theo anticoag
- [ ] TJ-17 Row-level audit badge
- [ ] TJ-18 Frozen originals for compare/review
- [ ] TJ-19 Compare current vs original
- [ ] TJ-20 Restore existing row to original
- [ ] TJ-21 Clinical notes append-only log
- [ ] TJ-22 Notes/history drawer
- [ ] TJ-23 Submit for review
- [ ] TJ-24 Approve treatment
- [ ] TJ-25 Reject treatment
- [ ] TJ-26 Unlock approved treatment
- [ ] TJ-27 Print preview
- [ ] TJ-28 Export JSON report
- [ ] TJ-29 Export Excel
- [ ] TJ-30 Raw export
- [ ] TJ-31 Delete snapshot row
- [ ] TJ-32 Manual fill gap / manual snapshot insert
- [ ] TJ-33 Bulk update snapshots
- [ ] TJ-34 Delete entire treatment

## 8. Nhan xet ca nhan cua CTO

## 8.1 Ve do hop ly lam sang

Minh danh gia huong hien tai la hop ly hon rat nhieu so voi mot "journal dang spreadsheet".

Diem dung:

- giu `snapshot_time` lam anchor lam sang
- tach treatment ownership bang patient/device/RUN_TIME thay vi chi dua vao UI
- giu `OC_XX` cho thay doi y lenh giua 2 moc gio
- co operator check-in va audit trail
- co review workflow nurse -> doctor

Doan nay la huong dung cho moi truong ICU vi:

- du lieu may phai la cot song
- con nguoi chi nen "correct", khong nen "tai tao timeline" qua de dang

## 8.2 Ve goc nhin bac si

Tu goc nhin bac si, 4 thu quan trong nhat la:

1. thu tu ca dieu tri phai dung
2. biet duoc gia tri nao may ghi, gia tri nao nguoi sua
3. de review nhanh thay doi truoc khi approve
4. approved roi thi phai that su khoa

He thong hien tai da tien gan dung 4 diem nay, dac biet la:

- compare view
- originals freeze
- row-level audit badge
- chronology fix

## 8.3 Ve trai nghiem nguoi dung

Voi dieu duong:

- detail panel dang kha tot neu muc tieu la xem nhanh journal va sua mot vai cot cho phep
- notes append-only la hop ly va de hieu
- operator check-in theo session la phu hop moi truong may tram dung chung

Voi bac si:

- review page co compare + restore + approve/reject la dung huong
- nhung van can lam ro hon state sau `reject` va sau `unlock`

## 8.4 Dieu minh thay chua on hoan toan

Co 4 diem minh cho rang can uu tien chot lai:

1. Khong nen de v1 va v2 song song lau trong review workflow
   - Vi reject/unlock dang khac nghia.

2. Khong nen de structural actions ton tai mo ho
   - Neu product policy la bo khoi luong clinical routine, thi API va UI cung nen dong bo.

3. Khong nen giu 2 mo hinh notes ma khong giai thich
   - `clinical_notes` va `append-only notes` de gay nham.

4. Backend phai la noi enforce allowlist that su
   - Khong nen chi tin vao frontend EditableCell.

## 8.5 Ket luan CTO

Tong the, chuong trinh dang di dung huong ve mat lam sang:

- co co so y nghia nghiep vu
- khong phai chi la "truy van co so du lieu"
- ma la mot he thong co:
  - chronology engine
  - session ownership logic
  - review governance
  - audit traceability

Neu chi nhin no nhu mot bai toan CRUD hay query DB thi se danh gia thieu.

Treatment Journal trong he thong nay thuc chat la:

- mot clinical workflow engine co backend policy,
- trong do PostgreSQL la source of truth moi,
- con QA/test can bao ve dung cac luat lam sang va chronology, khong chi so sanh API response.

## 9. Nguon tham chieu chinh

- `docs/TREATMENT_JOURNAL_SIMPLIFICATION_AND_HARDENING_SPEC.md`
- `docs/TREATMENT_SNAPSHOT_WORKFLOW.md`
- `docs/TREATMENT_SNAPSHOT_EDIT_POLICY_SPEC.md`
- `docs/TREATMENT_JOURNAL_AUDIT_VISIBILITY_SPEC.md`
- `docs/TREATMENT_DATA_PLATFORM_ARCHITECTURE_SPEC.md`
- `docs/treatment-logic-qa-sheet.md`
- `backend/services/treatment/treatment_recorder.py`
- `backend/services/treatment/treatment_snapshot_service.py`
- `backend/routers/treatment_router.py`
- `backend/routers/treatment_command_router.py`
- `backend/db/postgres/services/journal_command_service.py`
- `backend/db/postgres/services/review_service.py`
- `frontend/app/(main)/treatments/page.tsx`
- `frontend/app/(main)/treatments/DetailPanel.tsx`
- `frontend/app/(main)/treatments/review/page.tsx`
