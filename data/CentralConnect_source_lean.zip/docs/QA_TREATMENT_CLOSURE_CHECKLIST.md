# QA Checklist: Cơ Chế Tự Động Close Treatment (MVP)

Tài liệu này hướng dẫn QA test 4 cơ chế tự động kết thúc (close) ca lọc theo thiết kế Machine-Driven của MVP.

## 1. Nguyên Tắc Cốt Lõi

- **Tuyệt đối không có nút "End Treatment" trên UI** cho bất kỳ role nào (Nurse/Doctor/Admin).
- Trạng thái ca lọc (`IN_PROGRESS` -> `COMPLETED` / `TIMEOUT`) hoàn toàn do Machine/Backend quyết định dựa trên luồng dữ liệu (telemetry).
- Mọi kịch bản đóng ca phải đảm bảo Chronology của Journal không bị phá vỡ.

---

## 2. Test Cases (Positive)

### TC-1: Đóng ca lọc bằng packet END (Normal Flow)

Đây là luồng kết thúc ca lọc chuẩn xác do máy PrismaFlex chủ động báo cáo.

- **Tiền quyết (Pre-condition):** Một ca lọc đang chạy (State: `ĐANG CHẠY` / `IN_PROGRESS`).
- **Hành động (Action):** Giả lập máy phát một Data Packet có loại là `END` (End of Treatment) cho cùng cặp `device_id` + `patient_id`.
- **Kỳ vọng Backend:**
  - `outcome` chuyển thành `COMPLETED`.
  - `close_reason` = `NORMAL` (hoặc null tùy logic DB).
  - Packet `END` được chốt làm bản ghi Journal cuối cùng của ca đó.
- **Kỳ vọng Frontend:** Ca lọc đổi trạng thái thành `HOÀN THÀNH` trên Dashboard (không có cảnh báo lỗi).

### TC-2: Máy đổi Bệnh nhân khi đang chạy (Patient Change)

Xảy ra khi Điều dưỡng đổi thông tin bệnh nhân trực tiếp trên màn hình máy PrismaFlex mà quên End ca cũ.

- **Tiền quyết:** Ca lọc đang chạy với `patient_id = 'P-001'`.
- **Hành động:** Giả lập máy tiếp tục gửi packet mới nhưng với `patient_id = 'P-002'` (trên cùng `device_id`).
- **Kỳ vọng Backend:**
  - Treatment cũ (`P-001`) bị force-close: `outcome = COMPLETED`, `close_reason = 'PATIENT_CHANGED'`.
  - Ngay lập tức mở một Treatment UUID mới cho `P-002` chuẩn chronology.
- **Kỳ vọng Frontend:**
  - Ca `P-001` chuyển sang `HOÀN THÀNH`.
  - Xuất hiện dòng mới cho `P-002` ở trạng thái `ĐANG CHẠY`.

### TC-3: Reset Thời gian ca lọc (Run Time / Phase Reset)

Xảy ra khi máy khởi động lại đột ngột hoặc bắt đầu gắn quả lọc mới cho cùng bệnh nhân (reset thời gian chạy).

- **Tiền quyết:** Ca lọc `P-001` đang nhận packet với `RUN_TIME = 150` phút.
- **Hành động:** Giả lập máy bắn packet mới cho `P-001`, nhưng `RUN_TIME = 0` (hoặc báo `Phase = THERAPY_INIT`).
- **Kỳ vọng Backend:**
  - Treatment cũ đóng an toàn: `outcome = COMPLETED`, `close_reason = 'RUNTIME_RESET'`.
  - Tạo một Treatment mới (Ca 2) cho `P-001`.
- **Kỳ vọng Frontend:**
  - Ca `P-001` cũ chốt lại thành `HOÀN THÀNH`.
  - Dòng mới cho `P-001` xuất hiện, báo `ĐANG CHẠY`, giờ chạy bắt đầu từ 0.

### TC-4: Mất kết nối dẫn đến Timeout (Offline)

Xảy ra khi rút cáp mạng, mất điện, máy tắt ngang hoặc Wi-Fi rớt không kịp gửi `END`.

- **Tiền quyết:** Ca lọc đang chạy cập nhật lần cuối lúc `10:00:00`.
- **Hành động:** Ngắt hoàn toàn stream dữ liệu. Chờ đợi (hoặc tua thời gian hệ thống giả lập) vượt qua ngưỡng timeout cho phép (Ví dụ: 15 phút không có heartbeat -> `10:16:00`).
- **Kỳ vọng Backend:** Cronjob hoặc lệnh fetch List/Detail quét thấy `last_seen_time` quá hạn, tự động đánh dấu `outcome = TIMEOUT`.
- **Kỳ vọng Frontend:** Ca lọc bị chuyển sang trạng thái `QUÁ GIỜ` (màu đỏ/vàng cảnh báo).

---

## 3. Test Cases (Negative & Edge Cases)

### TC-5: Kiểm tra UI End Treatment (Negative)

- **Hành động:** QA đăng nhập bằng cả 3 role (Nurse, Doctor, Admin). Quét toàn bộ trang List, trang Detail và trang Review của 1 ca `IN_PROGRESS`.
- **Kỳ vọng:** TUYỆT ĐỐI KHÔNG tìm thấy bất kỳ nút "End Treatment", "Hoàn thành ca", "Đóng ca" nào.

### TC-6: Race Condition lúc Timeout

- **Tiền quyết:** Một ca lọc đang `IN_PROGRESS` vừa rơi vào đúng giây thứ 15 (sắp Timeout).
- **Hành động:** Bắn 1 packet dữ liệu thông thường cùng lúc với tick của Cronjob quét Timeout.
- **Kỳ vọng:** Transaction handling của Database (PostgreSQL) phải lock đúng. Nhận được packet thì `last_seen_time` được cập nhật và ca lọc VẪN tiếp tục `IN_PROGRESS`. Tránh việc vừa đánh `TIMEOUT` xong lại lọt packet vào ca đó.

### TC-7: Packet tới TRỄ sau khi có lệnh END

- **Tiền quyết:** Ca lọc đã nhận packet `END` và đánh dấu `COMPLETED`.
- **Hành động:** Do delay mạng bộ đệm đẩy lên 1 packet cũ (timestamp trước lúc END).
- **Kỳ vọng:** Backend từ chối nhận data (hoặc drop packet báo lỗi `TREATMENT_LOCKED`) nếu packet xuất hiện sai trình tự sau lệnh END. Không tự động mở lại treatment đã khóa.
