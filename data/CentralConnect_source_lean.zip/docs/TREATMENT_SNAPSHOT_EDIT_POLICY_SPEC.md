# Treatment Snapshot Edit Policy Spec

> Updated: 2026-04-03
> Scope: permission model and safety guardrails for Treatment Journal editing

## Goal

Reduce bug risk and improve real-world usability by locking down Treatment Snapshot editing during active recording, then reopening controlled edit rights after treatment stops.

This spec is intentionally conservative:

- fewer edit paths
- fewer overlapping features
- stronger backend gates
- clearer clinical ownership

## Product Principle

Treatment Journal must behave like a clinical record, not like a spreadsheet.

That means:

- telemetry defines the timeline
- humans may correct values, but should not mutate chronology
- synthetic rows should be rare and controlled
- active recording must stay stable and conflict-free

## Main Decision

## While treatment is actively recording:

- snapshot table is read-only
- no manual row edit
- no restore
- no delete
- no gap fill
- no add-next-hour

Allowed during recording:

- view snapshots
- view compare state if available
- edit clinical notes if needed
- edit limited administrative fields if already approved by product policy

## After treatment stops but before submission:

- nurse may edit existing rows
- nurse may restore existing rows
- nurse may fill missing internal `Hxx` gaps
- nurse may not create arbitrary trailing rows
- nurse may not delete rows unless explicitly allowed by doctor/admin policy

## During `PENDING_REVIEW`:

- nurse becomes read-only
- doctor may edit existing rows
- doctor may restore rows
- doctor may fill internal gaps if clinically justified
- doctor may reject or approve

## During `APPROVED`:

- everything is locked
- any change requires explicit unlock by doctor/admin

## After explicit unlock:

- only doctor/admin may edit
- unlock reason is mandatory
- audit log is mandatory
- re-approval should be required after changes

## State Model

Use two separate concepts:

### 1. Recording state

This is operational:

- `RECORDING_ACTIVE`
- `RECORDING_STOPPED`

It answers:

- is telemetry still actively driving this treatment?

### 2. Approval state

This is governance:

- `IN_PROGRESS`
- `COMPLETED`
- `PENDING_REVIEW`
- `APPROVED`
- `UNLOCKED_FOR_CORRECTION` (recommended logical state, even if implemented via flags)

It answers:

- who is allowed to change the clinical record?

## Why recording state must be separate

Current approval status alone is not enough.

A treatment can be:

- still receiving telemetry
- not yet submitted
- still technically editable by current APIs

That is exactly where conflict risk appears.

So the backend must gate writes using both:

- approval/governance state
- active-recording state

## Permission Matrix

| State | Nurse | Doctor | Admin | Notes |
|---|---|---|---|---|
| `RECORDING_ACTIVE` | View only | View only | View only | Snapshot journal locked |
| `RECORDING_STOPPED + IN_PROGRESS` | Edit existing, restore existing, fill internal gap | Same | Same | Best place for nursing cleanup |
| `PENDING_REVIEW` | Read-only | Edit/restore/fill/reject/approve | Same | Doctor review stage |
| `APPROVED` | Read-only | Read-only unless unlock | Unlock allowed | Fully locked record |
| `UNLOCKED_FOR_CORRECTION` | No access by default | Full correction rights | Full correction rights | Must require reason + audit |

## Allowed Actions By Feature

| Feature | Recording Active | Stopped Pre-Submit | Pending Review | Approved | Unlocked |
|---|---|---|---|---|---|
| Edit existing row | No | Nurse yes | Doctor yes | No | Doctor/Admin yes |
| Restore existing row | No | Nurse yes | Doctor yes | No | Doctor/Admin yes |
| Restore missing row | No | Nurse limited | Doctor yes | No | Doctor/Admin yes |
| Fill internal gap `Hxx` | No | Nurse yes | Doctor yes | No | Doctor/Admin yes |
| Add next hour | No | No | No | No | No |
| Delete row | No | Prefer no | Doctor/Admin only | No | Doctor/Admin only |
| Edit notes | Yes | Yes | Yes | Maybe yes if policy allows | Yes |

## Keep / Remove Decision

### Keep

- auto `H00`
- auto hourly rows
- auto `OC_XX`
- edit existing row
- restore existing row
- review/approve/unlock flow

### Keep with strict limits

- restore missing row
- fill missing internal `Hxx` row

### Remove or hide

- `Add Next Hour`

Reason:

- too easy to create synthetic future rows
- weak clinical trust
- overlaps with safer workflows
- increases chronology and audit complexity

## Backend Guardrails

Backend must be the source of truth for permission checks.

UI disable alone is not enough.

Required backend behavior:

1. Every snapshot write endpoint checks:
   - approval state
   - active recording state
   - user role

2. If `RECORDING_ACTIVE`:
   - reject `PUT /snapshots/{hourLabel}`
   - reject `POST /snapshots/manual`
   - reject restore actions
   - reject delete

3. If `APPROVED`:
   - reject all snapshot mutations unless treatment is explicitly unlocked

4. If `PENDING_REVIEW`:
   - reject nurse edits
   - allow doctor/admin corrections only

5. Every accepted mutation must write:
   - `updated_at`
   - `updated_by`
   - `action_type`
   - optional `reason`

Recommended error responses:

- `409 Conflict` for recording-active write attempts
- `403 Forbidden` for role or approval lock violations

## Frontend Guardrails

Frontend should make the safe path obvious:

### During recording

- hide edit icons
- hide restore buttons
- hide fill-gap buttons
- hide delete buttons
- show a small banner:
  - "Journal locked while treatment is recording"

### After stop, before submit

- show limited nursing tools only
- show row badges:
  - `AUTO`
  - `MANUAL`
  - `RESTORED`

### Pending review

- nurse sees read-only table
- doctor sees correction tools

### Approved

- all controls disabled
- show:
  - "Approved record"
  - unlock action only for authorized role

## Active Recording Detection

Recommended rule:

Treatment is `RECORDING_ACTIVE` when any of the following is true:

- recorder/session for this treatment is still active
- new telemetry has arrived within a short live window
- treatment outcome/close state does not yet indicate stop

Do not rely only on UI assumptions.
Backend should determine this state from recorder/runtime truth.

## Potential Drawbacks Of Locking During Recording

### Drawback 1: nurse cannot fix a small typo immediately

Response:

- acceptable tradeoff
- safer to correct after stop than to risk collision with active telemetry

### Drawback 2: long treatments may leave many hours before correction

Response:

- allow clinical notes during recording
- if truly needed later, add a "correction note" workflow instead of direct row mutation

### Drawback 3: doctors may want to intervene mid-treatment

Response:

- show live data and notes
- do not allow mutation of the journal timeline while machine data is still shaping it

## User Scenarios

### Scenario 1: Active treatment, nurse opens journal

Expected:

- can read everything
- cannot edit
- cannot restore
- cannot add row

### Scenario 2: Active treatment, nurse tries to edit H02 through API or stale UI

Expected:

- backend rejects mutation
- no partial save
- no chronology side effect

### Scenario 3: Treatment stops, nurse cleans up missed values

Expected:

- may edit existing `Hxx`
- may fill a missing internal `Hxx`
- may restore original values

### Scenario 4: Nurse submits for review

Expected:

- originals frozen
- nurse loses edit rights
- doctor gains review rights

### Scenario 5: Doctor corrects one row during review

Expected:

- chronology unchanged
- correction audited
- row still appears in same clinical place

### Scenario 6: Treatment approved

Expected:

- no one can edit by default

### Scenario 7: Doctor unlocks approved treatment

Expected:

- unlock reason required
- only doctor/admin edits allowed
- after correction, treatment should be re-approved

## Acceptance Criteria

- No snapshot mutation allowed while treatment is actively recording.
- No trailing manual row creation feature in the UI.
- Existing row edit works only in allowed states.
- Existing row restore works only in allowed states.
- Missing-gap fill works only for internal missing `Hxx`.
- Approved treatments are fully locked until explicit unlock.
- Every correction is auditable.
- Backend and frontend enforce the same policy.

## Implementation Notes For OPUS

1. Add a single backend helper such as `can_mutate_snapshots(treatment_id, role, action_type)`.
2. Use it in:
   - `PUT /snapshots/{hourLabel}`
   - `POST /snapshots/manual`
   - restore flows
   - delete flows
3. Add a frontend permission model derived from treatment detail.
4. Hide `Add Next Hour` from the UI entirely.
5. Keep `Fill Gap` only for internal missing `Hxx`, not arbitrary trailing creation.

## One-Line Product Policy

While telemetry is still writing the treatment story, humans may observe but not rewrite it.
