# Index Review Note

> TASK-107 deliverable. Reviews all indexes in the initial PostgreSQL schema.
> Reference: BACKEND_POSTGRES_PHASE1_HANDOFF.md Section 8, Architecture Spec Section 13

## Index Inventory

### `treatments` (3 indexes)

| Index                         | Columns                         | Rationale                                      |
| ----------------------------- | ------------------------------- | ---------------------------------------------- |
| `ix_treatments_device_start`  | `(device_id, start_time DESC)`  | Device-filtered treatment list                 |
| `ix_treatments_patient_start` | `(patient_id, start_time DESC)` | Patient-filtered treatment list                |
| `ix_treatments_outcome_start` | `(outcome, start_time DESC)`    | Outcome-filtered list (IN_PROGRESS, COMPLETED) |

### `treatment_phases` (1 index)

| Index                        | Columns                        | Rationale                 |
| ---------------------------- | ------------------------------ | ------------------------- |
| `ix_phases_treatment_number` | `(treatment_id, phase_number)` | Phase lookup by treatment |

### `treatment_status_events` (3 indexes)

| Index                             | Columns                          | Rationale                   |
| --------------------------------- | -------------------------------- | --------------------------- |
| `ix_status_events_treatment_time` | `(treatment_id, event_time ASC)` | Timeline view per treatment |
| `ix_status_events_device_time`    | `(device_id, event_time DESC)`   | Latest events per device    |
| `ix_status_events_code_time`      | `(event_code, event_time DESC)`  | Event filtering by type     |

### `treatment_journal_rows` (3 indexes + 1 partial)

| Index                                       | Columns                                                    | Rationale                                                   |
| ------------------------------------------- | ---------------------------------------------------------- | ----------------------------------------------------------- |
| `uq_journal_rows_treatment_row_code`        | `UNIQUE (treatment_id, row_code)`                          | Business key identity                                       |
| `ix_journal_rows_treatment_snapshot`        | `(treatment_id, snapshot_time ASC)`                        | Journal timeline ordering                                   |
| `ix_journal_rows_treatment_kind_snapshot`   | `(treatment_id, row_kind, snapshot_time ASC)`              | Filter by HOUR vs ORDER_CHANGE                              |
| `ix_journal_rows_treatment_snapshot_active` | `(treatment_id, snapshot_time ASC) WHERE is_deleted=FALSE` | **Partial index** — most common query excludes deleted rows |

### `snapshot_originals` (1 index + 1 unique)

| Index                                  | Columns                             | Rationale                  |
| -------------------------------------- | ----------------------------------- | -------------------------- |
| `uq_snapshot_originals_treatment_row`  | `UNIQUE (treatment_id, row_code)`   | One original per row       |
| `ix_snapshot_originals_treatment_time` | `(treatment_id, snapshot_time ASC)` | Review comparison ordering |

### `treatment_review_state` (1 index)

| Index                            | Columns                              | Rationale              |
| -------------------------------- | ------------------------------------ | ---------------------- |
| `ix_review_state_status_updated` | `(approval_status, updated_at DESC)` | Review queue filtering |

### `treatment_notes` (1 index)

| Index                        | Columns                          | Rationale                 |
| ---------------------------- | -------------------------------- | ------------------------- |
| `ix_notes_treatment_created` | `(treatment_id, created_at ASC)` | Note stream per treatment |

### `snapshot_audit_log` (3 indexes)

| Index                                | Columns                                     | Rationale                  |
| ------------------------------------ | ------------------------------------------- | -------------------------- |
| `ix_audit_log_treatment_created`     | `(treatment_id, created_at DESC)`           | Audit trail per treatment  |
| `ix_audit_log_treatment_row_created` | `(treatment_id, row_code, created_at DESC)` | Row-level audit history    |
| `ix_audit_log_operator_created`      | `(operator_name, created_at DESC)`          | Operator activity tracking |

### `treatment_list_projection` (3 indexes)

| Index                          | Columns                              | Rationale                  |
| ------------------------------ | ------------------------------------ | -------------------------- |
| `ix_projection_outcome_start`  | `(outcome, start_time DESC)`         | Outcome-filtered list view |
| `ix_projection_approval_start` | `(approval_status, start_time DESC)` | Review queue list          |
| `ix_projection_patient_start`  | `(patient_id, start_time DESC)`      | Patient-filtered list      |

### `raw_packet_manifest` (2 indexes)

| Index                            | Columns                                            | Rationale                |
| -------------------------------- | -------------------------------------------------- | ------------------------ |
| `ix_raw_manifest_treatment_seq`  | `(treatment_id, chunk_seq)`                        | Ordered chunk retrieval  |
| `ix_raw_manifest_treatment_time` | `(treatment_id, packet_time_min, packet_time_max)` | Time-range packet lookup |

## Summary

| Metric             | Count |
| ------------------ | ----- |
| Total tables       | 11    |
| Total indexes      | 22    |
| Unique constraints | 2     |
| Partial indexes    | 1     |
| CHECK constraints  | 4     |

## Assessment

- **Every FK column is indexed** ✅
- **Every WHERE + ORDER BY pattern has a supporting composite index** ✅
- **No over-indexing** — each index justifies an actual UI query pattern ✅
- **Partial index used correctly** for the most common query (non-deleted journal rows) ✅
- **Partitioning deferred** per ADR-5 — only append-heavy tables (audit_log, status_events) are candidates for future monthly partitioning ✅
