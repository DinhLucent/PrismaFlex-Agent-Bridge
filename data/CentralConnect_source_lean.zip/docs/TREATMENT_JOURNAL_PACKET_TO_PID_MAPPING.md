# Treatment Journal Packet-to-PID Mapping

## Muc dich

Tai lieu nay giai thich ro luong du lieu thuc te cua Treatment Journal:

1. Packet vao backend co shape gi
2. Journal doc truong nao tu packet
3. PID nao duoc map thanh cot Journal
4. Khi nao tao `H00/H01/...` va khi nao tao `OC_XX`
5. Diem nao de gay sai khi doi decoder hoac thay doi payload contract

Tai lieu nay duoc viet de AI agents va dev moi co the doc nhanh va hieu ngay Journal hien tai dang "an" du lieu nhu the nao.

---

## Tong quan luong du lieu

Journal khong nhan truc tiep cac cot nhu `qb`, `qd`, `tmp`, `uf_total`.

No nhan packet da decode san o dang JSON:

```json
{
  "packet_num": 169,
  "timestamp": "2026-01-30T08:37:13.347598",
  "packet_length": 2188,
  "s_header": { ... },
  "s_body": {
    "total_records": 172,
    "parameters": [
      { "record_num": 1, "type": "Actual", "id": 1, "value": -40, "record_time": 1769762229 },
      { "record_num": 2, "type": "Actual", "id": 2, "value": 235, "record_time": 1769762229 }
    ]
  }
}
```

Sau do backend:

1. Lay `s_header`
2. Lay `s_body.parameters[]`
3. Duyet tung parameter theo `id` va `value`
4. Chi giu cac PID nam trong `CRRT_PID_MAP`
5. Gop thanh snapshot row cho Journal

---

## Runtime contract quan trong

Hot path cua backend hien tai uu tien payload da co shape:

- `s_header`
- `s_body`
- `s_body.parameters[]`

Dieu nay quan trong hon viec packet duoc decode boi module nao.

Y nghia thuc te:

- Co the doi decoder o tang duoi
- Nhung khong duoc vo contract `s_header/s_body.parameters`
- Neu doi contract nay, Journal va Recorder de bi sai nghiep vu

---

## Noi Journal doc du lieu

Treatment Journal doc packet o service:

- `backend/services/treatment/treatment_snapshot_service.py`

Logic cot loi:

- `_extract_values(...)`: duyet `body["parameters"]`
- `CRRT_PID_MAP`: quy dinh PID nao map vao cot nao
- `ORDER_CHANGE_PIDS`: quy dinh PID nao duoc xem la thay doi y lenh
- `_save_snapshot(...)`: tao row snapshot va ghi vao DB

Journal hien tai doc:

- `p.get("id")`
- `p.get("value")`

Va khong dua vao `record_num` de map cot.

---

## Bang PID -> cot Journal

Bang duoi day phan anh logic hien tai trong `CRRT_PID_MAP`.

| PID | Cot Journal | Y nghia |
| --- | --- | --- |
| `17` | `qb` | Blood flow |
| `18` | `qs_pre` | Replacement pre-flow |
| `19` | `qs_post` | Replacement post-flow |
| `21` | `qd` | Dialysate flow |
| `22` | `qpbp` | Pre-blood flow |
| `1` | `pa` | Access pressure |
| `4` | `pv` | Return pressure |
| `2` | `pbe` | Filter pressure |
| `6` | `tmp` | TMP |
| `100` | `uf_total` | Total UF |
| `24` | `uf_hourly` | Hourly UF |
| `23` | `effluent_flow` | Effluent flow |
| `461` | `run_time_sec` | Run time |
| `60` | `blood_vol` | Blood volume processed |
| `38` | `heparin_rate` | Heparin continuous rate |
| `26` | `pt_weight` | Patient weight |
| `25` | `uf_rate_target` | UF rate target |
| `400` | `citrate_dose` | Citrate dose |
| `401` | `citrate_conc` | Citrate concentration |
| `403` | `citrate_load` | Citrate load |
| `404` | `calcium_rate` | Calcium syringe rate |
| `406` | `calcium_comp` | Calcium compensation |
| `409` | `anticoag_type_id` | Anticoagulation type |

### Luu y ve `qs`

Journal khong luu truc tiep PID `qs`.

No tinh:

```text
qs = qs_pre + qs_post
```

Tuc la:

- PID `18` -> `qs_pre`
- PID `19` -> `qs_post`
- snapshot cuoi cung luu cot `qs`

---

## PID kich hoat Order-Change (`OC_XX`)

Hien tai Journal xem cac PID sau la "y lenh" co y nghia tao `OC_XX`:

- `17` -> `qb`
- `21` -> `qd`
- `18` -> `qs_pre`
- `19` -> `qs_post`
- `22` -> `qpbp`
- `25` -> `uf_rate_target`

Neu mot trong cac PID tren thay doi, Journal co the tao:

- `OC_01`
- `OC_02`
- ...

`OC_XX` phai duoc sap xep theo `snapshot_time`, khong duoc day xuong cuoi bang.

---

## Scale va accuracy

Khong phai PID nao cung duoc luu nguyen gia tri tho.

Hien tai co rule scale:

- PID `38` (`heparin_rate`) -> nhan voi `0.1`

Nghia la:

- packet gui `value = 0`
- Journal luu `0.0`

Neu firmware sau nay co them PID can scale, phai cap nhat `PID_SCALE_MAP`.

---

## Vi du map tu packet mau

Tu packet mau:

- PID `17 = 200` -> `qb = 200`
- PID `18 = 0`, PID `19 = 600` -> `qs = 600`
- PID `21 = 600` -> `qd = 600`
- PID `22 = 100` -> `qpbp = 100`
- PID `1 = -40` -> `pa = -40`
- PID `2 = 235` -> `pbe = 235`
- PID `4 = 129` -> `pv = 129`
- PID `6 = 61` -> `tmp = 61`
- PID `24 = 250` -> `uf_hourly = 250`
- PID `100 = 3149` -> `uf_total = 3149`
- PID `23 = 1550` -> `effluent_flow = 1550`
- PID `60 = 191` -> `blood_vol = 191`
- PID `38 = 0` -> `heparin_rate = 0.0`
- PID `461 = 57041` -> `run_time_sec = 57041`
- PID `409 = 1` -> `anticoag_type_id = 1`

---

## Diem rat quan trong: Journal hien tai map theo `id/value`, khong loc theo `type`

Trong packet, mot PID co the xuat hien nhieu lan.

Vi du:

- `Actual`
- `Set`
- hoac nhieu record cung PID trong cung mot packet

Logic hien tai:

- khong check `type`
- khong check `record_num`
- chi lay `id` va `value`
- PID nao match thi ghi vao cache
- neu cung PID xuat hien nhieu lan, gia tri xuat hien sau se de gia tri truoc

He qua:

- Day la mot compatibility rule ngam rat quan trong
- Neu doi decoder hoac doi shape packet, khong duoc vo hanh vi nay neu chua QA parity

Day vua la diem manh, vua la diem de gay bug:

- Manh: Journal don gian, it phu thuoc format chi tiet
- Rui ro: Neu firmware doi thu tu records, gia tri cuoi cung co the khac

---

## Old decoder vs new decoder/unpacker

### Giong nhau o dau

Decoder cu va module moi giong nhau o core protocol:

- decode `patient_id`
- decode `sw_version`
- parse header 124 bytes
- parse body records
- tach `type` va `id` tu ma PID

### Khac nhau o dau

Decoder cu:

- `backend/prismaflex_decoder.py`
- `hex -> legacy JSON wrapper`
- co `packet_num`, `timestamp`, `packet_length`
- parameter co `record_num`

Module moi:

- `prismaflex_lib/unpacker.py`
- `hex -> intermediate JSON`
- tra `s_header`, `s_body`
- parameter khong co `record_num`, co them `original_code_hex`

Module semantic moi:

- `prismaflex_lib/decoder.py`
- `JSON -> typed/enriched objects`

### Ket luan compatibility

Journal hien tai van an toan neu:

- `s_header` giu nguyen field can dung
- `s_body.parameters[]` van giu:
  - `id`
  - `value`
  - `type`
  - `record_time`

Journal hien tai khong phu thuoc bat buoc vao:

- `record_num`

Tuy nhien, neu thay the decoder cu bang module moi thi van nen co:

- adapter compatibility
- parity test tren cung tap packet thuc

---

## Khuyen nghi cho AI agents

Neu can thay doi decoder, unpacker, replay tool, hoac ingestion contract:

1. Khong sua Journal truoc khi hieu `CRRT_PID_MAP`
2. Khong doi shape `s_header/s_body.parameters` neu chua co shim compatibility
3. QA bat buoc:
   - packet count parity
   - header parity
   - PID/value parity
   - chronology `Hxx/OC_XX`
4. Neu co y dinh loc theo `type` (`Actual` vs `Set`), phai mo ADR rieng
   vi day la thay doi nghiep vu, khong chi la refactor

---

## Checklist nhanh de tu kiem tra

- Packet co `s_header` khong?
- Packet co `s_body.parameters[]` khong?
- PID trong packet co map vao `CRRT_PID_MAP` khong?
- `qs` co duoc cong tu `qs_pre + qs_post` khong?
- `heparin_rate` co duoc scale dung khong?
- `OC_XX` co duoc kich dung khi PID y lenh thay doi khong?
- `snapshot_time` co giu dung chronology khong?
- Sau khi doi decoder, Journal row co giong truoc khong?

---

## Mot cau chot de ghi nho

Treatment Journal khong "hieu" toan bo packet.
No chi rut mot tap PID co y nghia lam sang tu `s_body.parameters[]`, map thanh cot snapshot, roi dung tap cot do de tao `Hxx` va `OC_XX`.
