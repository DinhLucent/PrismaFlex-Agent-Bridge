# Live Treatment Continuity Self-Verification Matrix

> Superseded in part by [TREATMENT_LIFECYCLE_REFINEMENT_SPEC.md](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/docs/TREATMENT_LIFECYCLE_REFINEMENT_SPEC.md).
> In particular, any older assumption that `END` plus `RUN_TIME > 0` should resume
> the same treatment is no longer valid.

## Purpose

This document defines the **expected live runtime behavior** for treatment continuity.

It is intentionally simple:

- keep treatment continuity easy to reason about
- prioritize `HOURLY SNAP` and `OC SNAP`
- prevent accidental `RAW DATA` split
- keep resume logic **device-scoped**

This is the matrix AI agents should use to self-check the live pipeline before changing code.

## Golden Runtime Rules

### Rule 1: Open gate

A new treatment may open only when:

- `therapy_status_id` is a start status
- valid `patient_id` exists

For current runtime, the start statuses are:

- `4 = WAITINGSTART`
- `5 = RUN`

### Rule 2: Same-device continuity

If the packet belongs to the **same `device_id`** and **same `patient_id`**, and the machine signals:

- `RUN_TIME > 0`

then the system should treat this as **continuation of the same treatment**.

### Rule 3: `RUN_TIME = 0` is not enough by itself

`RUN_TIME = 0` must **not** create a new treatment unless the packet also satisfies the normal start gate.

This prevents infinite fake treatments while the machine is powered on but not actually running a filter.

### Rule 4: Device isolation

Resume/reopen lookup must always be scoped by:

- same `device_id`
- same `patient_id`

Never resume a treatment from another device.

### Rule 5: Approval does not block runtime continuity

If an already-approved treatment later continues for the same device/patient with `RUN_TIME > 0`, runtime may continue that treatment.

Approval is **not** a runtime split gate in this model.

### Rule 6: Raw analyzer safety

If treatment continuity is preserved, then:

- `RAW DATA` must remain under the same `treatment_id`
- raw chunks may rotate, but must not silently switch to a new treatment UUID

If a true new treatment starts, then:

- old raw stream must close once
- new raw stream must start under the new `treatment_id`

## What AI Must Verify For Every Scenario

For each scenario below, AI must verify all 4 layers:

1. `Treatment lifecycle`
2. `Hourly snapshots`
3. `Order-change snapshots`
4. `Raw packet manifest / raw chunk ownership`

## Core Invariants

### Invariant A: No accidental treatment split

If the scenario says "continue same treatment", then all matching packets must resolve to exactly one `treatment_id`.

### Invariant B: No accidental treatment merge across devices

If the same patient appears on another device, that must be a different treatment.

### Invariant C: No fake open while idle

Packets with `RUN_TIME = 0` but without start status must not create treatment rows.

### Invariant D: Hourly/OC continuity follows treatment continuity

If a treatment continues, then:

- `Hxx` continues on the same treatment
- `OC_XX` continues on the same treatment
- counters/labels must not reset to `H00` or `OC_01` unless a true new treatment is created

### Invariant E: Raw continuity follows treatment continuity

If a treatment continues, raw packets must keep appending under the same `treatment_id`.

## Scenario Matrix

### S01 — Idle machine, no start

Input:

- no active session
- valid `device_id`
- valid or empty `patient_id`
- `RUN_TIME = 0`
- `therapy_status_id` is **not** `4` or `5`

Expected:

- no new treatment opens
- no `H00`
- no `OC_XX`
- no raw manifest row for a new treatment

Hard fail if:

- a treatment row is created
- raw starts streaming under a new UUID

### S02 — Fresh start by WAITINGSTART

Input:

- no active session
- valid `device_id`
- valid `patient_id`
- `therapy_status_id = 4`
- `RUN_TIME = 0`

Expected:

- open a new treatment
- create first `treatment_id`
- raw starts under that `treatment_id`
- `H00` begins on this treatment

### S03 — Fresh start by RUN

Input:

- no active session
- valid `device_id`
- valid `patient_id`
- `therapy_status_id = 5`
- `RUN_TIME = 0`

Expected:

- open a new treatment
- raw starts under that new `treatment_id`
- `H00` belongs to that treatment

### S04 — Same patient while treatment already active

Input:

- active session exists on device
- same `patient_id`
- any non-terminal packet

Expected:

- continue same `treatment_id`
- no split
- raw continues same treatment
- hourly/OC continue same treatment

### S05 — 4h disconnect, same device, same patient, `RUN_TIME > 0`

Input:

- treatment active for ~4h
- no `END`
- no packets for ~4h
- reconnect packet has same `device_id`
- same `patient_id`
- `RUN_TIME > 0`

Expected:

- continue same `treatment_id`
- mark interruption/reconnected behavior if implemented
- no new treatment UUID
- raw continues under same treatment
- missing hourly rows remain missing if no data existed during outage
- frontend may render GAP from missing `Hxx`

Hard fail if:

- a new treatment UUID appears
- `H00` restarts
- `OC_XX` restarts from `OC_01`
- raw manifest switches to another treatment unexpectedly

### S06 — `END`, then same patient continues with `RUN_TIME > 0`

Input:

- treatment receives `therapy_status_id = 8` (`END`)
- later the same device runs same patient again
- reopening packet satisfies start gate
- `RUN_TIME > 0`

Expected:

- resume the same treatment
- treatment continuity is preserved
- raw continues under same `treatment_id`
- hourly/OC continue on same treatment

Hard fail if:

- a second treatment row is created for the same continuity event
- raw splits into a new treatment UUID

### S07 — `END`, then same patient but fresh start (`RUN_TIME = 0`)

Input:

- prior treatment received `END`
- later same device and same patient start again
- new start packet satisfies start gate
- `RUN_TIME = 0`

Expected:

- create a new treatment
- old treatment stays closed
- old raw stream closes once
- new raw stream starts under new `treatment_id`
- `H00` restarts for the new treatment
- `OC_XX` restarts from `OC_01` for the new treatment

### S08 — `END`, but no real restart packet

Input:

- prior treatment received `END`
- subsequent packets have `RUN_TIME = 0`
- but `therapy_status_id` is not `4` or `5`

Expected:

- do not open new treatment
- do not stream raw into a new treatment

### S09 — Different patient on same device

Input:

- active treatment exists
- packet arrives with different `patient_id`
- packet satisfies start gate

Expected:

- old treatment closes
- new treatment opens
- raw old treatment closes once
- raw new treatment starts under new UUID
- new `H00` belongs to new treatment

### S10 — Same patient on different device

Input:

- device `PF_004` has patient `g12`
- device `PF_005` later receives patient `g12`
- `RUN_TIME > 0`

Expected:

- absolutely no cross-device resume
- `PF_005` must create/use its own treatment continuity
- raw/chunks remain isolated by treatment and device

Hard fail if:

- `PF_005` reuses `PF_004` treatment UUID

### S11 — Approved treatment continues

Input:

- treatment is already approved
- later same device, same patient, start packet arrives
- `RUN_TIME > 0`

Expected:

- runtime may continue same treatment
- no forced split because of approval state alone

### S12 — Active treatment with `RUN_TIME = 0` during non-start status

Input:

- active session already exists
- packet has `RUN_TIME = 0`
- packet is not a real restart/start transition

Expected:

- must be handled carefully
- should not create infinite new treatments while machine is idle/pre-run

This is the scenario most likely to expose over-eager `RUNTIME_RESET` logic.

## Snapshot Expectations

### Hourly snapshots

For live continuity scenarios:

- same treatment means `Hxx` stays on the same `treatment_id`
- outage does not force new treatment
- absence of data should remain absence of hourly rows

### Order-change snapshots

For live continuity scenarios:

- `OC_XX` stays on the same `treatment_id`
- counter does not reset unless a true new treatment begins

## Raw Data Expectations

### Continue same treatment

If the scenario says "same treatment continues", AI must verify:

- only one active clinical treatment identity exists
- raw packets keep using the same `treatment_id`
- chunk rotation is allowed
- treatment identity split is not allowed

### Start new treatment

If the scenario says "new treatment", AI must verify:

- previous treatment raw stream closes once
- previous manifest does not remain ambiguously active forever
- new treatment gets its own raw stream and manifest rows

## Minimal SQL Verification Set

### 1. Treatments

```sql
SELECT id, device_id, patient_id, start_time, end_time, outcome, close_reason, total_packets
FROM treatments
WHERE device_id = '<device_id>'
ORDER BY start_time;
```

### 2. Journal rows

```sql
SELECT treatment_id, row_code, row_kind, snapshot_time, reason
FROM treatment_journal_rows
WHERE treatment_id = '<treatment_id>'
ORDER BY snapshot_time, row_code;
```

### 3. Raw manifest

```sql
SELECT treatment_id, chunk_index, status, first_timestamp, last_timestamp, packet_count
FROM raw_packet_manifest
WHERE treatment_id = '<treatment_id>'
ORDER BY chunk_index;
```

## AI Pass/Fail Rules

AI should mark the run as **FAIL** if any of these occur:

- new treatment created during a continuity scenario
- treatment resumed across a different device
- raw stream switches treatment UUID unexpectedly
- old treatment raw never closes after a true split
- `H00` restarts when continuity should have been preserved
- `OC_XX` resets when continuity should have been preserved
- `RUN_TIME = 0` without start status creates extra treatments

## Recommended Replay Order

Run in this order to keep debugging simple:

1. `S01`
2. `S02`
3. `S04`
4. `S05`
5. `S06`
6. `S07`
7. `S08`
8. `S09`
9. `S10`
10. `S11`
11. `S12`

## Final Principle

For live runtime, the system should prefer this simple mental model:

- same device
- same patient
- `RUN_TIME > 0`

means:

- keep the same treatment
- keep the same hourly timeline
- keep the same OC timeline
- keep the same raw ownership

Any split that violates that principle must be treated as a hard analyzer-risk bug.
