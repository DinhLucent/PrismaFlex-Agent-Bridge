# DASHBOARD QA CHECKLIST AND TEST CASES

**Updated:** 2026-04-05  
**Role:** QA Lead / Tester / CTO Review  
**Status:** Draft for execution

Tài liệu này là bộ checklist và test case cho riêng khu vực **Dashboard** của PrismaFlex WebApp.
Mục tiêu là giúp QA và Tester kiểm tra đúng hành vi thực tế của code hiện tại sau đợt hardening gần đây.

**Tài liệu nên đọc trước khi dựng fake data:**
- [DASHBOARD_QA_DATA_MAPPING_GUIDE.md](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/DASHBOARD_QA_DATA_MAPPING_GUIDE.md)

**Nguồn chân lý khi test:**
- Ưu tiên hành vi thực tế từ code frontend/backend hiện hành.
- Tài liệu user guide chỉ dùng để tham khảo nghiệp vụ.
- Khi user guide và UI thực tế khác nhau, QA phải log rõ là `Doc mismatch`, không tự suy diễn.

---

## 1. Scope Dashboard

Phạm vi của tài liệu này bao gồm:

- Trang Dashboard chính `/`
- Header realtime của Dashboard
- Device cards
- Summary bar
- Offline grouping
- Status legend
- Cơ chế realtime nền ảnh hưởng trực tiếp đến Dashboard:
  - WebSocket `/ws`
  - polling `/api/v1/devices/{id}/events`
  - localStorage `known_devices`
  - cơ chế OFFLINE aging
  - audio arming

Ngoài phạm vi:

- Monitor detail page `/monitor/[id]`
- Treatment Journal
- Review/Approval workflow
- Analyzer

---

## 2. Dashboard Feature Checklist

| ID | Feature | Mục đích | Cơ chế chính | DB only? | QA Check |
| --- | --- | --- | --- | --- | --- |
| DASH-01 | Dashboard page load | Mở được trang trung tâm mà không crash | UI/WF | No | [ ] |
| DASH-02 | Header connection status | Hiển thị `CONNECTED / CONNECTING / OFFLINE` đúng trạng thái socket | WF | No | [ ] |
| DASH-03 | Header device counters | Hiển thị số thiết bị active và tổng thiết bị | WF | No | [ ] |
| DASH-04 | Synced clock | Đồng hồ đi theo `serverTime` nếu có, tự tick mỗi giây | ALG/WF | No | [ ] |
| DASH-05 | Audio arming | Chỉ phát âm thanh sau khi người dùng chủ động enable audio | WF | No | [ ] |
| DASH-06 | Responsive zoom | Tự scale Dashboard theo viewport lớn/nhỏ | ALG/UI | No | [ ] |
| DASH-07 | Severity-based sorting | Card nguy hiểm hơn phải nổi lên trước | ALG | No | [ ] |
| DASH-08 | Summary chips | Tổng hợp running/alarm/warning/caution/offline | ALG/UI | No | [ ] |
| DASH-09 | Empty state | Không có device thì hiển thị trạng thái rỗng rõ ràng | UI | No | [ ] |
| DASH-10 | Active vs offline grouping | Tách card đang hoạt động và offline thành 2 vùng | ALG/UI | No | [ ] |
| DASH-11 | Device identity block | Hiển thị mã máy, patient ID, therapy modality | WF/UI | No | [ ] |
| DASH-12 | Therapy status badge | Hiển thị trạng thái therapy theo màu map | BR/UI | No | [ ] |
| DASH-13 | Alarm emphasis | Hiển thị active alert count và alarm tiêu biểu | BR/UI | No | [ ] |
| DASH-14 | Running inline vitals | Card RUNNING hiển thị PA/PV/PBE/TMP/QB trực tiếp | WF/UI | No | [ ] |
| DASH-15 | Hover vital summary | Card không RUNNING nhưng online có tooltip vital summary khi hover | WF/UI | No | [ ] |
| DASH-16 | TMP fallback calculation | Nếu TMP raw lỗi hoặc bất thường thì tính lại từ pressure | ALG | No | [ ] |
| DASH-17 | WAS/system events panel | Hiển thị thay đổi thông số gần đây trên card | WF/UI | No | [ ] |
| DASH-18 | Event filter and dedup | Chỉ lấy event 30 phút gần nhất, bỏ param loại trừ, merge trong 5 phút | ALG | No | [ ] |
| DASH-19 | Event freshness labels | `just now`, `Xm` cập nhật đều theo thời gian | ALG/UI | No | [ ] |
| DASH-20 | Last sync / offline aging | Sau 45 giây không có telemetry thì chuyển OFFLINE | ALG/WF | No | [ ] |
| DASH-21 | Device persistence | Browser refresh vẫn nhớ known devices qua localStorage | WF | No | [ ] |
| DASH-22 | Forget offline device | Chỉ device OFFLINE mới cho phép forget khỏi dashboard | WF | No | [ ] |
| DASH-23 | WebSocket reconnect | Mất socket phải hiện trạng thái lỗi rồi tự reconnect | WF | No | [ ] |
| DASH-24 | Event polling fallback | Dù refresh browser vẫn lấy lại device events từ API | WF/DBQ | Mixed | [ ] |
| DASH-25 | Status legend | Có thể expand/collapse legend màu trạng thái | UI | No | [ ] |
| DASH-26 | Card navigation | Click card mở monitor detail đúng device | WF | No | [ ] |
| DASH-27 | Alarm audio escalation | Chỉ phát âm thanh khi severity mới xuất hiện, không spam lại liên tục | ALG/WF | No | [ ] |
| DASH-28 | Render stability | Card không rerender vô ích quá mức khi props không đổi | ALG | No | [ ] |

**Ghi chú cơ chế:**
- `DBQ`: có liên quan query dữ liệu backend.
- `WF`: workflow/state/UI flow.
- `ALG`: có logic xử lý, tính toán, lọc, merge hoặc state timing.
- `BR`: business rule.
- `UI`: trình bày giao diện.

---

## 3. Test Cases

### 3.1 Smoke

| ID | Priority | Precondition | Steps | Expected Result | Pass/Fail |
| --- | --- | --- | --- | --- | --- |
| D-SM-01 | P0 | Backend và frontend đang chạy | Mở Dashboard `/` | Trang load thành công, không trắng trang, không crash, có Header | [ ] |
| D-SM-02 | P0 | Backend chưa mở hoặc WS fail | Mở Dashboard | Header hiển thị `OFFLINE` hoặc `CONNECTING`, app không crash | [ ] |
| D-SM-03 | P0 | Không có device nào trong state/localStorage | Mở Dashboard | Hiện empty state, không có card rác, không lỗi console blocker | [ ] |
| D-SM-04 | P1 | Có ít nhất 1 device online | Resize trình duyệt desktop -> tablet -> mobile width | Layout vẫn dùng được, không chồng card nghiêm trọng, zoom không làm mất thao tác chính | [ ] |

### 3.2 Header

| ID | Priority | Precondition | Steps | Expected Result | Pass/Fail |
| --- | --- | --- | --- | --- | --- |
| D-HD-01 | P0 | Backend online, WS kết nối được | Mở Dashboard và quan sát Header | Badge hiển thị `CONNECTED` | [ ] |
| D-HD-02 | P1 | Backend vừa khởi động chậm hoặc socket đang reconnect | Refresh Dashboard lúc backend chưa ổn định | Header có thể đi qua `CONNECTING` rồi mới thành `CONNECTED` | [ ] |
| D-HD-03 | P1 | Có device online và device offline | Quan sát số đếm ở Header | Số active và tổng thiết bị hiển thị đúng theo state hiện tại | [ ] |
| D-HD-04 | P1 | `serverTime` đang được gửi đều | Quan sát đồng hồ 10-20 giây | Đồng hồ chạy đều, không đứng, không nhảy lùi bất thường | [ ] |
| D-HD-05 | P1 | Trình duyệt chưa từng cấp quyền audio cho app | Click nút enable audio | Nút chuyển sang trạng thái enabled nếu browser cho phép, không tự phát âm báo giả | [ ] |

### 3.3 Device Ordering And Summary

| ID | Priority | Precondition | Steps | Expected Result | Pass/Fail |
| --- | --- | --- | --- | --- | --- |
| D-ORD-01 | P0 | Có ít nhất 5 device với trạng thái: critical, warning, caution, advisory, running, offline | Mở Dashboard | Thứ tự ưu tiên phải là critical/malfunction -> warning -> caution -> advisory -> running -> offline/khác | [ ] |
| D-ORD-02 | P1 | Có hỗn hợp device nhiều trạng thái | So sánh summary chips với thực tế card | Số lượng chip khớp với số card từng nhóm | [ ] |
| D-ORD-03 | P1 | Có 0 device ở một số nhóm | Quan sát summary chips | Chỉ hiện chip có `count > 0`, không hiện chip rỗng | [ ] |
| D-ORD-04 | P1 | Có cả online và offline | Quan sát dashboard | Device online ở grid chính, OFFLINE ở section riêng phía dưới | [ ] |

### 3.4 Device Card Presentation

| ID | Priority | Precondition | Steps | Expected Result | Pass/Fail |
| --- | --- | --- | --- | --- | --- |
| D-CARD-01 | P0 | Có device RUNNING với dữ liệu đầy đủ | Quan sát 1 card RUNNING | Card hiển thị mã máy, patient ID, modality, therapy badge, trạng thái online | [ ] |
| D-CARD-02 | P0 | Có device có alarm PRESENT | Quan sát card | Hiển thị active alert count và title alarm đầu tiên đang PRESENT | [ ] |
| D-CARD-03 | P1 | Có device RUNNING không ở alarm card | Quan sát card | Grid PA/PV/PBE/TMP/QB hiển thị trực tiếp trong card | [ ] |
| D-CARD-04 | P1 | Có device online nhưng không RUNNING | Hover card | Hiện tooltip vital summary; bỏ hover thì tooltip biến mất | [ ] |
| D-CARD-05 | P1 | Có device OFFLINE | Quan sát card | Không hiển thị tooltip live data, style card xám và khác online card | [ ] |
| D-CARD-06 | P1 | Có therapy status id hợp lệ | Quan sát badge therapy | Text và màu badge khớp map therapy status, không ra `UNKNOWN` khi id hợp lệ | [ ] |
| D-CARD-07 | P1 | Có device active lâu hơn vài phút | Quan sát footer card | Có `Last sync`/time indicator hợp lý, không để trống vô lý | [ ] |
| D-CARD-08 | P1 | Có card bất kỳ | Click vào card | Điều hướng đúng sang `/monitor/{deviceId}` | [ ] |

### 3.5 Clinical Data Logic On Card

| ID | Priority | Precondition | Steps | Expected Result | Pass/Fail |
| --- | --- | --- | --- | --- | --- |
| D-DATA-01 | P0 | Có device RUNNING với `TMP` raw hợp lệ | Quan sát TMP | TMP hiển thị đúng giá trị raw | [ ] |
| D-DATA-02 | P0 | Có device RUNNING với `TMP` raw thiếu hoặc ngoài ngưỡng hợp lý, nhưng có filter/effluent/return pressure | Quan sát TMP | TMP fallback được tính từ `((filter + effluent) / 2) - return`, không để giá trị rác | [ ] |
| D-DATA-03 | P1 | Có event đổi thông số trong 30 phút gần nhất | Quan sát event panel | Event mới xuất hiện trên card đúng tên parameter và đúng hướng old -> new | [ ] |
| D-DATA-04 | P1 | Có event quá 30 phút | Quan sát event panel | Event cũ hơn 30 phút không còn hiển thị | [ ] |
| D-DATA-05 | P1 | Có event thuộc param nằm trong danh sách loại trừ | Quan sát event panel | Event đó không hiển thị trên dashboard | [ ] |
| D-DATA-06 | P0 | Có chuỗi đổi cùng 1 param trong vòng <= 5 phút, ví dụ 200 -> 220 -> 250 | Quan sát event panel | Dashboard merge thành 1 thay đổi lâm sàng có old sớm nhất và new muộn nhất | [ ] |
| D-DATA-07 | P0 | Có bounce-back nhanh, ví dụ 200 -> 220 -> 200 trong cửa sổ merge | Quan sát event panel | Event triệt tiêu không nên hiển thị như một thay đổi thật | [ ] |
| D-DATA-08 | P1 | Có event rất mới | Quan sát trong 1-2 phút | Nhãn thời gian đổi từ `just now` sang `1m`, `2m` theo thời gian | [ ] |

### 3.6 Realtime, Persistence, And Failure Handling

| ID | Priority | Precondition | Steps | Expected Result | Pass/Fail |
| --- | --- | --- | --- | --- | --- |
| D-RT-01 | P0 | Có device đang gửi telemetry đều | Quan sát Dashboard 1-2 phút | Card duy trì ONLINE/RUNNING, không tự rơi OFFLINE sai | [ ] |
| D-RT-02 | P0 | Có device đang online, sau đó ngắt nguồn dữ liệu > 45 giây | Chờ 45-60 giây | Device chuyển OFFLINE tự động | [ ] |
| D-RT-03 | P1 | Có device đã từng xuất hiện, sau đó refresh browser | Refresh Dashboard | Device vẫn còn trong dashboard nhờ `known_devices`, trạng thái ban đầu có thể là OFFLINE cho tới khi live update về lại | [ ] |
| D-RT-04 | P1 | Có device OFFLINE trong dashboard | Bấm nút forget và xác nhận | Device biến mất khỏi UI và khỏi localStorage | [ ] |
| D-RT-05 | P1 | Có device ONLINE | Quan sát card | Không có nút forget trên card online | [ ] |
| D-RT-06 | P1 | Đang có device events lưu ở backend | Refresh browser | Event panel được nạp lại qua `/api/v1/devices/{id}/events`, không mất sạch lịch sử ngắn hạn | [ ] |
| D-RT-07 | P0 | Đang mở Dashboard rồi tắt backend WS tạm thời | Theo dõi Header | Status chuyển `DISCONNECTED` hoặc `OFFLINE`, sau đó tự reconnect khi backend lên lại | [ ] |
| D-RT-08 | P1 | Audio đã enable, device đang không có alarm | Tạo warning mới rồi critical mới | Chỉ phát âm khi severity mới xuất hiện; không beep liên tục ở mỗi gói telemetry lặp lại | [ ] |

### 3.7 Status Legend

| ID | Priority | Precondition | Steps | Expected Result | Pass/Fail |
| --- | --- | --- | --- | --- | --- |
| D-LEG-01 | P2 | Có ít nhất 1 device trên dashboard | Click `Status Guide` | Legend expand được | [ ] |
| D-LEG-02 | P2 | Legend đang mở | Click lại `Status Guide` | Legend collapse được | [ ] |
| D-LEG-03 | P2 | Legend đang mở | Quan sát legend | Có đủ các trạng thái: malfunction/alarm, warning, caution, advisory, running, offline | [ ] |

---

## 4. Edge Cases QA Nên Soi Kỹ

| ID | Risk | Vì sao quan trọng | QA Check |
| --- | --- | --- | --- |
| D-RISK-01 | OFFLINE dựa trên browser time | Nếu clock client lệch hoặc tab bị pause mạnh, trạng thái có thể đổi muộn/sớm | [ ] |
| D-RISK-02 | Dashboard dùng cả WebSocket và polling events | Có nguy cơ trùng nhận event hoặc race nhẹ giữa polling và live event update | [ ] |
| D-RISK-03 | TMP fallback là logic tính toán | Cần xác nhận không vô tình hiển thị TMP sai khi raw TMP hợp lệ | [ ] |
| D-RISK-04 | Event merge 5 phút | Đây là logic lâm sàng, nếu merge sai sẽ làm mất hoặc bịa thay đổi y lệnh | [ ] |
| D-RISK-05 | Audio escalation | Nếu logic sai sẽ gây beep spam hoặc bỏ sót cảnh báo mới | [ ] |
| D-RISK-06 | localStorage known devices | Có thể giữ lại device cũ quá lâu nếu forget flow hoặc cleanup có lỗi | [ ] |

---

## 5. CTO Notes

Nhận xét cá nhân của mình cho Dashboard ở góc nhìn CTO và người dùng lâm sàng:

- Hướng thiết kế hiện tại khá hợp lý cho trạm theo dõi trung tâm: nhìn nhanh biết máy nào nguy hiểm trước.
- Logic ưu tiên màu và thứ tự card là đúng tinh thần vận hành ICU: alarm/warning phải nổi lên trước dữ liệu đẹp.
- Cơ chế tách `active` và `offline` là hợp lý, giúp tránh nhiễu nhận thức.
- Việc hiển thị event thay đổi thông số ngay trên card là hữu ích, nhưng đây cũng là nơi dễ phát sinh bug thuật toán nhất vì có lọc 30 phút, merge 5 phút, loại trừ param, và bounce-back suppression.
- Với MVP, QA nên ưu tiên test đúng 4 thứ: thứ tự ưu tiên card, OFFLINE aging, event merge/dedup, và audio escalation.
- Nếu một trong 4 nhóm trên sai, dashboard vẫn “đẹp” nhưng sẽ không còn đáng tin về mặt vận hành.

---

## 6. Khuyến nghị chạy test

Thứ tự nên chạy:

1. Smoke
2. Header + connection status
3. Card ordering + summary
4. Realtime/offline/reconnect
5. Event logic
6. Audio
7. Legend và polish

Mức chặn release:

- `P0` fail: không nên sign-off Dashboard.
- `P1` fail: cần đánh giá ảnh hưởng trước khi sign-off.
- `P2` fail: có thể cho qua tạm ở MVP nếu không ảnh hưởng an toàn vận hành.
