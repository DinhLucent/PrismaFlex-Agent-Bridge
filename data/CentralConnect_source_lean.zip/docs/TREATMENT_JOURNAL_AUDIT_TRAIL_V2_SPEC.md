# Treatment Journal Audit Trail V2 Spec

Updated: 2026-04-18
Owner: Codex draft for product + dev alignment
Status: Proposed

## 1. Muc dich

Tai lieu nay chot lai `Audit Trail` cho Treatment Detail theo goc nhin clinical-grade.

Muc tieu:

- tach ro `Clinical Notes` voi `Audit Trail`
- xac dinh action nao can show cho nguoi dung
- xac dinh action nao chi nen de o system log
- map truc tiep vao cac table/service hien co trong codebase
- tranh lap lai sai sot cua version cu: co history feed, nhung chua phai audit trail dung nghia

## 2. Ket luan ngan gon

`Clinical Notes` va `Audit Trail` khong phai la mot.

- `Clinical Notes` = narrative do nguoi dung ghi them
- `Audit Trail` = dau vet bat bien cua cac thay doi co y nghia lam sang va governance

Version cu cua UI da co gia tri, nhung no gan voi `activity feed` hon la `audit trail`.

Audit Trail V2 phai la mot `unified clinical timeline` hop nhat tu 3 nguon:

1. `treatment_notes`
2. `snapshot_audit_log`
3. `treatment_status_events` (co chon loc)

## 3. Gia tri san pham

Audit Trail co gia tri cao o 4 diem:

- truy vet trach nhiem: ai thay doi ho so, luc nao, vi sao
- tang do tin cay khi review: bac si thay duoc can thiep truoc khi approve
- dieu tra su co: phan biet du lieu may, du lieu nhap tay, restore, reject, unlock
- bao ve quy trinh: submit, approve, reject, unlock phai co dau vet ro rang

Neu chi co notes:

- co context
- nhung khong co bang chung thay doi du lieu

Neu chi co system log:

- co su kien
- nhung khong doc duoc theo workflow lam sang

## 4. Dinh nghia dung

### 4.1 Clinical Notes

Noi dung tu do do nguoi dung them moi, append-only.

Vi du:

- "Filter clotting, tang heparin"
- "Benh nhan kich thich, kiem tra lai duong day"

Notes khong phai la mutation log.

### 4.2 Audit Trail

Timeline bat bien cua:

- governance actions
- row-level data mutations
- selected lifecycle events

Moi entry phai tra loi duoc:

- ai
- role nao
- da lam gi
- tac dong vao dau
- khi nao
- neu co, truoc va sau la gi

### 4.3 System Events

Su kien runtime/telemetry khong nhat thiet co y nghia review.

System events van co gia tri, nhung khong nen lam nois default clinical timeline.

## 5. Data sources hien co trong codebase

### 5.1 treatment_notes

Muc dich:

- luu note append-only

Code:

- `backend/db/postgres/models/treatment_notes.py`
- `backend/db/postgres/repositories/notes_repository.py`
- `backend/services/treatment/postgres_treatment_db.py:get_notes()`

Nen show duoi nhom:

- `Notes`

### 5.2 snapshot_audit_log

Muc dich:

- luu row-level mutation audit
- luu review actions trong command service

Code:

- `backend/db/postgres/models/snapshot_audit_log.py`
- `backend/db/postgres/repositories/audit_repository.py`
- `backend/db/postgres/services/journal_command_service.py`
- `backend/db/postgres/services/review_service.py`

Nen show duoi nhom:

- `Clinical Actions`

### 5.3 treatment_status_events

Muc dich:

- luu lifecycle va legacy status events
- hien tai cung dang gan review/system events o mot so flow v1

Code:

- `backend/db/postgres/models/treatment_status_events.py`
- `backend/services/treatment/postgres_treatment_db.py:get_status_log()`
- `backend/services/treatment/treatment_recorder.py`
- `backend/services/treatment/postgres_treatment_db.py:log_approval_event()`

Nen show duoi nhom:

- `System`

chi sau khi da filter bo noise.

## 6. Action taxonomy can show

### 6.1 Bat buoc show trong default audit trail

Day la nhung action nguoi dung can thay ngay, khong can bat filter:

- add note
- submit for review
- approve
- reject
- unlock
- edit existing snapshot values
- restore existing snapshot
- manual insert hour
- patient info update
- clinical time override update
- delete snapshot row
- bulk update rows

Ly do:

- tat ca deu thay doi ho so lam sang hoac governance state

### 6.2 Nen show, nhung o nhom System / filter rieng

- record opened
- same-patient resume
- reconnected after gap
- treatment closed
- patient change
- fresh start `RUN_TIME = 0`
- end received

Ly do:

- co gia tri dieu tra va forensic
- nhung neu show mac dinh se rat on ao

### 6.3 Khong nen show trong clinical audit trail

- refresh list
- open modal
- export JSON
- export RAW
- export Excel
- print preview
- view-only compare

Ly do:

- day la read actions
- khong thay doi ho so

Neu can theo doi security/usage thi dua sang telemetry khac, khong dua vao treatment audit trail.

## 7. Action-by-action recommendation

| Action | Nen show | Nhom | Can hien thi gi |
| --- | --- | --- | --- |
| Add note | Yes | Note | author, role, content, time |
| Submit review | Yes | Governance | actor, role, time |
| Approve | Yes | Governance | actor, role, time |
| Reject | Yes | Governance | actor, role, reason, time |
| Unlock | Yes | Governance | actor, role, time |
| Edit stable row | Yes | Clinical action | row_code, field, old -> new, actor, role, time |
| Restore row | Yes | Clinical action | row_code, field list, actor, role, time |
| Manual insert Hxx | Yes | Clinical action | hour label, actor, role, time |
| Delete row | Yes | Clinical action | row_code, actor, role, reason if any, time |
| Bulk update | Yes | Clinical action | field list, affected scope, actor, role, time |
| Patient info update | Yes | Clinical action | field, old -> new, actor, role, time |
| Start/end override | Yes | Clinical action | old -> new, actor, role, time |
| Record opened | Optional | System | device, patient, time |
| Reconnect gap | Optional | System | gap duration, time |
| Closed | Optional | System | reason, time |

## 8. UI recommendation

### 8.1 Muc tieu UX

Treatment Detail can co 2 lop thong tin:

- timeline table
- audit drawer

Khong nen chen full audit vao tung row table vi:

- rat de roi
- kho doc
- khong scale khi so entry lon

### 8.2 Layout de xuat

Trong Treatment Detail:

- giu bang timeline nhu hien tai
- them mot nut `Ghi chu & Audit Trail`
- mo mot side drawer hoac bottom drawer
- drawer hien timeline moi nhat truoc

### 8.3 Filter trong drawer

Can co 4 filter:

- `All`
- `Notes`
- `Clinical Actions`
- `System`

Mac dinh:

- vao `All`
- nhung `System` co the collapse san neu qua dai

### 8.4 Entry format

Moi entry nen co:

- icon theo loai
- title ngan gon
- subtitle `by <name> • <role>`
- timestamp
- body
- neu la mutation: before -> after

Vi du:

- `Nurse Lan added note`
- `Dr Minh approved treatment`
- `H05.heparin_rate changed: 2.0 -> 2.5`
- `Row H07 restored to machine-original values`

### 8.5 Color mapping

- Notes: amber
- Governance: violet or indigo
- Clinical action: cyan / blue
- System: slate / teal
- Dangerous action nhu delete: red

## 9. What the old UI got right and wrong

### 9.1 Dung

Version cu co y tuong dung:

- gom notes va status history vao mot drawer timeline
- de user xem duoc context ngay trong detail

### 9.2 Sai / chua du

No van thieu 3 diem:

- chua tach `note` va `audit`
- chua show row-level `before -> after`
- dang dua vao `status_log`, trong khi `status_log` chua phai audit mutation dung nghia

Tom lai:

- old UI = good history feed
- V2 = proper audit trail

## 10. Gaps hien tai cua codebase

### 10.1 Frontend gaps

Current frontend da mat wiring cua history drawer:

- `frontend/app/(main)/treatments/DetailPanel.tsx` khong con render `detail.notes` / `detail.status_log`
- `frontend/app/(main)/treatments/types.ts` khong con `notes` va `status_log`

### 10.2 Backend gaps

Backend co data, nhung chua co `unified audit trail API`.

Hien tai:

- notes nam o `treatment_notes`
- row mutation nam o `snapshot_audit_log`
- system/review legacy nam o `treatment_status_events`

Can them mot query layer hop nhat.

### 10.3 Logging gaps

Co mot so mutation hien chua du audit:

- `update_patient_info` chua log field-level audit
- `delete_snapshot` chua log actor/reason vao audit table
- `update_snapshots_bulk` chua log per-field changes
- `manual insert` dang vao `status_events`, chua vao `snapshot_audit_log`
- `add note` dang duoc luu o notes table, nhung khong co normalized audit entry layer

### 10.4 Duplicate semantics

Review actions hien dang co the xuat hien o 2 noi:

- `snapshot_audit_log` trong command flow v2
- `treatment_status_events` trong flow v1

V2 phai normalize de UI khong bi duplicate.

## 11. Backend contract de xuat

Them endpoint read-only:

- `GET /api/v1/treatments/{id}/audit-trail`

Response shape:

```json
{
  "entries": [
    {
      "id": "note-5",
      "kind": "note",
      "action": "add_note",
      "time": "2026-04-18T10:52:35+07:00",
      "actor_name": "Hotfix Test",
      "actor_role": "nurse",
      "target": {
        "type": "treatment"
      },
      "summary": "Added clinical note",
      "body": "hotfix verification note",
      "source_table": "treatment_notes"
    },
    {
      "id": "audit-91",
      "kind": "clinical_action",
      "action": "edit_existing_snapshot_values",
      "time": "2026-04-18T11:02:00+07:00",
      "actor_name": "Nurse Lan",
      "actor_role": "nurse",
      "target": {
        "type": "journal_row",
        "row_code": "H05",
        "field_name": "heparin_rate"
      },
      "summary": "Edited H05.heparin_rate",
      "before": "2.0",
      "after": "2.5",
      "source_table": "snapshot_audit_log"
    }
  ]
}
```

## 12. Mapping rules cho unified API

### 12.1 treatment_notes -> entry

- `kind = note`
- `action = add_note`
- `body = content`
- `actor_name = author_name`
- `actor_role = author_role`

### 12.2 snapshot_audit_log -> entry

- `kind = clinical_action` cho row mutation
- `kind = governance` cho `submit_review`, `approve`, `reject`, `unlock`
- `target.row_code = row_code`, tru khi `row_code = "*"`

Action mapping:

- `edit_existing_snapshot_values` -> `Edited row value`
- `restore_existing_snapshot` -> `Restored row`
- `submit_review` -> `Submitted for review`
- `approve` -> `Approved`
- `reject` -> `Rejected`
- `unlock` -> `Unlocked`

### 12.3 treatment_status_events -> entry

Chi lay cac event co y nghia:

- `RECONNECTED`
- `CLOSED`
- `MANUAL_INSERT`
- `SUBMITTED`
- `APPROVED`
- `REJECTED`
- `UNLOCKED`

Mac dinh bo qua:

- noise `RECORDING`

Neu `snapshot_audit_log` da co governance action tuong duong:

- uu tien `snapshot_audit_log`
- suppress duplicate tu `treatment_status_events`

## 13. Product rule cho man hinh detail

### 13.1 Mac dinh nen show

- Notes
- Governance
- Clinical Actions

### 13.2 Mac dinh nen an sau filter

- System lifecycle

### 13.3 Khong nen cho user sua log

Audit trail phai:

- immutable
- append-only

Khong cho:

- edit note da tao
- xoa note trong normal workflow
- xoa audit entry

Neu can cleanup ky thuat:

- chi qua admin tooling
- phai co ly do

## 14. Implementation order

### Phase A: Restore user-visible value fast

- phuc hoi drawer `Ghi chu & Audit Trail` trong Treatment Detail
- dua lai `notes` va `status_log` vao `TreatmentDetail` type
- render lai history feed de user co ngay gia tri quan sat

### Phase B: Chuyen tu history feed sang audit trail dung nghia

- them `GET /audit-trail`
- hop nhat `notes + snapshot_audit_log + filtered status_events`
- doi drawer sang consume unified entries

### Phase C: Close logging gaps

- audit patient info update
- audit snapshot delete
- audit bulk update
- audit manual insert vao audit table

## 15. Acceptance criteria

Mot doctor mo Treatment Detail phai tra loi duoc ngay:

- treatment nay co note gi khong
- nurse/doc da thay doi gi tren journal
- ho so da submit/approve/reject/unlock luc nao
- ai la nguoi thuc hien
- neu la row edit, gia tri truoc va sau la gi

Khong duoc de:

- history chi show notes ma khong show data mutation
- UI bi duplicate approve/reject tu 2 nguon
- system noise che mat action lam sang quan trong
- user nham `current operator` voi `historical actor`

## 16. Final decision

Chot huong:

- `Clinical Notes` phai ton tai nhu mot nhom rieng
- `Audit Trail` phai la immutable timeline cua governance + journal mutations
- `System Events` chi la lop bo tro, khong phai mac dinh trung tam
- UI detail can phuc hoi phan history ngay, nhung dich cuoi phai la unified audit trail V2
