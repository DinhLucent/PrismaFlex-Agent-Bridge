# Comprehensive QA Test Matrices: Dashboard, Journal, Save Record & Analyzer

> Updated: 2026-04-03
> Status: Aligned with Clinical-Grade hardening (Operator Identity + Edit Policy + Chronology Fix)

Day la bo test matrix tong hop cho cac thanh phan chinh cua PrismaFlex WebApp.
Cross-ref: `docs/treatment-logic-qa-sheet.md` cho SP1-SP5 same-patient continuation cases.

## 1. Dashboard QA Matrix

| ID    | Feature                | Kich ban                                 | Input / Action                                  | Expected Result                                                  | Pass/Fail | Notes |
| :---- | :--------------------- | :--------------------------------------- | :---------------------------------------------- | :--------------------------------------------------------------- | :-------- | :---- |
| DB-01 | Real-time Status       | Thay doi trang thai WAIT -> PRIME -> RUN | Thiet bi gui cac packet chuyen doi lien tuc     | Dashboard cap nhat trang thai va thong so ngay, khong can reload |           |       |
| DB-02 | Treatment Split        | Cung patient nhung `RUN_TIME = 0`        | Packet co `RUN_TIME = 0` trong cung session     | Dashboard bo focus `T1`, hien thi session `T2` moi               |           |       |
| DB-03 | Patient Change         | `patient_id` doi giua chung              | Packet moi mang `patient_id` benh nhan khac     | Dashboard split ngay va hien thi patient moi (`T2`)              |           |       |
| DB-04 | Ghost Session          | Session ket thuc som `< 300s`            | Gui chuoi packet ket thuc nhanh hon 300s        | Dashboard khong giu session rac trong lich su                    |           |       |
| DB-05 | Auto-Timeout           | Mat ket noi > 24h                        | Simulate khong co packet moi qua 24h            | Dashboard danh dau offline / auto-closed dung logic              |           |       |
| DB-06 | Backfill -> Live       | Backfill xong roi co live packet         | Day chuoi backfill, sau do gui live packet      | Dashboard chuyen sang live, khong duplicate device               |           |       |
| DB-07 | Multi-Device Isolation | Device A backfill, device B live         | Gui backfill device A + live device B dong thoi | State A va B doc lap, khong nhiem cheo, B khong bi close sai     |           |       |

## 2. Operator Identity QA Matrix

| ID    | Feature          | Kich ban                          | Input / Action                          | Expected Result                                    | Pass/Fail | Notes |
| :---- | :--------------- | :-------------------------------- | :-------------------------------------- | :------------------------------------------------- | :-------- | :---- |
| OP-01 | First Check-In   | Lan dau bam edit/submit/approve   | Bam bat ky nut mutation                 | Modal hoi ten xuat hien truoc khi action chay      |           |       |
| OP-02 | Session Cache    | Bam them edit sau khi da check-in | Bam edit cell hoac fill gap lan 2+      | Khong hoi lai ten, dung identity tu sessionStorage |           |       |
| OP-03 | Treatment Switch | Doi sang treatment khac           | Chon treatment khac trong list          | Modal hoi ten lai vi treatment_id doi              |           |       |
| OP-04 | Badge Display    | Sau khi check-in                  | Nhin header cua page                    | Badge hien ten operator + nut Doi + nut Xoa        |           |       |
| OP-05 | Badge Change     | Bam nut Doi tren badge            | Bam Doi                                 | Modal hoi ten moi, cap nhat badge                  |           |       |
| OP-06 | Badge Clear      | Bam nut Xoa tren badge            | Bam Xoa                                 | Badge bien mat, lan mutation tiep hoi lai tu dau   |           |       |
| OP-07 | Header Injection | Gui request mutation              | Inspect network request headers         | Co `X-Operator-Name` va `X-User-Role` dung gia tri |           |       |
| OP-08 | Tab Close Reset  | Dong tab roi mo lai               | Dong tab browser, mo lai treatment page | sessionStorage bi xoa, phai check-in lai           |           |       |

## 3. Journal QA Matrix

### 3a. Chronology & Data

| ID    | Feature               | Kich ban                             | Input / Action                                | Expected Result                                                       | Pass/Fail | Notes                                           |
| :---- | :-------------------- | :----------------------------------- | :-------------------------------------------- | :-------------------------------------------------------------------- | :-------- | :---------------------------------------------- |
| JR-01 | OC Chronology         | OC_XX chen vao giua Hxx              | Chen `OC_XX` khi timeline da co H00, H01      | `OC_XX` nam dung vi tri theo `snapshot_time`, khong bi day xuong cuoi |           | Backend ORDER BY snapshot_time ASC              |
| JR-04 | Delete Entry          | Xoa 1 manual entry                   | Xoa `OC_XX` tren UI                           | Entry bi xoa ma khong lam lech chronology row con lai                 |           |                                                 |
| JR-05 | Restore Existing      | Restore 1 row da ton tai bi edit sai | Khoi phuc `OC_XX` hoac `Hxx` dang con ton tai | Row duoc tra ve gia tri goc va giu dung `snapshot_time`               |           | Frontend strips `_` meta keys                   |
| JR-06 | Restore Missing OC    | Restore 1 `OC_XX` da bi xoa/mat      | Khoi phuc missing `OC_XX` tu originals        | Row tao lai voi `snapshot_time` goc, chen dung chronology             |           | Backend preserve time, frontend strip meta keys |
| JR-07 | Journal Continue      | `RUN_TIME > 0` sau END               | Gui `END` -> same patient + `RUN_TIME > 0`    | Journal tiep tuc `T1`, khong mo Journal `T2`                          |           | Cross-ref SP1                                   |
| JR-08 | H00 Stable After Edit | Edit H00 roi reload                  | Sua gia tri H00, F5 reload trang              | H00 van nam o dau timeline, khong nhay xuong cuoi                     |           | snapshot_time preserved                         |
| JR-09 | Print/Export Order    | In hoac export sau khi edit          | Edit H01, sau do bam Print hoac Export Excel  | Timeline in/xuat giu dung clinical order                              |           |                                                 |

### 3b. Edit Policy & RBAC

| ID    | Feature               | Kich ban                          | Input / Action                                | Expected Result                                             | Pass/Fail | Notes          |
| :---- | :-------------------- | :-------------------------------- | :-------------------------------------------- | :---------------------------------------------------------- | :-------- | :------------- |
| JR-10 | Lock IN_PROGRESS      | Edit khi treatment dang chay      | Mo Journal khi treatment `IN_PROGRESS`        | Banner amber lock, tat ca mutation disabled tru Notes       |           |                |
| JR-11 | Notes While Recording | Ghi notes khi dang record         | Bam notes khi treatment `IN_PROGRESS`         | Notes modal mo binh thuong, luu thanh cong                  |           | Notes luon bat |
| JR-12 | APPROVED Lock         | Edit khi treatment da duyet       | Mo Journal khi treatment `APPROVED`           | Banner xanh, toan bo read-only, chi Unlock cho doctor/admin |           |                |
| JR-13 | Unlock Flow           | Doctor bam Unlock                 | Bam Unlock tren treatment `APPROVED`          | Treatment chuyen ve editable, banner bien mat               |           |                |
| JR-14 | Nurse Pending Lock    | Nurse mo treatment PENDING_REVIEW | Nurse vao review khi treatment dang cho duyet | Banner tim, nurse chi doc, khong duoc edit/approve/reject   |           |                |
| JR-15 | Doctor Approve        | Doctor duyet treatment            | Doctor bam Approve tren treatment PENDING     | Treatment chuyen APPROVED, Journal lock                     |           |                |
| JR-16 | Doctor Reject         | Doctor tu choi treatment          | Doctor bam Reject + nhap ly do                | Treatment chuyen ve editable, nurse co the sua lai          |           |                |

### 3c. Error Handling

| ID    | Feature              | Kich ban                      | Input / Action                           | Expected Result                                     | Pass/Fail | Notes         |
| :---- | :------------------- | :---------------------------- | :--------------------------------------- | :-------------------------------------------------- | :-------- | :------------ |
| JR-20 | 400 Missing Operator | Gui request khong co header   | Bypass frontend, gui PUT truc tiep       | Toast do "Thieu thong tin nguoi thao tac"           |           | Backend guard |
| JR-21 | 403 Sai Quyen        | Nurse edit treatment APPROVED | Nurse co gang sua du lieu da duyet       | Toast do "Khong co quyen thuc hien hanh dong nay"   |           |               |
| JR-22 | 409 Dang Record      | Edit khi IN_PROGRESS          | Bypass frontend, gui PUT khi dang record | Toast vang "Dang ghi du lieu — khong the chinh sua" |           |               |
| JR-23 | Network Error        | Mat mang khi save             | Ngat mang roi bam save                   | Toast do "Loi mang"                                 |           |               |

## 4. Save Record & Analyzer QA Matrix

| ID    | Feature          | Kich ban                            | Input / Action                                 | Expected Result                                   | Pass/Fail | Notes |
| :---- | :--------------- | :---------------------------------- | :--------------------------------------------- | :------------------------------------------------ | :-------- | :---- |
| RA-01 | RawData Boundary | T1 bi tach thanh T2                 | Trigger dieu kien `T2` nhu `RUN_TIME = 0`      | Packet T1 vao raw T1, packet moi vao raw T2       |           |       |
| RA-02 | Packet END Owner | Packet bao ket thuc ca              | Gui packet `END` tai boundary                  | `END` luu trong raw cua `T1`, khong lot sang `T2` |           |       |
| RA-03 | Read Concurrency | Analyzer doc luc dang ghi           | Chay Analyzer khi treatment van `IN_PROGRESS`  | Analyzer doc duoc ma khong gay khoa file          |           |       |
| RA-04 | Safe Compression | Analyzer xu ly file sau khi ca dong | Chay Analyzer tren treatment vua `COMPLETED`   | File raw duoc verify/nen an toan                  |           |       |
| RA-05 | Stress Backfill  | Do du lieu cu toc do cao            | Bom 5000+ packet backfill trong vai giay       | Raw luu dung thu tu, khong split sai session      |           |       |
| RA-06 | Out-of-Order     | Packet cu toi sau packet moi        | Gui packet co timestamp nho hon packet da nhan | Raw va Analyzer handle chronology dung            |           |       |
| RA-07 | Multi-Device     | Nhieu may gui dong thoi             | Gui packet tu 3 thiet bi cung luc              | Khong nhiem cheo owner/state giua cac device      |           |       |

## 5. Same-Patient Continuation (SP) Matrix

> Cross-ref: Xem chi tiet tai `docs/treatment-logic-qa-sheet.md` (SP1-SP5)

| ID  | Kich ban                                   | Expected                                     | Status |
| :-- | :----------------------------------------- | :------------------------------------------- | :----- |
| SP1 | RUN -> END -> same patient -> RUN_TIME > 0 | Van la T1, raw noi tiep                      | PASS   |
| SP2 | SP1 + co OC_XX                             | OC_XX interleave dung giua Hxx               | PASS   |
| SP3 | SP1 -> stop -> review/edit                 | Journal chi unlock khi khong con IN_PROGRESS | PASS   |
| SP4 | SP1 -> delete/restore missing              | Restore khong lam sai chronology OC_XX       | PASS   |
| SP5 | RUN -> END -> same patient -> RUN_TIME = 0 | Dong T1, mo T2                               | PASS   |

## Pass / Fail Rules

- `PASS` khi Treatment ID, RawData, Snapshot ownership/boundary, DB/Index, Logs deu dung.
- `FAIL` neu chi can mot packet boundary vao sai treatment.
- `FAIL` neu packet `END` khong nam o treatment cu.
- `FAIL` neu `same patient + RUN_TIME > 0` ma khong resume dung `T1`.
- `FAIL` neu `RUN_TIME = 0` ma van resume `T1`.
- `FAIL` neu xuat hien `no running event loop`, `WinError 32`, hoac close/open churn bat thuong.
