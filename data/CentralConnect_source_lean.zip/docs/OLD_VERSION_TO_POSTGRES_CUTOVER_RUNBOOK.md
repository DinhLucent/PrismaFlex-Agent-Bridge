# Old Version to PostgreSQL Cutover Runbook

Status: Draft for customer-side installation  
Audience: CTO, onsite engineer, backend-agent, ops, customer IT  
Scope: Cut over from old customer installation to the new build that keeps monitor/trends on SQLite but moves Treatment Journal runtime onto PostgreSQL.

## 1. Executive Summary

This cutover is **not** a simple code copy.

The new build has a mixed-storage architecture:

- **Trend / monitor path** still uses SQLite (`backend/trends.db`)
- **Treatment Journal / review / audit / raw manifest path** uses PostgreSQL
- **Raw telemetry files** still live on disk as JSONL chunks under `data/treatments/raw`

This means:

- you **can** wipe old treatment data and re-backfill from Mirth Connect
- but you **must not** blindly delete everything SQLite-related, because `trends.db` still belongs to the monitoring path
- you **must** find and stop hidden old runtime processes before starting the new build

## 2. What Can Be Wiped vs What Must Be Preserved

### Safe to wipe if the customer accepts a clean Treatment reset

- PostgreSQL database `prismaflex` contents
- treatment raw chunks under `data/treatments/raw`
- treatment archive files under `backend/archive`
- old treatment SQLite file:
  - `backend/prismaflex_treatment.db`

### Do NOT wipe unless you intentionally want to reset monitor/trend history too

- `backend/trends.db`
- `backend/trends.db-shm`
- `backend/trends.db-wal`

### Must be preserved

- `backend/prismaflex_reference.db`
- source code folder backup
- logs before cutover

## 3. Hidden Runtime Risk Checklist

Before touching code or database, check for hidden/old runtime components.

On this machine, these were found:

- PM2 processes:
  - `icub-backend`
  - `icub-frontend`
- Windows services:
  - `postgresql-x64-16` (expected)
  - `PrismaFlexDataCapture`
  - `PrismaFlexDecoderService`
  - `PrismaFlexDecoderService_May7`

Customer machines may have similar hidden services or startup tasks.

### Mandatory checks

1. PM2
2. Windows Services
3. Scheduled Tasks
4. Startup folder shortcuts
5. leftover `python.exe`, `pythonw.exe`, `node.exe`

## 4. Important Operational Notes

### 4.1 Do not use these blindly in production

- `start_frontend.bat`
  - currently runs `npm run dev`
  - this is **not** the correct production frontend mode
- `start_backend.bat`
  - kills **all** `python.exe` and `pythonw.exe`
  - dangerous on shared/customer machines

Production startup should use:

- `pm2` with `ecosystem.config.js`

### 4.2 PostgreSQL setup script warning

File:

- `backend/scripts/setup_db.py`

Current behavior:

- creates role `prismaflex`
- creates database `prismaflex`
- uses a hardcoded root Postgres URL in the script

Rule:

- **Do not run this script blindly on the customer machine**
- either:
  - edit it first for the real customer Postgres password
  - or do the DB creation manually with `psql`

### 4.3 Runtime config warning

Backend runs from:

- `cwd = backend/` under PM2

`backend/config.py` reads:

- `POSTGRES_URL`

and defaults to:

- `postgresql+psycopg2://prismaflex:prismaflex@localhost:5432/prismaflex`

Implication:

- if customer credentials differ, you must provide `POSTGRES_URL`
- best options:
  - create `backend/.env`
  - or inject env vars via PM2 config

Do not assume repo-root `.env` will be picked up correctly by backend runtime.

## 5. Pre-Cutover Preparation

### Step 1 - Freeze data ingress

Before changing anything:

1. stop live feed into backend from Mirth
2. keep historical source intact
3. decide the backfill window and exact start/end

If customer wants:

- old Treatment data removed
- then re-backfilled from Mirth

that is acceptable, but only after backups are taken.

### Step 2 - Record the current machine state

Run and save outputs:

```powershell
pm2 list
Get-Service | Where-Object { $_.Name -match 'pm2|postgres|Prisma|ICU|node' -or $_.DisplayName -match 'pm2|postgres|Prisma|ICU|node' } | Select-Object Name,DisplayName,Status
Get-ScheduledTask | Where-Object { $_.TaskName -match 'Prisma|ICU|pm2|backend|frontend' -or $_.TaskPath -match 'Prisma|ICU' } | Select-Object TaskName,TaskPath,State
Get-ChildItem "$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"
Get-Process python,pythonw,node -ErrorAction SilentlyContinue
```

Save screenshots or text outputs into the cutover record.

### Step 3 - Backup the current installation

Backup at minimum:

1. whole project folder
2. `backend/logs/`
3. `backend/archive/`
4. `data/treatments/raw/`
5. `backend/prismaflex_treatment.db`
6. `backend/trends.db*`
7. Postgres dump if the customer machine already has a `prismaflex` DB

Suggested backup structure:

```text
BACKUP_YYYYMMDD_HHMM/
  code/
  logs/
  archive/
  raw/
  sqlite/
  postgres/
```

### Step 4 - Stop all old runtime processes

#### 4.1 PM2

```powershell
pm2 stop all
pm2 delete all
pm2 save
```

#### 4.2 Kill leftover processes

```powershell
taskkill /f /im python.exe
taskkill /f /im pythonw.exe
taskkill /f /im node.exe
```

Then verify:

```powershell
Get-Process python,pythonw,node -ErrorAction SilentlyContinue
```

#### 4.3 Hidden Windows services

If the customer machine still has old decoder/capture services and they are not part of the new target architecture, stop them:

```powershell
Stop-Service PrismaFlexDataCapture -ErrorAction SilentlyContinue
Stop-Service PrismaFlexDecoderService -ErrorAction SilentlyContinue
Stop-Service PrismaFlexDecoderService_May7 -ErrorAction SilentlyContinue
```

If customer confirms they must stay disabled:

```powershell
Set-Service PrismaFlexDataCapture -StartupType Disabled
Set-Service PrismaFlexDecoderService -StartupType Disabled
Set-Service PrismaFlexDecoderService_May7 -StartupType Disabled
```

Only disable after confirming they are truly legacy and not part of the intended production topology.

#### 4.4 Scheduled Tasks / Startup

If any customer machine has old tasks or startup links for PrismaFlex, disable/remove them before new deployment.

## 6. Install / Verify PostgreSQL

### Step 5 - Install PostgreSQL 16

Recommended:

- PostgreSQL 16
- pgAdmin optional but useful

During installation:

- remember the `postgres` superuser password
- ensure Windows service `postgresql-x64-16` is installed and running

Verify:

```powershell
Get-Service postgresql-x64-16
```

Expected:

- `Status = Running`

### Step 6 - Create application role and database

Recommended manual method with `psql`:

```powershell
"C:\\Program Files\\PostgreSQL\\16\\bin\\psql.exe" -U postgres -d postgres
```

Then run:

```sql
CREATE ROLE prismaflex WITH LOGIN PASSWORD 'CHANGE_ME_STRONG_PASSWORD';
CREATE DATABASE prismaflex OWNER prismaflex;
GRANT ALL PRIVILEGES ON DATABASE prismaflex TO prismaflex;
```

### Important note

Do **not** grant SUPERUSER unless there is a proven blocker.

Owner + normal login is the preferred production posture.

## 7. Deploy the New Code

### Step 7 - Replace application files

Recommended:

1. keep a backup of the old folder
2. deploy the new code into a clean folder
3. avoid partial overwrites if the old folder has unknown local edits

If you must reuse the same folder:

- first stop everything completely
- then overwrite only after backup

### Step 8 - Install Python dependencies

From:

- `PrismaFlexWebApp/backend`

Run:

```powershell
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Current required backend stack includes:

- `fastapi`
- `uvicorn`
- `sqlalchemy`
- `alembic`
- `psycopg2-binary`

### Step 9 - Install frontend dependencies and build

From:

- `PrismaFlexWebApp/frontend`

Run:

```powershell
npm ci
npm run build
```

Do not rely on `npm run dev` for production cutover.

## 8. Configure PostgreSQL Connection for Runtime

### Step 10 - Set runtime connection string

Preferred:

- create `backend/.env`

Example:

```env
POSTGRES_URL=postgresql+psycopg2://prismaflex:CHANGE_ME_STRONG_PASSWORD@localhost:5432/prismaflex
LOG_LEVEL=INFO
```

Alternative:

- inject `POSTGRES_URL` via PM2 `env`

### Step 11 - Verify backend config

Current runtime reads:

- `backend/config.py`

Check that effective `POSTGRES_URL` points to the customer DB you just created.

## 9. Run Database Migrations

### Step 12 - Apply Alembic schema

From:

- `PrismaFlexWebApp/backend`

Run:

```powershell
alembic upgrade head
```

### Step 13 - Verify tables exist

Use `psql` or pgAdmin:

```sql
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;
```

Expected important tables:

- `treatments`
- `treatment_journal_rows`
- `treatment_review_state`
- `snapshot_originals`
- `snapshot_audit_log`
- `treatment_list_projection`
- `raw_packet_manifest`

Also verify Alembic:

```sql
SELECT * FROM alembic_version;
```

## 10. Clean Treatment Data for Fresh Backfill

This section is only for the scenario you described:

- customer already on old version
- you intentionally want a clean Treatment reset
- customer will re-backfill from Mirth

### Step 14 - Backup first, then wipe Treatment PostgreSQL tables

Connect to `prismaflex` and run:

```sql
TRUNCATE TABLE
  snapshot_audit_log,
  snapshot_originals,
  treatment_notes,
  treatment_review_state,
  raw_packet_manifest,
  treatment_journal_rows,
  treatment_status_events,
  treatment_phases,
  treatment_list_projection,
  treatment_config,
  treatments
RESTART IDENTITY CASCADE;
```

### Step 15 - Remove old treatment raw files

If customer truly wants a clean replay:

```powershell
Remove-Item 'D:\\PrismaFlexProject\\PrismaFlexDeviceManager - v2\\PrismaFlexWebApp\\data\\treatments\\raw\\*' -Force -ErrorAction SilentlyContinue
```

### Step 16 - Archive or remove old treatment SQLite file

The new runtime path uses Postgres adapter for Treatment.

Old SQLite treatment file should be moved out of the way to avoid confusion:

```powershell
Rename-Item 'D:\\PrismaFlexProject\\PrismaFlexDeviceManager - v2\\PrismaFlexWebApp\\backend\\prismaflex_treatment.db' 'prismaflex_treatment.db.pre_cutover_backup'
```

### Step 17 - Preserve trends unless intentionally resetting monitor history

Do **not** delete:

- `backend/trends.db`
- `backend/trends.db-shm`
- `backend/trends.db-wal`

unless customer explicitly wants monitor history reset too.

## 11. Start the New Application

### Step 18 - Start via PM2

From repo root:

```powershell
pm2 start ecosystem.config.js
pm2 save
```

Verify:

```powershell
pm2 list
```

Expected:

- `icub-backend` online
- `icub-frontend` online

### Step 19 - Verify ports

Backend:

- `http://localhost:8000`

Frontend:

- `http://localhost:3000`

Quick checks:

```powershell
Invoke-WebRequest http://localhost:8000/docs
Invoke-WebRequest http://localhost:3000
```

### Step 20 - Check logs before opening Mirth

Review:

- `backend/logs/backend.log`
- `backend/logs/errors.log`
- `backend/logs/audit.log`
- `backend/logs/replay_status.log`

There must be:

- no Postgres connection error
- no migration/table-not-found error
- no manifest FK error at idle startup

## 12. Backfill and Live Cutover Order

### Step 21 - Open historical backfill first

Recommended operational order:

1. keep live feed paused
2. send historical packets from Mirth first
3. let backfill finish
4. verify treatment list and Journal chronology
5. only then resume live feed

### Step 22 - Verify backfill before opening live

Check:

- treatment list has expected patient/device rows
- journal rows appear
- `OC_XX` chronology is correct
- raw chunks are created
- no duplicate treatments from same-patient continuation

### Step 23 - Resume live feed

After backfill verification:

1. resume live channel from Mirth
2. watch first 10-15 minutes closely
3. verify backfill -> live handoff behavior

Use:

- [BACKFILL_LIVE_HANDOFF_QA_MATRIX.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/BACKFILL_LIVE_HANDOFF_QA_MATRIX.md)

## 13. Post-Install Verification

### Step 24 - Run DB sanity checks

```sql
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;
```

```sql
SELECT * FROM alembic_version;
```

### Step 25 - Run browser/runtime QA

Use:

- [POSTGRES_QA_HANDOFF_REPORT.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/POSTGRES_QA_HANDOFF_REPORT.md)
- [TREATMENT_JOURNAL_RUNTIME_QA_CHECKLIST.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/TREATMENT_JOURNAL_RUNTIME_QA_CHECKLIST.md)
- [BACKFILL_LIVE_HANDOFF_QA_MATRIX.md](D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/BACKFILL_LIVE_HANDOFF_QA_MATRIX.md)

### Step 26 - Pay special attention to these

- first operator check-in
- chronology after reload
- `H00` stability
- `OC_XX` ordering
- same-patient continue
- backfill -> live handoff
- approve/reject/unlock roles

## 14. Rollback Plan

If the new build fails badly and customer must return to the old version:

1. stop PM2 new processes
2. restore old code folder
3. restore old treatment SQLite and raw files if needed
4. point runtime back to the old startup method
5. keep Postgres stopped from app usage until root cause is fixed

Do not attempt partial rollback with mixed old/new code.

## 15. Final CTO Notes

1. This cutover is safest if done in a clean maintenance window.
2. The biggest practical risk is **not** Postgres installation itself.
   The biggest risk is an old hidden runtime path still running in parallel.
3. Do not trust batch files for production startup.
4. Do not wipe `trends.db` unless you intentionally want to reset monitor history.
5. Do not open live Mirth feed until backfill verification is complete.
