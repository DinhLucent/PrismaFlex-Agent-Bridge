## Treatment Data Platform Architecture Spec

Status: Proposed  
Audience: CTO, backend engineers, DB architects, reviewers  
Scope: Replacement of SQLite-based treatment storage with a production-grade SQL platform for multi-user clinical workflows

### 1. Executive Position

The current SQLite design is good enough for a single-machine demo and for validating workflow logic, but it is not the right long-term foundation for a treatment journal that will be:

- edited by multiple users,
- queried concurrently while telemetry is still arriving,
- audited later,
- repaired or replayed,
- and expected to stay clinically consistent under real hospital usage.

My recommendation is:

- Use **PostgreSQL** as the primary operational database.
- Keep the **Treatment Journal** and **clinical workflow state** in PostgreSQL.
- Do **not** expose generic CRUD semantics from the UI.
- Keep the API command-driven and policy-aware.
- Do **not** force all raw telemetry into the same mutation model as the Journal UI.

If the hospital or IT department is already standardized on Microsoft SQL Server and has DBA support, MSSQL is an acceptable enterprise alternative. But from a product and engineering perspective, PostgreSQL is the better default choice for this codebase.

### 2. Why SQLite Is No Longer the Right Fit

The current SQLite implementation already shows strong design intent:

- WAL mode and busy timeout
- a lightweight `treatment_index`
- `snapshot_originals`
- append-only notes
- snapshot chronology fixes
- operator tracking

Those are good decisions.

The problem is not that SQLite is "bad". The problem is that the product is no longer behaving like a simple local log file. It is becoming a multi-actor, stateful clinical workflow system.

Long-term pain points with SQLite in this domain:

- Single-writer bottleneck under sustained concurrent writes
- Operational fragility on shared machines or multi-process access
- Weak migration governance
- Harder audit and locking semantics
- Poor fit for growing event/audit tables
- Poor separation between OLTP journal state and heavy telemetry storage
- Greater risk when future features require role-aware editing, review queues, or concurrent sessions

For a clinical-facing journal, consistency and observability matter more than minimal setup.

### 3. Technology Choice: PostgreSQL vs MSSQL

#### Recommended default: PostgreSQL

Reasons:

- Best fit for Python/FastAPI ecosystems
- Excellent support for transactional OLTP workloads
- Strong indexing and partitioning
- Native JSON/JSONB when needed, without forcing schemaless design
- Easier local/dev/staging parity than MSSQL
- Lower operational friction for an app team
- Better fit for future event/audit workloads

#### Acceptable alternative: Microsoft SQL Server

Use MSSQL only if one or more of these are true:

- hospital IT already mandates MSSQL,
- backup/replication/monitoring is already standardized on Microsoft stack,
- DBAs are already operating SQL Server for related systems,
- Windows-only operational alignment is a hard requirement.

#### CTO position

If we are choosing based on this application's architecture, I recommend **PostgreSQL**.

If we are choosing based on hospital-wide infrastructure policy, MSSQL may override that.

### 4. What the Current System Is Actually Doing

This spec is reverse-engineered from current code behavior, not from abstract theory.

Current storage and query responsibilities live mainly in:

- `backend/services/treatment/treatment_database.py`
- `backend/routers/treatment_router.py`

Current data model already covers these domains:

- treatment master record
- phase history
- therapy status log
- journal rows (`H00`, `H01`, `OC_XX`, ...)
- treatment setup/config
- notes
- treatment list/index
- raw packets
- frozen originals for review/restore

Current query patterns:

- paginated list of treatments by outcome/patient/device/time
- fetch full treatment detail by `treatment_id`
- fetch snapshots ordered by `snapshot_time`
- append status log entries
- append note log entries
- update a single snapshot row
- freeze snapshots to originals on submit
- retrieve originals for compare/review
- export raw telemetry
- approval state transitions (`DRAFT`, `PENDING_REVIEW`, `APPROVED`)

This is not a generic spreadsheet. It is already a workflow-oriented clinical record system.

### 5. Architectural Principle

The biggest design choice is this:

**The Treatment Journal must be command-driven, not CRUD-driven.**

That means:

- UI should not send arbitrary "update row", "add row", or "delete row" requests without semantic intent.
- Backend should expose clinical commands with explicit policy gates.
- Database should enforce chronology, identity, and immutability for clinical timestamps.

This is the core difference between a safe journal platform and a fragile editable grid.

### 6. Proposed Bounded Contexts

The current SQLite file mixes several concerns. In PostgreSQL, these should be separated logically.

#### A. Treatment Lifecycle

Owns:

- treatment identity
- patient/device association
- start/end
- outcome/state
- interruption/continuation metadata

#### B. Treatment Journal

Owns:

- hourly rows
- order-change rows
- manual edits on existing stable rows
- clinical timestamps

#### C. Review and Approval

Owns:

- submit for review
- approve/reject/unlock
- review comments and audit
- frozen originals

#### D. Notes and Annotations

Owns:

- append-only clinical notes
- authorship
- timestamps

#### E. Telemetry / Raw Data

Owns:

- raw packet persistence
- replay/export support
- forensic traceability

This should not share the same mutation path as the Journal UI.

### 7. High-Level Data Architecture

```mermaid
flowchart LR
  A["Telemetry ingestion"] --> B["Treatment lifecycle service"]
  A --> C["Raw telemetry store"]
  B --> D["Journal command service"]
  D --> E["PostgreSQL OLTP"]
  F["Review / Journal UI"] --> D
  G["Doctor review UI"] --> D
  H["Reporting / export"] --> I["Journal query service"]
  I --> E
  J["Replay / repair tools"] --> C
  J --> E
```

### 8. Recommended Database Strategy

#### 8.1 PostgreSQL OLTP database

Use PostgreSQL as the operational source of truth for:

- treatments
- journal rows
- review state
- originals
- audit
- notes
- lightweight listing/index views

#### 8.2 Raw telemetry strategy

I do **not** recommend forcing all raw packet storage into the same OLTP table model as the Journal UI long-term.

Recommended path:

- Short term:
  - keep raw packets in PostgreSQL only if volume is still manageable,
  - partition by treatment date or packet time.
- Long term:
  - store raw packets in object storage or chunked files,
  - keep only metadata/manifests in PostgreSQL.

Why:

- raw telemetry is high-volume and append-heavy,
- journal edits are low-volume and transaction-sensitive,
- these are different workloads and should not compete unnecessarily.

### 9. Proposed Schema

The goal is not to normalize the Journal into dozens of tiny cell tables. For this UI, the current wide-row pattern is still the right shape.

#### 9.1 `treatments`

Purpose:

- treatment master record

Key columns:

- `id UUID PRIMARY KEY`
- `device_id TEXT NOT NULL`
- `patient_id TEXT`
- `patient_name TEXT`
- `therapy_type_id INT`
- `anticoag_type_id INT`
- `start_time TIMESTAMPTZ NOT NULL`
- `first_run_time TIMESTAMPTZ`
- `end_time TIMESTAMPTZ`
- `last_seen_time TIMESTAMPTZ NOT NULL`
- `outcome TEXT NOT NULL`
- `fsm_state TEXT NOT NULL`
- `close_reason TEXT`
- `total_run_seconds INT`
- `total_paused_seconds INT`
- `total_phases INT`
- `total_packets BIGINT`
- `is_valid BOOLEAN`
- `had_interruption BOOLEAN`
- `had_program_restart BOOLEAN`
- `sw_version TEXT`
- `start_time_override TIMESTAMPTZ`
- `end_time_override TIMESTAMPTZ`
- `clinical_notes TEXT`
- `created_at TIMESTAMPTZ NOT NULL`
- `updated_at TIMESTAMPTZ NOT NULL`
- `version INT NOT NULL DEFAULT 1`

Constraints:

- `CHECK (outcome IN ('IN_PROGRESS','COMPLETED','INTERRUPTED','ARCHIVED','INVALID'))`

Indexes:

- `(device_id, start_time DESC)`
- `(patient_id, start_time DESC)`
- `(outcome, start_time DESC)`

#### 9.2 `treatment_phases`

Purpose:

- lifecycle segments for pauses, resumes, same-patient continuation

Columns:

- `id UUID PRIMARY KEY`
- `treatment_id UUID NOT NULL`
- `phase_number INT NOT NULL`
- `phase_type TEXT NOT NULL`
- `start_time TIMESTAMPTZ NOT NULL`
- `end_time TIMESTAMPTZ`
- `created_at TIMESTAMPTZ NOT NULL`
- `updated_at TIMESTAMPTZ NOT NULL`

Indexes:

- `(treatment_id, phase_number)`

#### 9.3 `treatment_status_events`

Purpose:

- append-only state/event log

Columns:

- `id BIGSERIAL PRIMARY KEY`
- `treatment_id UUID NOT NULL`
- `device_id TEXT NOT NULL`
- `event_time TIMESTAMPTZ NOT NULL`
- `therapy_status_id INT`
- `fsm_state TEXT NOT NULL`
- `patient_id TEXT`
- `event_code TEXT NOT NULL`
- `note TEXT`
- `created_at TIMESTAMPTZ NOT NULL`

Indexes:

- `(treatment_id, event_time ASC)`
- `(device_id, event_time DESC)`
- `(event_code, event_time DESC)`

#### 9.4 `treatment_journal_rows`

Purpose:

- source of truth for the journal grid

This is the replacement for `treatment_hourly_snapshots`.

Columns:

- `id BIGSERIAL PRIMARY KEY`
- `treatment_id UUID NOT NULL`
- `device_id TEXT NOT NULL`
- `row_code TEXT NOT NULL`
- `row_kind TEXT NOT NULL`
- `snapshot_time TIMESTAMPTZ NOT NULL`
- `stable_at TIMESTAMPTZ`
- `source TEXT NOT NULL`
- `is_deleted BOOLEAN NOT NULL DEFAULT FALSE`
- `deleted_at TIMESTAMPTZ`
- `deleted_by TEXT`

Telemetry columns:

- `qb NUMERIC(10,2)`
- `qs NUMERIC(10,2)`
- `qd NUMERIC(10,2)`
- `qpbp NUMERIC(10,2)`
- `pa NUMERIC(10,2)`
- `pv NUMERIC(10,2)`
- `pbe NUMERIC(10,2)`
- `tmp NUMERIC(10,2)`
- `uf_total NUMERIC(12,2)`
- `uf_hourly NUMERIC(12,2)`
- `effluent_flow NUMERIC(12,2)`
- `run_time_sec INT`
- `blood_vol NUMERIC(12,2)`
- `heparin_rate NUMERIC(12,2)`
- `pt_weight NUMERIC(12,2)`
- `uf_rate_target NUMERIC(12,2)`
- `citrate_dose NUMERIC(12,2)`
- `citrate_conc NUMERIC(12,2)`
- `citrate_load NUMERIC(12,2)`
- `calcium_comp NUMERIC(12,2)`
- `calcium_rate NUMERIC(12,2)`
- `anticoag_type_id INT`

Manual-editable columns:

- `heparin_bolus TEXT`
- `solution_type TEXT`
- `duosol_count NUMERIC(12,2)`
- `prismasol_count NUMERIC(12,2)`
- `filter_type TEXT`
- `kali NUMERIC(12,2)`
- `notes TEXT`

Audit columns:

- `created_at TIMESTAMPTZ NOT NULL`
- `updated_at TIMESTAMPTZ NOT NULL`
- `created_by TEXT`
- `updated_by TEXT`
- `version INT NOT NULL DEFAULT 1`

Constraints:

- `UNIQUE (treatment_id, row_code)`
- `CHECK (row_kind IN ('HOUR','ORDER_CHANGE'))`
- `CHECK (source IN ('AUTO','MANUAL','MERGED','RESTORED'))`

Important rule:

- `snapshot_time` is immutable after insertion.

Indexes:

- `(treatment_id, snapshot_time ASC)`
- `(treatment_id, row_code)`
- `(treatment_id, row_kind, snapshot_time ASC)`
- partial index on non-deleted rows:
  - `(treatment_id, snapshot_time ASC) WHERE is_deleted = FALSE`

#### 9.5 `snapshot_originals`

Purpose:

- frozen machine-original rows used in review and restore

Columns:

- `id BIGSERIAL PRIMARY KEY`
- `treatment_id UUID NOT NULL`
- `row_code TEXT NOT NULL`
- `snapshot_time TIMESTAMPTZ NOT NULL`
- `snapshot_json JSONB NOT NULL`
- `frozen_at TIMESTAMPTZ NOT NULL`
- `frozen_by TEXT`

Constraints:

- `UNIQUE (treatment_id, row_code)`

Indexes:

- `(treatment_id, snapshot_time ASC)`

#### 9.6 `treatment_review_state`

Purpose:

- approval workflow state

Columns:

- `treatment_id UUID PRIMARY KEY`
- `approval_status TEXT NOT NULL`
- `submitted_at TIMESTAMPTZ`
- `submitted_by TEXT`
- `approved_at TIMESTAMPTZ`
- `approved_by TEXT`
- `rejected_at TIMESTAMPTZ`
- `rejected_by TEXT`
- `reject_reason TEXT`
- `unlocked_at TIMESTAMPTZ`
- `unlocked_by TEXT`
- `updated_at TIMESTAMPTZ NOT NULL`

Constraints:

- `CHECK (approval_status IN ('DRAFT','PENDING_REVIEW','APPROVED','REJECTED'))`

Indexes:

- `(approval_status, updated_at DESC)`

#### 9.7 `treatment_notes`

Purpose:

- append-only note stream

Columns:

- `id BIGSERIAL PRIMARY KEY`
- `treatment_id UUID NOT NULL`
- `author_name TEXT NOT NULL`
- `author_role TEXT`
- `content TEXT NOT NULL`
- `created_at TIMESTAMPTZ NOT NULL`

Indexes:

- `(treatment_id, created_at ASC)`

#### 9.8 `snapshot_audit_log`

Purpose:

- append-only audit for every manual journal mutation

Columns:

- `id BIGSERIAL PRIMARY KEY`
- `treatment_id UUID NOT NULL`
- `row_code TEXT NOT NULL`
- `action TEXT NOT NULL`
- `field_name TEXT`
- `old_value JSONB`
- `new_value JSONB`
- `operator_name TEXT NOT NULL`
- `operator_role TEXT`
- `reason TEXT`
- `created_at TIMESTAMPTZ NOT NULL`

Indexes:

- `(treatment_id, created_at DESC)`
- `(treatment_id, row_code, created_at DESC)`
- `(operator_name, created_at DESC)`

#### 9.9 `treatment_list_projection`

Purpose:

- fast list view projection

This is the conceptual successor to `treatment_index`.

I would keep this pattern.

Why:

- list/history screens should not join heavy journal/event tables every time,
- it gives us a stable UX projection,
- it keeps paginated list queries simple and fast.

Implementation options:

- a real table maintained by application commands, or
- a materialized view refreshed asynchronously.

For this product, I recommend a **real projection table** maintained by the application.

#### 9.10 `raw_packet_manifest`

Purpose:

- metadata only for raw telemetry chunks or object storage references

Columns:

- `id BIGSERIAL PRIMARY KEY`
- `treatment_id UUID NOT NULL`
- `storage_kind TEXT NOT NULL`
- `chunk_seq INT NOT NULL`
- `packet_time_min TIMESTAMPTZ`
- `packet_time_max TIMESTAMPTZ`
- `packet_count BIGINT NOT NULL`
- `byte_count BIGINT`
- `content_ref TEXT NOT NULL`
- `created_at TIMESTAMPTZ NOT NULL`

Indexes:

- `(treatment_id, chunk_seq)`
- `(treatment_id, packet_time_min, packet_time_max)`

### 10. Command Model

This is where I disagree with a generic query/add/delete/update approach.

The Journal API should expose commands like:

- `edit_existing_snapshot_values`
- `restore_existing_snapshot`
- `submit_treatment_review`
- `approve_treatment`
- `reject_treatment`
- `unlock_treatment`
- `append_note`
- `update_patient_context`

The API should **not** expose open-ended table CRUD semantics to the clinical UI.

Why:

- policy becomes enforceable,
- chronology becomes enforceable,
- audit becomes meaningful,
- review state remains safe,
- UI cannot accidentally mutate structure it should never own.

### 11. Policy Matrix

#### Nurse

- Can edit allowed manual fields on existing stable rows
- Can write notes
- Can submit for review
- Cannot delete rows
- Cannot restore missing rows
- Cannot create structural rows

#### Doctor/Admin

- Can review and approve/reject
- Can unlock approved treatments
- Can perform structural repair actions only after treatment is no longer recording

#### Important CTO decision

I recommend removing these from the normal Journal UI:

- add next hour
- fill gap
- restore missing row
- delete row

These belong either in:

- a doctor/admin-only review screen,
- or a separate maintenance tool,
- or a backend replay/rebuild workflow.

### 12. Query Design

#### 12.1 Treatment list

Do not build the list screen by scanning `treatments` plus subqueries every time.

Use `treatment_list_projection`.

Filters expected:

- outcome
- approval_status
- patient
- device
- start time range

Use cursor pagination, not large OFFSET scans, once dataset grows materially.

#### 12.2 Treatment detail

One request should return:

- treatment master
- config/setup
- review state
- journal rows ordered by `snapshot_time`
- optional notes

Do not return raw packets in this request.

#### 12.3 Review compare

Fetch:

- current journal rows
- frozen originals

Both ordered by `snapshot_time`.

#### 12.4 Notes

Append-only. Query by `(treatment_id, created_at)`.

#### 12.5 Status and event timelines

Append-only. Query by `(treatment_id, event_time)`.

### 13. Index Strategy

From the current codebase and expected growth, these are the critical rules:

- Every foreign key gets an index
- Every `WHERE` + `ORDER BY` pair used in UI gets a supporting composite index
- Journal timeline must have `(treatment_id, snapshot_time)`
- Status log must have `(treatment_id, event_time)`
- Notes must have `(treatment_id, created_at)`
- Projection list needs `(approval_status, start_time DESC)` and `(outcome, start_time DESC)`

Avoid index sprawl. Every index must justify an actual query pattern.

### 14. Partitioning Strategy

Partitioning is not needed for every table.

#### Do not partition yet

- `treatments`
- `treatment_review_state`
- `treatment_list_projection`
- `snapshot_originals`

#### Strong candidates for partitioning

- `treatment_status_events`
- `snapshot_audit_log`
- raw telemetry tables if raw stays in SQL

Recommended partitioning approach:

- monthly range partition by `created_at` or `event_time`

Do not over-partition early. Partition only the append-heavy tables.

### 15. Transaction and Concurrency Rules

#### Keep transactions short

Do not hold long UI-driven transactions while doing heavy compare/export work.

#### Use optimistic locking on journal rows

`version` should increment on each update.

UI submits:

- `row_code`
- `version`
- changed fields only

If version mismatches:

- reject with conflict,
- reload row,
- let user retry.

This is much safer than last-write-wins if multiple users ever touch the same row.

#### Immutable clinical timestamp

`snapshot_time` must never change after row creation.

This is non-negotiable.

### 16. Raw Telemetry Decision

This is the part where I do **not** fully agree with "database everything" if interpreted literally.

I recommend:

- Journal, review, notes, audit, and projections: PostgreSQL
- Raw telemetry: choose based on scale

Short term:

- partitioned PostgreSQL table is acceptable

Long term:

- chunked files or object storage
- manifest and query metadata in PostgreSQL

Reason:

- raw telemetry is not the same workload as interactive journal review,
- combining them too tightly will eventually create operational friction.

### 17. Module Split Recommendation

If the backend keeps growing, split the current monolithic `treatment_database.py`.

Recommended modules:

- `treatment_repository.py`
- `journal_repository.py`
- `review_repository.py`
- `notes_repository.py`
- `audit_repository.py`
- `projection_repository.py`
- `raw_repository.py`

Service layer:

- `journal_command_service.py`
- `journal_query_service.py`
- `review_service.py`
- `operator_audit_service.py`
- `treatment_projection_service.py`

Router should only do:

- HTTP validation
- role/operator extraction
- command dispatch

This split is worth doing if the next wave includes Postgres migration plus policy hardening.

### 18. Migration Plan

#### Phase 1: Stabilize current semantics

Before migration:

- remove high-risk UI features from Journal
- freeze command model
- finalize policy matrix
- stop adding generic snapshot mutations

#### Phase 2: Introduce PostgreSQL in parallel

- create Postgres schema
- dual-write selected entities if needed
- build read verification scripts
- compare SQLite vs Postgres outputs on real treatments

#### Phase 3: Migrate read paths

- treatment list
- treatment detail
- review compare
- notes

#### Phase 4: Migrate write paths

- patient updates
- snapshot value edits
- review commands
- notes

#### Phase 5: Move raw storage strategy

- decide: keep raw in SQL partitions or move to object storage + manifest

#### Phase 6: Decommission SQLite

- only after parity checks pass

### 19. Non-Goals

This spec does not recommend:

- turning the Journal into a fully generic spreadsheet
- EAV-style per-cell schema for the main grid
- letting the UI send arbitrary CRUD mutations
- mixing heavy telemetry writes and interactive journal review into one unbounded table forever

### 20. Final Recommendation

My CTO recommendation is:

1. Move the treatment platform to **PostgreSQL**.
2. Keep the Journal as a **wide-row relational model**, not EAV.
3. Keep a separate **projection table** for list/history.
4. Make the Journal API **command-driven**, not CRUD-driven.
5. Keep `snapshot_time` immutable and audit every manual change.
6. Treat raw telemetry as a separate storage concern from the interactive journal.
7. Remove risky structural timeline operations from the normal Journal UI.

This gives us:

- better concurrency,
- better auditability,
- safer review flows,
- clearer ownership boundaries,
- and a database design that scales with real usage instead of only with the demo.
