# LIVE Simulation Test Plan

Muc tieu cua bo test nay la mo phong lai ingest gan giong van hanh that nhat co the, nhung khong bat dau bang Mirth. Cac bai test duoi day dung cung mot file raw cu, sau do chay o 3 che do:

- `LIVE`
- `BACKFILL`
- `CUTOVER` = backfill xong roi chuyen sang live tren cung file

Tool moi:

- [simulate_ingest.py](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/backend/tools/simulate_ingest.py)

## Vi sao test theo cach nay

- Neu fail o `code + raw`, loi nam o runtime/pipeline, khong bi nhieu boi Mirth.
- Neu pass o simulator nhung fail qua Mirth, luc do moi nghi toi ordering/channel merge.
- `CUTOVER` la case nhay cam nhat, vi no tra loi cau hoi: "backfill xong, live tiep treatment do thi raw va snap co tiep tuc on khong?"

## Input duoc ho tro

Tool nhan:

- raw pre-Mirth: `packet_num`, `s_header`, `s_body`
- hoac payload da normalize: `meta`, `header`, `body`

## Che do route

### Split route

Dung khi backend moi da tach:

- `/api/v1/telemetry/backfill`
- `/api/v1/telemetry/live`
- `/api/v1/devices/{device_id}/handoff`

Vi du:

```bash
cd backend
python -m tools.simulate_ingest ..\\data\\done\\May4_data.ndjson --mode cutover --route-style split --cutover-at-index 1000 --backfill-speed 0 --live-speed 60
```

### Legacy route

Dung khi backend cu van chi co:

- `/api/v1/telemetry`

Vi du:

```bash
cd backend
python -m tools.simulate_ingest ..\\data\\done\\May4_data.ndjson --mode live --route-style legacy --speed 60
```

## Scenario A - Raw file as LIVE

Muc tieu:

- gia lap file cu nhu dang chay live
- xem runtime continuity, `Hxx`, `OC_XX`, va raw streaming co on khong

Lenh:

```bash
cd backend
python -m tools.simulate_ingest ..\\data\\done\\May4_data.ndjson --mode live --route-style split --speed 60
```

Check:

- `treatments` co bi tach treatment bat thuong khong
- `treatment_journal_rows` co `Hxx` va `OC_XX` hop ly khong
- `raw_packet_manifest` co chunk active/finalized dung boundary khong

## Scenario B - Raw file as BACKFILL

Muc tieu:

- xac nhan chronology backfill khi khong qua Mirth
- phan biet ro fail do importer hay do channel merge

Lenh:

```bash
cd backend
python -m tools.simulate_ingest ..\\data\\done\\May4_data.ndjson --mode backfill --route-style split --speed 0
```

Tuy chon:

```bash
python -m tools.simulate_ingest ..\\data\\done\\May4_data.ndjson --mode backfill --route-style split --sort-by-time --speed 0
```

Check:

- file unsorted phai canh bao `out_of_order_pairs > 0`
- file sorted moi dung de danh gia importer chronology

## Scenario C - BACKFILL -> LIVE cutover

Muc tieu:

- backfill mot phan raw
- goi handoff
- live tiep cung treatment do
- xem raw co tiep treatment hay bi split sai

Lenh:

```bash
cd backend
python -m tools.simulate_ingest ..\\data\\done\\May4_data.ndjson --mode cutover --route-style split --cutover-at-index 5000 --backfill-speed 0 --live-speed 120
```

Hoac cutover theo moc thoi gian:

```bash
cd backend
python -m tools.simulate_ingest ..\\data\\done\\May4_data.ndjson --mode cutover --route-style split --cutover-at-timestamp "2026-02-11 22:30:00 UTC" --backfill-speed 0 --live-speed 120
```

Check quan trong nhat:

- `treatment_id` truoc va sau handoff co giong nhau khong
- `Hxx` co tiep noi dung chronology khong
- `OC_XX` live sau cutover co chen vao dung treatment khong
- `raw_packet_manifest` co tiep tuc theo cung `treatment_id` khong
- chunk raw moi neu duoc tao thi co van thuoc cung treatment khong

## SQL checks can chay sau moi scenario

```sql
SELECT id, patient_id, device_id, start_time, end_time, outcome, total_packets
FROM treatments
ORDER BY start_time DESC;
```

```sql
SELECT treatment_id, row_code, row_kind, snapshot_time
FROM treatment_journal_rows
ORDER BY snapshot_time;
```

```sql
SELECT treatment_id, chunk_index, first_timestamp, last_timestamp, is_closed
FROM raw_packet_manifest
ORDER BY treatment_id, chunk_index;
```

```sql
SELECT device_id, active_mode, active_treatment_id, last_patient_id, last_seen_time
FROM device_state;
```

## Ket qua mong doi cho CUTOVER

- backend khong duoc tao treatment moi neu van la same device + same patient + treatment dang tiep tuc
- raw co the mo chunk moi sau handoff, nhung van phai thuoc cung `treatment_id`
- khong duoc mat `Hxx`
- `OC_XX` sau handoff phai vao dung treatment dang tiep tuc

## Luu y ve file raw May4

`May4_data.ndjson` da duoc self-check la bi interleave nang. Vi vay:

- dung `--sort-by-time` neu muon danh gia importer theo contract chronology sach
- dung file goc unsorted nhu mot negative test de kiem tra warning/logging va resilience
