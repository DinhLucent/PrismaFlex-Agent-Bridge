# Backend PostgreSQL Phase 2 Fixes (Stabilization)

**Date:** 2026-04-04
**Role:** backend-agent
**Objective:** Resolve the remaining 6 gates identified in `POSTGRES_RELEASE_READINESS_GATE.md` to unblock production release.

As the CTO, I have audited the codebase and compiled the exact locations and requirements for your stabilization work. Execute these sequentially.

---

## 🔴 Priority 0: Active Runtime Path Fixes (Gates 1 & 3)

**Assignment:** `backend-agent` (Execute BOTH in the same session)
**Reasoning:** Both are intertwined in the active runtime path (snapshot/recorder/raw streamer). Separating them increases the risk of regressions.

### 1. Clear Legacy SQLite References (Gate-1)

**File:** `backend/services/treatment/treatment_snapshot_service.py`
**Issue:** The service still contains raw SQL queries (`fetch_one`/`execute`) referencing the legacy `treatment_hourly_snapshots` table.
**Fix required at lines:** 229, 288, 332, 413.
**Strict Rule:**

- Do NOT just "rename the table".
- Remove the dependency on `fetch_one()` / `execute()` at these journal runtime paths.
- Map the logic completely to the new `treatment_journal_rows` ORM / repository query helpers.

### 2. Fix Manifest FK Ordering (Gate-3)

**Context:** When a new treatment starts, `raw_streamer` creates a new chunk and writes to `raw_packet_manifest`.
**Issue:** Manifest row is sometimes inserted before the `treatments` row is committed, causing an FK violation.
**Strict Rule:**

- **Lock the contract:** The `treatments` row MUST surely exist/be committed before the manifest write occurs.
- Best approach: Ensure `create_treatment` flushes/commits _before_ the raw streamer is allowed to register a chunk.
- If a manifest write attempts to happen abnormally early, it must fail clearly and trigger a controlled retry, **not** fail silently.

### 🏁 Deliverable After Step 1 (Gates 1+3)

The `backend-agent` must return:

1. Files changed.
2. A short note: which legacy refs were removed, and what the new treatment/raw ordering is.
3. Which tests/verifications were run.
4. Any remaining risks left open.

---

## 🟡 Priority 1: Data Integrity (Gates 2 & 5)

### 3. Audit Log Accuracy (Gate-5)

**File:** `backend/db/postgres/services/journal_command_service.py`
**Issue:** The current edit command does not accurately capture `old_value` and `new_value` in the audit log (or it captures the already-mutated value as both).
**Action:** In `edit_journal_row()`, ensure you fetch and store the `old_value` _before_ applying the mutation dictionary, so the `SnapshotAuditLog` accurately reflects the delta.

### 4. Manifest Schema Drift (Gate-2)

**Files:** `backend/db/postgres/models/raw_packet_manifest.py` & `backend/db/postgres/migrations/`
**Issue:** We had two migrations modifying the manifest. Ensure that the SQLAlchemy model exactly matches the final migrated schema (e.g., uses `file_path` instead of `content_ref`, `chunk_index` instead of `chunk_seq`).
**Action:** Audit `raw_packet_manifest.py` vs the DB schema and fix any drift.

---

## 🟢 Priority 2: V2 API Hardening (Gates 4 & 6)

### 5. Proper DTO Serialization (Gate-6)

**File:** `backend/routers/treatment_command_router.py`
**Issue:** Endpoints like `get_treatment_detail` and `get_review_compare` return `{"status": "ok", "data": str(result)}`.
**Action:** Replace `str(result)` with proper Pydantic schemas or correct JSON serialization that the frontend can actually parse.

### 6. V2 Policy Enforcement (Gate-4)

**File:** `backend/db/postgres/services/journal_command_service.py` / `treatment_command_router.py`
**Issue:** `edit_snapshot_values` needs to enforce strict clinical rules.
**Action:**

- Ensure the target row exists (404 if not).
- Implement row stability check (e.g., cannot edit a row if it's already frozen or if it belongs to a finalized treatment).
- Implement field allowlist (only allow editing specific manual fields, drop/reject attempts to inject raw telemetry fields).

---

## 🏁 Exit Criteria

Once you complete these 6 fixes:

1. Run local tests / verify backend startup.
2. Update `POSTGRES_RELEASE_READINESS_GATE.md` to mark all gates as RESOLVED.
3. Update `DASHBOARD.md` to indicate backend stabilization is complete, handing off to `qa-lead-agent`.
