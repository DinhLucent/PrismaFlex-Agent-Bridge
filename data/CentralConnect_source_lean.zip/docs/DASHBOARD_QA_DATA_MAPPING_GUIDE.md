# DASHBOARD QA DATA MAPPING GUIDE

**Updated:** 2026-04-05  
**Role:** QA / Tester / Dev / CTO  
**Status:** Working reference

Tài liệu này giải thích kỹ luồng dữ liệu của **Dashboard** để QA có thể:

- hiểu packet máy thật đang có shape gì
- hiểu backend Dashboard thực sự đọc trường nào
- biết phần nào là decode, phần nào là reference lookup
- tạo fake data đúng tầng để test
- không phải đoán mò PID, alarm ID, therapy ID

---

## 1. Vấn đề QA đang gặp là gì

Dashboard không lấy trực tiếp một object “đã sẵn sàng cho UI”.

Nó đi qua nhiều lớp:

1. Máy PrismaFlex gửi S-message nhị phân
2. Decoder đổi sang JSON có `s_header` và `s_body.parameters[]`
3. Backend nhận packet qua `/api/v1/telemetry`
4. Backend enrich bằng **Reference DB**
5. Backend broadcast ra WebSocket
6. Frontend tiếp tục lọc/suy diễn để vẽ card, event, summary, offline state

Vì vậy nếu QA chỉ nhìn một packet decode lớn rồi thử sửa PID ngẫu nhiên, rất dễ test sai tầng.

---

## 2. Có 3 shape dữ liệu khác nhau

### 2.1 Decoder output

Đây là shape rất gần với packet bạn đưa:

```json
{
  "packet_num": 169,
  "timestamp": "2026-01-30T08:37:13.347598",
  "packet_length": 2188,
  "s_header": { "...": "..." },
  "s_body": {
    "total_records": 172,
    "parameters": [ { "...": "..." } ]
  }
}
```

Shape này đúng với decoder ở [prismaflex_decoder.py](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/prismaflex_decoder.py).

### 2.2 Ingestion payload mà backend Dashboard cần

Đây mới là shape nên post vào `/api/v1/telemetry`:

```json
{
  "meta": {
    "device_id": "QA_DASH_001",
    "timestamp": "2026-04-05T10:00:00+07:00",
    "packet_num": 1
  },
  "s_header": {
    "machine_id": 7,
    "patient_id": "PT001",
    "therapy_type_id": 3,
    "therapy_status_id": 5,
    "timestamp": "2026-04-05 10:00:00 UTC",
    "sw_version": "SW8.20V04R00"
  },
  "s_body": {
    "parameters": []
  }
}
```

Backend đọc:

- `meta.device_id`
- `meta.timestamp`
- `meta.packet_num`
- `s_header` hoặc `header`
- `s_body` hoặc `body`

Xem ở [main.py#L482](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/main.py#L482).

**Điểm rất quan trọng:**

- Packet decode mẫu của QA **chưa đủ** để post thẳng vào Dashboard test.
- Nếu thiếu `meta.device_id`, backend sẽ không biết card thuộc máy nào.
- Nếu `packet_num` không tăng dần theo từng `device_id`, fast update có thể bị frontend bỏ qua.

### 2.3 Frontend state mà Dashboard thực sự dùng

Frontend không giữ nguyên packet gốc.

Nó giữ `deviceMap`, `deviceEvents`, `connectionStatus`, `serverTime` trong [WebSocketProvider.tsx](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/frontend/app/providers/WebSocketProvider.tsx).

Dashboard page chỉ đọc một phần của state này để vẽ:

- `device.id`
- `device.status`
- `device.active_alarms`
- `device.data.s_header.patient_id`
- `device.data.s_header.therapy_type_id`
- `device.data.s_header.therapy_status_id`
- `device.data.s_body.parameters`
- `deviceEvents[device.id]`

Xem ở [page.tsx#L189](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/frontend/app/%28main%29/page.tsx#L189).

---

## 3. End-to-End Pipeline cho Dashboard

### Bước 1: Packet decode

Packet nhị phân được decode thành:

- `s_header`
- `s_body.parameters[]`

Mỗi parameter có:

- `type`: `Actual`, `Set`, `Alarm`
- `id`
- `value`
- `record_num`
- `record_time`

### Bước 2: Backend ingest

Backend nhận payload ở `/api/v1/telemetry` tại [main.py#L482](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/main.py#L482).

Backend lấy:

- `header = data.get("s_header") or data.get("header", {})`
- `body = data.get("s_body") or data.get("body", {})`
- `meta = data.get("meta", {})`

### Bước 3: Fast path cho Dashboard

Nếu packet được coi là `LIVE`, backend sẽ cắt gọn packet bằng [telemetry_filter.py#L30](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/services/treatment/telemetry_filter.py#L30) và broadcast `TELEMETRY_FAST_UPDATE`.

Fast path chỉ lấy:

- `meta.device_id`
- `meta.timestamp`
- `meta.packet_num`
- `s_header.patient_id`
- `s_header.therapy_type_id`
- `s_header.therapy_status_id`
- một số vital PID quan trọng
- alarm type record đơn giản

### Bước 4: Heavy path

Mọi packet đều vào queue background.

Ở đây backend:

- enrich therapy type/status name bằng Reference DB
- enrich parameter label / value_text
- convert `Alarm` records thành `active_alarms`
- lưu trend / event / alarm history
- broadcast `TELEMETRY_UPDATE`
- broadcast `EVENT_UPDATE` nếu có thay đổi parameter tracked

Xem ở [main.py#L279](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/main.py#L279).

### Bước 5: Frontend tổng hợp

Frontend nhận:

- `HEARTBEAT`
- `TELEMETRY_FAST_UPDATE`
- `TELEMETRY_UPDATE`
- `EVENT_UPDATE`

và còn poll thêm:

- `/api/v1/devices/{id}/events`

Xem ở [WebSocketProvider.tsx#L163](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/frontend/app/providers/WebSocketProvider.tsx#L163).

---

## 4. Reference DB làm gì

Reference DB dùng class [ReferenceDatabase](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/prismaflex_lib/reference_db.py).

### 4.1 Therapy type

Từ `therapy_type_id`, backend suy ra tên therapy:

- `0 = SCUF`
- `1 = CVVH`
- `2 = CVVHD`
- `3 = CVVHDF`
- `4 = TPE`
- `5 = HP`
- `6 = NOT_CHOOSE`

### 4.2 Therapy status

Từ `therapy_status_id`, backend suy ra tên status:

- `0 = IDLE`
- `5 = RUN`
- `6 = CHANGE_BAGS`
- `7 = THERAPY_STOPPED`
- `8 = END`
- `9 = RETURN`

Nhưng frontend Dashboard còn có logic riêng để quy status hiển thị:

- `[1,2,3,4,5,10,11,12,13,14,15] => RUNNING`
- `[0,6,7,8] => STOPPED`
- `9 => ALARM`

Xem ở [WebSocketProvider.tsx#L266](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/frontend/app/providers/WebSocketProvider.tsx#L266).

**Kết luận rất quan trọng cho QA:**

- `therapy_status_id` chủ yếu quyết định badge/status tổng quát.
- **Màu alarm card không nên giả lập chỉ bằng therapy_status_id.**
- Màu severity card đến từ `active_alarms.category`.

### 4.3 Parameter label và value_text

Backend tra `numerical_parameters` và `enumerative_parameters` để:

- thêm `label`
- thêm `value_text` cho enumerative parameters

Xem ở [main.py#L316](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/main.py#L316).

### 4.4 Alarm mapping

Backend chỉ tạo `active_alarms` khi parameter có:

- `type == "Alarm"`
- `value in [1, 2]`

Sau đó lookup `alarm_id` trong bảng `alarms` của `prismaflex_reference.db`.

Xem ở [main.py#L304](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/main.py#L304) và [reference_db.py#L76](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/prismaflex_lib/reference_db.py#L76).

**Điểm QA phải nhớ:**

- `body.alarms` không phải là contract chính cho dashboard card.
- Thứ dashboard dùng là `parameters[]` có `type = "Alarm"`.

---

## 5. PIDs quan trọng cho Dashboard

## 5.1 Header IDs quan trọng

| Field | Ý nghĩa | Dùng ở đâu |
| --- | --- | --- |
| `meta.device_id` | ID của card | toàn Dashboard |
| `s_header.patient_id` | Patient hiện tại | card subtitle |
| `s_header.therapy_type_id` | Loại therapy | modality |
| `s_header.therapy_status_id` | Badge trạng thái | therapy badge và state |
| `meta.packet_num` | chống update cũ đè update mới | fast update |
| `meta.timestamp` | quyết định LIVE/DELAYED | fast path / quality |

## 5.2 Vital PIDs dùng cho fast Dashboard path

Fast path chỉ trích các PID sau trong [telemetry_filter.py#L12](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/services/treatment/telemetry_filter.py#L12):

| PID | Label nội bộ | Ý nghĩa |
| --- | --- | --- |
| `1` | `access_pressure` | PA |
| `2` | `filter_pressure` | Filter pressure |
| `3` | `effluent_pressure` | Effluent pressure |
| `4` | `return_pressure` | PV |
| `6` | `tmp` | TMP |
| `17` | `blood_flow_qb` | QB |
| `18` | `replacement_flow_pre` | QS pre |
| `19` | `replacement_flow_post` | QS post |
| `21` | `dialysate_flow_qd` | QD |
| `22` | `pbp_flow` | QPBP |
| `23` | `effluent_rate` | Effluent rate |
| `24` | `net_uf_rate` | Net UF |
| `38` | `heparin_flow` | Heparin |
| `410` | `effluent_dose` | Effluent dose |

**Lưu ý:**

- Fast path chỉ lấy `type == "Actual"`.
- Nếu QA muốn card update nhanh và ổn định, nên gửi các PID này dưới `type = "Actual"`.

## 5.3 PIDs mà Dashboard event panel thực sự track

Event panel không track mọi PID.

Nó chỉ track các PID ở [event_service.py#L24](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/services/event_service.py#L24):

| PID | Ý nghĩa |
| --- | --- |
| `17` | Blood flow |
| `18` | Replacement pre flow |
| `19` | Replacement post flow |
| `21` | Dialysate flow |
| `22` | Pre-blood flow |
| `24` | Patient fluid removal / UF balance |
| `37` | Bolus interval |
| `38` | Heparin continuous rate |
| `47` | Pre-HCT |
| `400` | Citrate-related |
| `406` | Calcium compensation |
| `409` | Anticoag type |
| `410` | Effluent dose |
| `411` | Filter type |
| `412` | related enumerative setting |
| `413` | related enumerative setting |
| `414` | related enumerative setting |
| `460` | related setting |

**Lưu ý quan trọng:**

- Pressure PID `1,2,3,4,6` không được track trong event panel vì quá nhiễu.
- Nếu QA đổi pressure mà chờ event panel hiện WAS, đó là test sai kỳ vọng.

---

## 6. Dashboard card màu và severity đến từ đâu

Card được ưu tiên và tô màu theo `active_alarms`, không phải chỉ theo therapy status.

Frontend sort theo thứ tự:

1. `ALARM` hoặc `MALFUNCTION`
2. `WARNING`
3. `CAUTION`
4. `ADVISORY`
5. `RUNNING`
6. `OFFLINE`

Xem ở [page.tsx#L91](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/frontend/app/%28main%29/page.tsx#L91).

### 6.1 Alarm sample IDs thật từ Reference DB

QA có thể dùng các ID thật sau:

| Category | Alarm ID | Title | Mục đích test |
| --- | --- | --- | --- |
| `WARNING` | `1` | `Air in Blood` | warning card |
| `WARNING` | `6` | `Filter Clotted` | warning card |
| `CAUTION` | `193` | `Unresolved Flow Problem` | caution card |
| `ADVISORY` | `226` | `Check Access` | advisory card |
| `MALFUNCTION` | `65` | `General System Failure (0)` | critical/malfunction card |
| `MALFUNCTION` | `67` | `Communication Error (2)` | critical/malfunction card |

### 6.2 Cách fake alarm đúng

Thêm vào `parameters[]`:

```json
{ "type": "Alarm", "id": 1, "value": 1 }
```

hoặc:

```json
{ "type": "Alarm", "id": 65, "value": 1 }
```

Ý nghĩa:

- `value = 1` -> `PRESENT`
- `value = 2` -> `OVERRIDDEN`

---

## 7. Packet mẫu của bạn map thế nào với Dashboard

Từ packet mẫu bạn đưa:

- `therapy_type_id = 3` -> `CVVHDF`
- `therapy_status_id = 5` -> running therapy
- `patient_id = "g7"` -> hiện trên card
- `PID 1 = -40` -> Access pressure
- `PID 2 = 235` -> Filter pressure
- `PID 3 = 127` -> Effluent pressure
- `PID 4 = 129` -> Return pressure
- `PID 6 = 61` -> TMP
- `PID 17 = 200` xuất hiện ở `Set` -> QB cho flow setting
- `PID 18 = 0`, `19 = 600`, `21 = 600`, `22 = 100` -> flow settings
- `PID 24 = 250` -> UF / patient fluid removal setting
- `PID 38 = 0` -> heparin rate
- `PID 409 = 1` -> anticoag type `Systemic`
- `PID 410 = 31` -> effluent dose
- `PID 411 = 4` -> filter type enumerative
- `PID 461 = 57041` -> run time

**Nhưng để Dashboard test được, QA vẫn phải thêm `meta.device_id`, `meta.timestamp`, `meta.packet_num`.**

---

## 8. Fake data strategy cho QA

## 8.1 Không nên fake ở DB trực tiếp

Cho Dashboard QA, nên fake ở tầng:

- `POST /api/v1/telemetry`

Không nên bắt đầu bằng:

- sửa trực tiếp SQLite trend DB
- sửa trực tiếp Postgres journal tables
- tiêm data thẳng vào frontend state

Vì như vậy sẽ bỏ qua logic mapping và rất dễ sai kết luận.

## 8.2 Khi nào nên dùng packet tối giản

Dùng packet tối giản khi test:

- card có hiện không
- therapy badge
- patient ID
- summary counts
- offline aging
- event merge
- alarm card

Packet tối giản là đủ, không cần 172 record.

## 8.3 Khi nào nên dùng packet gần máy thật

Dùng packet decode gần máy thật khi test:

- parity decoder
- scale/accuracy
- duplicate PID order
- compatibility giữa decoder cũ và nguồn data mới

---

## 9. Các scenario QA nên dùng

## 9.1 Scenario A: Green running card

Mục tiêu:

- có card online
- therapy mode hiện đúng
- patient ID hiện đúng
- vitals hiện đúng

Payload tối thiểu:

```json
{
  "meta": {
    "device_id": "QA_RUN_001",
    "timestamp": "NOW_ISO",
    "packet_num": 1
  },
  "s_header": {
    "machine_id": 7,
    "patient_id": "PT_QA_001",
    "therapy_type_id": 3,
    "therapy_status_id": 5,
    "timestamp": "NOW_MACHINE_TIME",
    "sw_version": "SW8.20V04R00"
  },
  "s_body": {
    "parameters": [
      { "type": "Actual", "id": 1, "value": -40 },
      { "type": "Actual", "id": 2, "value": 235 },
      { "type": "Actual", "id": 3, "value": 127 },
      { "type": "Actual", "id": 4, "value": 129 },
      { "type": "Actual", "id": 6, "value": 61 },
      { "type": "Actual", "id": 17, "value": 200 }
    ]
  }
}
```

## 9.2 Scenario B: TMP fallback

Mục tiêu:

- test TMP fallback trên card

Payload:

- bỏ PID `6`
- vẫn giữ PID `2`, `3`, `4`

Frontend sẽ tính:

```text
TMP = ((filter + effluent) / 2) - return
```

Xem ở [page.tsx#L207](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/frontend/app/%28main%29/page.tsx#L207).

## 9.3 Scenario C: Event panel QB change

Mục tiêu:

- test event panel và merge window

Gửi cùng `device_id`:

1. packet 1: PID `17 = 200`
2. packet 2: PID `17 = 220`
3. packet 3: PID `17 = 250`

trong vòng <= 5 phút.

Kỳ vọng:

- Dashboard merge thành một thay đổi `200 -> 250`

## 9.4 Scenario D: Warning alarm card

Mục tiêu:

- test card warning

Thêm:

```json
{ "type": "Alarm", "id": 1, "value": 1 }
```

Kỳ vọng:

- card warning
- title có thể là `Air in Blood`
- summary chip warning tăng

## 9.5 Scenario E: Malfunction card

Mục tiêu:

- test critical/malfunction priority

Thêm:

```json
{ "type": "Alarm", "id": 65, "value": 1 }
```

Kỳ vọng:

- card nhảy lên đầu
- category = `MALFUNCTION`
- summary alarm tăng

## 9.6 Scenario F: Patient/session reset

Mục tiêu:

- test behavior khi đổi patient

Gửi cùng `device_id` nhưng đổi:

- `patient_id` từ `PT_A` sang `PT_B`

Kỳ vọng:

- cache event/session có thể bị purge/reset ở backend

Xem ở [event_service.py#L65](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/backend/services/event_service.py#L65).

**QA lưu ý:**

- đừng dùng scenario này cho test UI card thông thường
- chỉ dùng khi test session reset/patient change

---

## 10. Những field QA có thể bỏ qua khi test Dashboard

Thường không cần quan tâm khi test Dashboard cơ bản:

- `stx`
- `crc`
- `packet_length`
- `message_counter`
- `command_code`
- `flags`
- `record_num`
- `record_time`
- đa số PID scale/load/sensor nội bộ không hiển thị trên card

Các field này quan trọng cho protocol/debug sâu, nhưng không phải đầu vào tối thiểu của Dashboard QA.

---

## 11. Những bẫy QA dễ gặp

### Bẫy 1: Post đúng packet decode nhưng quên `meta.device_id`

Kết quả:

- card không lên đúng máy
- hoặc device thành `unknown`

### Bẫy 2: Dùng timestamp quá cũ

Kết quả:

- packet bị coi là `DELAYED`
- fast path không chạy
- UI không phản ứng như mong đợi realtime

### Bẫy 3: `packet_num` không tăng

Kết quả:

- fast update bị bỏ qua vì frontend chống packet cũ đè packet mới

### Bẫy 4: Dùng pressure PID để chờ event panel

Kết quả:

- event panel không hiện
- vì pressure PID không nằm trong tracked change set

### Bẫy 5: Chỉ đổi `therapy_status_id` để mong có alarm card

Kết quả:

- card có thể đổi badge/status
- nhưng không có severity alarm như QA mong đợi

### Bẫy 6: Đổi `patient_id` trong test UI bình thường

Kết quả:

- backend reset/purge event history của device
- test về event/continuity bị nhiễu

---

## 12. Khuyến nghị cho QA

Thứ tự tốt nhất để dựng test data:

1. Dựng `device_id`, `packet_num`, `timestamp` chuẩn
2. Dựng `s_header` tối thiểu
3. Dựng 5-6 PID vital chính
4. Thêm tracked PID nếu test events
5. Thêm `Alarm` type record nếu test severity
6. Chỉ đổi `patient_id` khi test session reset

Nếu muốn nhanh, team QA nên duy trì **một bộ fixture chuẩn**:

- `clean_running.json`
- `tmp_fallback.json`
- `warning_alarm.json`
- `malfunction_alarm.json`
- `qb_change_step1.json`
- `qb_change_step2.json`
- `patient_change.json`

---

## 13. Tài liệu liên quan

- [PrismaFlex-Protocol-Spec.md](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/PrismaFlex-Protocol-Spec.md)
- [TREATMENT_JOURNAL_PACKET_TO_PID_MAPPING.md](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/TREATMENT_JOURNAL_PACKET_TO_PID_MAPPING.md)
- [RAW_TELEMETRY_ARCHITECTURE_SPEC.md](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/RAW_TELEMETRY_ARCHITECTURE_SPEC.md)
- [DASHBOARD_QA_CHECKLIST_AND_TEST_CASES.md](/D:/PrismaFlexProject/PrismaFlexDeviceManager%20-%20v2/PrismaFlexWebApp/docs/DASHBOARD_QA_CHECKLIST_AND_TEST_CASES.md)

