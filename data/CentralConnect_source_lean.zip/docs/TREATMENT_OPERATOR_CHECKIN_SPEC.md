# Treatment Operator Check-In Spec

> Updated: 2026-04-03
> Scope: require a human operator name before any manual treatment mutation in demo mode

## Goal

Add a simple, practical operator identity step for demo use:

- before a user can edit treatment data, they must enter the current operator name
- the name is entered once per treatment editing session
- the name is then attached to later mutations for auditability

This is not a login system.
This is a lightweight clinical traceability feature for demo environments.

## Product Decision

## Yes, require an operator name before any treatment mutation.

But:

- do not ask for it while only viewing
- do not ask for it on every cell edit
- ask once per treatment edit session
- show it clearly in the UI
- allow changing it explicitly

## Why this is the right balance

### Good

- better traceability than anonymous edits
- much lighter than full login
- fits shared-computer demo workflow
- easy for nurses/doctors to understand

### Avoided bad UX

- no repeated typing on every edit
- no forced account system yet
- no hard dependency on staff directory

## Core Principle

`role` and `operator` are different things.

- `role` answers: what actions are allowed?
- `operator` answers: who actually performed this action?

In demo mode:

- `role` stays as current role switch (`nurse`, `doctor`, `admin`)
- `operator` is a free-text human name entered before editing

Operator name does not grant permission by itself.
It only identifies the person behind an allowed action.

## Scope

This requirement applies to manual treatment mutations only.

Examples:

- edit snapshot row
- restore snapshot row
- fill internal gap row
- delete snapshot row
- edit patient info
- edit clinical notes
- submit for review
- approve / reject / unlock

This does not apply to:

- viewing data
- automatic telemetry capture
- background system jobs

## UX Flow

### 1. View mode

User opens a treatment:

- no operator prompt
- can browse freely

### 2. First mutation attempt

If user clicks any write action and no operator is active for this treatment:

- open modal
- ask for operator name
- require non-empty value
- after confirm, continue the original action

### 3. Active operator session

While editing the same treatment:

- do not ask again for every action
- show visible badge:
  - `Người thao tác: <name>`
- provide:
  - `Đổi người thao tác`
  - `Xóa người thao tác`

### 4. If operator is cleared

- next write action prompts again

## Input Rules

Demo-mode operator input can be free text.

Validation:

- trim whitespace
- minimum 2 characters
- maximum 60 characters
- reject blank values

Recommended:

- preserve exact user-entered casing
- collapse repeated spaces

Examples accepted:

- `Nguyen Thi A`
- `Dieu duong Lan`
- `BS Minh`

## Session Model

Use one operator per treatment editing session.

Recommended storage:

- frontend state + `sessionStorage`

Recommended key:

- `treatment_operator::<treatment_id>`

Stored data:

- `name`
- `role`
- `captured_at`

## Lifetime

Keep operator context only for the current browser session.

Recommended clearing rules:

- clear when switching to another treatment
- clear when role changes
- clear when user clicks `Đổi người thao tác`
- clear on browser tab close automatically via `sessionStorage`

Optional:

- clear after successful `submit`, `approve`, or `unlock`

Do not use `localStorage` for this feature.
Reason:

- shared hospital/demo machines can leak stale operator identity across sessions

## Interaction With Snapshot Edit Policy

Operator check-in does not replace edit policy.

Order of enforcement must be:

1. Can this action happen in the current treatment state?
2. Does the current role allow it?
3. Is there a valid operator name?
4. Then perform mutation.

So:

- if treatment is still recording, action is blocked even if operator name exists
- if treatment is approved, action is blocked unless unlocked
- if role is wrong, action is blocked even if operator name exists

## Backend Requirements

Backend must enforce operator presence for write routes.

Do not rely only on UI.

### Header

Recommended request header:

- `X-Operator-Name`

Optional companion header:

- `X-User-Role` already exists and should remain

### Validation helper

Add one shared helper:

- `require_operator_name(request)`

Behavior:

- read `X-Operator-Name`
- trim and validate
- raise `400 Bad Request` if missing/blank

### Apply to mutation endpoints

At minimum:

- `PUT /treatments/{id}/patient`
- `PUT /treatments/{id}/notes`
- `PUT /treatments/{id}/snapshots/{hourLabel}`
- `DELETE /treatments/{id}/snapshots/{hourLabel}`
- `POST /treatments/{id}/snapshots/manual`
- `PUT /treatments/{id}/snapshots-bulk` if still kept
- `POST /treatments/{id}/submit`
- `POST /treatments/{id}/approve`
- `POST /treatments/{id}/reject`
- `POST /treatments/{id}/unlock`

Automatic telemetry ingestion must not require operator headers.

## Data Recording Strategy

For demo mode, use a minimal but useful audit model.

## Required

Every accepted manual mutation must log:

- operator name
- role
- action type
- timestamp

### Minimum viable implementation

Reuse existing audit/event logging:

- write operator name into audit logger message
- append operator name to `log_approval_event(...)`

Examples:

- `MANUAL_EDIT by Nguyen Thi A (nurse)`
- `RESTORE_ROW by BS Minh (doctor)`

## Recommended schema addition

Add `updated_by` to `treatment_hourly_snapshots`.

Why:

- lets UI show who last edited a row
- helps support teams inspect a treatment without reading logs

Recommended future-safe columns:

- `updated_by TEXT`
- optional later: `created_by TEXT`

For demo v1, `updated_by` is enough.

For other entities like notes or patient info:

- logging may be enough for now
- do not over-model too early

## Frontend Requirements

### Add an Operator Check-In modal

Suggested fields:

- `Tên người thao tác`

Buttons:

- `Xác nhận`
- `Hủy`

### Add a small operator badge in treatment detail

Example:

- `Người thao tác: Nguyen Thi A`

Actions:

- `Đổi`
- `Xóa`

### Wrap all write actions

Before any mutation:

- call `ensureOperatorForTreatment(treatmentId, role)`
- if no operator exists, open modal
- continue action only after success

### Important

Do not ask for operator name when:

- opening the detail panel
- opening print preview
- exporting
- viewing review

Only ask when the user is about to mutate data.

## Suggested Implementation Shape

### Frontend helper

Create one helper or hook:

- `useTreatmentOperator()`

Responsibilities:

- get current operator for treatment
- set operator
- clear operator
- ensure operator before action

### Mutation wrapper

Create one shared function:

- `fetchWithOperator(...)`

Responsibilities:

- append `X-Operator-Name`
- append `X-User-Role`
- keep mutation calls consistent

This avoids patching each screen ad hoc.

## User Scenarios

### Scenario 1: nurse opens treatment just to read

Expected:

- no prompt
- no friction

### Scenario 2: nurse clicks edit on `H02`

Expected:

- modal asks for operator name
- after confirm, edit proceeds
- future edits in same treatment do not ask again

### Scenario 3: nurse edits multiple rows in one treatment

Expected:

- operator captured once
- same name used for all later writes

### Scenario 4: doctor opens same treatment later

Expected:

- if role changed, operator session must be re-entered
- do not silently reuse nurse identity

### Scenario 5: user changes treatment

Expected:

- new treatment requires its own operator check-in for writes

### Scenario 6: recording is active

Expected:

- user may have operator name
- write action is still blocked by recording policy

### Scenario 7: approved treatment

Expected:

- operator name alone does not bypass lock
- unlock flow still required

## Risks And Mitigations

### Risk 1: typo in operator name

Accepted for demo mode.

Mitigation:

- visible operator badge
- easy change operator action

### Risk 2: stale operator on shared machine

Mitigation:

- use `sessionStorage`, not `localStorage`
- clear on treatment switch and role change

### Risk 3: fake names

Accepted for demo mode.

Future phase:

- replace with login-backed identity

### Risk 4: extra friction

Mitigation:

- prompt only on first mutation
- never prompt for read-only actions

## Acceptance Criteria

- Viewing a treatment does not ask for operator name.
- First mutation attempt asks for operator name if none is active.
- Operator name is reused for later mutations in the same treatment session.
- Switching treatment requires a new operator context.
- Switching role requires a new operator context.
- Backend rejects write requests without operator name.
- Audit trail includes operator name for all manual treatment mutations.
- Active recording lock still wins over operator check-in.
- Approved lock still wins over operator check-in.

## Recommended OPUS Scope

### Phase 1

- frontend operator modal
- session-scoped operator storage
- `X-Operator-Name` header for mutation calls
- backend validation helper
- audit log integration

### Phase 2

- `updated_by` on snapshot rows
- UI badge on each edited row

### Phase 3

- replace free-text operator with real account identity

## One-Line Product Policy

Before anyone can change a treatment record, the system must know who is touching it — even in demo mode.
