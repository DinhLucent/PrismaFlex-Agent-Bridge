# Treatment Snapshot Workflow

> Updated: 2026-04-03 (Hotfix #2)
> Status: **Mainline Ready (Clinical Grade)**
> Scope: Identity-aware mutations, status-based locking, stable clinical chronology, and 3 hotfixes for deployment readiness.

## Purpose

This document explains the hardened Treatment Snapshot system, detailing how operator traceability and edit policies are enforced across the stack, and how clinical chronology is preserved.

### Core Enhancements (2026-04-03 Fix)

- **Identity Gating**: All mutations require a checked-in operator.
- **Edit Policy**: UI and Backend locking based on treatment status (Recording/Pending/Approved).
- **Audit Logging**: Every manual edit records the operator name in `updated_by`.
- **Chronology Stability**: Manual edits no longer overwrite clinical `snapshot_time`. `OC_XX` rows are interleaved by clinical timestamp.

### Hotfixes for Mainline Readiness (2026-04-03 #2)

- **EditableCell First-Click Fix**: `ensureOperator()` now wraps the click-to-edit action, preventing 400 errors on first edit.
- **Review Delete Fix**: `deleteSnapshot()` now uses `fetchWithOperator()` with proper error handling.
- **Restore OC_XX Chronology Fix**: Backend `update_snapshot_manual()` now accepts `snapshot_time` from payload for missing rows, preventing OC_XX from falling back to `now()`.

## Hardened Workflow

```mermaid
flowchart TD
    subgraph Entry ["Telemetry & Automated"]
        P["Telemetry Packet"] --> Proc["process_packet()"]
        Proc --> H00["H00: Initial baseline (Frozen @ 60s)"]
        Proc --> HXX["HXX: Hourly rows (Bucket-driven)"]
        Proc --> OC["OC_XX: Order-change (Event-driven)"]
    end

    subgraph Identity ["Frontend Identity Gate"]
        User["User Interaction"] --> Gate{"ensureOperator()"}
        Gate -- "Missing" --> Modal["Identity Check-In Modal"]
        Modal --> ID["sessionStorage Identity"]
        Gate -- "Exists" --> ID
    end

    subgraph Mutation ["Mutation Workflow"]
        ID --> Fetch["fetchWithOperator()"]
        Fetch --> Headers["Headers: X-Operator-Name, X-User-Role"]
        Headers --> Guard1["require_operator_name()"]
        Guard1 --> Guard2["can_mutate_snapshots()"]
        Guard2 -- "Status Lock" --> Error["403 / 409 Toast Failure"]
        Guard2 -- "Permitted" --> Service["TreatmentSnapshotService"]
    end

    subgraph Integrity ["Data Integrity & Chronology"]
        Service --> Upsert["upsert_snapshot()"]
        Upsert --> DB[("SQLite Table (Audit: updated_by)")]
        DB -- "manual/restore" --> Pres["Preserve clinical snapshot_time"]
        DB -- "auto" --> AutoT["Derive from Clinical Packet Time"]
    end

    subgraph Display ["Ordered Output"]
        DB --> GET["GET snapshots"]
        GET --> Sort["Sort Interleave Logic"]
        Sort --> ST["Stable clinical timeline: H rows + interleaved OC"]
        ST --> UI_View["Detail / Review / Export / Print"]
    end
```

## Hardened Runtime Logic

### 1. Auto Snapshot Generation (Immutable Chronology)

`TreatmentSnapshotService.process_packet()` remains the source of truth for automated data.

- **Hour Labeling**: Buckets packets into `H00`, `H01`, etc.
- **Frozen Baseline**: `H00` is locked after 60s of treatment to preserve starting state.
- **Event Preservation**: `OC_XX` rows capture order changes between hourly points.

### 2. Manual Mutations (Identity-Gated)

All manual actions (`Fill Gap`, `Edit Cell`, `Restore`, `Submit`, `Approve`, `Reject`, `Unlock`) are now **Gated**:

- **Frontend**: `ensureOperator()` prompts for identity via `OperatorCheckInModal`.
- **Headers**: `X-Operator-Name` and `X-User-Role` are required for all `POST/PUT/DELETE` requests.
- **Audit**: Database records the operator name in `updated_by` column.

### 3. Edit Policy (State-Based Locking)

UI and Backend strictly enforce:

- **Recording Active**: Journal is read-only except for Clinical Notes.
- **Pending Review**: Nurse is read-only; Doctor/Admin can edit/restore.
- **Approved**: Entire treatment is locked. Only Doctor/Admin can `Unlock`.

### 4. Chronology Preservation (Fixed)

- **Manual Edit**: `PUT /snapshots/{hourLabel}` now preserves the existing `snapshot_time`.
- **Restore**: Frontend strips meta keys before sending payload; Backend preserves clinical timestamp.
- **Sort Logic**: `DetailPanel` implements an interleave sort that positions `OC_XX` rows correctly between `Hxx` rows based on true clinical time.
- **Stable H00**: Hour rows no longer "jump" to the bottom after being edited.

## UI/UX Mechanisms

### Lớp 1: Operator Identity — Modal Check-In

```
┌──────────────────────────────────────────┐
│    🏥 Xác nhận Người thao tác            │
│                                          │
│    Tên điều dưỡng / bác sĩ:             │
│    ┌──────────────────────────────────┐  │
│    │  Nguyễn Thị A                    │  │
│    └──────────────────────────────────┘  │
│                                          │
│           [ Hủy ]   [ Xác nhận ]         │
└──────────────────────────────────────────┘
```

Khi nào xuất hiện:

- **Lần đầu** bấm vào bất kỳ hành động ghi (edit, fill gap, submit, approve, reject, unlock, notes).
- **Đổi treatment** hoặc **đổi role** → hỏi lại.
- **Cùng treatment, cùng session** → không hỏi lại (lưu `sessionStorage`).

Lý do chọn `sessionStorage`:

- Máy trạm bệnh viện thường dùng chung. `localStorage` sẽ giữ tên người cũ sau khi đổi ca.
- `sessionStorage` tự xóa khi đóng tab → phù hợp с mô hình ca trực.

### Lớp 2: Operator Badge — Thông tin hiện tại

```
  ┌───────────────────────────┐
  │  👤 Nguyễn Thị A  [Đổi]  │
  └───────────────────────────┘
```

Vị trí: header của treatment page và review page.
Hành vi:

- Nút **Đổi**: mở lại modal check-in để đổi operator (ví dụ: giao ca giữa chừng).
- Nút **Xóa**: xóa identity, lần thao tác tiếp sẽ phải check-in lại.
- **Ẩn khi chưa check-in** — tránh gây nhiễu thị giác.

### Lớp 3: Status Banners — Trạng thái Journal

Ba loại banner, hiện ngay trên data table:

| Trạng thái                   | Banner                                        | Màu               | Icon           | Ý nghĩa                                                      |
| ---------------------------- | --------------------------------------------- | ----------------- | -------------- | ------------------------------------------------------------ |
| `outcome = IN_PROGRESS`      | "Journal đang bị khóa — máy đang ghi dữ liệu" | 🟠 Amber, pulsing | 🔒 Lock        | Dữ liệu realtime đang chạy, không được sửa để tránh xung đột |
| `approval_status = APPROVED` | "Journal đã được phê duyệt — chỉ đọc"         | 🟢 Green          | 🛡️ ShieldCheck | Dữ liệu đã finalize, cần Unlock để chỉnh                     |
| Nurse + `PENDING_REVIEW`     | "Journal đang chờ bác sĩ duyệt"               | 🟣 Indigo         | ⏳ Clock       | Nurse chỉ đọc, không được sửa khi đang chờ duyệt             |

**Lý do chọn inline banner** (không phải modal blocking):

- Modal sẽ chặn workflow hoàn toàn, nhưng nurse vẫn cần **đọc** dữ liệu và ghi **notes**.
- Banner cho phép nhìn dữ liệu bình thường, chỉ disable các nút mutation.

### Lớp 4: Edit Lock States — Disabled Interactions

Khi journal bị khóa (bất kỳ lý do nào ở trên):

| UI Element                   | Trạng thái                                                                           | Lý do                                                      |
| ---------------------------- | ------------------------------------------------------------------------------------ | ---------------------------------------------------------- |
| EditableCell (click to edit) | `disabled` — hiển thị giá trị bình thường, **không có** icon ✎, không phản hồi click | Tránh confuse user nghĩ rằng có thể sửa                    |
| Fill Gap button              | **Ẩn hoàn toàn**                                                                     | Không cần thấy nếu không thể thêm row                      |
| Submit / Approve / Reject    | `disabled` + `opacity-50`                                                            | Vẫn nhìn thấy nút nhưng không thể bấm                      |
| Restore / Delete (review)    | `disabled`                                                                           | Ngăn thao tác phá dữ liệu đã duyệt                         |
| Clinical Notes               | **Luôn bật** ngay cả khi recording                                                   | Notes là observation log, không xung đột với realtime data |
| Unlock (doctor/admin only)   | **Luôn bật** khi `APPROVED`                                                          | Cơ chế thoát khóa duy nhất                                 |

### Lớp 5: Error Toasts — Phản hồi Mutation

Khi backend từ chối một thao tác:

| HTTP Code     | Màu Toast  | Message mẫu                              | Khi nào xảy ra                                     |
| ------------- | ---------- | ---------------------------------------- | -------------------------------------------------- |
| 400           | 🔴 Error   | "Thiếu thông tin người thao tác"         | Frontend gửi request mà không có `X-Operator-Name` |
| 403           | 🔴 Error   | "Không có quyền thực hiện hành động này" | Sai role hoặc treatment đã khóa                    |
| 409           | 🟡 Warning | "Đang ghi dữ liệu — không thể chỉnh sửa" | Treatment outcome vẫn là `IN_PROGRESS`             |
| Network error | 🔴 Error   | "Lỗi mạng"                               | Mất kết nối hoặc timeout                           |

**Lý do dùng toast** (không phải alert/modal):

- Alert blocking cản workflow khi user cần bấm nhiều ô liên tục.
- Toast tự biến mất sau vài giây, không cần dismiss thủ công.

### Lớp 6: Workflow Diagram — UX Flow

```mermaid
flowchart LR
    subgraph UserAction ["User muốn sửa dữ liệu"]
        Click["Click vào cell / button"]
    end

    Click --> BannerCheck{"Banner khóa?"}
    BannerCheck -- "Có" --> Blocked["Disabled / Hidden\n(User thấy banner giải thích)"]
    BannerCheck -- "Không" --> OperatorCheck{"Đã check-in?"}

    OperatorCheck -- "Chưa" --> Modal["Modal hỏi tên"]
    Modal -- "Nhập tên" --> Proceed["Gửi request + headers"]
    Modal -- "Hủy" --> Cancel["Không làm gì"]
    OperatorCheck -- "Rồi" --> Proceed

    Proceed --> Backend{"Backend guard"}
    Backend -- "Pass" --> Success["✅ Cập nhật + Toast success"]
    Backend -- "400/403/409" --> Toast["🔴 Toast error / warning"]
```

## Scenario Matrix (Validated)

| ID  | Scenario                           | Result                                                          | Status      |
| --- | ---------------------------------- | --------------------------------------------------------------- | ----------- |
| S1  | H00 created during first 60s       | Baseline captured correctly                                     | ✅ OK       |
| S2  | Order settings change              | `OC_XX` inserted into timeline                                  | ✅ OK       |
| S3  | User edits an existing `H0x` row   | Value updated; `snapshot_time` preserved; `updated_by` recorded | ✅ Fixed    |
| S4  | User restores row from originals   | Meta keys stripped; clinical chronology preserved               | ✅ Fixed    |
| S5  | Treatment is `IN_PROGRESS`         | Mutation buttons disabled; "Journal Locked" banner shown        | ✅ Hardened |
| S6  | Clinical Notes during Recording    | Always allowed (Audit-logged)                                   | ✅ OK       |
| S7  | Approved treatment review          | Entire sheet locked; only Unlock permited                       | ✅ Hardened |
| S8  | Nurse tries unauthorized edit      | Client-side blocked; Backend `can_mutate` 403 gate              | ✅ Hardened |
| S9  | Detail page reload after edit      | Rows stay in clinical order via Interleave Sort                 | ✅ Fixed    |
| S10 | Print / Excel Export               | Data follows stable clinical chronology                         | ✅ Fixed    |
| S11 | First inline edit without check-in | Modal appears before edit mode activates                        | ✅ Hotfixed |
| S12 | Delete row in review page          | Uses operator headers; toast on success/failure                 | ✅ Hotfixed |
| S13 | Restore missing OC_XX              | Original `snapshot_time` preserved; correct chronology position | ✅ Hotfixed |

## Historical Bug: Chronology Jumping (RESOLVED)

Previously, any manual update or restore action would overwrite a row's `snapshot_time` with the current system clock. This caused edited rows (like `H00`) to move to the bottom of the clinical timeline.

**Mitigation Applied:**

1. **Backend**: `upsert_snapshot` logic checks for existing rows and protects the `snapshot_time` field during updates. For missing rows, `update_snapshot_manual` now accepts `snapshot_time` from the payload (used during restore).
2. **Frontend**: The stable sorting logic in `DetailPanel` and `review/page.tsx` enforces `hour_label` consistency for `Hxx` rows, interleaving `OC_XX` rows using their stable clinical timestamps.
3. **Payload**: Restore actions strip meta-keys but preserve `snapshot_time` for backend timestamp recovery.

## Clinical Safety Mandates

1. **Identity**: Every manual data change must be attributed to a physical operator via `X-Operator-Name`.
2. **Chronology**: `snapshot_time` is an immutable clinical anchor. It must never be mutated by UI edits.
3. **Editability**: Treatment status is the primary arbiter of data mutability.
   - `IN_PROGRESS` -> Strictly Read-Only (except Notes).
   - `APPROVED` -> Data Frozen.

## Bottom Line

The hardened system ensures that the Treatment Journal is both **Clinically Accurate** (stable chronology) and **Forensically Sound** (identity-gated audit trails).
