# RAW TELEMETRY ARCHITECTURE SPECIFICATION (Sprint 4)

## 1. Motivation

Raw telemetry data from PrimaFlex devices can exceed **1GB per 24h treatment**. The previous architecture (recording everything into a single `.jsonl` file and converting to `.jsonl.gz`) causes three major issues:

- **OOM Risk in Analyzer:** Reading 1GB JSON into memory (`json.loads`) freezes the `treatment_analyzer` server.
- **Decompression Penalty:** If a machine restarts and the file was already compressed to `.gz`, `raw_streamer.py` must decode a 1GB file just to append new data.
- **DB Bloat:** Saving raw JSON structures into PostgreSQL is impossible at this scale.

## 2. Solution: The Manifest-Managed Chunk Architecture

To eliminate file locking, OOM errors, and decompression overhead, we decouple data recording from data analysis using the **Manifest Pattern** + **DuckDB**.

### 2.1 Chunking Recorder (`raw_streamer.py`)

- Live telemetry is written to **append-only JSONL** text files (e.g., `treatment_{id}_chunk001.jsonl`).
- When a file reaches **50MB** (or 100,000 packets), the stream is rotated to a new file `..._chunk002.jsonl`.
- Resumption (`SAME PATIENT`) no longer requires decompression. It simply creates a new chunk (`..._chunk003.jsonl`) and records immediately.

### 2.2 The Manifest Table (`raw_packet_manifest`)

A new PostgreSQL table acts as the unified ledger for chunks representing a single treatment.

```sql
CREATE TABLE raw_packet_manifest (
    id SERIAL PRIMARY KEY,
    treatment_id UUID NOT NULL,
    chunk_index INT NOT NULL,     -- 1, 2, 3...
    file_path TEXT NOT NULL,      -- Relative or absolute path
    format VARCHAR(10) NOT NULL,  -- 'JSONL' or 'PARQUET'
    status VARCHAR(20) NOT NULL,  -- 'ACTIVE', 'CLOSED', 'ARCHIVED'
    first_timestamp TIMESTAMP,
    last_timestamp TIMESTAMP,
    size_bytes BIGINT,
    UNIQUE(treatment_id, chunk_index)
);
```

### 2.3 Background Compression Worker

- Periodically scans `raw_packet_manifest` for chunks in `status='CLOSED'` and `format='JSONL'`.
- Uses a background thread to safely convert `.jsonl` -> `.parquet` (Columnar format, ~90% compression).
- Upon success, deletes the `<chunk>.jsonl` and updates the manifest row `format='PARQUET'`.

### 2.4 High-Performance Analysis (`treatment_analyzer`)

- When a user views a treatment analysis, `app.py` queries the `raw_packet_manifest` via Postgres to receive the ordered list of active and closed chunks.
- It leverages **DuckDB** to execute native SQL across both Parquet and JSONL files simultaneously.
- DuckDB engine loads only the specific columns needed (e.g., `time`, `pa`, `pv`) into memory natively, dropping analysis time from 40 seconds to **< 50 milliseconds**.

## 3. Sprint 4 Deliverables

- `TASK-111`: (Backend) Implement `raw_packet_manifest` table and upgrade `raw_streamer.py` with 50MB chunking logic.
- `TASK-112`: (Backend) Implement Background Parquet Worker to compress CLOSED JSONL chunks.
- `TASK-113`: (Analyzer) Rewrite `treatment_analyzer/app.py` to drop `json.loads` and use DuckDB to trace the chunk manifest.
