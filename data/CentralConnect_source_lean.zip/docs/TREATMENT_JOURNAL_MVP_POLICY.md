# Treatment Journal MVP Policy

Updated: 2026-04-04T23:08+07:00  
Owner: CTO  
Status: **APPROVED** — Ban hanh cho dev/QA thuc thi

## 1. Muc tieu

Policy nay dung de chot pham vi MVP cua Treatment Journal.

Muc tieu lon nhat cua MVP:

- on dinh
- de test
- it bug chronology
- it bug state machine
- it bug quyen han

Journal MVP khong duoc bi bien thanh spreadsheet editor.

## 2. Nguyen tac cot loi

Treatment Journal phai duoc xem la ho so lam sang.

Dieu nay co nghia:

- timeline do may va backend quyet dinh
- con nguoi chi duoc bo sung va hieu chinh noi dung tren row da ton tai
- khong cho nguoi dung thuong quy tai tao timeline bang tay
- snapshot_time la moc lam sang bat bien

## 3. Pham vi MVP

### 3.1 Giu trong MVP

- Auto H00
- Auto H01/H02/... theo treatment time
- Auto OC_XX khi co order change
- View list/history/detail
- Edit manual fields tren existing stable rows
- Append-only notes
- Submit for review
- Approve
- Reject
- Unlock
- Restore existing row to original machine values (giu, nhung restricted)

### 3.2 Loai khoi clinical UI MVP

Nhung muc sau KHONG nam trong luong UI thuong quy cua nurse/doctor:

- Fill gap
- Add next hour
- Add row
- Restore missing row
- Bulk update rows
- Delete row

Neu can giu vi ly do ky thuat, chi duoc giu o maintenance/admin path, khong duoc xuat hien trong clinical workflow.

## 4. Vai tro va quyen han

### 4.1 Nurse

Nurse duoc:

- xem journal
- sua manual fields tren row da ton tai va da stable
- them notes
- submit for review

Nurse khong duoc:

- tao row moi
- fill gap thoi gian
- restore missing row
- delete row
- bulk update
- approve / reject / unlock

### 4.2 Doctor

Doctor duoc:

- xem journal
- xem compare current vs original
- approve
- reject (ho so ve DRAFT, nurse sua lai roi submit lai)
- unlock
- restore existing row to original machine values

Doctor KHONG duoc sua data truc tiep trong MVP.
Neu can thay doi noi dung: Reject -> Nurse sua -> Submit lai.

Doctor khong nen duoc lam trong MVP clinical UI:

- tao row moi
- fill gap timeline
- add next hour
- restore missing row
- delete row thuong quy

### 4.3 Admin / Maintenance

Admin hoac maintenance tool moi duoc xu ly:

- rebuild timeline
- create missing rows
- structural recovery
- delete row
- bulk repair

Tat ca cac thao tac nay phai co:

- ly do bat buoc
- audit day du
- UI rieng

## 5. Quy tac du lieu bat buoc

Day la cac rule dev va QA khong duoc pha:

1. `snapshot_time` khong duoc doi sau khi row da tao.
2. `Hxx` va `OC_XX` phai duoc sap xep theo chronology lam sang.
3. Edit tay khong duoc day row xuong cuoi timeline.
4. `END` packet van thuoc treatment cu.
5. `same patient + RUN_TIME > 0` -> tiep tuc treatment cu.
6. `patient change` hoac `RUN_TIME = 0` -> mo treatment moi.
7. Moi manual mutation phai co operator.
8. Approved treatment phai bi khoa cho toi khi unlock.

## 6. Quy tac mutation trong MVP

### 6.1 Chi sua row da ton tai

MVP chi cho phep mutation tren row da co san.

Khong co mutation MVP nao duoc:

- tao row timeline moi
- chen row moi vao giua timeline
- sua `snapshot_time`

### 6.2 Chi sua field manual

Frontend va backend phai thong nhat:

- chi cho sua manual fields
- khong cho sua telemetry fields nhu QB, QD, QS, TMP, PA, PV, UF...

Manual field allowlist cho MVP:

- `solution_type` (loai dich)
- `duosol` (duosol ml)
- `prismasol` (prismasol ml)
- `kali` (kali meq)
- `filter_set` (bo loc)
- `heparin_bolus` (hep bolus)
- `heparin_rate` (hep duy tri)
- `clinical_notes` (ghi chu lam sang tren row)

Neu field nao can mo sau nay, phai co policy moi.

### 6.3 Restore chi ap dung cho existing row

`Restore` trong MVP co nghia:

- restore gia tri may goc cho row da ton tai
- khong tao row moi
- khong restore missing row
- khong doi chronology

### 6.4 Stable-Row Policy (Edit IN_PROGRESS)

Việc khoá (Lock) toàn bộ Journal khi ca lọc đang chạy `IN_PROGRESS` là một biện pháp an toàn kỹ thuật nhưng gây cản trở cho Lâm sàng (Ví dụ: Setup Heparin ở H00). Do đó, MVP cho phép mở khóa một phần theo **Stable-Row Policy**:

- **Active Streaming Row (Dòng đang ghi):** Dòng cuối cùng thuộc mốc thời gian hiện tại mà máy đang gửi telemetry lên (Ví dụ: đang chạy mốc `H03` thì dòng `H03` là Active Row). Dòng này bị READ-ONLY toàn bộ lưới để tránh đụng độ (Race condition) với worker.
- **Stable Rows (Các dòng quá khứ):** Các dòng từ `H02` trở về trước (`H00`) đã chốt sổ data máy. Điều dưỡng ĐƯỢC PHÉP edit các `Manual field` (Heparin, Note) trên các dòng này ngay cả khi ca lọc vẫn đang `IN_PROGRESS`.
- **Tuyệt đối:** Dù mở khóa sửa ô (cell), hành động cấu trúc như "Fill Gap" / "Add Row" vẫn bị ẩn hoàn toàn ở UI hằng ngày.

## 7. Review workflow MVP

State machine MVP (DA CHOT):

```
DRAFT -> PENDING_REVIEW -> APPROVED
  ^           |
  |   reject  |
  +-----------+
  ^                       |
  |       unlock          |
  +-----------------------+
```

- `DRAFT`: nurse duoc sua, submit
- `PENDING_REVIEW`: nurse khong sua duoc, doctor review
- `APPROVED`: khoa hoan toan, chi unlock boi doctor/admin

Reject:

- Reject -> DRAFT (mot nghia duy nhat)
- Nurse sua lai roi submit lai
- Ly do reject khuyen nghi bat buoc

Unlock:

- Unlock -> DRAFT (doctor/admin mo khoa de nurse sua)
- Ghi audit day du

## 8. Quy tac giao dien MVP

Clinical UI MVP phai don gian:

- journal detail de doc duoc nhanh
- chi hien edit icon tren field duoc sua
- khong hien nut Fill Gap
- khong hien nut Add Next Hour
- khong hien nut Restore Missing
- khong hien nut Delete Row
- notes de dung va ro
- review page uu tien compare + approve/reject/unlock + restore existing row

Neu button nao khong nam trong MVP policy thi khong duoc hien tren UI thuong quy.

## 9. Quy tac backend MVP

Backend phai la source of truth.

Backend bat buoc enforce:

- operator required cho mutation
- role check
- treatment lock check
- stable row check
- field allowlist
- audit log

Khong duoc chi an button tren frontend ma backend van cho goi API nguy hiem.

## 10. QA acceptance criteria

QA coi MVP dat khi:

- nurse chi sua duoc manual fields tren row da ton tai
- nurse khong thay va khong dung duoc structural actions
- doctor review duoc current vs original
- doctor approve/reject/unlock dung state
- restore existing row giu nguyen chronology
- edit tay khong doi snapshot_time
- operator duoc ghi nhan cho moi mutation
- approved treatment that su bi khoa
- khong con bug row nhay thu tu sau edit/restore

## 11. Quy tac scope

Neu co yeu cau moi sau MVP, uu tien theo thu tu:

1. tinh an toan lam sang
2. tinh de test
3. tinh don gian cho user
4. tinh de bao tri
5. tinh nang moi

Neu 1 tinh nang moi lam tang do phuc tap chronology hoac state machine, mac dinh la KHONG dua vao MVP.

## 12. Quy dinh cho dev team

Khi code theo policy nay:

- uu tien v2 command-driven API cho mutation
- khong mo rong them CRUD mutation moi o v1
- khong giu song song 2 nghia business cho reject/unlock
- neu endpoint nguy hiem van con ton tai, phai:
  - an khoi UI
  - them guard role
  - them audit
  - lap ke hoach deprecate

## 13. Quy dinh cho QA team

Khi test theo policy nay:

- test theo hanh vi duoc phep
- test ca hanh vi phai bi chan
- uu tien test chronology, state machine, operator audit
- coi structural actions con lo ra UI la bug
- coi API nguy hiem van cho vai tro sai su dung la bug nghiem trong

## 14. Ket luan

MVP Journal phai theo triet ly:

- may tao timeline
- nurse bo sung noi dung
- doctor duyet va hieu chinh
- admin moi sua cau truc

Neu giu duoc 4 dong nay, he thong se:

- it bug hon
- de QA hon
- de dao tao nguoi dung hon
- an toan lam sang hon
