# Prismaflex® Communication Programmer's Guide

![](images/39f83d803256fe3424ddfeee66863876d849c2608262a3a22a36bc4061d1efb3.jpg)

Communication Programmer's Guide

Program version 8.XX

Order number:

G5015010

© 2005-2015 Gambro Lundia AB. All rights reserved.

# Trademarks

Gambro, Prismaflex, Adsorba, Prismaflo, Prismacomfort, Prismatherm, MARSFLUX, diaFLUX, diaMARS, X-MARS, septeX, oXiris, Hospital, MARS and PrismaLung are trademarks belonging to the Gambro Group.

# Manufacturer

Gambro Lundia AB

Box 10101

Magistratsvagen 16

SE-220 10 LUND

Sweden

Phone +46 46 169000

www.gambro.com

Questions or comments about this publication can be directed to your local representative or to the manufacturer.

# Table of contents

# 1 Introduction 3

1.1 Introduction 4   
1.2 Service information 4

# 2 Communications Interfaces 5

2.1 Communications Interfaces 6

# 2.2 General Settings 7

2.2.1 MachID 7   
2.2.2 Master Time Settings 7

# 2.3 Ethernet Connections 7

2.3.1 Software requirements 7   
2.3.2 Network Settings 8   
2.3.3 Connecting the Prismaflex® Ethernet Network Interface 8

# 2.4 RS232 Connections 8

2.4.1 Software Requirements 8   
2.4.2 Connecting the Prismaflex RS232 Interface 9

# 3 Accessing the communication 11

3.1 Accessing the Prismaflex Communication 12   
3.2 S-message Subtypes 12

# 3.3 S-message Structure 12

3.3.1 S-message Structure Definition 12   
3.3.2 CRC Calculation 14   
3.3.3 Message Body: S-record Structure Definition 15   
3.3.4 Message Flags 15   
3.3.5 Patient Identifier 16   
3.3.6 Software Revision Encoding Convention 16

# 3.4 Endianness 16

# 3.5 Alarm 16

# 4 Example of a Received Data Stream 17

# 4.1 Example of a Received Data Stream 18

# 5 General coding conventions 19

# 5.1 S-message Header Informations 20

5.1.1 Therapy Type 20   
5.1.2 Therapy Status 20

# 5.2 Parameters 20

5.2.1 Numerical parameters 20   
5.2.2 Enumerative Parameters 30

5.2.3 32

5.2.3.1 Alarm parameters 32   
5.2.3.2 Warning 32   
5.2.3.3 Caution 34   
5.2.3.4 Advisory 35   
5.2.3.5 Malfunction 36

# 6 The USB interface 39

6.1 Automatic saving of History Data 40   
6.2 Transferring History Data to a USB flash drive 40

6.3 Interpretation of History Data 42

6.3.1 How to transfer the USB Flash Drive Content to a Computer 42   
6.3.2 Example of a LOX file copied from a USB flash drive 42

# 7 Decoding 2D barcode 45

7.1 2D barcode information 46   
7.2 Example of a 2D barcode scanned on a Prismaflex control unit 46

# 1 Introduction

1.1 Introduction 4   
1.2 Service information 4

# 1.1 Introduction

This Programmer's Guide provides the information needed when writing a customized software program which will collect synchronous data from the Prismaflex control unit, and store it in a personal computer (PC). This Guide is intended for use only by trained and experienced software programmers. Before writing a data collection/storage program, the programmer should understand how the medical institution wishes to use the collected data.

Note: Detailed information about the Prismaflex control unit is available in the Prismaflex Operator's Manual and the Prismaflex Service Manual.

# NOTE!

This Programmer's Guide has to be provided with the Gambro Non Disclosure Agreement.

# 1.2 Service information

For technical assistance, contact your representative.

# 2 Communications Interfaces

# 2.1 Communications Interfaces 6

# 2.2 General Settings 7

2.2.1 MachID 7   
2.2.2 Master Time Settings 7

# 2.3 Ethernet Connections 7

2.3.1 Software requirements 7   
2.3.2 Network Settings 8   
2.3.3 Connecting the Prismaflex Ethernet Network Interface 8

# 2.4 RS232 Connections 8

2.4.1 Software Requirements 8   
2.4.2 Connecting the Prismaflex RS232 Interface 9

# 2.1 Communications Interfaces

The Prismaflex control unit is equipped with three different communication interfaces, located on the rear panel:

- an Ethernet network port, with a 10Base-T compatible connector   
- two optically isolated RS232 serial communication ports   
- a USB port, compatible with USB 2.0

![](images/c0bc2a9dc104b9ad9685d227beb02fbef314d2896d680febe7b9a7c26c9aeb4b.jpg)  
Figure 2-1. Ethernet and RS232 interfaces

The Ethernet network port, the RS232 serial communication ports and the USB port are IEC 60601-1 compliant. For information about the USB interface, refer to Section 6 "The USB interface" on page 39.

When the Prismaflex control unit is connected to an IT network, the Responsible Organization should identify, analyze, evaluate and control risks due to the integration of the Prismaflex system in the IT network. Subsequent changes in the IT network could introduce new risks and require additional analysis.

Changes in the IT network environment includes:

- changes in the IT network configuration   
- connection of additional items to the IT network   
- disconnecting items from the IT network   
- update of equipment connected to the IT network   
- upgrade of equipment connected to the IT network

![](images/c1439bb08eddf136b15290e4594650fc418a75899fab53aff7e02436e794e60e.jpg)

# WARNING!

If a Patient Data Management System (PDMS) is to be used with the Prismaflex system, the Responsible Organization is obliged to verify compatibility between the two systems. The Responsible Organization should identify, analyze, evaluate and control risks due to integration of Prismaflex in an IT network. Subsequent changes to the IT network could introduce new risks and require new analysis. The use of a PDMS not compatible with the Prismaflex system can result in presentation of erroneous data. It is the responsibility of the physician to verify all data before prescribing any therapeutic or pharmacological action for the patient.

![](images/7a8a8ef1f0c4840cb4f33d2b02936d7a3aed13653c0d9afe503091e2f405ffbb.jpg)

# WARNING!

The information provided via the Prismaflex communications interfaces is intended to supplement the patient treatment data displayed by the Prismaflex control unit. Prismaflex communications interfaces information should not be used as the sole basis for medical decisions. If there is a discrepancy between information obtained through the Prismaflex communications interface and the information shown on the Prismaflex display, the information shown on the Prismaflex display is to be considered correct.

![](images/b288949a4d9fc99b31d1138a5215857543d00eb393c519a6ad4f5c3e32a1dc48.jpg)

# WARNING!

The personal computer used for receiving/storing collected Prismaflex data must meet or exceed the IEC 60950 electrical isolation specification for computers.

![](images/a1728d1b55321fd4b4b1766b6702bc90880ae5cb04f717ec1816f80f37614b79.jpg)

# NOTE!

The patient ID is hidden by default when using any of the external communication protocols. The Responsible Organization has the legal responsibility to comply with data security and confidentiality requirements.

# 2.2 General Settings

# 2.2.1 MachID

Each Prismaflex system can be associated with a 2-byte word (hereafter MachID) that is attached - for identification purposes - to every message that the Prismaflex system itself sends through its communication interfaces.

In order to take full advantage of the Prismaflex Communication Protocol device identification feature, check the uniqueness of the MachID across your Prismaflex network in the Calibration section in service mode, in the Service - External Communication Interface screen. MachID is setable between 0 to 255.

# 2.2.2 Master Time Settings

The Prismaflex control unit sends messages at fixed intervals called Master time. Master timer can be configured in Calibration section in service mode, in screen Service - External Communication Interface. Master timer can be adjusted between 5 to 60 sec. The default value for this parameter (Master Timer) is 10 sec. It applies to Ethernet port 3001 and RS232.

When using Ethernet port 3002 (Service messages), fixed interval is 1 sec.

# 2.3 Ethernet Connections

# 2.3.1 Software requirements

The Prismaflex Ethernet network interface is bound to a TCP/IP software stack, run by the Prismaflex control unit operating system. The Prismaflex control unit has to be connected to a Ethernet LAN having an available IP protocols suite, so that a communication channel can be opened.

The PC connected to the Prismaflex control unit has to be TCP/IP enabled and it should be able to perform a connection to the TCP port (listening port) on which the Prismaflex communication system is listening for connection requests. So make sure that the correct route is set, and that the firewall (if any) between the socket endpoints is properly configured.

If the Ethernet port number is set to 3001, then Status-messages are received (see Section 3.2 "S-message Subtypes" on page 12).

If the Ethernet port number is set to 3002, then Service-messages are received (see Section 3.2 "S-message Subtypes" on page 12).

# NOTE!

the messages do not contain the number of the listening port. However, when a communication is active, it's possible to verify which listening port is used by checking the value of the field FLAG in the message header (see Section 3.3.4 "Message Flags" on page 15).

In case of a socket timeout, the Prismaflex control unit will drop a stalled TCP connection after $20 \pm 10$ seconds. The timeout allows for detection of an unplugged ethernet cable.

# 2.3.2 Network Settings

The IP address, bound to the Prismaflex Ethernet network interface and the other relevant IP settings (Subnet Mask and Gateway) can be found in Calibration section in Service Mode, in screen Service - IP Settings.

Check that the chosen IP address is unique across your IP network, or network software malfunction will arise.

# 2.3.3 Connecting the Prismaflex® Ethernet Network Interface

The Ethernet network interface connector is located on the rear panel of the Prismaflex control unit.

To connect the Prismaflex control unit to the LAN a twisted-pair Cat.5E D+ class patch cable should be used: one plug has to be attached to the Prismaflex Ethernet network interface connector, and the other can be inserted in a free patch jack in your LAN hub/switch.

# 2.4 RS232 Connections

# 2.4.1 Software Requirements

The Prismaflex RS232 port settings are given by the manufacturer and they cannot be changed:

<table><tr><td>Configuration</td><td>Setting</td></tr><tr><td>Baud rate</td><td>9600</td></tr><tr><td>Data bits</td><td>8</td></tr><tr><td>Parity</td><td>None</td></tr><tr><td>Stop bits</td><td>1</td></tr><tr><td>Flow control</td><td>None</td></tr><tr><td>Buffer max size</td><td>1024</td></tr><tr><td>Out</td><td>648</td></tr><tr><td>In</td><td></td></tr></table>

RS232 connection sends out Status messages.

# 2.4.2

# Connecting the Prismaflex® RS232 Interface

![](images/1d98d1799b1060e8c9833fe5e1120d7179fa26cb7bf9796495ebc30acfc17bc2.jpg)

# WARNING!

To connect the Prismaflex control unit to a PC, use only a RS232 Interface Cable that conforms to the requirements of IEC 60601-1 and IEC 61000-4 standards, and meets European Standard EN 55011, limit B.

![](images/a9da13bb729376d609f1d1e01094bae047520f5c5820cbc25d5133f73ca8b2c8.jpg)

# CAUTION!

Devices connected to the RS232 serial communication port or the Ethernet port must comply with IEC 60950. Connected cables must have a Kitagawa RFC-10 ferrite or equivalent to fulfill EMC requirements.

The RS232 communications port is exposed on a DB9-type female connector, located on the rear panel of the Prismaflex control unit.

Pin configuration of the RS232 communication port is shown in Figure 2-2 "RS232 connector - DB9 Female" on page 9. To connect the interface cable to the Prismaflex control unit and PC, proceed as follows:

1. Line up the pins on the cable's connector with the sockets on the Prismaflex RS232 port. Press the pins into the sockets. Use the two finger screws to tighten the connector to the Prismaflex control unit.   
2. Attach the other cable end to an unused COM port of the PC. Use the two finger screws to tighten the connector to the PC.

![](images/b776621aafbad9fff1431d8110832f29a8c907d3c68910c3ceb94c435400b8d2.jpg)  
Figure 2-2. RS232 connector - DB9 Female

This page is intentionally left blank.

# 3 Accessing the communication

3.1 Accessing the Prismaflex Communication 12   
3.2 S-message Subtypes 12   
3.3 S-message Structure 12

3.3.1 S-message Structure Definition 12   
3.3.2 CRC Calculation 14   
3.3.3 Message Body: S-record Structure Definition 15   
3.3.4 Message Flags 15   
3.3.5 Patient Identifier 16   
3.3.6 Software Revision Encoding Convention 16

3.4 Endianness 16   
3.5 Alarm 16

# 3.1 Accessing the Prismaflex® Communication

Prismaflex control unit makes available a synchronous data flow (containing both technical and dialysis-related information) via the Communication Interfaces. Once the logical connection has been established, the Prismaflex connection peer starts receiving the information that Prismaflex control unit has been previously configured for.

Parameter values are not filtered depending on e.g. chosen treatment, so parameters will always contain default values if they are not changed by the user or valid in the current situation.

In the Ethernet connection scenario, after the TCP connection has been opened, the Prismaflex control unit periodically writes a binary formatted message (hereafter called S-message) on the newly created socket. The result is a sequence of messages, characterized by a timing set, which can be configured via the Prismaflex Service Mode, as described in the Section 2.2.2 "Master Time Settings" on page 7.

The RS232 connection has a similar behaviour: shortly after the serial connection has been opened, the peer receives a byte stream, containing a periodical S-message sequence. Make sure to start decoding only after a whole message has been received.

# 3.2 S-message Subtypes

There are two types of S-messages. They are called S-message subtypes and they are:

- Status-message   
- Service-message

Using Ethernet connections both types of S-messages are available, see Section 2.3 "Ethernet Connections" on page 7. For the RS232 connection only the status message is available, see Section 2.4 "RS232 Connections" on page 8.

All S-message instances share the same structure definition: header and body, see Section 3.3.1 "S-message Structure Definition" on page 12. Being a Status-message or a Service-message determines the content of the body, since some parameters can only be present in Service-message, see Section 3.3.3 "Message Body: S-record Structure Definition" on page 15 and Section 5.2 "Parameters" on page 20.

# 3.3 S-message Structure

# 3.3.1 S-message Structure Definition

The S-message is composed of two main sections:

header   
- body

The header is always present. It has a fixed and predetermined size (in bytes), and contains a fixed number of fields. See Table 3-1 "S-message structure definition" on page 13.

The body is not always present and it does not have a fixed size. When it exists, it contains a sequence of one or more S-records, see Section 3.3.3 "Message Body: S-record Structure Definition" on page 15.

The precise S-message structure definition is given in the following table:

Table 3-1. S-message structure definition   

<table><tr><td>Section</td><td>Field name</td><td>Type</td><td>Description</td><td>Allowed values</td></tr><tr><td>Header</td><td>STX</td><td>Unsigned short (16 bit)</td><td>Start of text marker</td><td>0x0002</td></tr><tr><td></td><td>CRC</td><td>Unsigned short (16 bit)</td><td>Cyclic redundancy check, computed applying the standard CRC16 algorithm to the message portion that starts from the subsequent field and that extends to the end of the message. See Section 3.3.2 “CRC Calculation” on page 14.</td><td>any</td></tr><tr><td></td><td>MachID</td><td>Unsigned short (16 bit)</td><td>Prismaflex control unit identifier. It can be set via the Prismaflex user interface, in the Service Mode section. See Section 2.2.1 “MachID” on page 7.</td><td>[0x0000 ; 0xffff]</td></tr><tr><td></td><td>ClinicalSWID</td><td>Unsigned short (16 bit)</td><td>Clinical software identifier. Currently not used.</td><td>0x0064</td></tr><tr><td></td><td>MsgCounter</td><td>Integer (32 bit)</td><td>Message counter. Currently not used.</td><td>0x00000000</td></tr><tr><td></td><td>CmdCode</td><td>Integer (32 bit)</td><td>Command code. Currently not used.</td><td>0x00000000</td></tr><tr><td></td><td>MsgInfo</td><td>Integer (32 bit)</td><td>Message information. The number of S-records in the message body.</td><td>See Section 3.3.3 “Message Body: S-record Structure Definition” on page 15</td></tr><tr><td></td><td>Flags</td><td>Integer (32 bit)</td><td>Message flags</td><td>See Section 3.3.4 “Message Flags” on page 15</td></tr><tr><td></td><td>PatID</td><td>Unicode chars (20 x 32 bit)</td><td>Patient identifier</td><td>See Section 3.3.5 “Patient Identifier” on page 16</td></tr><tr><td></td><td>SWRevision</td><td>Integer (32 bit)</td><td>Software revision. Represents the Prismaflex software revision code.</td><td>See Section 3.3.6 “Software Revision Encoding Convention” on page 16</td></tr><tr><td></td><td>TherapyType</td><td>Integer (32 bit)</td><td>Therapy type. Represents the therapy selected for the currently delivered treatment.</td><td>See Section 5.1.1 “Therapy Type” on page 20</td></tr><tr><td></td><td>TherapyStatus</td><td>Integer (32 bit)</td><td>Therapy status. Contains information about the status of the treatment.</td><td>See Section 5.1.2 “Therapy Status” on page 20</td></tr><tr><td></td><td>Time</td><td>Integer (32 bit)</td><td>Contains the timestamp associated to the message, expressed in seconds elapsed from the Jan, 01 1970 midnight.</td><td>[0; 0x7FFFFFF]</td></tr><tr><td></td><td>MBL</td><td>Unsigned integer (32 bit)</td><td>Message body length</td><td>[0; 0x000017f4]</td></tr><tr><td>Body</td><td></td><td>Sequence of S-records</td><td></td><td>0 or moreSRecords.</td></tr></table>

# 3.3.2 CRC Calculation

Here is an extract of the source code used to calculate the CRC.  
#define STX_CRC_LENGTH 4 //length of STX + CRC  
#define POLY 0x8408 //used by CRC calculation alg

# Function for calculating the CRC of the message

{ unsigned short int i; unsigned short intCRC $= 0$ for $\mathrm{(i = STX\_CRC\_LENGTH)}$ . $\mathrm{i} <   ($ sizeof(MsgHeader)+ data->i_message.headersmessage_length）； $\mathrm{i + + )}$ this->bytecrc(&data->c_message[i]，&crc); data->i_message.header.crc $=$ CRC;

# Function used to add one byte to the CRC result

{ unsigned short int j,ch,Q; ch=(unsigned short int) \*bufptr; for $(j = 1;j <   = 8;j + + )$ { $Q = (\star \mathrm{crcres}\& 0\mathrm{x}0001)\wedge$ (ch & 0x0001); if $(Q = = 0\times 0001)$ { \*crcres $=$ \*crcres>>1; \*crcres $=$ \*crcres^POLY; } else { \*crcres $=$ \*crcres>>1; } ch $=$ ch>>1; } return $\star$ CRCRES;

# 3.3.3 Message Body: S-record Structure Definition

The message body contains zero or more S-records. No separator or terminator is used in the S-records sequence.

Each S-record represents a measure (Measure_value) relative to a Prismaflex control unit parameter (Param_code), performed at a given time (Time).

More formally, a S-record is the binary serialization of a C-language variable of a type defined as follows:

```txt
typedef struct{ unsigned intParam_code; unsigned intTime; intMeasure_value; } SRecord 
```

built under the rules described in Section 3.4 "Endianness" on page 16.

Param_code is the code for the parameter. There are Numerical parameters, Enumerative parameters and Alarm (Warning, Malfunction, Caution, and Advisory) parameters. They are listed in Section 5.2 "Parameters" on page 20.

# NOTE!

For Numerical and Enumerative Parameters (ActualValue), the Param_code corresponds to the ID in the Parameters section.

# NOTE!

For Numerical and Enumerative Parameters (SetValue), the Param_code corresponds to 0x40000000 + the ID in the Parameters section.

# NOTE!

For Alarm Parameters, the Param_code corresponds to 0x80000000 + the ID in the Parameters section.

Time is the set time on the Prismaflex Control unit when the sampling measure has been performed. It's expressed in seconds, elapsed from the Jan, 01 1970 midnight (epoch time). Measure_value represents the value of the parameter, expressed in exponential notation (base-10). Only the mantissa is included in the Srecord: the exponent to be used is fully determined given a particular parameter code, and it can be found in Parameters section.

# 3.3.4 Message Flags

Some useful information can be found in the Flags field. This value should be interpreted as a result of multiple bitwise-OR operations across every single atomic data that applies, and that can be one or more of the following (in C language #define-type representation):

define STATUSMESSAGEFROMPRISMAFLEX0x00000001

define SERVICE_MESSAGE__FROM_PRISMAFLEX0x00000002

define PWRFAIL_MESSAGE__FROM_PRISMAFLEX0x10000000

![](images/fb710fef7540eb6d4e25942cdc3c249589a1e8c763e7d6c7675af81c2e65ad29.jpg)

# WARNING!

In case of power failure event detected via the appropriate message flag (PWRFAIL_MESSAGE__FROM_PRISMAFLEX), all the remaining message information - including the entire message body - must be ignored, since the data correctness is not guaranteed.

# 3.3.5 Patient Identifier

Patient Identifier represents the patient ID. Its value can be set via the Prismaflex User Interface, in the "Enter Patient Information" screen. It can contain a maximum of 20 characters. Patient ID is hidden by default (determined by a parameter in service mode). Configuration can be done in the Calibration section in service mode, in the Service - External Communication Interface screen.

# NOTE!

The patient ID is hidden by default when using any of the external communication protocols. The Responsible Organization has the legal responsibility to comply with data security and confidentiality requirements.

# 3.3.6 Software Revision Encoding Convention

The SWRevision field of every S-message contains the Prismaflex software version. Despite the software version of the Prismaflex Control System includes build information, it is not visible in every place of the application. Therefore the SWRevision field has the following structure:

SWa.bVcRd

where a, b, c and d are numbers.

Here are the steps to get the Prismaflex software version from the SWRevision field:

- Apply the little-endian convention to the SWRevision field.   
- Convert the hexadecimal value to the decimal value (e.g. a b c d).   
- Extract the digits and group them according to the above Prismaflex software version structure.

See Section 4.1 "Example of a Received Data Stream" on page 18.

# 3.4 Endianness

Endianness refers to sequencing methods used in one-dimensional systems. The convention "little-endian" (little-units-first, i.e. Intel x86-type representation) applies to all binary streams, when talking or listening to the Prismaflex System.

Let suppose that the value of the field "Flags" of a certain message is "02 00 00 00". According to the little-endian convention, that value must be read as "00 00 00 02". That tells us that we are analyzing a Service-message.

# 3.5 Alarm

Information about alarms are given at the end of an S-message (both Status-message and Service-message), after the Numerical and Enumerative parameters list.

Only alarm with the highest priority will be included when an S-message is sent.

# 4 Example of a Received Data Stream

4.1 Example of a Received Data Stream 18

# 4.1 Example of a Received Data Stream

The following table shows an example of a portion of received data stream, containing a S-message.

Output is the received data.

Value is the output according to the little-endian convention.

Field Name is the naming convention for that portion of output.

Description is its explanation.

Figure 4-1. Exemple of a recieved data stream   

<table><tr><td>Output</td><td>Value</td><td>Field name</td><td>Description</td></tr><tr><td>02 00</td><td>00 02</td><td>STX (Header)</td><td>Start of text marker.</td></tr><tr><td>FF D9</td><td>D9 FF</td><td>CRC (Header)</td><td>Cyclic redundancy check.</td></tr><tr><td>0A 00</td><td>00 0A</td><td>MachID (Header)</td><td>Machine identifier. Settable in service - Calibration screen - External Communication Interface. In this example the ID = 10.</td></tr><tr><td>64 00</td><td>00 64</td><td>ClinicalSwID</td><td>Clinical software identifier. Currently not used.</td></tr><tr><td>00 00 00 00</td><td>00 00 00 00</td><td>MsgCounter</td><td>Message counter. Currently not used.</td></tr><tr><td>00 00 00 00</td><td>00 00 00 00</td><td>CmdCode</td><td>Command code. Currently not used.</td></tr><tr><td>60 00 00 00</td><td>00 00 00 60</td><td>MsgInfo (Header)</td><td>Message information. In this example there are 96 s-records in the message body.</td></tr><tr><td>01 00 00 00</td><td>00 00 00 01</td><td>Flags (Header)</td><td>This Flag indicate that it is a status message.</td></tr><tr><td>2A 00 00 00</td><td>00 00 00 2A</td><td>PatID</td><td>The Patient identifier is entered in Setup mode. The Patient identifier is hidden by default (determined by a parameter in service mode). Configuration can be done in the Calibration section in service mode, in the Service - External Communication Interface screen.</td></tr><tr><td>2A 00 00 00</td><td>00 00 00 2A</td><td></td><td></td></tr><tr><td>2A 00 00 00</td><td>00 00 00 2A</td><td></td><td></td></tr><tr><td>2A 00 00 00</td><td>00 00 00 2A</td><td></td><td></td></tr><tr><td>2A 00 00 00</td><td>00 00 00 2A</td><td></td><td></td></tr><tr><td>2A 00 00 00</td><td>11 00 00 2A</td><td></td><td></td></tr><tr><td>2A 00 00 00</td><td>11 00 00 2A</td><td></td><td></td></tr><tr><td>2A 00 00 00</td><td>11 00 00 2A</td><td></td><td></td></tr><tr><td>2A 00 00 00</td><td>11 00 00 2A</td><td></td><td></td></tr><tr><td>2B 00 00 00</td><td>11 00 00 2A</td><td></td><td></td></tr><tr><td>2B 00 00 00</td><td>11 00 00 2A</td><td></td><td></td></tr><tr><td>2B 00 00 00</td><td>11 00 00 2A</td><td></td><td></td></tr><tr><td>2B 00 00 00</td><td>11 00</td><td>SWRevision (Header)</td><td>Conversion from hex. to dec. gives value 8100200. The Prismaflex SW version is 8.10V02R00. Can be found in fifth technical screen on the Prismaflex control unit or in Service - Diagnose - SW Configuration.</td></tr><tr><td>68 99 78 00</td><td>00 78 99 68</td><td></td><td></td></tr><tr><td>06 00 00 00</td><td>00 00 00 06</td><td>TherapyType (Header)</td><td>Selected Therapy is NOT_CHOOSE. See table 5.1.</td></tr><tr><td>00 00 00 00</td><td>00 00 00 00</td><td>TherapyStatus (Header)</td><td>The Prismaflex control unit is in state IDLE. See Table 5.2.</td></tr><tr><td>10 F5 41 55</td><td>55 41 F5 10</td><td>Time (Header)</td><td>The message timestamp, expressed in seconds elapsed from Jan, 01 1970 midnight, also called Epoch time. Time stamp corresponds to time displayed on the Prismaflex control unit. In this example the timestamp is 1430385936 and the conversion gives Thu, 30 Apr 2015 09:25:36 GMT.</td></tr><tr><td>80 04 00 00</td><td>00 00 04 80</td><td>MBL (Header)</td><td>The length of the S-message&#x27;s body is 1152 bytes. (3x32 bit) x MsgInfo (96 S-records) = 1152 bytes.</td></tr><tr><td>01 00 00 00</td><td>00 00 00 01</td><td>1st S-record (Body)</td><td>Param_code: 1 (ACCESS PRESSURE) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 500 mmHg.</td></tr><tr><td>10 F5 41 55</td><td>55 41 F5 10</td><td></td><td></td></tr><tr><td>F4 01 00 00</td><td>00 00 01 F4</td><td></td><td></td></tr><tr><td>02 00 00 00</td><td>00 00 00 02</td><td>2nd S-record (Body)</td><td>Param_code: 2 (FILTER.pressURE) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 500 mmHg</td></tr><tr><td>10 F5 41 55</td><td>55 41 F5 10</td><td></td><td></td></tr><tr><td>F4 01 00 00</td><td>00 00 01 F4</td><td></td><td></td></tr><tr><td>03 00 00 00</td><td>00 00 00 03</td><td>3rd S-record (Body)</td><td>Param_code: 3 (EFFLUENT.pressURE) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 500 mmHg</td></tr><tr><td>10 F5 41 55</td><td>55 41 F5 10</td><td></td><td></td></tr><tr><td>F4 01 00 00</td><td>00 00 01 F4</td><td></td><td></td></tr><tr><td>04 00 00 00</td><td>00 00 00 04</td><td>4th S-record (Body)</td><td>Param_code: 4 (RETURN.pressURE) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: -500 mmHg</td></tr><tr><td>10 F5 41 55</td><td>55 41 F5 10</td><td></td><td></td></tr><tr><td>OC FE FF FF</td><td>FF FF FE OC</td><td></td><td></td></tr><tr><td>06 00 00 00</td><td>00 00 00 06</td><td>5th S-record (Body)</td><td>Param_code: 6 (TMP) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: -500 mmHg</td></tr><tr><td>10 F5 41 55</td><td>55 41 F5 10</td><td></td><td></td></tr><tr><td>OC FE FF FF</td><td>FF FF FE OC</td><td></td><td></td></tr><tr><td>07 00 00 00</td><td>00 00 00 07</td><td>6th S-record (Body)</td><td>Param_code: 7 (DP) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 500 mmHg</td></tr><tr><td>10 F5 41 55</td><td>55 41 F5 10</td><td></td><td></td></tr><tr><td>F4 01 00 00</td><td>00 00 01 F4</td><td></td><td></td></tr><tr><td>3C 00 00 00</td><td>00 00 00 3C</td><td>7th S-record (Body)</td><td>Param_code: 60 (BLOOD_VOL_PROCESSED) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 0 l</td></tr><tr><td>10 F5 41 55</td><td>55 41 F5 10</td><td></td><td></td></tr><tr><td>00 00 00 00</td><td>00 00 00 00</td><td>9 th S-record (Body)</td><td>Param_code: 59 (RUN_TIME) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 0 s</td></tr><tr><td>C6 00 00 00</td><td>00 00 00 C6</td><td>8 th S-record (Body)</td><td>Param_code: 198 (EXCESS_PATIENT_FLUID_SIGN) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 0 ml</td></tr><tr><td>10 F5 41 55</td><td>55 41 F5 10</td><td></td><td></td></tr><tr><td>00 00 00 00</td><td>00 00 00 00</td><td></td><td></td></tr><tr><td>3B 00 00 00</td><td>00 00 00 3B</td><td>9 th S-record (Body)</td><td>Param_code: 59 (RUN_TIME) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 0 s</td></tr><tr><td>10 F5 41 55</td><td>55 41 F5 10</td><td></td><td></td></tr><tr><td>00 00 00 00</td><td>00 00 00 00</td><td></td><td></td></tr><tr><td>5E 00 00 00</td><td>00 00 00 5E</td><td>10 th S-record (Body)</td><td>Param_code: 94 (REPLACEMENT_PRE_CUMULATED) Time: Thu, 30 Apr 2015 09:25:36 GMT Measure_value: 0 ml</td></tr><tr><td>10 F5 41 55</td><td>55 41 F5 10</td><td></td><td></td></tr><tr><td>00 00 00 00</td><td>00 00 00 00</td><td></td><td></td></tr></table>

# 5 General coding conventions

# 5.1 S-message Header Informations 20

5.1.1 Therapy Type 20   
5.1.2 Therapy Status 20

# 5.2 Parameters 20

5.2.1 Numerical parameters 20   
5.2.2 Enumerative Parameters 30   
5.2.3 32

5.2.3.1 Alarm parameters 32   
5.2.3.2 Warning 32   
5.2.3.3 Caution 34   
5.2.3.4 Advisory 35   
5.2.3.5 Malfunction 36

# 5.1 S-message Header Informations

# 5.1.1 Therapy Type

Table 5-1. Therapy Type   

<table><tr><td>Value</td><td>Therapy type</td></tr><tr><td>0</td><td>SCUF</td></tr><tr><td>1</td><td>CVVH</td></tr><tr><td>2</td><td>CVVHD</td></tr><tr><td>3</td><td>CVVHDF</td></tr><tr><td>4</td><td>TPE</td></tr><tr><td>5</td><td>HP</td></tr><tr><td>6</td><td>NOT_CHOOSE</td></tr></table>

# 5.1.2 Therapy Status

Table 5-2. Therapy Status   

<table><tr><td>Value</td><td>Therapy status</td></tr><tr><td>0</td><td>IDLE</td></tr><tr><td>1</td><td>CUSTOM</td></tr><tr><td>2</td><td>PRIME</td></tr><tr><td>3</td><td>PRIMETEST</td></tr><tr><td>4</td><td>WAITINGSTART</td></tr><tr><td>5</td><td>RUN</td></tr><tr><td>6</td><td>CHANGE Bags</td></tr><tr><td>7</td><td>THERAPY_STOPPED</td></tr><tr><td>8</td><td>END</td></tr><tr><td>9</td><td>RETURN</td></tr><tr><td>10</td><td>RECIRCULATION</td></tr><tr><td>11</td><td>RECIRC_PRIME</td></tr><tr><td>12</td><td>RECIRC_PRIMETEST</td></tr><tr><td>13</td><td>RECIRC_WAITINGSTART</td></tr><tr><td>14</td><td>CALIBRATION</td></tr><tr><td>15</td><td>SWLOAD</td></tr></table>

# 5.2 Parameters

# 5.2.1 Numerical parameters

Table 5-3. Numerical parameters   

<table><tr><td>ID</td><td>Name and Description</td><td>Accu-racy(4)</td><td>Unit</td><td>MAXValue</td><td>MINValue</td><td>StatusMSG</td><td>ServiceMSG</td><td>Type</td><td>Note</td></tr><tr><td>1</td><td>ACCESSPRESSURE: actual value of the pressure at the access pod</td><td>0</td><td>mmHg</td><td>500</td><td>-500</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>2</td><td>FILTERPRESSURE: actual value of the pressure at the filter pod</td><td>0</td><td>mmHg</td><td>500</td><td>-500</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>3</td><td>EFFLUENTPRESSURE: actual pressure at the effluent pod</td><td>0</td><td>mmHg</td><td>500</td><td>-500</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>4</td><td>RETURN PRESSURE: actual pressure at the return pod</td><td>0</td><td>mmHg</td><td>500</td><td>-500</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>5</td><td>FIFTHPRESSURE: actual pressure at the 5th pod</td><td>0</td><td>mmHg</td><td>500</td><td>-500</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>6</td><td>TMP: actual value of the transmembrane pressure</td><td>0</td><td>mmHg</td><td>500</td><td>-500</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>7</td><td>DP: actual value of the pressure drop</td><td>0</td><td>mmHg</td><td>500</td><td>-500</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>8</td><td>PUMP1: actual value of the rpm of the pre-blood pump</td><td>2</td><td>rpm</td><td>250</td><td>-250</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>9</td><td>PUMP2: actual value of the rpm of the replacement pump</td><td>2</td><td>rpm</td><td>250</td><td>-250</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>10</td><td>PUMP3: actual value of the rpm of the dialysate pump</td><td>2</td><td>rpm</td><td>250</td><td>-250</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>11</td><td>PUMP4: actual value of the rpm of the effluent pump</td><td>2</td><td>rpm</td><td>250</td><td>-250</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>12</td><td>BLOOD_RPM: actual value of the rpm of the blood pump.</td><td>2</td><td>rpm</td><td>90</td><td>-90</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>13</td><td>SCALE1: actual value of the weight on the pre-blood scale</td><td>0</td><td>g</td><td>15000</td><td>-50</td><td></td><td>X</td><td>ACT</td><td>(5)</td></tr><tr><td>14</td><td>SCALE2: actual value of the weight on the replacement scale</td><td>0</td><td>g</td><td>15000</td><td>-50</td><td></td><td>X</td><td>ACT</td><td>(5)</td></tr><tr><td>15</td><td>SCALE3: actual value of the weight on the dialysate scale</td><td>0</td><td>g</td><td>15000</td><td>-50</td><td></td><td>X</td><td>ACT</td><td>(5)</td></tr><tr><td>16</td><td>SCALE4: actual value of the weight on the effluent scale</td><td>0</td><td>g</td><td>15000</td><td>-50</td><td></td><td>X</td><td>ACT</td><td>(5)</td></tr><tr><td>17</td><td>BLOOD_FLOW: blood flow set by user</td><td>0</td><td>ml/min</td><td>(*)</td><td>(*)</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>18</td><td>REPLACEMENT_PRE_FLOW: replacement pre flow set by user</td><td>0</td><td>ml/hr</td><td>(*)</td><td>(*)</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>19</td><td>REPLACEMENT_POST_FLOW: replacement post flow set by user</td><td>0</td><td>ml/hr</td><td>(*)</td><td>(*)</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>21</td><td>DIALYSATE_FLOW: dialysate flow set by user</td><td>0</td><td>ml/hr</td><td>(*)</td><td>(*)</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>22</td><td>PRE_BLOOD_FLOW: pre-blood flow set by user</td><td>0</td><td>ml/hr</td><td>(*)</td><td>(*)</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>23</td><td>EFFLUENT_FLOW: effluent flow set by the Prismaflex control unit software on the base of the other flows set</td><td>0</td><td>ml/hr</td><td>(*)</td><td>(*)</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>24</td><td>PT_WEIGHTBalance: Patient fluid removal flow set by user.</td><td>0</td><td>ml/hr</td><td>(*)</td><td>(*)</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>26</td><td>PT_WEIGHT: patient weight. Operator enters this value together with Patient ID and Pre-Hematocrit value during start up.</td><td>0</td><td>kg</td><td>999</td><td>0</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>34</td><td>BLD_NORM: normalization value of the BLD</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>35</td><td>BLD_SIGNAL: value of the BLD signal</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>36</td><td>BOLUS_VOL: anticoagulant bolus volume set by user</td><td>1</td><td>ml</td><td>5</td><td>0</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>37</td><td>BOLUS_INTERVAL: anticoagulant bolus interval set by user</td><td>0</td><td>hr</td><td>24</td><td>1</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>38</td><td>HEPARIN_CONT_RATE: anticoagulant continuous rate set by user</td><td>1</td><td>ml/hr</td><td>5</td><td>0</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>44</td><td>UFR: ultrafiltration ratio. Value is calculated by the Prismaflex software.</td><td>0</td><td>%</td><td>5000</td><td>0</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>47</td><td>PRE_HCT: Pre-Hematocrit value. Operator enters this value together with Patient ID and Patient weight during start up.</td><td>0</td><td>%</td><td>60</td><td>10</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>59</td><td>CAL Runs_TIME: actual run time of the therapy</td><td>0</td><td>s</td><td>10 000 000</td><td>0</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>60</td><td>BLOOD_VOL_PROCESSSED: actual blood volume processed</td><td>0</td><td>I</td><td>780</td><td>0</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>92</td><td>NEXT_INTERV_HOURS: field about the hour of the next intervention</td><td>0</td><td>hr</td><td>(/)</td><td>(/)</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>93</td><td>NEXT_INTERV_MINUTES: field about the minutes of the next intervention</td><td>0</td><td>min</td><td>(/)</td><td>(/)</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>94</td><td>IO_HIST_PRE_REPL_WITHOUT_PBP_TOT: actual cumulated volume for replacement PRE (excluding PBP). Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml</td><td>(/)</td><td>(/)</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>95</td><td>IO_HIST_POST_REPL_TOT: Total Replacement volume Post delivered. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml</td><td>(/)</td><td>(/)</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>97</td><td>IO_HIST_DIAL_TOT: actual cumulated volume for dialysate. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml</td><td>(/)</td><td>(/)</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>98</td><td>IO_HIST_PBP_TOT: actual cumulated volume for pre-blood. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml</td><td>(/)</td><td>(/)</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>99</td><td>IO_HIST_EFFL_TOT: actual cumulated volume for effluent. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml</td><td>(/)</td><td>(/)</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>100</td><td>IO_HIST_PFR_TOT: actual cumulated volume for patient fluid removal. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml</td><td>(/)</td><td>(/)</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>120</td><td>ADC_PBP_SCALE: actual ADC value of the weight on pre-blood scale</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td>(1)</td></tr><tr><td>121</td><td>ADC_REPL_SCALE: actual ADC value of the weight on replacement scale</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td>(1)</td></tr><tr><td>122</td><td>ADC_DIAL_SCALE: actual ADC value of the weight on dialysate scale</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td>(1)</td></tr><tr><td>123</td><td>ADC_EFFL_SCALE: actual ADC value of the weight on effluent scale</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td>(1)</td></tr><tr><td>124</td><td>ADC_ACCESS_POD: actual ADC value of the access pressure</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>125</td><td>ADC_FILTER_POD: actual ADC value of the filter pressure</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>126</td><td>ADC_RETURN_POD: actual ADC value of the return pressure</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>127</td><td>ADC_EFLUENT_POD: actual ADC value of the effluent pressure</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>128</td><td>ADC_5TH_POD: actual ADC value of the 5th pod pressure</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>145</td><td>COUNTS_BLOOD_PUMP</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td>(2)</td></tr><tr><td>146</td><td>COUNTS_PBP_PUMP</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td>(2)</td></tr><tr><td>147</td><td>COUNTS_REPLACE_PUMP</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td>(2)</td></tr><tr><td>148</td><td>COUNTS_DIAL_PUMP</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td>(2)</td></tr><tr><td>149</td><td>COUNTS_EFLUENT_PUMP</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td>(2)</td></tr><tr><td>151</td><td>BLD_OFF_SIGNAL: value of signal when the BLD is OFF</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>152</td><td>BLD_DIFFERENCE: difference between the signal in ON and in OFF condition</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>153</td><td>BLD_AVERAGE: average of Transmitter ON signal and transmitter OFF signal</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>154</td><td>PWM_NORM: PWM normalization value</td><td>1</td><td>%</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>155</td><td>PWM: PWM actual value</td><td>1</td><td>%</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>156</td><td>SYRINGE_COUNT: meter value of the encoder pulses of the syringe pump received during UP manual operation</td><td>0</td><td>counts</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>157</td><td>SYRINGE_RATE: speed of the syringe pump</td><td>3</td><td>mm/s</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>168</td><td>ADC_SYRINGE: ADC value of the force applied to the syringe pump.</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>170</td><td>SYRINGE FORCE_apPLIED: value of the force applied to the syringe pump</td><td>0</td><td>N</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>171</td><td>SYRINGE_OVL_threshold: value of the overload threshold of the syringe pump</td><td>0</td><td>N</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td>(3)</td></tr><tr><td>176</td><td>ARPS.Reference_1: AD value of the voltage</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>177</td><td>ARPS.Reference_2: AD value of the voltage</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>178</td><td>ARPS.Reference_3: AD value of the voltage</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>183</td><td>ADC_24_VOLT: AD value of the voltage +24V</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>184</td><td>ADC_5_VOLT_VP: AD value of the voltage +5Vp</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>185</td><td>ADC_5_VOLT_VD: AD value of the voltage +5Vd</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>186</td><td>ADC_12_VOLT: AD value of the voltage +12V</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>187</td><td>ADC_5NEG_VOLT: AD value of the voltage -5V</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>188</td><td>SLOPE_OVL: slope value of the syringe pump</td><td>0</td><td>none</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>189</td><td>LOADThreshold: load threshold of the syringe pump</td><td>0</td><td>N</td><td>(/)</td><td>(/)</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>192</td><td>MAX_GAIN: max value of volume gain set by user</td><td>0</td><td>ml</td><td>2000</td><td>0</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>196</td><td>EXCESS.Patient_FLUID_LIMIT: limit value for excess patient fluid loss or gain, in CRRT, set by user</td><td>0</td><td>ml</td><td>400</td><td>100</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>198</td><td>EXCESS.Patient_FLUID_SIGN: signed actual value for patient excess fluid loss or gain, in CRRT. Positive value = GAIN Negative value = LOSS</td><td>0</td><td>ml</td><td>(/)</td><td>(/)</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>400</td><td>CITRATE_DOSE: citrate dose set by user</td><td>1</td><td>mmol/l</td><td>6</td><td>0</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>401</td><td>CITRATE_CONCENTRATION: citrate concentration (excl. citric acid) of the used citrate solution</td><td>0</td><td>mmol/l</td><td>600</td><td>10</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>402</td><td>CITRATE_SOL_CITR_ACID_CONC: citric acid concentration of the used citrate solution</td><td>0</td><td>mmol/l</td><td>100</td><td>0</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>403</td><td>CITRATE_LOAD: citrate load</td><td>1</td><td>mmol/h</td><td>()</td><td>()</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>404</td><td>CALCIUM_SYRINGE_RATE: calcium syringe flow rate</td><td>1</td><td>ml/hr</td><td>100</td><td>2</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>405</td><td>CALCIUM_CONCENTRATION: calcium concentration of the calcium solution in the syringe</td><td>0</td><td>mmol/l</td><td>1000</td><td>80</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>406</td><td>CALCIUM_COMPENSATION: calcium compensation set by user</td><td>0</td><td>%</td><td>200</td><td>5</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>407</td><td>IO_HIST_SYRINGE_TOT: actual cumulated volume for infused syringe solution</td><td>0</td><td>ml</td><td>21474 83647</td><td>-21474 83647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>408</td><td>REPL_SOL_CA_CONC: Calcium concentration in used Replacement solution.</td><td>2</td><td>mmol/l</td><td>1.75</td><td>0.00</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>410</td><td>EFFL_DOSE: Calculated Total Effluent dose</td><td>0</td><td>ml/kg/h</td><td>21474 83647</td><td>-21474 83647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>412</td><td>Filtration_FRACT: Calculated Filtration fraction value</td><td>0</td><td>%</td><td>100</td><td>0</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>413</td><td>REPL_PRE_PERCENT: Replacement solution pre infused in blood circuit. Includes Pre Blood pump solution.</td><td>0</td><td>%</td><td>100</td><td>0</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>414</td><td>REPL_POST_PERCENT: Replacement solution post infused in blood circuit</td><td>0</td><td>%</td><td>100</td><td>0</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>415</td><td>CURRENT_FILTER_TIME: Run time for the disposable set currently in use, displayed in the Status screen</td><td>0</td><td>sec</td><td>21474 83647</td><td>0</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>416</td><td>IO_HIST_PFR_1HR_CHART: Patient fluid removal value per 1 hour. Reset every hour.</td><td>0</td><td>ml</td><td>21474 83647</td><td>-21474 83647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>417</td><td>IO_HIST_PFR_24HR_CHART: Patient fluid removal volume presented per 24 hour from beginning of chart time setting in custome mode. Default start time is 00:00.</td><td>0</td><td>ml</td><td>21474 83647</td><td>-21474 83647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>418</td><td>IO_HIST_PFR_1HR: Patient Fluid Removal volume per 1 hour sliding window</td><td>0</td><td>ml</td><td>21474 83647</td><td>-21474 83647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>419</td><td>IO_HIST_PFR_24HR: Patient fluid removal volume presented per 24 hour sliding window</td><td>0</td><td>ml</td><td>21474 83647</td><td>-21474 83647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td rowspan="2">420</td><td>IO_HIST_UF_1HR: Ultra filtration rate per 1 hour sliding window</td><td rowspan="2">0</td><td rowspan="2">ml</td><td rowspan="2">2147483647</td><td rowspan="2">-2147483647</td><td rowspan="2">X</td><td rowspan="2">X</td><td rowspan="2">ACT</td><td rowspan="2"></td></tr><tr><td>Ultrafiltration volume = Total Replacement volume + Pre Blood Pump volume + Patient Fluid Removal volume</td></tr><tr><td rowspan="2">421</td><td>IO_HIST_UF_24HR: Ultra filtration rate per 24 hour sliding window</td><td rowspan="2">0</td><td rowspan="2">ml</td><td rowspan="2">2147483647</td><td rowspan="2">-2147483647</td><td rowspan="2">X</td><td rowspan="2">X</td><td rowspan="2">ACT</td><td rowspan="2"></td></tr><tr><td>Ultrafiltration volume = Total Replacement volume + Pre Blood Pump volume + Patient Fluid Removal volume</td></tr><tr><td rowspan="2">422</td><td>IO_HIST_UF_TOT: Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td rowspan="2">0</td><td rowspan="2">ml</td><td rowspan="2">2147483647</td><td rowspan="2">-2147483647</td><td rowspan="2">X</td><td rowspan="2">X</td><td rowspan="2">ACT</td><td rowspan="2"></td></tr><tr><td>Ultrafiltration volume = Total Replacement volume + Pre Blood Pump volume + Patient Fluid Removal volume</td></tr><tr><td rowspan="2">423</td><td>IO_HIST_UF_DOSE_1HR: Ultrafiltration dose</td><td rowspan="2">0</td><td rowspan="2">ml/kg/h</td><td rowspan="2">2147483647</td><td rowspan="2">-2147483647</td><td rowspan="2">X</td><td rowspan="2">X</td><td rowspan="2">ACT</td><td rowspan="2"></td></tr><tr><td>Per 1 hour sliding window</td></tr><tr><td rowspan="2">424</td><td>IO_HIST_UF_DOSE_24HR: Ultrafiltration dose</td><td rowspan="2">0</td><td rowspan="2">ml/kg/h</td><td rowspan="2">2147483647</td><td rowspan="2">-2147483647</td><td rowspan="2">X</td><td rowspan="2">X</td><td rowspan="2">ACT</td><td rowspan="2"></td></tr><tr><td>Per 24 hour sliding window</td></tr><tr><td>425</td><td>IO_HIST_UF_DOSE_TOT: Total Ultrafiltration dose. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td rowspan="2">426</td><td>IO_HIST_TOT_REPL_WITH_PBP_1HR: Total replacement volume delivered. Includes PBP volume.</td><td rowspan="2">0</td><td rowspan="2">ml</td><td rowspan="2">2147483647</td><td rowspan="2">-2147483647</td><td rowspan="2">X</td><td rowspan="2">X</td><td rowspan="2">ACT</td><td rowspan="2"></td></tr><tr><td>Per 1 Hour sliding window</td></tr><tr><td rowspan="2">427</td><td>IO_HIST_TOT_REPL_WITH_PBP_24HR: Total replacement volume delivered. Includes PBP volume.</td><td rowspan="2">0</td><td rowspan="2">ml</td><td rowspan="2">2147483647</td><td rowspan="2">-2147483647</td><td rowspan="2">X</td><td rowspan="2">X</td><td rowspan="2">ACT</td><td rowspan="2"></td></tr><tr><td>Per 24 hour sliding window</td></tr><tr><td rowspan="2">428</td><td>IO_HIST_TOT_REPL_WITH_PBP_TOT: Total replacement volume delivered. Includes PBP volume. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td rowspan="2">0</td><td rowspan="2">ml</td><td rowspan="2">2147483647</td><td rowspan="2">-2147483647</td><td rowspan="2">X</td><td rowspan="2">X</td><td rowspan="2">ACT</td><td rowspan="2"></td></tr><tr><td>From beginning of treatment</td></tr><tr><td>429</td><td>IO_HIST_TOT_REPL_WITH_PBP_DOSE_1HR: Replacement (incl Pre Blood Pump) dosePer 1 hour sliding window</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>430</td><td>IO_HIST_TOT_REPL_WITH_PBP_DOSE_24HR: Replacement (incl Pre Blood Pump) dosePer 24 hour sliding window</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>431</td><td>IO_HIST_TOT_HIST_REPL_WITH_PBP_DOSE_TOT: Total Replacement (incl Pre Blood Pump) dose. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>432</td><td>IO_HIST_PRE_REPL_WITH_PBP_1HR: Total Replacement volume pre delivered including PBPPer 1 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>433</td><td>IO_HIST_PRE_REPL_WITH_PBP_24HR: Total Replacement volume pre delivered including PBPPer 24 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>434</td><td>IO_HIST_PRE_REPL_WITH_PBP_TOT: Total Replacement volume pre delivered including PBP. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>435</td><td>IO_HIST_PRE_REPL_WITH_PBP_DOSE_1HR: Total Replacement dose pre delivered including Pre Blood PumpPer 1 hour sliding window</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>436</td><td>IO_HIST_PRE_REPL_WITH_PBP_DOSE_24HR: Total Replacement dose pre delivered including Pre Blood PumpPer 24 hour sliding window</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>437</td><td>IO_HIST_PRE_REPL_WITH_PBP_DOSE_TOT: Total Replacement dose pre delivered including Pre Blood Pump. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>438</td><td>IO_HIST_POST_REPL_1HR: Total Replacement volume Post deliveredPer 1 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>439</td><td>IO_HIST_POST_REPL_24HR: Total Replacement volume Post deliveredPer 24 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>440</td><td>IO_HIST_POST_REPL_TOT: Do not use this ID. Use ID95.Total Replacement volume Post delivered.Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>441</td><td>IO_HIST_POST_REPL_DOSE_1HR: Total Replacement dose Post deliveredPer 1 hour sliding window</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>442</td><td>IO_HIST_POST_REPL_DOSE_24HR: Total Replacement dose Post deliveredPer 24 hour sliding window</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>443</td><td>IO_HIST_POST_REPL_DOSE_TOT: Total Replacement dose Post delivered. Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>444</td><td>IO_HIST_EFFL_1HR: Total effluent volume per 1 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>445</td><td>IO_HIST_EFFL_24HR: Total effluent volume per 24 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>446</td><td>IO_HIST_EFFL_DOSE_1HR: Total effluent dosePer 1 hour sliding window</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>447</td><td>IO_HIST_EFFL_DOSE_24HR: Total effluent dosePer 24 hour sliding window</td><td>0</td><td>ml/kg/h</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>448</td><td>IO_HIST_PBP_1HR: Total PBP volumePer 1 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>449</td><td>IO_HIST_PBP_24HR: Total PBP volumePer 24 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>450</td><td>IO_HIST_DIAL_1HR: Total Dialysate volumePer 1 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>451</td><td>IO_HIST_DIAL_24HR: Total Dialysate volumePer 24 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>452</td><td>IO_HIST_TOT_REPL_1HR: Total Replacement volumePer 1 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>453</td><td>IO_HIST_TOT_REPL_24HR: Total Replacement volumePer 24 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>454</td><td>IO_HIST_TOT_REPL_TOT: Total Replacement volume. Total volume from beginning of treatment.Includes the volume from previous filter sets if the option same patient has been used. Selecting New patient resets this value to 0.</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>455</td><td>IO_HIST_SYRINGE_1HR: Total syringe volumePer 1 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>456</td><td>IO_HIST_SYRINGE_24HR: Total syringe volumePer 24 hour sliding window</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>457</td><td>IO_HIST_NUMBER_OFSETS_USED: Total number of sets used in the current treatment</td><td>0</td><td>piece</td><td>10</td><td>0</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>458</td><td>IO_HIST_PFR_1HR_PERIODIC_CHART: Cumulative value over the last completed period. This value shall be the same as the last completed periodic value displayed on the PFR screen in History.</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>459</td><td>IO_HIST_PFR_24HR_PERIODIC_CHART: Cumulative value starting at the "Chart Begin Time" and up to the last completed hour. This value shall be the same as the last completed total value displayed on the PFR screen in History.</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>460</td><td>POST_HCT: Post-filter Hematocrit</td><td>0</td><td>%</td><td>(/)</td><td>(/)</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>461</td><td>RUN_TIME: Treatment time excluding recirculation and stop time</td><td>0</td><td>sec</td><td>10000000</td><td>0</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>462</td><td>IO_HIST_TOT_PLASMA_TOT: Total Plasma volumeTotal volume from beginning of treatment</td><td>0</td><td>ml</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>463</td><td>SERIAL_NUMBER: Prismaflex serial number. It can be set via the Prismaflex user interface, in Calibration section in service mode, in screen Service - Serial Number.</td><td>0</td><td>none</td><td>99999</td><td>0</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>464</td><td>MONITOR_ID_PDMS: Monitor ID</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>SET</td><td>(6)</td></tr><tr><td>465</td><td>ARPS_PRESSURE: actual pressure at the ARPS pod</td><td>0</td><td>mmHg</td><td>500</td><td>-500</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>466</td><td>ADC_ARPS_POD: actual ADC value of the ARPS pressure</td><td>0</td><td>none</td><td>2147483647</td><td>-2147483647</td><td></td><td>X</td><td>ACT</td><td></td></tr></table>

Table 5-4. Legend and Notes   

<table><tr><td>(*)</td><td>Filter dependent value (see Prismaflex Operator Manual)</td></tr><tr><td>(1)</td><td>For this field two records are sent with the same ID number:
• the first is the Protective channel AD value
• the second is the Control channel AD value</td></tr><tr><td>(2)</td><td>For this field four records are sent with the same ID number:
• the 1st is the duration of the phase from sensor A to sensor B (unit ms)
• the 2nd is the duration of the phase from sensor B to sensor A (unit ms)
• the 3rd is the number of pulses accumulated for the sensor A
• the 4th is the number of pulses accumulated for the sensor B</td></tr><tr><td>(3)</td><td>Syringe dependent value (see Prismaflex Operator Manual)</td></tr><tr><td>(4)</td><td>Accuracy means number of decimals, i.e. received value is 400 and with accuracy 2 it shall read 4.00.</td></tr><tr><td>(5)</td><td>For this field two records are sent with the same ID number:
• the first is the Protective channel value in gram
• the second is the Control channel value in gram</td></tr><tr><td>(6)</td><td>For this field the Monitor ID is sent as an Integer. E.g. the monitor ID 4692-1A34 is sent as value 1183980034.</td></tr><tr><td>(/)</td><td>Value not useful</td></tr></table>

# 5.2.2 Enumerative Parameters

Table 5-5. Enumerative parameters   

<table><tr><td>ID</td><td>Name</td><td>Value allowed</td><td>MAX Value</td><td>MIN Value</td><td>Status MSG</td><td>Service MSG</td><td>Type</td><td>Note</td></tr><tr><td>296</td><td>NEXT_INTERV ENUM : type of next intervention, displayed on the Status screen on the Prismaflex control unit.</td><td>0 = effluent bag full1 = replacement bag empty2 = dialysate bag empty3 = replacement 2 empty4 = pre-blood bag empty5 = suggestion to normalize BLD6 = time to change set cause of usage time7 = prescription delivered8 = syringe empty</td><td>8</td><td>0</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>350</td><td>SYRINGE_OVERLOAD D: syringe pump overload type.</td><td>0 = normal1= absolute overload</td><td>1</td><td>0</td><td></td><td>X</td><td>ACT</td><td></td></tr><tr><td>409</td><td>ANTICOAG_METHOD: Anticoagulation method selected by the user.</td><td>0 = None, (No Anticoagulation)1 = Systemic, (Systemic (e.g. Heparin), Prismaflex syringe pump)2 = Cit/Cal, (Citrate/Calcium, External pump)3 = Cit/Cal, (Citrate/Calcium, Prismaflex syringe pump)</td><td>3</td><td>0</td><td>X</td><td>X</td><td>SET</td><td></td></tr><tr><td>411</td><td>FILTRO Selected disposable set by the user.</td><td>0 = M101 = M602 = ST603 = HF204 = M1005 = ST1006 = M1507 = ST1508 = Oxiris9 = HF100010 = HF140011 = Septex12 = TPE100013 = TPE200014 = TPE2015 = TPE6016 = HPX0117 = HPX0218 = HPX0319 = HPX0420 = HPX0521 = MarsFlux0622 = MarsFlux2123 = None</td><td>23</td><td>0</td><td>X</td><td>X</td><td>ACT</td><td></td></tr><tr><td>467</td><td>PRISMALUNG_supp LEMENT: CRRT with PrismaLung supplement, set by user.</td><td>0= PrismaLung not used1= PrismaLung used</td><td>1</td><td>0</td><td>X</td><td>X</td><td>SET</td><td></td></tr></table>

# 5.2.3 Alarms

# 5.2.3.1 Alarm parameters

Each alarm parameter can assume one of the following values:

Table 5-6. Alarms   

<table><tr><td>Alarm value</td><td>Description</td></tr><tr><td>1</td><td>alarm present</td></tr><tr><td>2</td><td>alarm overridden</td></tr></table>

# 5.2.3.2 Warning

Table 5-7. Warning   

<table><tr><td>ID</td><td>Name</td><td>Title</td></tr><tr><td>1</td><td>ALMW_BUBBLE_DETECT</td><td>Air in Blood</td></tr><tr><td>2</td><td>ALMW_Z_RET_PRESSURE</td><td>Return Disconnection</td></tr><tr><td>3</td><td>ALMW_RETPRESSUNDER_OP</td><td>Return Pressure Dropping</td></tr><tr><td>4</td><td>ALMW_FILTER_ZERO</td><td>Set Disconnection</td></tr><tr><td>6</td><td>ALMW_CLOTTED_FILTER</td><td>Filter Clotted</td></tr><tr><td>7</td><td>ALMW_CLOTTED_PLASMAFILTER</td><td>Plasmafilter Clotted</td></tr><tr><td>8</td><td>ALMW_HP_CLOTTED_FILTER</td><td>HP Cartridge Clotted</td></tr><tr><td>9</td><td>ALMW_BLOOD_LEAK</td><td>Blood Leak Detected</td></tr><tr><td>10</td><td>ALMW_H_RET_PRESSURE / ALMW_H_RETPRESSURE_RECOVERY</td><td>Return Extremely Positive</td></tr><tr><td>11</td><td>ALMW_H_RETPRESSURE_NO_RECOVERY</td><td>Return Extremely Positive</td></tr><tr><td>12</td><td>ALMW_L_ACCRESSURE / ALMW_L_ACCRESSURE_RECOVERY</td><td>Access Extremely Negative</td></tr><tr><td>13</td><td>ALMW_L_ACCRESSURE_NO_RECOVERY</td><td>Access Extremely Negative</td></tr><tr><td>14</td><td>ALMW_H_ACCRESSURE</td><td>Access Extremely Positive</td></tr><tr><td>15</td><td>ALMW_H_FIL_PRESSURE</td><td>Filter Extremely Positive</td></tr><tr><td>16</td><td>ALMW Runs_POWER_FAIL</td><td>Power Failure</td></tr><tr><td>18</td><td>ALMW_W Bags_FULL_PRIME</td><td>Bag Full – Effluent (Prime)</td></tr><tr><td rowspan="2">19</td><td rowspan="2">ALMW_D Bags Empty_PRIME</td><td>Bag/Container Empty – Dialysate (Prime)</td></tr><tr><td>Bag/Container Empty – Replacement 2 (Prime)</td></tr><tr><td>20</td><td>ALMW_R Bags Empty_PRIME</td><td>Bag/Container Empty – Replacement (Prime)</td></tr><tr><td>21</td><td>ALMW_P Bags Empty_PRIME</td><td>Bag/Container Empty – PBP (Prime)</td></tr><tr><td>22</td><td>ALMW_R_INCORRECT_PRIME Bags_volume</td><td>Bag Volume Incorrect – Replacement (Prime)</td></tr><tr><td rowspan="2">23</td><td rowspan="2">ALMW_D_INCORRECT_PRIME Bags_volume</td><td>Bag Volume Incorrect – Dialysate (Prime)</td></tr><tr><td>Bag Volume Incorrect – Replacement 2 (Prime)</td></tr><tr><td>24</td><td>ALMW_W_INCORRECT_PRIME Bags_volume</td><td>Bag Volume Incorrect – Effluent (Prime)</td></tr><tr><td>25</td><td>ALMW_P_INCORRECT_PRIME Bags VOLUME</td><td>Bag Volume Incorrect - PBP (Prime)</td></tr><tr><td>26</td><td>ALMW_R_PRIME_scale_OPEN</td><td>Scale Open - Replacement (Prime)</td></tr><tr><td rowspan="2">27</td><td rowspan="2">ALMW_D_PRIME Scale_OPEN</td><td>Scale Open - Dialysate (Prime)</td></tr><tr><td>Scale Open - Replacement 2 (Prime)</td></tr><tr><td>28</td><td>ALMW_W_PRIME_SCALS_OPEN</td><td>Scale Open - Effluent (Prime)</td></tr><tr><td>29</td><td>ALMW_P_PRIME_SCALS_OPEN</td><td>Scale Open - PBP (Prime)</td></tr><tr><td>30</td><td>ALMW_PRIME_LINE_PPI_CLAMPED</td><td>Clamped Lines - PBP</td></tr><tr><td rowspan="2">31</td><td rowspan="2">ALMW_PRIME_LINE_D_CLAMPED</td><td>Clamped Lines - Dialysate</td></tr><tr><td>Clamped Lines - Replacement 2</td></tr><tr><td>32</td><td>ALMW_PRIME_LINERep_CLAMPED</td><td>Clamped Lines - Replacement</td></tr><tr><td>33</td><td>ALMW_PRIME_LINE_RETURN_CLAMPED</td><td>Clamped Lines - Return</td></tr><tr><td>34</td><td>ALMW_PRIME_LINE_EFFLRET_CLAMPED</td><td>Access Line is Obstructed</td></tr><tr><td>35</td><td>ALMW_PRIME_SYNRINGE_LINE_CLAMPED</td><td>Syringe Clamped</td></tr><tr><td>38</td><td>ALMW_PRIME_SYNRINGE EMPTY</td><td>Syringe Empty</td></tr><tr><td>39</td><td>ALMW_RIC_TIME_ELAPSED</td><td>Recirculation Time Exceeded</td></tr><tr><td>40</td><td>ALMW_TOOWeight_PUMP_ALM</td><td>Weight Alarm Not Cleared</td></tr><tr><td>63</td><td>ALMW_EFFLUENT_PRIME Bags VOLUME</td><td>Effluent Bag Incorrect</td></tr><tr><td>262</td><td>ALMW_setup_ERROR</td><td>Set-up error</td></tr><tr><td>263</td><td>ALMW_LINE_CROSSED_PBP_DIALOG</td><td>Crossed Lines Dialysate and PBP</td></tr><tr><td>264</td><td>ALMW_LINE_CROSSED_PBP Replica</td><td>Crossed Lines PBP and Replacement</td></tr><tr><td>265</td><td>ALMW_LINE_CROSSED_DIALOG Replica</td><td>Crossed Lines Dialysate and Replacement</td></tr><tr><td>266</td><td>ALMW_LINE_CROSSED_PBP_DIALOG Replica</td><td>Crossed Lines PBP, Dialysate and Replacement</td></tr><tr><td>267</td><td>ALMW_LINE_CROSSED_PBP Replica</td><td>Crossed Lines Repl. 2 and PBP</td></tr><tr><td>268</td><td>ALMW_LINE_CROSSED Replica</td><td>Crossed Lines Repl. 2 and Replacement</td></tr><tr><td>269</td><td>ALMW_LINE_CROSSED_PBP Replica</td><td>Crossed Lines PBP, Repl. 2 and Replacement</td></tr><tr><td>270</td><td>ALMW_BP_SEG_SIZE_LF_DETECTED Replica</td><td>Wrong Set Selected</td></tr><tr><td>271</td><td>ALMW_BP_SEG_SIZE_HF Detective Replica</td><td>Wrong Set Selected</td></tr><tr><td>281</td><td>ALMW_INCORRECT_DISPOSABLE_BARCODE</td><td>Wrong Set Loaded - Wrong Bar Code</td></tr><tr><td>282</td><td>ALMW_INCORRECT_DISPOSABLE_RECognition</td><td>Wrong Set Loaded - No recognition</td></tr><tr><td>292</td><td>ALMW_PRIME_CALCIUM_SYNRINGE emptied</td><td>Calcium Syringe Empty</td></tr><tr><td>293</td><td>ALMW_PRIME_CALCIUMLine_CLAMPED</td><td>Calcium Line Clamped</td></tr><tr><td>294</td><td>ALMW_PRIME_CALCIUMLine_NOT_CONNECTED</td><td>Calcium Line Not Connected</td></tr><tr><td>307</td><td>ALMW_PINCHVALVES_POS_INCORRECT_LOAD</td><td>Loading Error - Pinch valves position</td></tr><tr><td>308</td><td>ALMW_PINCHVALVES_POS_INCORRECT_UNLOAD</td><td>Unloading Error - Pinch valves position</td></tr><tr><td>316</td><td>ALMW_BATTERY_LOW</td><td>Battery Low</td></tr><tr><td>317</td><td>ALMW_UNSUIT_CA.sol</td><td>Unsuitable Ca Solution</td></tr><tr><td>319</td><td>ALMW_NOLine_IN_BLD</td><td>Effluent line not in BLD (Check that the line is correctly inserted alteratively clean the BLD)</td></tr><tr><td>332</td><td>ALMW_FLUID_LEAK_DETECTED</td><td>Fluid Leak Detected</td></tr><tr><td>335</td><td>ALMW_SYRINGE_LATCH</td><td>Syringe Plunger Not Secured</td></tr><tr><td>337</td><td>ALMW Lines_NOT_CLAMPED</td><td>Lines Not Clamped</td></tr></table>

# 5.2.3.3 Caution

Table 5-8. Caution   

<table><tr><td>ID</td><td>Name</td><td>Title</td></tr><tr><td>193</td><td>ALMC_TOOWeight_PUMP_ALM</td><td>Unresolved Flow Problem</td></tr><tr><td>194</td><td>ALMC_W_INCORRECT_CHANGES</td><td>Flow Problem (Effluent)</td></tr><tr><td>195</td><td>ALMC_R_INCORRECT_CHANGES</td><td>Flow Problem (Replacement)</td></tr><tr><td>196</td><td>ALMC_PPI_INCORRECT_CHANGES</td><td>Flow Problem (PBP)</td></tr><tr><td>197</td><td>ALMC_D_INCORRECT_CHANGES</td><td>Flow Problem (Dialysate)</td></tr><tr><td>198</td><td>ALMC_TPE_PRESCRIPTION</td><td>TPE Prescription Delivered</td></tr><tr><td>199</td><td>ALMC_W_BAG_FULL</td><td>Bag Full (Effluent)</td></tr><tr><td>200</td><td>ALMC_D_BAG_empty</td><td>Bag Empty (Dialysate, Replacement Bag 2 Empty) (Variable tare)</td></tr><tr><td>201</td><td>ALMC_R_BAG_empty</td><td>Bag Empty (Replacement) (Variable tare)</td></tr><tr><td>202</td><td>ALMC_R_TPE_BAG_empty</td><td>Replacement Container Empty</td></tr><tr><td>203</td><td>ALMC_P_BAG_empty</td><td>Bag Empty (PBP) (Variable tare)</td></tr><tr><td>204</td><td>ALMC_MAX_UFR</td><td>TMP Excessive</td></tr><tr><td>205</td><td>ALMC_TPE_MAX_UFR</td><td>TMPa Excessive</td></tr><tr><td>207</td><td>ALMC_R_INCORRECT BagsVolumes</td><td>Bag Volume Incorrect - Replacement</td></tr><tr><td>208</td><td>ALMC_D_INCORRECT BagsVolumes</td><td>Bag Volume Incorrect - Dialysate
Bag Volume Incorrect - Replacement 2</td></tr><tr><td>209</td><td>ALMC_W_INCORRECT BagsVolumes</td><td>Bag Volume Incorrect - Effluent</td></tr><tr><td>210</td><td>ALMC_P_INCORRECT BagsVolumes</td><td>Bag Volume Incorrect - PBP</td></tr><tr><td>211</td><td>ALMC_R Scale_OPEN</td><td>Scale Open - Replacement</td></tr><tr><td>212</td><td>ALMC_D Scale_OPEN</td><td>Scale Open - Dialysate
Scale Open - Replacement 2</td></tr><tr><td>213</td><td>ALMC_W Scale_OPEN</td><td>Scale Open - Effluent</td></tr><tr><td>214</td><td>ALMC_P Scale_OPEN</td><td>Scale Open - PBP</td></tr><tr><td>217</td><td>ALMC_EFFLUENT Bags_volume</td><td>Effluent Bag Incorrect</td></tr><tr><td>218</td><td>ALMC_MAX_PTGAIN</td><td>Patient Fluid Gain Excessive</td></tr><tr><td rowspan="2">219</td><td rowspan="2">ALMC_D_fix_BAG_empty</td><td>Bag Empty (Dialysate)</td></tr><tr><td>Replacement Bag 2 Empty (Fixed tare)</td></tr><tr><td>220</td><td>ALMC_R_fix_BAG_empty</td><td>Replacement Bag Empty (Fixed tare)</td></tr><tr><td>221</td><td>ALMC_P_fix_BAG_empty</td><td>PBP Bag Empty (Fixed tare)</td></tr><tr><td>222</td><td>ALMC_EXCESSPATIENT_FLUID</td><td>Loss/Gain Limit Reached</td></tr><tr><td>273</td><td>ALMC_R2_INCORRECT_CHANGE</td><td>Flow Problem (Replacement 2)</td></tr><tr><td>295</td><td>ALMC_ANTIICOAG_SUSPENDED</td><td>Anticoagulation suspended</td></tr><tr><td>296</td><td>ALMC_EFF_ON_CLAMPING</td><td>Flow Problem (Effluent)</td></tr><tr><td>297</td><td>ALMCRep_ON_CLAMPING</td><td>Flow Problem (Replacement)</td></tr><tr><td>298</td><td>ALMC_PBP_ON_CLAMPING</td><td>Flow Problem (PBP Flow)</td></tr><tr><td>299</td><td>ALMC_DIA_ON_CLAMPING</td><td>Flow Problem (Dialysate)</td></tr><tr><td>300</td><td>ALMC_REP2_ON_CLAMPING</td><td>Flow Problem (Replacement 2)</td></tr><tr><td>323</td><td>ALMC_EFF_CONTROL_ERROR</td><td>Flow Problem (Effluent)</td></tr><tr><td>324</td><td>ALMC_REP_CONTROL_ERROR</td><td>Flow Problem (Replacement)</td></tr><tr><td>325</td><td>ALMC_PBP_CONTROL_ERROR</td><td>Flow Problem (PBP)</td></tr><tr><td>326</td><td>ALMC_DIA_CONTROL_ERROR</td><td>Flow Problem (Dialysis)</td></tr><tr><td>327</td><td>ALMC_REP2_CONTROL_ERROR</td><td>Flow Problem (Replacement 2)</td></tr><tr><td>333</td><td>ALMC_FLUID_LEAK_DETECTED</td><td>Fluid Leak Detected</td></tr></table>

# 5.2.3.4 Advisory

Table 5-9. Advisory   

<table><tr><td>ID</td><td>Name</td><td>Title</td></tr><tr><td>226</td><td>ALMA_ACCPRESS_OVER_OP</td><td>Check Access</td></tr><tr><td>227</td><td>ALMA_ACCPRESS UNDER_OP</td><td>Check Access</td></tr><tr><td>228</td><td>ALMA_RET_PRESS_OVER_OP</td><td>Check Return</td></tr><tr><td>229</td><td>ALMA_PAUSE_TIME_EXPIRED</td><td>Blood Flow Stopped</td></tr><tr><td>230</td><td>ALMA_SYNRINGE emptied</td><td>Syringe Empty</td></tr><tr><td>231</td><td>ALMA_SYNRINGE_LINE_CLAMPED</td><td>Syringe Line Clamped</td></tr><tr><td>232</td><td>ALMA_CLOTTING_FILTER</td><td>Filter is Clotting</td></tr><tr><td>233</td><td>ALMA_TPE_CLOTTING_FILTER</td><td>Plasmafilter is Clotting</td></tr><tr><td>234</td><td>ALMA_HP_CLOTTING_FILTER</td><td>HP Cartridge is Clotting</td></tr><tr><td>235</td><td>ALMA_MAX_UFR</td><td>TMP Too High</td></tr><tr><td>236</td><td>ALMA_TPE_MAX_UFR</td><td>TMPa Too High</td></tr><tr><td>237</td><td>ALMA_REPLACE_BLOOD_CIRCUIT</td><td>Time to Change Set (72 hours)</td></tr><tr><td>240</td><td>ALMA_RET_PRESS_CANNOT_MON</td><td>Cannot Detect Return</td></tr><tr><td>244</td><td>ALMA_CONFIRM_POSITIVE_RANGE</td><td>Confirm Access Range (POS)</td></tr><tr><td>245</td><td>ALMA_CONFIRM_NEGATIVE_RANGE</td><td>Confirm Access Range (NEG)</td></tr><tr><td>258</td><td>ALMA_CONFIRM_CONFIRM_POSITIVE_RANGE</td><td>Confirm Positive Access Pressure</td></tr><tr><td>259</td><td>ALMA_SYNRINGE_LINE_CLAMPED_TEST</td><td>Check Syringe Line</td></tr><tr><td>261</td><td>ALMA_SYNRINGE_NOT_LOADeds</td><td>Syringe Not Loaded</td></tr><tr><td>279</td><td>ALMA_FLUID_PUMPS_STOPPED</td><td>Fluid Pumps Stopped</td></tr><tr><td>280</td><td>ALMA_CITRATE_CHECK_POINT</td><td>Anticoagulation Checkpoints</td></tr><tr><td>301</td><td>ALMA_SYRINGE_ALMOST emptied</td><td>Syringe Almost Empty</td></tr><tr><td>302</td><td>ALMA_CALCIUM_SYRINGE emptied</td><td>Calcium Syringe Empty</td></tr><tr><td>303</td><td>ALMA_CALCIUM_LINE_CLAMPED</td><td>Calcium Line Clamped</td></tr><tr><td>304</td><td>ALMA_CALCIUM_LINE_NOT_CONNECTED</td><td>Calcium Line Not Connected</td></tr><tr><td>305</td><td>ALMA MEMORYBackup</td><td>Memory Backup</td></tr><tr><td>306</td><td>ALMA_START_MARS-treated</td><td>MARS TREATMENT</td></tr><tr><td>314</td><td>ALMA_BATTERY_EXHAUSTED</td><td>Battery Exhausted</td></tr><tr><td>315</td><td>ALMA_MAIN_POWER_LOST</td><td>Main Power Lost</td></tr><tr><td>320</td><td>ALMA SELF_TEST_OVERDUE</td><td>Self-test overdue</td></tr><tr><td>322</td><td>ALMA_INCOMPLETE_BOLUS</td><td>Incomplete Bolus (Treatment was stopped during an anticoagulation bolus)</td></tr><tr><td>330</td><td>ALMA_CHECK_OXYGENSUPPLY</td><td>Check Oxygen Supply</td></tr><tr><td>331</td><td>ALMA_STORAGE_NOT_READY</td><td>Cannot save history data</td></tr></table>

# 5.2.3.5 Malfunction

Table 5-10. Malfunction   

<table><tr><td>ID</td><td>Name</td><td>Title</td></tr><tr><td>65</td><td>ALMM_generalSAFESTATEundefined</td><td>General System Failure (0)</td></tr><tr><td>67</td><td>ALMM WATCHDOG_FAIL_ON_TASK</td><td>Communication Error (2)</td></tr><tr><td>68</td><td>ALMM_PROTCOMMUNICATIONLINK_ERROR</td><td>Communication Error (3)</td></tr><tr><td>69</td><td>ALMM_CONCOMMUNICATIONLINK_ERROR</td><td>Communication Error (4)</td></tr><tr><td>70</td><td>ALMM_STATUSCOMM MISSING</td><td>Communication Error (5)</td></tr><tr><td>71</td><td>ALMM_ALARMCOMM MISSING</td><td>Communication Error (6)</td></tr><tr><td>72</td><td>ALMM_SENDTOPSLAVE_ERROR</td><td>Communication Error (7)</td></tr><tr><td>74</td><td>ALMM_SETVAL_INCONGRUENCE</td><td>Memory Error (4)</td></tr><tr><td>75</td><td>ALMM_PRESURE_HWTEST_FAIL</td><td>Pressures Circuit Board</td></tr><tr><td>76</td><td>ALMM_VOLTAGE_OUT_RANGE</td><td>Voltage Out of Range</td></tr><tr><td>77</td><td>ALMM_SETVAL_INCONGRUENCE_CTRL PROT</td><td>Memory Error (6)</td></tr><tr><td>81</td><td>ALMM_BUBBLE_TEST_FAIL</td><td>Air Detector</td></tr><tr><td>82</td><td>ALMM_CLOSE_CLAMP</td><td>Clamp Stuck Closed</td></tr><tr><td>83</td><td>ALMM_B_RATE用户提供</td><td>Blood Pump</td></tr><tr><td>84</td><td>ALMM_W_RATE用户提供</td><td>Effluent Pump</td></tr><tr><td>85</td><td>ALMM_R_RATE用户提供</td><td>Replacement Pump</td></tr><tr><td>86</td><td>ALMM_D_RATE用户提供</td><td>Dialysate Pump</td></tr><tr><td>87</td><td>ALMM_P_RATE用户提供</td><td>PBP Pump</td></tr><tr><td>88</td><td>ALMM_BLD_NORM_FAIL</td><td>Normalization Failed</td></tr><tr><td>89</td><td>ALMM_BLOOD_TEST_FAIL</td><td>Blood Leak Detector</td></tr><tr><td>98</td><td>ALMM_STST_ACC_EFFL_FAIL</td><td>Self-Test Failure (5)</td></tr><tr><td>99</td><td>ALMM_STST.fil_EFFL_FAIL</td><td>Self-Test Failure (6)</td></tr><tr><td>100</td><td>ALMM_STST_EFFL.fil_ACC_FAIL</td><td>Self-Test Failure (7)</td></tr><tr><td>109</td><td>ALMM_STST_RET_FAIL</td><td>Self-Test Failure (16)</td></tr><tr><td>110</td><td>ALMM_PRTST_BLDNORM_FAIL</td><td>Prime Self-Test (17)</td></tr><tr><td>111</td><td>ALMM_PRTST_BLD_FAIL</td><td>Prime Self-Test (18)</td></tr><tr><td>112</td><td>ALMM_PRTST_STOPPUMP_FAIL</td><td>Prime Self-Test (19)</td></tr><tr><td>113</td><td>ALMM_PRTST_PUMPOCCL_FAIL</td><td>Prime Self-Test (20)</td></tr><tr><td>114</td><td>ALMM_PRTST_DIAL_PINCH_FAIL</td><td>Prime Self-Test (21)</td></tr><tr><td>115</td><td>ALMM_PRTSTRep_PINCH_FAIL</td><td>Prime Self-Test (22)</td></tr><tr><td>116</td><td>ALMM_PRTST_DIALREP_PINCH_FAIL</td><td>Prime Self-Test (23)</td></tr><tr><td>117</td><td>ALMM_PRTST_24V_FAIL</td><td>Prime Self-Test (24)</td></tr><tr><td>118</td><td>ALMM_PRTST_CLAMP_FAIL</td><td>Prime Self-Test (25)</td></tr><tr><td>119</td><td>ALMM_PRTST_24V_CLAMP_FAIL</td><td>Prime Self-Test (26)</td></tr><tr><td>121</td><td>ALMM_PRTST_ACC_FAIL</td><td>Prime Self-Test (1)</td></tr><tr><td>122</td><td>ALMM_PRTST_FIL_FAIL</td><td>Prime Self-Test (2)</td></tr><tr><td>123</td><td>ALMM_PRTST_ACCFUL_FAIL</td><td>Prime Self-Test (3)</td></tr><tr><td>124</td><td>ALMM_PRTST_EFFL_FAIL</td><td>Prime Self-Test (4)</td></tr><tr><td>125</td><td>ALMM_PRTST_ACC_EFFL_FAIL</td><td>Prime Self-Test (5)</td></tr><tr><td>126</td><td>ALMM_PRTST_FIL_EFFL_FAIL</td><td>Prime Self-Test (6)</td></tr><tr><td>127</td><td>ALMM_PRTST_EFFL_FIL_ACC_FAIL</td><td>Prime Self-Test (7)</td></tr><tr><td>136</td><td>ALMM_PRTST_RET_FAIL</td><td>Prime Self-Test (16)</td></tr><tr><td>137</td><td>ALMM_SYRINGE_PUMP_CONTROL</td><td>Syringe Pump (1)</td></tr><tr><td>138</td><td>ALMMDIFFERINGWeights_REPLACE</td><td>Scales - Replacement</td></tr><tr><td>139</td><td>ALMM_DIFFERINGWeights_DIALYSATE</td><td>Scales - Dialysate</td></tr><tr><td></td><td></td><td>Scales - Replacement 2</td></tr><tr><td>140</td><td>ALMM_DIFFERINGWeights_PPI</td><td>Scales - PBP</td></tr><tr><td>141</td><td>ALMM_DIFFERINGWeights_EFFLUENT</td><td>Scales - Effluent</td></tr><tr><td>142</td><td>ALMM_PRESS_ZERO_TEST_FAIL</td><td>Pressure Zero Test</td></tr><tr><td>143</td><td>ALMM scales_ZERO_TEST_FAIL</td><td>Scale Zero Test</td></tr><tr><td>146</td><td>ALMM_ERROR_DATA_SAVED_INCustom</td><td>Cannot Save Custom Data</td></tr><tr><td>147</td><td>ALMM_NOALIGN_ONLibrary_DATA</td><td>Library Data</td></tr><tr><td>148</td><td>ALMM_NOALIGN_ONCUSTOM_DATA</td><td>Custom Data</td></tr><tr><td>149</td><td>ALMM_DATA_ERROR</td><td>Memory Error (1)</td></tr><tr><td>151</td><td>ALMM_SETVAL_BAD_CRC</td><td>Memory Error (3)</td></tr><tr><td>152</td><td>ALMM_CO_INCONGRUENT_INFO</td><td>Memory Error (5)</td></tr><tr><td>153</td><td>ALMM_LINE_IN_CLAMP</td><td>Line in Clamp</td></tr><tr><td>154</td><td>ALMM_NO_LINE_IN_ABD</td><td>No Line In Air Detector</td></tr><tr><td>155</td><td>ALMM_LINE_IN_ABD</td><td>Line In Air Detector</td></tr><tr><td>156</td><td>ALMM_DIALOG_PINCH_WRONG</td><td>Upper Pinch Valve</td></tr><tr><td>157</td><td>ALMM Replica_PINCH_WRONG</td><td>Lower Pinch Value</td></tr><tr><td>158</td><td>ALMM.Scale_HWTEST_FAIL</td><td>Scales Circuit Board</td></tr><tr><td>159</td><td>ALMM_SYRINGE_HWTEST_FAIL</td><td>Syringe Circuit Board</td></tr><tr><td>160</td><td>ALMM scales_EFFLSENS_FAIL</td><td>Effluent Scale Sensor</td></tr><tr><td>161</td><td>ALMM scales_REPLSENS_FAIL</td><td>Replacement Scale Sensor</td></tr><tr><td>162</td><td>ALMM scales_DIALSENS_FAIL</td><td>Dialysate Scale Sensor</td></tr><tr><td></td><td></td><td>Replacement 2 Scale Sensor</td></tr><tr><td>163</td><td>ALMM scales_PBPSENS_FAIL</td><td>PBP Scale Sensor</td></tr><tr><td>165</td><td>ALMM_NO_LINE_IN_CLAMP</td><td>No Line in Clamp</td></tr><tr><td>166</td><td>ALMM_SYRINGE_NOT_LOADED</td><td>Syringe Not Loaded</td></tr><tr><td>272</td><td>ALMM_R2_RATE_WRONG</td><td>Replacement Pump 2</td></tr><tr><td>283</td><td>ALMM_SYRINGE_PUMP_RATE</td><td>Syringe Pump (2)</td></tr><tr><td>284</td><td>ALMM_SYRINGE_PUMP.Direction</td><td>Syringe Pump (3)</td></tr><tr><td>285</td><td>ALMM_SYRINGE_PUMP_CONFIG</td><td>Syringe Pump (4)</td></tr><tr><td>286</td><td>ALMM_SYRINGE_PUMP_SENSOR</td><td>Syringe Pump (5)</td></tr><tr><td>287</td><td>ALMM_SYRINGE_PUMP_forceHIGH</td><td>Syringe Pump (6)</td></tr><tr><td>288</td><td>ALMM_SYRINGE_PUMP_forceLOW</td><td>Syringe Pump (7)</td></tr><tr><td>289</td><td>ALMM_SYRINGE_PUMP_MOVING</td><td>Syringe Pump (8)</td></tr><tr><td>290</td><td>ALMM_SYRINGE_PUMP_NOTMOVING</td><td>Syringe Pump (9)</td></tr><tr><td>291</td><td>ALMM backups MEMORY_PTASK_AC</td><td>Memory Error (7)</td></tr><tr><td>309</td><td>ALMM GENERAL SAFESTATE_ALL_PUMPS</td><td>General System Failure (1)</td></tr><tr><td>310</td><td>ALMM GENERAL SAFESTATE_FLUID_PUMPS</td><td>General System Failure (2)</td></tr><tr><td>311</td><td>ALMM GENERAL SAFESTATE_CLOSE_CLAMP</td><td>General System Failure (3)</td></tr><tr><td>312</td><td>ALMM GENERAL SAFESTATE_PS_CRIT_CNT</td><td>General System Failure (4)</td></tr><tr><td>313</td><td>ALMM GENERAL SAFESTATE_I2C_RETRY_CNT</td><td>General System Failure (5)</td></tr><tr><td>318</td><td>ALMM GENERAL SAFESTATE_SYRINGE_PUMP</td><td>General System Failure (6)</td></tr><tr><td>321</td><td>ALMM_TOO_HIGH_AUTO_BLOOD_RETURN</td><td>Auto blood return (Amount of blood to be automatically returned is to high compared to filter volume)</td></tr><tr><td>328</td><td>ALMM_STST SoundsCHECK_FAILED</td><td>Self-Test Failure (30)</td></tr><tr><td>329</td><td>ALMM SoundsCHECK_FAILED</td><td>Sound Check</td></tr><tr><td>336</td><td>ALMM GENERAL SAFESTATE_PS_REBOOTS</td><td>General System Failure (7)</td></tr></table>

# 6 The USB interface

6.1 Automatic saving of History Data 40   
6.2 Transferring History Data to a USB flash drive 40   
6.3 Interpretation of History Data 42

6.3.1 How to transfer the USB Flash Drive Content to a Computer 42   
6.3.2 Example of a LOX file copied from a USB flash drive 42

# 6.1 Automatic saving of History Data

History data are automatically saved by the Prismaflex control unit in an internal memory. Additional information is also included to support the manufacturer when a technical investigation needs to take place. The history data of the last treatment can be accessed from the History screen.

At the end of the treatment when the set is unloaded, the history data are saved into a compressed LOX file in the internal memory for later transfer to a USB flash drive. The internal memory stores up to 100 consecutive history files; thereafter, the oldest data is gradually replaced with new data.

If any error is detected while saving treatment data to the internal memory, the alarm Advisory: Download Interrupted is activated and the user is given the option to save current treatment data immediately to an attached USB flash drive.

If the machine is powered down (switched off) or a total power loss occurs during treatment, History Data are retained in the internal memory.

# 6.2 Transferring History Data to a USB flash drive

The Prismaflex control unit is able to transfer the content of the internal memory to a USB flash drive.

# Procedure

1) In the Choose Patient screen of the Prismaflex control unit, press the DOWNLDB DATA softkey.   
2) When the Download screen appears, insert a USB flash drive into the USB port of the Prismaflex control unit. The DOWNLD DATA softkey is enabled.   
3) Press the DOWNLD DATA softkey and wait for a confirmation that the download is finished. While the History data files are being downloaded, the CHOOSE PATIENT softkey is disabled.

Each time the DOWNLD DATA softkey is pressed, all history files stored in the internal memory are copied to the USB flash drive.

History files transferred to the USB flash drive will be saved in a folder on the USB flash drive with a name based on the serial number of the Prismaflex control unit.

![](images/4bfccbb5b81691e4281c1210d7b656dcaa0f8967d810df4bff4c405a7d5a93a6.jpg)

![](images/9ba86a52e6a18274a664c0192349e1122ed0cda5f6549576ecd2eefa9a94bf05.jpg)  
Figure 6-1. Choose Patient screen   
Figure 6-2. Download screen

4) When the data download has finished, press ERASE DATA to erase old history data.

# NOTE!

Erasing the History Data is possible before downloading it to the USB flash drive. Always make sure to download the data before erasing it to avoid data loss.

5) Remove the USB flash drive after downloading History Data files. The DOWNLD DATA softkey is disabled and the CHOOSE PATIENT softkey is enabled after the USB flash drive is removed.

# 6.3 Interpretation of History Data

# 6.3.1 How to transfer the USB Flash Drive Content to a Computer Before you begin

The computer should have a USB port to connect the USB flash drive and a software to be able to decompress file and to import the downloaded .lox file (e.g.: 7-zip file manager and Excel).

# Procedure

1) Insert the USB flash drive into the USB port on the PC. The flash drive is identified by Windows as a removable disk.   
2) Copy the one single LOX file or the complete folder structure to the PC hard disk.   
3) Erase files from the USB flash drive, after having checked that the files have been copied correctly.   
4) Use the proper command to eject the USB flash drive from the computer.   
5) Use your preferable tool to decompress the file saved on your PC.

# 6.3.2 Example of a LOX file copied from a USB flash drive

File name is interpreted in the following way (11IE5FEA.LOX used as an example):

File name is based on following structure:

# SSSYMDHM.* (time is based on download time)

- SSS Device serial (Base36, zero padded)   
- Y Year since 2000 (Base36)   
M Month (Base36)   
D Day (Base36)   
- H Hour of day (Base36)   
- M Last even minute of hour (Base36)

The file used as an example gives following values:

- 111 = 1350 (serial number of the Prismaflex control unit)   
E = 14 (Year 2014)   
- 5 = May   
F=15   
E = 14 (2 PM)   
- A = 10 (Minute 20)

Copied file comes from a Prismaflex control unit with serial number 1350 and time for the download was 14:20, $15^{\text{th}}$ of May, 2014.

Use 7-zip or other compressing tools to extract file content of the LOX file. The new file (11IE5FEA) needs to be extracted as well.

After extraction, following files can be found in the 11IE5FEA file:

Logging information:

- 11IE5FEA.PLC (Information used for technical investigations)   
- 11IE5FEA.PLE (Events during treatment, copy from History)   
11IE5FEA.PLI (Information used for technical investigations)   
- 11IE5FEA.PLP (Pressure readings, copy from History)   
11IE5FEA.PLR (Information used for technical investigations)   
11IE5FEA.PLS (Scale readings, copy from History)   
11IE5FEA.PLT (Information used for technical investigations)   
- 11IE5FEA.PLY (Information used for technical investigations)   
- 11IE5FEA.PLL (Information used for technical investigations)

Customised settings:

11IE5FEA.PCA (Information used for technical investigations)   
11IE5FEA.PCI (Information used for technical investigations)   
11IE5FEA.PCM (Information used for technical investigations)   
- 11IE5FEA.PCU (Information used for technical investigations)

Start Microsoft Excel or similar tool. From the file menu select "Open" and then select one of the files, *.PLE, *.PLP or *.PLS. Follow the "Text Import Wizard".

See the following example of information found in the *.PLE, *.PLP and *.PLS files.

Figure 6-3. Event   

<table><tr><td></td><td>A</td><td>B</td><td>C</td><td>D</td><td>E</td><td>F</td><td>G</td><td>H</td><td>I</td></tr><tr><td>1</td><td>MonitorID: 4692-1a34</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td>SW VERSION: 8.10 VO2R00</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td>Language: English</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4</td><td>Language Version: Default Language</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td colspan="5">Fingerprint: 810ENGBO0013500008BA8499F58A31E0110DF17321X00001X004H4ZENAHEADBEADBEADBEADBEOBOEOI</td><td></td><td></td><td></td><td></td></tr><tr><td>6</td><td>Set Id: M100</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8</td><td>Calibration data:</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>9</td><td>Pressure:</td><td>Neg Zero:</td><td>Neg Span:</td><td>Pos Zero:</td><td>Pos Span:</td><td>MiddleAd:</td><td></td><td></td><td></td></tr><tr><td>10</td><td>Access</td><td>512</td><td>1024</td><td>512</td><td>1024</td><td>512</td><td></td><td></td><td></td></tr><tr><td>11</td><td>Return</td><td>511</td><td>1002</td><td>511</td><td>1002</td><td>511</td><td></td><td></td><td></td></tr><tr><td>12</td><td>Filter</td><td>512</td><td>1009</td><td>512</td><td>1009</td><td>512</td><td></td><td></td><td></td></tr><tr><td>13</td><td>Effluent</td><td>508</td><td>1006</td><td>508</td><td>1006</td><td>508</td><td></td><td></td><td></td></tr><tr><td>14</td><td>Fifth</td><td>516</td><td>1013</td><td>516</td><td>1013</td><td>516</td><td></td><td></td><td></td></tr><tr><td>15</td><td>ARPS</td><td>515</td><td>1008</td><td>515</td><td>1008</td><td>515</td><td></td><td></td><td></td></tr><tr><td>16</td><td>Scale:</td><td>Prot Zero:</td><td>Prot Span:</td><td>Prot Error:</td><td>Control Zero:</td><td>Control Span:</td><td>Control Error:</td><td></td><td></td></tr><tr><td>17</td><td>PBP</td><td>17288</td><td>-4313</td><td>2</td><td>-25589</td><td>4357</td><td>1</td><td></td><td></td></tr><tr><td>18</td><td>Replacement</td><td>17222</td><td>-4257</td><td>0</td><td>-25178</td><td>4268</td><td>0</td><td></td><td></td></tr><tr><td>19</td><td>Dialysate</td><td>18196</td><td>-4460</td><td>1</td><td>-25252</td><td>4277</td><td>0</td><td></td><td></td></tr><tr><td>20</td><td>Effluent</td><td>17619</td><td>-4329</td><td>4</td><td>-25852</td><td>4356</td><td>5</td><td></td><td></td></tr><tr><td>21</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>22</td><td>Repositioning data:</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>23</td><td>Subcode=0</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>24</td><td>Effluent E0=0, E1=0</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>25</td><td>Filter E0=0, E1=0</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>26</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>27</td><td>Index</td><td>Time</td><td>Class(cod)</td><td>Class</td><td>Type(cod)</td><td>Type</td><td>Sample(cod)</td><td>Sample</td><td>ExcessPtFluidLoss/Gain</td></tr><tr><td>28</td><td>0</td><td>2015-04-30 11:25</td><td>16</td><td>SET_VALUE</td><td>332</td><td>Preventive maintenance due in (days)</td><td>-3544</td><td>-3544</td><td></td></tr><tr><td>29</td><td>1</td><td>2015-04-30 11:25</td><td>8</td><td>EVENT</td><td>38</td><td>New patient confirmed.</td><td>0</td><td></td><td></td></tr><tr><td>30</td><td>2</td><td>2015-04-30 11:25</td><td>8</td><td>EVENT</td><td>5</td><td>Therapy selected: SCUF</td><td>0</td><td></td><td></td></tr><tr><td>31</td><td>3</td><td>2015-04-30 11:25</td><td>8</td><td>EVENT</td><td>42</td><td>Anticoagulation selected: None</td><td>0</td><td></td><td></td></tr><tr><td>32</td><td>4</td><td>2015-04-30 11:25</td><td>8</td><td>EVENT</td><td>11</td><td>LOAD selected.</td><td>0</td><td></td><td></td></tr><tr><td>33</td><td>5</td><td>2015-04-30 11:26</td><td>16</td><td>SET_VALUE</td><td>532</td><td>Filter selected:</td><td>23</td><td>None</td><td></td></tr><tr><td>34</td><td>6</td><td>2015-04-30 11:26</td><td>16</td><td>SET_VALUE</td><td>433</td><td>Bar code label:</td><td>0</td><td>1,01425E+12</td><td></td></tr><tr><td>35</td><td>7</td><td>2015-04-30 11:26</td><td>16</td><td>SET_VALUE</td><td>532</td><td>Filter selected:</td><td>4</td><td>M100</td><td></td></tr><tr><td>36</td><td>8</td><td>2015-04-30 11:27</td><td>8</td><td>EVENT</td><td>13</td><td>PRIME selected.</td><td>0</td><td></td><td></td></tr><tr><td>37</td><td>9</td><td>2015-04-30 11:27</td><td>64</td><td>MDBMALFUNCTION</td><td>192</td><td>MALFUNCTION: Effluent Scale Sensor</td><td>1 (o)</td><td></td><td></td></tr><tr><td>38</td><td>10</td><td>2015-04-30 11:33</td><td>64</td><td>MDBMALFUNCTION</td><td>192</td><td>MALFUNCTION: Effluent Scale Sensor</td><td>0 (x)</td><td></td><td></td></tr><tr><td>39</td><td>11</td><td>2015-04-30 11:39</td><td>16</td><td>SET_VALUE</td><td>412</td><td>Prismailung Event Code</td><td>1</td><td>1</td><td></td></tr><tr><td>40</td><td>12</td><td>2015-04-30 11:39</td><td>8</td><td>EVENT</td><td>14</td><td>PRIME TEST selected.</td><td>0</td><td></td><td></td></tr><tr><td>41</td><td>13</td><td>2015-04-30 11:39</td><td>8</td><td>EVENT</td><td>77</td><td>BLD Normalization done.</td><td>0</td><td></td><td></td></tr><tr><td>42</td><td>14</td><td>2015-04-30 11:39</td><td>16</td><td>SET_VALUE</td><td>202</td><td>Current BLD PWM value:</td><td>327</td><td>32.7 %</td><td></td></tr><tr><td>43</td><td>15</td><td>2015-04-30 11:39</td><td>16</td><td>SET_VALUE</td><td>203</td><td>Current BLD sensor value:</td><td>43867</td><td>43867</td><td></td></tr><tr><td>44</td><td>16</td><td>2015-04-30 11:39</td><td>16</td><td>SET_VALUE</td><td>149</td><td>BLD OFF Signal:</td><td>128</td><td>128</td><td></td></tr><tr><td>45</td><td>17</td><td>2015-04-30 11:44</td><td>8</td><td>EVENT</td><td>15</td><td>Prime test passed.</td><td>0</td><td></td><td></td></tr><tr><td>46</td><td>18</td><td>2015-04-30 11:45</td><td>16</td><td>SET_VALUE</td><td>194</td><td>Selected Limit</td><td>400</td><td>400 ml</td><td></td></tr><tr><td>47</td><td>19</td><td>2015-04-30 11:45</td><td>16</td><td>SET_VALUE</td><td>22</td><td>Pre Blood Pump</td><td>50</td><td>50 ml/h</td><td></td></tr><tr><td>48</td><td>20</td><td>2015-04-30 11:45</td><td>16</td><td>SET_VALUE</td><td>24</td><td>Pt Fluid Removal</td><td>50</td><td>50 ml/h</td><td></td></tr><tr><td>49</td><td>21</td><td>2015-04-30 11:46</td><td>16</td><td>SET_VALUE</td><td>416</td><td>Patient ID:</td><td>1</td><td>4124b0c09335c27f086f</td><td></td></tr><tr><td>50</td><td>22</td><td>2015-04-30 11:46</td><td>16</td><td>SET_VALUE</td><td>26</td><td>Patient Weight:</td><td>75</td><td>75 kg</td><td></td></tr></table>

<table><tr><td></td><td>A</td><td>B</td><td>C</td><td>D</td><td>E</td><td>F</td><td>G</td></tr><tr><td>1</td><td colspan="2">MonitorID: 4692-1a34</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td colspan="2">SW VERSION: 8.10 V02R00</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td colspan="2">Language: English</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4</td><td colspan="2">Language Version: Default Language</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td colspan="6">Fingerprint: 810ENGB001350000BAB499F58A31E0110DF17321X00001X004H4ZENADBEADBEADBEADBE0B0E08</td><td></td></tr><tr><td>6</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7</td><td>Index</td><td>Time</td><td>ACCESS PRESSURE</td><td>FILTER PRESSURE</td><td>EFFLUENT PRESSURE</td><td>RETURN PRESSURE</td><td>ARPS PRESSURE</td></tr><tr><td>8</td><td>0</td><td>2015-04-30 11:47</td><td>-64</td><td>109</td><td>65</td><td>72</td><td>0</td></tr><tr><td>9</td><td>1</td><td>2015-04-30 11:48</td><td>-63</td><td>103</td><td>63</td><td>64</td><td>0</td></tr><tr><td>10</td><td>2</td><td>2015-04-30 11:49</td><td>-63</td><td>104</td><td>65</td><td>66</td><td>-1</td></tr><tr><td>11</td><td>3</td><td>2015-04-30 11:50</td><td>-70</td><td>102</td><td>64</td><td>68</td><td>-1</td></tr><tr><td>12</td><td>4</td><td>2015-04-30 11:51</td><td>-56</td><td>105</td><td>62</td><td>63</td><td>-2</td></tr><tr><td>13</td><td>5</td><td>2015-04-30 11:52</td><td>-56</td><td>106</td><td>65</td><td>65</td><td>-2</td></tr><tr><td>14</td><td>6</td><td>2015-04-30 11:53</td><td>-51</td><td>108</td><td>63</td><td>71</td><td>-2</td></tr><tr><td>15</td><td>7</td><td>2015-04-30 11:54</td><td>-52</td><td>108</td><td>62</td><td>71</td><td>-3</td></tr></table>

Figure 6-4. Pressures

<table><tr><td></td><td>A</td><td>B</td><td>C</td><td>D</td><td>E</td><td>F</td><td>G</td><td>H</td><td>I</td><td>J</td><td>K</td><td>L</td><td>M</td><td>N</td></tr><tr><td>1</td><td colspan="2">MonitorID: 4692-1a34</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>2</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>3</td><td colspan="2">SW VERSION: 8.10 V02R00</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>4</td><td colspan="2">Language: English</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>5</td><td colspan="2">Language Version: Default Language</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>6</td><td colspan="8">Fingerprint: 810ENGB001350000BAB499F58A31E0110DF17321X00001X004H4ZENADBEADBEADBEADBE0B0E08</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>7</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>8</td><td>Index</td><td>Time</td><td>RUN_TIME</td><td>POSTINFUSION</td><td>PREINFUSION</td><td>DIALYSATE</td><td>EFFLUENT</td><td>PREBLOOD-INF</td><td>SYRINGE-INF</td><td>EXCESS_PT_FLUID</td><td>PUMP1</td><td>PUMP2</td><td>PUMP3</td><td>PUMP4</td></tr><tr><td>9</td><td>0</td><td>2015-04-30 11:47</td><td>36</td><td>0</td><td>0</td><td>0</td><td>1</td><td>7</td><td>0</td><td>6</td><td>64</td><td>0</td><td>0</td><td>180</td></tr><tr><td>10</td><td>1</td><td>2015-04-30 11:48</td><td>96</td><td>0</td><td>0</td><td>0</td><td>3</td><td>6</td><td>0</td><td>4</td><td>64</td><td>0</td><td>0</td><td>131</td></tr><tr><td>11</td><td>2</td><td>2015-04-30 11:49</td><td>156</td><td>0</td><td>0</td><td>0</td><td>5</td><td>6</td><td>0</td><td>4</td><td>64</td><td>0</td><td>0</td><td>136</td></tr><tr><td>12</td><td>3</td><td>2015-04-30 11:50</td><td>216</td><td>0</td><td>0</td><td>0</td><td>6</td><td>5</td><td>0</td><td>3</td><td>72</td><td>0</td><td>0</td><td>146</td></tr><tr><td>13</td><td>4</td><td>2015-04-30 11:51</td><td>276</td><td>0</td><td>0</td><td>0</td><td>8</td><td>5</td><td>0</td><td>3</td><td>83</td><td>0</td><td>0</td><td>170</td></tr><tr><td>14</td><td>5</td><td>2015-04-30 11:52</td><td>336</td><td>0</td><td>0</td><td>0</td><td>10</td><td>5</td><td>0</td><td>1</td><td>114</td><td>0</td><td>0</td><td>188</td></tr><tr><td>15</td><td>6</td><td>2015-04-30 11:53</td><td>396</td><td>0</td><td>0</td><td>0</td><td>12</td><td>6</td><td>0</td><td>2</td><td>112</td><td>0</td><td>0</td><td>175</td></tr><tr><td>16</td><td>7</td><td>2015-04-30 11:54</td><td>456</td><td>0</td><td>0</td><td>0</td><td>13</td><td>7</td><td>0</td><td>1</td><td>119</td><td>0</td><td>0</td><td>194</td></tr></table>

Figure 6-5. Scales

# 7 Decoding 2D barcode

7.1 2D barcode information 46   
7.2 Example of a 2D barcode scanned on a Prismaflex control unit 46

# 7.1 2D barcode information

2D barcode is the graphical representation of the fingerprint shown in the header of the *.PLE, *.PLP and *.PLS files found in the *.LOX file structure, described in Section 6 "The USB interface" on page 39.

2D Barcode can be accessed from the sixth technical screen or in Diagnose section in service mode, in screen Service - 2D barcode.

# 7.2 Example of a 2D barcode scanned on a Prismaflex control unit

810ENGB001350000BAB499F58A31E0110DF17321X00001X004H4ZENADBEADBEDADBEBA0B0E08

Decoding

Software version

$810\Rightarrow \mathrm{SW}8.10$

Language

ENGB = English

Table 7-1.   

<table><tr><td>Language Name</td><td>ISO 639-1 + ISO 3166-1</td></tr><tr><td>English (Great Britain)</td><td>enGB</td></tr><tr><td>Chinese (Simplified)</td><td>zhCN</td></tr><tr><td>Chinese (Traditional)</td><td>zhTW</td></tr><tr><td>Czech</td><td>csCZ</td></tr><tr><td>Danish</td><td>daDK</td></tr><tr><td>Dutch (The Netherlands)</td><td>nɪNL</td></tr><tr><td>Estonian</td><td>etEE</td></tr><tr><td>Finnish</td><td>fiFI</td></tr><tr><td>French (France)</td><td>frFR</td></tr><tr><td>German (Germany)</td><td>deDE</td></tr><tr><td>Greek</td><td>eIGR</td></tr><tr><td>Hungarian</td><td>huHU</td></tr><tr><td>Italian (Italy)</td><td>itIT</td></tr><tr><td>Korean</td><td>koKR</td></tr><tr><td>Latvian</td><td>lvLV</td></tr><tr><td>Lithuanian</td><td>ltLT</td></tr><tr><td>Norwegian (Bokmål)</td><td>nbNO</td></tr><tr><td>Polish</td><td>plPL</td></tr><tr><td>Portuguese (Portugal)</td><td>ptPT</td></tr><tr><td>Romanian (Romania)</td><td>roRO</td></tr><tr><td>Russian</td><td>ruRU</td></tr><tr><td>Slovak</td><td>skSK</td></tr><tr><td>Slovenian (Slovene)</td><td>sI SI</td></tr><tr><td>Spanish (Spain)</td><td>esES</td></tr><tr><td>Swedish</td><td>svSE</td></tr><tr><td>Turkish</td><td>trTR</td></tr></table>

# Language pack version

$$
0 = 0 (0 = \text {d e f a u l t}
$$

# Serial number

$$
0 1 3 5 0 = P A 0 1 3 5 0
$$

The serial number is encoded in plain text, in the range of 0-99999.

In SW 7.10 and later: The default value 0 shall be encoded as "00000".

In SW < SW 7.00: The default value 0 shall be encoded as “*****”.

# MAC address

$$
0 0 0 B A B 4 9 9 F 5 8 = 0 0 - 0 B - A B - 4 9 - 9 F - 5 8
$$

# System date of fingerprint

$$
\begin{array}{l} A 3 1 E \Rightarrow 2 0 1 5 - 0 4 - 3 0 \\ A \Rightarrow 2 0 0 5 + 1 0 = 2 0 1 5 \\ 3 \Rightarrow 0 4 (\text {m o n t h} 0 - 1 1) \\ 1 E \Rightarrow 3 0 (d a y 1 - 3 1) \\ ^ {* * *} = I n v a l i d \\ \end{array}
$$

# Last preventive maintenance done

$$
\begin{array}{l} 0 1 1 0 \Rightarrow 2 0 0 5 - 0 2 - 1 6 \\ 0 \Rightarrow 2 0 0 5 + 0 = 2 0 0 5 \\ 1 \Rightarrow 0 2 (\text {m o n t h} 0 - 1 1) \\ 1 0 \Rightarrow 1 6 (d a y 1 - 3 1) \\ \end{array}
$$

$$
^ {* * *} = I n v a l i d
$$

Dates are encoded using 4 hexadecimal digits, the 1:st one being the number of years passed since 2005 (market introduction), the 2:nd being the month (0-11), and the 3:rd and 4:th being the day of the month (1-31).

In SW 7.10 and greater: Dates outside the available range shall be encoded as “\*\*\*\*.

In SW < SW 7.00: Dates outside the available range shall be encoded as "0000".

# HW/SW configuration

DF17 = Little endian, LSB to MSB

Table 7-2.   

<table><tr><td>06</td><td>00</td><td></td><td></td></tr><tr><td>MSB→LSB</td><td>MSB→LSB</td><td></td><td></td></tr><tr><td>00000110</td><td>00000000</td><td></td><td></td></tr><tr><td>00000000</td><td>00000001</td><td>CRRT MARS</td><td>1=unlocked, 0=locked</td></tr><tr><td>00000000</td><td>00000010</td><td>Citrate/Calcium</td><td>1=unlocked, 0=locked</td></tr><tr><td>00000000</td><td>00000100</td><td>Citrate</td><td>1=unlocked, 0=locked</td></tr><tr><td>00000000</td><td>00001000</td><td>CRRT septex</td><td>1=unlocked, 0=locked</td></tr><tr><td>00000000</td><td>00010000</td><td>HP</td><td>1=unlocked, 0=locked</td></tr><tr><td>00000000</td><td>00100000</td><td>TPE 250</td><td>1=unlocked, 0=locked</td></tr><tr><td>00000000</td><td>01000000</td><td>TPE 400</td><td>1=unlocked, 0=locked</td></tr><tr><td>00000000</td><td>10000000</td><td>Oxiris</td><td>1=unlocked, 0=locked</td></tr><tr><td>00000001</td><td>00000000</td><td>HF 20</td><td>1=unlocked, 0=locked</td></tr><tr><td>00000010</td><td>00000000</td><td>RS232</td><td>1=enabled, 0=disabled</td></tr><tr><td>00000100</td><td>00000000</td><td>Battery Backup</td><td>1=enabled, 0=disabled</td></tr><tr><td>00001000</td><td>00000000</td><td>High Flow Warmer</td><td>1=unlocked, 0=locked</td></tr><tr><td>00010000</td><td>00000000</td><td>Prismalung</td><td>1=unlocked, 0=locked</td></tr><tr><td>00100000</td><td>00000000</td><td>Not used</td><td></td></tr><tr><td>01000000</td><td>00000000</td><td>Not used</td><td></td></tr><tr><td>10000000</td><td>00000000</td><td>Not used</td><td></td></tr></table>

# Scale error

321X00001X004H4Z

Table 7-3.   

<table><tr><td>Base 36</td><td>Dec</td><td></td></tr><tr><td>32</td><td>110</td><td>PBP_px</td></tr><tr><td>1X</td><td>69</td><td>PBP_cx</td></tr><tr><td>00</td><td>0</td><td>Rep_px</td></tr><tr><td>00</td><td>0</td><td>Rep_cx</td></tr><tr><td>1X</td><td>69</td><td>Dia_px</td></tr><tr><td>00</td><td>0</td><td>Dia_cx</td></tr><tr><td>4H</td><td>161</td><td>Eff_px</td></tr><tr><td>4Z</td><td>179</td><td>Eff_cx</td></tr></table>

PBP Prot error(PBP_p) = Exp(PBP_px/100) - 1

Where: $\mathsf{Exp} = 2,71828182845904$

# Calibration data for ABD

EN

Table 7-4.   

<table><tr><td>Base 36</td><td>Dec</td><td></td></tr><tr><td>EN</td><td>527</td><td>ABD_x</td></tr></table>

ABD = Exp(ABD_x/100) - 1Where: Exp = 2,71828182845904

# Scale firmware

ADBE = Effluent CRC: 0xDABE

ADBE = PBP CRC: 0xADBE

ADBE = Dialysate CRC: 0xADBE

ADBE = Replacement CRC: 0xADBE

# Syringe pump firmware

0B0E = Syringe CRC: 0x0B0E

# For Gambro development internal use

08
