# Treatment Journal Simplification And Hardening Spec

> Updated: 2026-04-03
> Owner mindset: CTO
> Scope: product policy, UX pruning, backend hardening, database direction, module split guidance

## Executive Decision

Treatment Journal is one of the most-used screens in the product.

Because of that, the goal is **not** "make it feature rich".
The goal is:

- make it clinically trustworthy
- make it easy for nurses to use
- reduce timeline/chronology bugs
- remove structural actions that create hidden conflicts

My conclusion is:

- **yes**, some current features should be removed or hidden
- **no**, we should not remove everything
- **yes**, nurse workflow should be simplified to "fill values only"
- **yes**, structural repair actions should leave the main clinical UI

This is not just to reduce UX clutter.
It is to reduce real process risk.

## What I Agree With

I agree with these product decisions:

- nurses should mainly fill values, not repair the timeline
- while treatment is actively recording, only low-risk edits should be allowed
- risky structural actions should not live in the same screen as normal nursing input
- replay/rebuild from source data is safer than trying to reconstruct missing timeline rows by hand

## What I Do **Not** Agree With

I do **not** agree with removing every recovery feature blindly.

Specifically:

- I do **not** recommend removing `restore existing row to original values`
  - if the row already exists
  - if `snapshot_time` stays immutable
  - if the system restores machine-origin values only
  - then this is a low-risk, clinically useful action

- I do **not** recommend redesigning the entire DB before pruning the workflow
  - first simplify policy and UX
  - then refactor modules and schema if still needed

In short:

- remove dangerous **structural** actions from clinical UI
- keep safe **value correction** actions

## Product Principle

Treatment Journal must behave like a **clinical record**, not like a spreadsheet.

That means:

- telemetry defines the timeline
- humans may correct values
- humans should not casually create, delete, or reconstruct the timeline
- chronology must come from backend truth, not UI heuristics

## Final Feature Decision Matrix

| Feature | Decision | Why |
|---|---|---|
| Auto `H00` | Keep | High clinical value, stable baseline logic |
| Auto `H01/H02/...` | Keep | Core timeline generation |
| Auto `OC_XX` | Keep | Captures real interventions between hours |
| Edit existing row values | Keep | Primary nurse workflow |
| Edit notes | Keep | Low-risk and useful during care |
| Restore existing row to original machine values | Keep, but restricted | Useful and low-risk if row already exists |
| Restore missing row | Remove from clinical UI | Too easy to rebuild chronology wrong |
| Fill gap / create missing row | Remove from clinical UI for now | Structural action, conflicts with recording and chronology |
| Add next hour | Remove | Synthetic row creation has weak trust and high risk |
| Delete row | Remove from nurse/doctor UI | High medico-legal risk, should not be a routine clinical action |
| Bulk update rows | Remove | Audit risk, low clinical value |

## CTO Product Policy

### 1. Nurse workflow

Nurse should only be able to:

- open the journal
- view all rows
- edit allowed manual values on **existing stable rows**
- edit notes
- submit for review

Nurse should **not** be able to:

- delete rows
- create rows
- fill missing hours
- restore missing rows
- reconstruct timeline

### 2. Doctor workflow

Doctor should be able to:

- review the journal
- approve / reject
- unlock approved treatment if needed
- restore an **existing** row to original machine values

Doctor should **not** routinely do:

- add missing rows manually in the clinical UI
- delete rows from the clinical UI

If timeline repair is truly needed, use a separate maintenance path.

### 3. Admin / support workflow

Admin or support tools may handle:

- replay raw data
- rebuild treatment snapshots
- delete/rebuild corrupted treatment records
- deep maintenance / recovery

These actions should not be mixed into the daily nurse journal experience.

## Why Remove Structural Actions From The Main UI

Structural actions are the source of most dangerous bugs:

- wrong `snapshot_time`
- wrong `OC_XX` placement
- wrong chronology after restore
- fake rows beyond real treatment duration
- row count/report mismatch
- audit ambiguity

These actions are also the least frequently needed in normal clinical use.

So the right decision is:

- keep them out of the main workflow
- solve exceptional repair through maintenance tooling

## In-Progress Editing Policy

This is the safest practical policy for the current product:

### During `IN_PROGRESS`

Allowed:

- edit notes
- edit allowed manual values on **existing stable rows**

Not allowed:

- add row
- fill gap
- restore missing
- delete row
- structural restore
- approve/reject/unlock

### Why this is safe

Because editing values on an already existing stable row does **not**:

- create a new timeline node
- move chronology
- change treatment boundary
- invent a row that telemetry never created

This is much safer than timeline repair.

## Stable Row Definition

### `H00`

`H00` is stable only after baseline freeze is complete.

Recommended rule:

- do not allow manual edit during the initial `60s` freeze window

### `H01/H02/...`

Stable if:

- the row already exists in DB

### `OC_XX`

Stable if:

- the row already exists in DB

### Missing row

Not stable.
Clinical UI must not let nurse create it.

## Field-Level Edit Allowlist

Backend must enforce this.
Do not rely only on frontend visibility.

### Heparin mode

Allow nurse edit on existing stable rows:

- `heparin_bolus`
- `heparin_rate`
- `duosol_count`
- `prismasol_count`
- `filter_type`
- `kali`

### Citrate mode

Allow nurse edit on existing stable rows:

- `duosol_count`
- `prismasol_count`
- `filter_type`
- `kali`
- `calcium_comp`
- `citrate_dose`

### Never allow manual edit for telemetry-driven fields

- `qb`
- `qd`
- `qs`
- `qpbp`
- `uf_total`
- `uf_hourly`
- `pa`
- `pv`
- `pbe`
- `tmp`

If the product later needs one of these fields to become editable, it must be a conscious policy change.

## Backend Contract

### Current problem

`update_snapshot_manual()` is being used for multiple very different actions:

- edit existing row values
- create row
- restore existing row
- restore missing row

This is too much responsibility in one path and keeps creating edge cases.

### Required direction

Split actions conceptually, even if the first implementation still shares some helpers.

Recommended command layer:

- `edit_snapshot_values()`
- `restore_existing_snapshot()`
- `submit_treatment_review()`
- `approve_treatment_review()`
- `reject_treatment_review()`
- `unlock_treatment_review()`

Do **not** keep "restore missing row" in the daily clinical command layer.

### Required backend rules

`PUT /snapshots/{hourLabel}`

- only updates an existing row
- rejects if row does not exist
- rejects disallowed keys
- rejects unstable rows
- preserves `snapshot_time`

`POST /snapshots/manual`

- remove from nurse clinical path
- if kept temporarily, backend should reject for nurse

`DELETE /snapshots/{hourLabel}`

- remove from clinical UI
- keep only for internal maintenance if absolutely needed

`restore missing row`

- remove from clinical UI
- if maintenance path exists, it must require original timestamp and source proof

## Database Direction

The DB should support a **safe table workflow**, not a loose spreadsheet workflow.

### Keep the current wide-row snapshot table for now

Do **not** rush into a full EAV or JSON redesign.
That would slow delivery and create more uncertainty.

Current table shape is still fine for the current UI.

### Immediate DB requirements

`treatment_hourly_snapshots` must remain the source of truth for:

- `hour_label`
- `snapshot_time`
- clinical values
- `source`
- `created_at`
- `updated_at`
- `updated_by`

Recommended additions if low-risk:

- `version INTEGER DEFAULT 1`
- `row_kind TEXT` with values like `HOUR`, `ORDER_CHANGE`
- `deleted_at TEXT NULL` for future soft-delete

### Audit table recommendation

Add a separate append-only table later:

`snapshot_audit_log`

Suggested columns:

- `id`
- `treatment_id`
- `hour_label`
- `action_type`
- `field_name`
- `old_value`
- `new_value`
- `operator_name`
- `role`
- `created_at`

This is better than trying to encode full audit history into the main snapshot row.

## Module Split Recommendation

If OPUS feels the code is getting fragile, stop patching inside a single huge file and split by responsibility.

### Backend split

Recommended folder:

`backend/services/treatment/journal/`

Suggested modules:

- `journal_policy_service.py`
  - permission matrix
  - role checks
  - recording-state checks
  - stable-row checks

- `journal_command_service.py`
  - edit existing values
  - restore existing row
  - submit/approve/reject/unlock

- `journal_query_service.py`
  - fetch journal rows
  - compare rows
  - review queries

- `journal_audit_service.py`
  - append audit events

Router stays thin:

- validate request
- call policy
- call command service
- return result

### Frontend split

Recommended folder:

`frontend/app/(main)/treatments/journal/`

Suggested modules:

- `journalPermissions.ts`
  - `canEditValue`
  - `canRestoreExisting`
  - `canSubmit`
  - etc.

- `journalEditableFields.ts`
  - field allowlist by therapy mode

- `journalRowState.ts`
  - stable row detection
  - row badge state

- `journalActions.ts`
  - shared mutation wrappers

This prevents policy from being duplicated inconsistently across multiple components.

## UI Simplification Plan

### Keep visible in nurse UI

- edit existing manual values
- notes
- operator badge / operator entry
- submit review

### Remove or hide from nurse UI

- fill gap button
- restore missing rows button
- delete row button
- add next hour button
- bulk operations

### Keep visible in doctor review UI

- approve
- reject
- restore existing row to machine values

### Remove or hide from doctor review UI

- delete row
- restore missing rows

If support still needs these, they belong in a maintenance-only screen or script.

## Why This Is The Right Tradeoff

This policy intentionally sacrifices some flexibility.

That is the correct tradeoff because:

- the product is used under clinical pressure
- the journal is heavily used
- operators need clarity, not power
- timeline integrity matters more than convenience

The current system has already shown that too many edit modes create:

- chronology bugs
- confusing UI
- operator confusion
- inconsistent review/export behavior

So the safe decision is to **reduce surface area**.

## Recommended Implementation Phases

### Phase 1: stabilize the product now

Do this immediately:

1. Remove nurse UI for:
   - fill gap
   - restore missing
   - delete row
   - add next hour
2. Make `PUT /snapshots/{hourLabel}` update existing rows only.
3. Enforce backend field allowlist.
4. Allow nurse edit only on existing stable rows.
5. Preserve chronology and `snapshot_time`.

### Phase 2: doctor-safe review workflow

1. Keep doctor approve/reject/unlock.
2. Keep doctor restore existing row to machine values.
3. Remove delete-row from doctor clinical UI unless there is a proven real need.

### Phase 3: maintenance tooling

1. Separate replay/rebuild/repair tools from Treatment Journal UI.
2. Add audit table if needed.
3. Add module split if code continues to grow.

## Explicit Non-Goals

This spec does **not** recommend:

- rebuilding the full DB architecture immediately
- keeping all recovery features in the main UI
- allowing nurses to repair the timeline
- allowing structural journal edits during active recording

## Acceptance Criteria

1. Nurse can edit manual values on existing stable rows.
2. Nurse cannot create, delete, restore-missing, or fill-gap from the journal UI.
3. `H00` cannot be edited before freeze completes.
4. `snapshot_time` never mutates on value edit.
5. `OC_XX` stays in clinical chronological order.
6. Doctor can still restore an existing row to original machine values.
7. Missing-row repair is no longer part of normal clinical workflow.
8. Support/admin can still recover a bad treatment by replay/rebuild outside the journal UI.

## One-Line CTO Guidance

Treatment Journal should help clinicians document care, not let them reconstruct the timeline by hand.
