# Treatment Journal Runtime QA Checklist

Purpose: help QA verify whether the current PrismaFlex build is operationally safe enough for hands-on trial, with special focus on Treatment Journal, chronology, role/policy behavior, and recent PostgreSQL migration work.

Use this as a manual checklist for browser QA plus a light backend sanity pass.

## 1. Test Rules

- Test with at least 2 roles:
  - `nurse`
  - `doctor` or `admin`
- Test on at least 2 treatment states:
  - `IN_PROGRESS`
  - `COMPLETED` or `PENDING_REVIEW`
- Capture evidence for every fail:
  - screenshot
  - treatment id
  - row code (`H00`, `H01`, `OC_01`, ...)
  - role used
  - exact action sequence
- Mark each case:
  - `PASS`
  - `FAIL`
  - `BLOCKED`
- If a case fails, note whether it is:
  - UI-only
  - backend-only
  - chronology/data-integrity
  - permission/policy

## 2. Exit Criteria

Do not call the build ready unless all of these are true:

- No crash during normal treatment detail/review usage
- Journal chronology remains stable after reload
- Operator check-in works on the first mutation attempt
- Nurse and doctor permissions match policy
- Review flow works end-to-end
- No incorrect value formatting in treatment screens
- No obvious regression in print/export/review/detail consistency

## 3. Smoke Test First

These are the first 10 cases QA should run before anything else.

| ID | Area | Action | Expected |
|---|---|---|---|
| S1 | List | Open treatment list | Page loads, no crash, rows visible |
| S2 | Detail | Open one treatment detail | Journal grid renders, no blank crash |
| S3 | Chronology | Check visual order of `Hxx` and `OC_XX` | Ordered by clinical time, `OC_XX` not pushed to bottom |
| S4 | Operator | First edit attempt with no operator active | System asks for operator name before save |
| S5 | Nurse edit | Edit one existing stable row field | Save succeeds, row stays in place |
| S6 | Reload | Refresh page after edit | Edited value persists, chronology unchanged |
| S7 | Submit | Submit a completed treatment for review | Status changes correctly |
| S8 | Review | Open review compare | Current/original data loads, no serialization issue |
| S9 | Doctor action | Approve or reject as doctor/admin | Action succeeds only for allowed role |
| S10 | Export | Open print/export flow | Data matches detail/review, no obvious mismatch |

## 4. Treatment Lifecycle

### 4.1 Start / Continue / End

| ID | Scenario | Steps | Expected |
|---|---|---|---|
| TL1 | New treatment | Start a fresh run | New treatment appears with correct patient/device |
| TL2 | Same patient continue | `RUN -> END -> same patient -> RUN_TIME > 0` | Same treatment id continues |
| TL3 | Same patient new run | `RUN -> END -> same patient -> RUN_TIME = 0` | Old treatment closes, new treatment opens |
| TL4 | Patient change | Continue with different patient | New treatment starts, old one closes |
| TL5 | Completed treatment view | Open a finished treatment | Journal/review/export all load normally |

### 4.2 Multi-device

| ID | Scenario | Steps | Expected |
|---|---|---|---|
| TL6 | Two devices in parallel | Watch/open treatments from 2 devices | No cross-device contamination |
| TL7 | Backfill/live isolation | Use one old/backfill-like treatment and one recent treatment | One treatment should not close or distort the other |

## 5. Journal Chronology

This is the most important section.

| ID | Scenario | Steps | Expected |
|---|---|---|---|
| JC1 | Hourly order | Inspect `H00 -> H01 -> H02...` | Hour rows appear in correct order |
| JC2 | OC interleave | Inspect a treatment with `OC_XX` rows | `OC_XX` appears between the right hourly rows |
| JC3 | Edit existing row | Edit an existing row then reload | Row does not jump to bottom |
| JC4 | Review compare chronology | Open review compare for same treatment | Same chronology as detail view |
| JC5 | Print chronology | Open print preview | Same chronology as detail/review |
| JC6 | Excel/export chronology | Export and inspect order | Same chronology as UI |

Special attention:

- `H00` must not move after edit
- `OC_XX` must not collect at the end
- reload must not reshuffle rows

## 6. Nurse Editing Policy

Policy target:

- nurse can edit manual values on existing stable rows
- nurse should not perform structural timeline actions

| ID | Scenario | Steps | Expected |
|---|---|---|---|
| NP1 | First edit with no operator | Click into editable cell | Operator prompt appears before mutation |
| NP2 | Existing stable row edit | Edit `heparin_bolus`, `notes`, or other manual field | Save succeeds |
| NP3 | Non-editable machine field | Try editing telemetry-like field if UI allows | Must be blocked or unavailable |
| NP4 | Approved treatment locked | Try editing after approve | Blocked with clear message |
| NP5 | Recording policy | While treatment is `IN_PROGRESS`, try allowed edit | Behavior must match current product policy; if blocked, message must be clear |
| NP6 | Unstable row policy | Try editing a row that should not yet be stable | Must be blocked if stability policy is implemented |

Important note for QA:

- `NP6` is currently a known focus area. Verify whether backend truly blocks unstable-row edits, not just UI.

## 7. Operator Check-In

| ID | Scenario | Steps | Expected |
|---|---|---|---|
| OP1 | First mutation | First edit action in a fresh session | Modal/prompt asks operator name |
| OP2 | Same treatment second mutation | Edit again in same treatment | No repeated prompt |
| OP3 | Change treatment | Open another treatment and mutate | Re-check behavior; prompt if policy requires |
| OP4 | Change operator | Use change/reset operator control if present | New operator becomes active cleanly |
| OP5 | Error language | Trigger validation error | Message is understandable and localized appropriately |

## 8. Review Workflow

| ID | Scenario | Steps | Expected |
|---|---|---|---|
| RV1 | Submit review | Nurse submits completed treatment | Moves to `PENDING_REVIEW` |
| RV2 | Approve as doctor | Doctor approves pending treatment | Moves to `APPROVED` |
| RV3 | Reject as doctor | Doctor rejects pending treatment | Moves to `REJECTED` or draft-compatible state per flow |
| RV4 | Unlock approved | Doctor/admin unlocks approved treatment | Moves back to editable review state |
| RV5 | Wrong role approve | Try approve as nurse | Must fail cleanly |
| RV6 | Wrong role unlock | Try unlock as nurse | Must fail cleanly |
| RV7 | Notes | Add clinical note | Saves and remains visible |

## 9. Snapshot / Journal Data Integrity

| ID | Scenario | Steps | Expected |
|---|---|---|---|
| DI1 | Edit existing row | Change one manual field | Only that value changes |
| DI2 | Audit visibility | If audit UI exists, verify editor/update info | Correct editor and timing shown |
| DI3 | Compare originals | Open review compare after manual edit | Original vs current difference is accurate |
| DI4 | Reload integrity | Refresh page | Data persists exactly |
| DI5 | Cross-screen parity | Compare detail, review, print | Same value set everywhere |

## 10. Numeric / Clinical Formatting Regression

### 10.1 Heparin Rate

| ID | Scenario | Input | Expected |
|---|---|---|---|
| HM1 | Snapshot value | raw PID 38 = `20` | UI shows `2.0 ml/hr` |
| HM2 | Low decimal | raw PID 38 = `5` | UI shows `0.5 ml/hr` |
| HM3 | Detail panel | Open treatment detail | Same displayed value |
| HM4 | Review/print/export | Open review and print | Same displayed value |

### 10.2 TMP / DeltaP chart readability

| ID | Scenario | Steps | Expected |
|---|---|---|---|
| CH1 | TMP below threshold | Threshold high, data around 100-150 | Line still clearly visible |
| CH2 | TMP near threshold | Data near threshold | Threshold and line both readable |
| CH3 | DeltaP below threshold | Low data, higher threshold | Line does not collapse near bottom |

## 11. PostgreSQL-Specific Backend Sanity

These can be run by QA with backend help or by Codex QA.

| ID | Check | Expected |
|---|---|---|
| PG1 | `alembic_version` exists | Migration table exists |
| PG2 | Core tables exist | `treatments`, `treatment_journal_rows`, `treatment_review_state`, `snapshot_originals`, `snapshot_audit_log`, `treatment_list_projection`, `raw_packet_manifest` |
| PG3 | Query endpoint shape | `/api/v2/.../detail` returns structured JSON, not stringified blobs |
| PG4 | Review endpoint role gate | Wrong role cannot approve/reject/unlock |
| PG5 | Raw manifest contract | No runtime error from removed `chunk_seq` |
| PG6 | Raw FK safety | No new FK violation in logs when treatment/chunk registration occurs |

Suggested SQL checks:

```sql
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;
```

```sql
SELECT * FROM alembic_version;
```

## 12. Error Log Watchlist

QA or backend observer should watch for these:

- foreign key violation on `raw_packet_manifest`
- serialization error from `/api/v2` query endpoints
- missing table / missing column errors
- role/policy bypass
- chronology drift after reload
- save succeeds but row order changes

## 13. Recommended Codex QA Sequence

Run in this order:

1. Smoke test `S1-S10`
2. Chronology `JC1-JC6`
3. Nurse policy `NP1-NP6`
4. Review workflow `RV1-RV7`
5. Formatting regression `HM1-HM4`, `CH1-CH3`
6. PostgreSQL sanity `PG1-PG6`
7. Multi-device/lifecycle `TL1-TL7`

## 14. QA Report Template

Use this report format:

```text
Build:
Branch:
Backend commit/WIP note:
Frontend commit/WIP note:

Smoke:
- PASS/FAIL

Critical findings:
1.
2.

Chronology:
- PASS/FAIL

Permissions:
- PASS/FAIL

Operator check-in:
- PASS/FAIL

Review workflow:
- PASS/FAIL

PostgreSQL sanity:
- PASS/FAIL

Ready for wider trial:
- YES / NO

Notes:
```

## 15. CTO Release Recommendation Rule

Recommend `YES` only if:

- no P0 or P1 fail remains
- chronology is stable
- operator flow is usable
- role gating is correct
- review flow works
- no Postgres runtime error appears during test session

Recommend `NO` if any of these occur:

- row jumps chronology after edit
- wrong role can approve/unlock
- unstable row can be edited against policy
- API returns malformed data
- raw manifest/runtime logs show FK or schema drift errors
