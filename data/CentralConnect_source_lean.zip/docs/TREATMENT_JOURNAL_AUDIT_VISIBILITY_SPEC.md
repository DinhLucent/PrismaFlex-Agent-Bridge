# Treatment Journal Audit Visibility Spec

> Superseded on 2026-04-18 by `docs/TREATMENT_JOURNAL_AUDIT_TRAIL_V2_SPEC.md`.
> Tai lieu nay giu lai de tham chieu lich su pham vi `row-level visibility` ban dau.

Updated: 2026-04-03

## 1. Problem

Treatment Journal da co `operator check-in`, nhung UI hien tai chi cho biet:

- ai dang thao tac o phien hien tai

UI chua cho biet ro:

- row nao da bi sua tay
- ai la nguoi sua gan nhat
- sua vao luc nao
- row nao la `AUTO`, `MANUAL`, `EDITED`, hay `RESTORED`

Ket qua la:

- nguoi dung nhin bang Journal khong biet dau la gia tri may, dau la gia tri da can thiep tay
- khi can audit nhanh ngay tren man hinh, khong co dau vet truc quan
- badge `operator` tren top bar khong thay the duoc `row-level audit`

## 2. Goal

Them lop hien thi audit toi thieu cho Treatment Journal de:

- user nhin vao row la biet row do co bi can thiep tay hay khong
- user biet ai sua gan nhat
- user biet thoi diem sua gan nhat
- giu UI gon, de doc, phu hop demo va su dung thuc te

Khong muc tieu cua phase nay:

- khong lam full audit log theo tung field
- khong can build trang lich su audit rieng
- khong can login/account thuc

## 3. Data Model Su Dung Trong Phase Nay

Tan dung cac truong da co hoac dang gan co san:

- `source`
- `updated_by`
- `updated_at`
- `reason` voi `OC_XX` neu co

Y nghia hien thi:

- `source = AUTO`: row tu may / telemetry
- `source = MANUAL`: row tao tay hoac nhap tay
- `source = MERGED`: row auto nhung da co can thiep tay
- `updated_by`: nguoi thao tac gan nhat
- `updated_at`: thoi diem thao tac gan nhat

## 4. UX Model

Can tach ro 2 tang:

### 4.1 Current Operator

Day la badge dang co o top bar:

- cho biet ai dang thao tac hien tai
- khong phai audit lich su

Badge nay duoc giu lai.

### 4.2 Row-Level Audit

Moi row Journal can co bieu hien truc quan cho biet:

- row nay co bi sua tay khong
- ai sua gan nhat
- sua luc nao

Day moi la thong tin audit user can khi review ho so.

## 5. UI Requirements

### 5.1 Detail Panel

Ap dung tai:

- `frontend/app/(main)/treatments/DetailPanel.tsx`

Can them audit mini-stack o cot dau tien cua moi row, ben duoi `hour_label` va thoi gian:

- Neu row la auto nguyen ban:
  - giu giao dien gon
  - khong can show them dong audit

- Neu row co can thiep tay:
  - hien badge nho:
    - `MANUAL`
    - `EDITED`
    - `RESTORED`
  - hien dong text nho:
    - `by <updated_by>`
  - hien dong text nho:
    - `<HH:mm dd/MM>` tu `updated_at`

Khuyen nghi visual:

- `MANUAL`: amber
- `EDITED`: blue hoac cyan
- `RESTORED`: teal

Neu khong du cho:

- uu tien badge + `by <name>`
- thoi gian dua vao tooltip

### 5.2 Review Page

Ap dung tai:

- `frontend/app/(main)/treatments/review/page.tsx`

Can them mot cot hoac sub-cell audit o cuoi row:

- badge source
- `updated_by`
- `updated_at`

Neu can tiet kiem chieu ngang:

- cot `Audit`
- dong 1: badge
- dong 2: `by <name>`
- dong 3: time nho

Day la man hinh bac si review, nen thong tin audit can ro hon Detail Panel.

### 5.3 Tooltip / Hover

Ca Detail Panel va Review page nen co tooltip khi hover row badge:

- `Source: AUTO/MANUAL/MERGED`
- `Last edited by: <name>`
- `Last edited at: <time>`

### 5.4 Print / Export

Phase nay:

- khong bat buoc dua full audit vao print/docx
- nhung nen can nhac them ky hieu nho `M` hoac `Edited` neu row da bi sua tay

Neu chua kip:

- co the de phase sau

## 6. Audit Status Mapping

Frontend khong nen chi show truc tiep `source`.

Can map ve nhan de user de hieu:

- `AUTO` + khong co `updated_by` -> khong hien badge hoac hien `AUTO`
- `MANUAL` -> badge `MANUAL`
- `MERGED` + co `updated_by` -> badge `EDITED`
- Neu action la restore va co cach xac dinh -> badge `RESTORED`

Phase nay neu chua co truong action rieng cho restore:

- co the tam hien `EDITED`
- hoac them field nhe nhu `last_manual_action`

## 7. Backend Support

Ap dung tai:

- `backend/services/treatment/treatment_database.py`
- `backend/routers/treatment_router.py`

Can dam bao API detail/review tra ve du:

- `source`
- `updated_by`
- `updated_at`

Neu hien tai `SELECT *` da tra ve roi thi khong can doi API shape lon.

Can dam bao cac action sau gan `updated_by` dung:

- inline edit
- restore existing row
- fill gap
- manual add
- delete neu row van con hien trong review logic

Neu muon distinguish `RESTORED` voi `EDITED`, can them mot field nhe:

- `last_manual_action TEXT`

Gia tri:

- `EDIT`
- `RESTORE`
- `FILL_GAP`
- `MANUAL_INSERT`

Phase nay:

- field nay la recommended, khong bat buoc neu muon ra ban nhanh

## 8. Product Recommendation

### Phase 1: Bat buoc cho ban sap cai

Lam ngay:

- hien `updated_by` tren row
- hien `updated_at` tren row hoac tooltip
- hien badge `MANUAL/EDITED`
- giu badge `current operator` o top bar

Day la muc toi thieu de user audit truc quan tren man hinh.

### Phase 2: Nen lam sau

- them `last_manual_action`
- hien `RESTORED` rieng
- dua audit marker vao print/export

### Phase 3: Full audit trail

Neu sau nay can audit y khoa manh hon:

- tao bang `snapshot_audit_log`

De xuat schema:

- `id`
- `treatment_id`
- `hour_label`
- `field_name`
- `old_value`
- `new_value`
- `action`
- `operator`
- `role`
- `timestamp`

Khong nam trong scope release hien tai.

## 9. Acceptance Criteria

Mot row da sua tay phai hien:

- co badge khac row auto
- co ten nguoi sua
- co thoi gian sua gan nhat

Mot row auto chua sua:

- khong bi gan audit marker sai

Review page:

- bac si nhin vao phan audit la biet row nao da bi nurse/chinh tay

Detail Panel:

- user nhin nhanh van doc duoc timeline ma khong bi roi

Khong duoc:

- nham `current operator` voi `historical editor`
- lam table qua roi den muc kho doc
- an mat `hour_label`/`snapshot_time` vi nhoi audit qua nhieu

## 10. Suggested Implementation Order

1. Render `updated_by`, `updated_at`, `source` o Review page
2. Render mini-audit stack o Detail Panel
3. Them badge mapping `AUTO/MANUAL/EDITED`
4. Neu can, them `last_manual_action`

## 11. Final Product Decision

Ket luan cho ban sap cai:

- NEN co row-level audit visibility
- KHONG du chi co operator badge o top
- NEN lam giao dien audit nho, ro, khong lam bang Journal nang ne

Day la thay doi gia tri cao, rui ro thap, va rat hop voi workflow thuc te cua dieu duong/bac si.
