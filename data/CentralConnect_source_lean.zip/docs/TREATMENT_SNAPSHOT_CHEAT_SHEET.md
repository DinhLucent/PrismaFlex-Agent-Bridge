# Treatment Snapshot Cheat Sheet

> Updated: 2026-04-03
> Purpose: quick reference for dev, QA, and reviewer before touching Treatment Journal

## Core Mental Model

- `snapshot_time` = clinical sample time
- `updated_at` = human edit time
- `hour_label` = logical journal slot
- `H00/H01/H02...` = hourly clinical timeline
- `OC_XX` = order-change event snapshot between hourly rows

## What Must Never Happen

- Editing `H00` makes it move below `H01/H02`
- Restore changes chronology
- Print order differs from review order
- Export order differs from detail panel order
- Manual edit replaces clinical time with wall-clock `now`

## Safe Rules

### Hourly rows

- `H00` always stays first hourly row
- `H01` always stays after `H00`
- `H02` always stays after `H01`
- Hourly row order is defined by the number in `hour_label`

### Order-change rows

- `OC_XX` may appear between hourly rows
- `OC_XX` is ordered by true clinical `snapshot_time`

### Manual edit

- update values
- update `updated_at`
- keep `snapshot_time`

### Restore

- restore original values
- keep original clinical time
- do not stamp restore time into `snapshot_time`

## Quick Scenario Table

| Case | Action | Expected |
|---|---|---|
| S1 | Edit `H00` | `H00` stays first |
| S2 | Edit `H01` | `H01` stays between `H00` and `H02` |
| S3 | Restore `H00` | `H00` keeps original place |
| S4 | Add missing `H03` | row appears at `start_time + 3h` |
| S5 | `OC_01` exists between `H01` and `H02` | order remains clinically correct |
| S6 | Reload page after edit | row order unchanged |
| S7 | Print after edit | same order as detail panel |
| S8 | Export after edit | same order as review table |

## Files Most Likely To Be Involved

- [treatment_snapshot_service.py](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/backend/services/treatment/treatment_snapshot_service.py)
- [treatment_database.py](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/backend/services/treatment/treatment_database.py)
- [treatment_router.py](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/backend/routers/treatment_router.py)
- [DetailPanel.tsx](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/frontend/app/(main)/treatments/DetailPanel.tsx)
- [review/page.tsx](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/frontend/app/(main)/treatments/review/page.tsx)
- [CrrtPrintPreview.tsx](C:/Users/ADMIN/.codex/worktrees/09de/PrismaFlexWebApp/frontend/app/components/CrrtPrintPreview.tsx)

## 30-Second QA Checklist

- Edit `H00`: does it stay at the top?
- Edit `H01`: does it stay in the middle?
- Restore `H00`: does it stay in place?
- Reload page: is order still correct?
- Print preview: same order?
- Export: same order?
- `updated_at` changed?
- `snapshot_time` unchanged?

## One-Line Summary

Treatment Snapshot chronology must be anchored to clinical time, not to the time a user clicks Save.
