# Backfill Fix C-D Flash Checklist

> Updated: 2026-04-06
> Audience: FLASH
> Goal: finish `Fix C` and `Fix D` in very small steps without touching hourly/OC logic yet

## Rule Of Work

- Do `one task at a time`.
- Do not refactor unrelated code.
- Do not mix parser fixes and session fixes in one patch.
- After each task, run one small verification before moving on.

## Scope

This checklist only covers:

- `Fix C`: stabilize replay timestamp parsing
- `Fix D`: isolate backfill sessions from live cleanup/resumption logic

This checklist does **not** cover yet:

- `H00/H01` slot-first fix
- historical `OC_XX` generation
- frontend timeline fixes

## Task C1

Create one shared packet-time resolver.

Target:

- `backend/main.py`
- or a tiny helper file if that is cleaner

Required behavior:

- precedence = `meta.timestamp_unix > meta.timestamp > header.timestamp`
- support `int`, `float`, and `str`
- return timezone-aware `datetime` in GMT+7

Done when:

- one function exists
- no duplicated precedence logic in backfill route

## Task C2

Use the shared resolver inside the backfill route.

Target:

- `backend/main.py`

Required behavior:

- `receive_backfill` resolves packet time using the shared function
- log one clear line once per replay/device:
  - chosen source
  - raw value
  - resolved ISO datetime

Done when:

- logs show `Replay Parsing Contract`
- route no longer guesses timestamp inline

## Task C3

Make `backfill_worker` use the same resolved time contract.

Target:

- `backend/main.py`

Required behavior:

- worker must not re-interpret the packet with different precedence
- route and worker must agree on `pkt_time`

Done when:

- one packet produces the same logical time in route and worker logs

## Task C4

Update recorder time parsing for parity.

Target:

- `backend/services/treatment/treatment_recorder.py`

Required behavior:

- `_parse_time` supports `datetime`, `int`, `float`, `str`
- unix seconds and unix milliseconds are both handled
- output is always aware GMT+7

Done when:

- recorder can accept `timestamp_unix`-driven packets without shifting time

## Task C5

Update snapshot service time parsing for parity.

Target:

- `backend/services/treatment/treatment_snapshot_service.py`

Required behavior:

- parsing behavior matches recorder
- no separate replay-time interpretation

Done when:

- snapshot path and recorder path resolve the same packet time

## Task D1

Disable DB-based resumption logic for backfill opens.

Target:

- `backend/services/treatment/treatment_recorder.py`

Required behavior:

- if `is_live=False`, skip:
  - same-patient resume lookup
  - recent-closed resumption
  - live recovery shortcuts
- use only the in-memory backfill session map

Done when:

- backfill treatment creation no longer depends on prior DB state

## Task D2

Disable ghost discard for backfill closes.

Target:

- `backend/services/treatment/treatment_recorder.py`

Required behavior:

- short backfill sessions must still be preserved
- live sessions keep the old ghost cleanup behavior

Done when:

- a replay with only 2 minutes of data is still stored in DB

## Task D3

Flush all backfill importer caches on shutdown.

Target:

- `backend/main.py`

Required behavior:

- app shutdown calls `app.state.backfill_importer.flush_all()`
- safe guard if importer is absent

Done when:

- the final open slot is not lost when backend stops after replay

## Verification After Each Task

### After C1-C5

Run one replay packet with:

- `meta.timestamp_unix`
- `meta.timestamp`
- `header.timestamp`

Expected:

- the system chooses the correct source
- time is not shifted by server clock

### After D1-D3

Run a tiny replay:

- same device
- short duration
- then shutdown

Expected:

- treatment is preserved
- no ghost discard
- no last-slot loss

## Stop Conditions

Stop and report immediately if:

- live flow starts failing after backfill changes
- one patch changes both parser and session behavior together
- replay count becomes non-deterministic across two identical runs

## Final Acceptance For This Checklist

- replay start time is no longer shifted by parser ambiguity
- short backfill treatments are preserved
- backfill no longer depends on live recovery/resume logic
- shutdown does not lose the last buffered replay state

## Next Checklist

After this file is complete, move to:

- `H00/H01 slot-first semantics`
- `historical ORDER_CHANGE projector`
