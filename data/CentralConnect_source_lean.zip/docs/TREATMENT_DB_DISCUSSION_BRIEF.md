## Treatment DB Discussion Brief

Purpose: Brief for architecture discussion before implementation planning  
Audience: CTO, Gemini review, backend lead, DB architect  
Decision stage: Pre-branch / pre-sprint

### 1. Context

The current application is clinically usable and the workflow logic has been improved significantly, but the storage layer is still based on SQLite.

SQLite is no longer the right strategic platform for the following reasons:

- multi-user editing and review flows are increasing,
- operator audit and approval workflow are growing,
- Journal behavior is becoming policy-heavy,
- telemetry, review, notes, and audit are currently too tightly coupled,
- future repair/replay and concurrent access will become operationally fragile.

The system now behaves less like a local log viewer and more like a workflow-oriented clinical record system.

### 2. What Must Be Preserved

Any DB redesign must preserve these current clinical truths:

- `snapshot_time` is clinical time and must be immutable after row creation.
- `OC_XX` must interleave by clinical time, not by label grouping.
- Nurse workflow should stay simple:
  - edit allowed values on existing stable rows,
  - add notes,
  - submit for review.
- Structural timeline actions should not live in the routine nurse UI.
- Same-patient continuation logic must not be broken by DB refactor.
- Raw telemetry and Journal logic should not be forced through the same mutation path.

### 3. Proposed Direction

Default recommendation:

- Move Treatment Journal and workflow state to **PostgreSQL**
- Keep APIs **command-driven**, not generic CRUD
- Keep a **wide-row journal table**, not EAV
- Keep a **projection table** for list/history
- Split **raw telemetry storage strategy** from interactive Journal mutation

### 4. Decisions To Confirm With Gemini

#### Decision A: Postgres vs MSSQL

Recommendation:

- choose **PostgreSQL** unless hospital IT policy strongly prefers MSSQL.

Questions:

- Is there any operational reason to prefer MSSQL over Postgres in this environment?
- If MSSQL is chosen, does that justify the added complexity for app engineering?

#### Decision B: One DB vs split storage

Recommendation:

- use PostgreSQL for Journal/workflow/audit,
- keep raw telemetry on a separate storage strategy if volume grows.

Questions:

- Should raw telemetry remain in SQL short-term?
- Should raw telemetry move to chunked file/object storage with manifest metadata in DB?

#### Decision C: Journal model

Recommendation:

- keep one wide relational journal row per `Hxx` or `OC_XX`

Questions:

- Do we agree that EAV/per-cell tables are unnecessary complexity for this UI?
- Do we agree that wide rows better match the review/export grid?

#### Decision D: API model

Recommendation:

- commands, not CRUD

Examples:

- `edit_existing_snapshot_values`
- `submit_review`
- `approve_treatment`
- `restore_existing_snapshot`

Questions:

- Do we explicitly ban generic row add/delete/update endpoints from the clinical UI?

#### Decision E: Feature pruning

Recommendation:

- remove from routine Journal UI:
  - add next hour
  - fill gap
  - restore missing row
  - delete row

Questions:

- Should all structural timeline repair move to doctor/admin tooling or maintenance tooling?
- Should delete/restore be moved out of the main Journal screen entirely?

### 5. Proposed Future Data Domains

#### A. Treatment Lifecycle

- treatment identity
- patient/device linkage
- start/end/outcome
- phase history

#### B. Treatment Journal

- hourly rows
- order-change rows
- stable/editable values
- immutable clinical time

#### C. Review and Approval

- submit
- approve
- reject
- unlock
- frozen originals

#### D. Notes and Audit

- append-only clinical notes
- row-level audit
- operator attribution

#### E. Raw Telemetry

- packet manifests
- replay/export
- forensic retention

### 6. High-Level Schema Shape

Core proposed tables:

- `treatments`
- `treatment_phases`
- `treatment_status_events`
- `treatment_journal_rows`
- `snapshot_originals`
- `treatment_review_state`
- `treatment_notes`
- `snapshot_audit_log`
- `treatment_list_projection`
- `raw_packet_manifest`

### 7. Indexing Principles

Must-have:

- FK indexes on every relationship column
- `(treatment_id, snapshot_time)` for journal timeline
- `(treatment_id, row_code)` unique identity
- `(treatment_id, created_at)` for notes and audit streams
- `(approval_status, start_time DESC)` and `(outcome, start_time DESC)` for list views
- partition strategy for large append-heavy tables if volume warrants it

### 8. Risks If We Do Nothing

- more UI policy patches layered over SQLite limitations
- harder concurrency bugs under real usage
- audit visibility remains partial
- repair/rebuild paths remain mixed with normal clinical editing
- schema becomes harder to evolve safely

### 9. Risks If We Over-Engineer Too Early

- trying to redesign telemetry, Journal, reporting, and workflow all in one sprint
- adopting EAV or hyper-normalized structures that fight the grid UI
- building a generic data platform instead of solving the actual Journal domain

### 10. CTO Recommendation

The right move is not "database everything in one giant redesign".

The right move is:

1. Freeze Journal workflow rules.
2. Simplify the Journal UI to safe operations only.
3. Move the operational Journal domain to PostgreSQL.
4. Keep raw telemetry as a separate storage concern.
5. Build command-oriented APIs and audit from the start.

### 11. If Gemini Agrees, The Next Step Should Be

After alignment, create:

- one implementation branch,
- one architecture sprint,
- one migration sprint,
- one UX hardening sprint,
- one QA verification matrix for parity against the current SQLite behavior.

### 12. Proposed Implementation Breakdown After Approval

#### Sprint 1: Domain freeze and API contract

- finalize policy matrix
- freeze command model
- remove risky UI features
- define Postgres schema

#### Sprint 2: Postgres foundation

- migrations
- repositories
- transaction model
- indexes
- audit log

#### Sprint 3: Journal migration

- treatment detail queries
- row edits
- notes
- review/originals

#### Sprint 4: Raw telemetry strategy

- decide SQL partition vs manifest/object storage
- wire export/replay path

#### Sprint 5: QA and cutover

- parity checks
- historical migration validation
- rollback strategy

### 13. Specific Questions For Gemini Review

Please challenge these assumptions directly:

1. Is PostgreSQL clearly the right default over MSSQL for this product?
2. Is the wide-row journal table the correct long-term shape?
3. Should raw telemetry stay in SQL at all?
4. Should the list/history screen continue to use a projection table?
5. Are there any missing indexes or partitioning concerns from a production DB perspective?
6. Is the command-driven API requirement too strict, or exactly right for a clinical journal?
7. Should restore/delete structural actions be removed from the clinical UI entirely?

### 14. Expected Outcome Of The Discussion

The discussion should end with a yes/no decision on:

- DB platform
- raw telemetry storage approach
- final table architecture
- command model
- scope of feature pruning
- phase-by-phase migration plan

Without those six decisions, the team should not begin the refactor.
