param(
    [string]$BaseUrl = "http://localhost:8000",
    [string[]]$Devices = @("PF_003", "PF_004", "PF_007"),
    [switch]$Fix
)

$ErrorActionPreference = "Stop"

function Normalize-DeviceId {
    param([string]$Raw)

    $text = "$Raw".Trim()
    if ([string]::IsNullOrWhiteSpace($text) -or $text.ToLowerInvariant() -eq "unknown") {
        return "unknown"
    }

    $upper = $text.ToUpperInvariant()
    if ($upper.StartsWith("PF_")) {
        $suffix = $upper.Substring(3).Trim()
        $num = 0
        if ([int]::TryParse($suffix, [ref]$num)) {
            return ("PF_{0:D3}" -f $num)
        }
        return $upper
    }

    $rawNum = 0
    if ([int]::TryParse($text, [ref]$rawNum)) {
        return ("PF_{0:D3}" -f $rawNum)
    }

    return $text
}

function Get-DeviceAliases {
    param([string]$DeviceId)

    $aliases = New-Object System.Collections.Generic.List[string]
    $normalized = Normalize-DeviceId $DeviceId
    $aliases.Add($normalized)

    if ($normalized.StartsWith("PF_")) {
        $suffix = $normalized.Substring(3).Trim()
        $num = 0
        if ([int]::TryParse($suffix, [ref]$num)) {
            $aliases.Add([string]$num)
        }
    }

    return $aliases | Select-Object -Unique
}

function Convert-ModeMap {
    param($ModeObject)

    $map = @{}
    if ($null -eq $ModeObject) {
        return $map
    }

    foreach ($prop in $ModeObject.PSObject.Properties) {
        $map[$prop.Name] = [string]$prop.Value
    }
    return $map
}

function Get-Modes {
    param([string]$Url)

    $modeObject = Invoke-RestMethod -Method Get -Uri "$Url/api/v1/devices/mode" -TimeoutSec 10
    return Convert-ModeMap $modeObject
}

function Print-ModeSummary {
    param(
        [hashtable]$ModeMap,
        [string[]]$TargetDevices
    )

    Write-Host ""
    Write-Host "Target device readiness:"
    Write-Host "------------------------"

    $hasBackfill = $false
    foreach ($device in ($TargetDevices | ForEach-Object { Normalize-DeviceId $_ } | Select-Object -Unique)) {
        $aliases = @(Get-DeviceAliases $device)
        $states = @()

        foreach ($alias in $aliases) {
            if ($ModeMap.ContainsKey($alias)) {
                $states += ("{0}={1}" -f $alias, $ModeMap[$alias])
                if ($ModeMap[$alias] -eq "BACKFILL") {
                    $hasBackfill = $true
                }
            }
        }

        if ($states.Count -eq 0) {
            Write-Host ("[OK]   {0}: NONE (ready for LIVE packet)" -f $device) -ForegroundColor Green
        } elseif (($states -join ", ") -match "BACKFILL") {
            Write-Host ("[WARN] {0}: {1}" -f $device, ($states -join ", ")) -ForegroundColor Yellow
        } else {
            Write-Host ("[OK]   {0}: {1}" -f $device, ($states -join ", ")) -ForegroundColor Green
        }
    }

    Write-Host ""
    Write-Host "All BACKFILL locks:"
    Write-Host "-------------------"
    $backfillRows = @(
        foreach ($key in ($ModeMap.Keys | Sort-Object)) {
            if ($ModeMap[$key] -eq "BACKFILL") {
                "{0}={1}" -f $key, $ModeMap[$key]
            }
        }
    )

    if ($backfillRows.Count -eq 0) {
        Write-Host "[OK]   No BACKFILL locks found." -ForegroundColor Green
    } else {
        foreach ($row in $backfillRows) {
            Write-Host ("[WARN] {0}" -f $row) -ForegroundColor Yellow
        }
    }

    return $hasBackfill
}

function Fix-BackfillLocks {
    param(
        [hashtable]$ModeMap,
        [string[]]$TargetDevices,
        [string]$Url
    )

    $body = @{ from = "BACKFILL"; to = "LIVE" } | ConvertTo-Json
    foreach ($device in ($TargetDevices | ForEach-Object { Normalize-DeviceId $_ } | Select-Object -Unique)) {
        foreach ($alias in @(Get-DeviceAliases $device)) {
            if ($ModeMap.ContainsKey($alias) -and $ModeMap[$alias] -eq "BACKFILL") {
                Write-Host ("Handoff {0}..." -f $alias)
                try {
                    Invoke-RestMethod -Method Post -Uri "$Url/api/v1/devices/$alias/handoff" -ContentType "application/json" -Body $body -TimeoutSec 30 | Out-Null
                    Write-Host ("[OK]   {0}: handoff completed" -f $alias) -ForegroundColor Green
                } catch {
                    Write-Host ("[FAIL] {0}: {1}" -f $alias, $_.Exception.Message) -ForegroundColor Red
                }
            }
        }
    }
}

Write-Host "ICU-B Connect LIVE mode checker"
Write-Host ("Backend: {0}" -f $BaseUrl)

try {
    Invoke-RestMethod -Method Get -Uri "$BaseUrl/" -TimeoutSec 10 | Out-Null
    Write-Host "[OK]   Backend reachable" -ForegroundColor Green
} catch {
    Write-Host ("[FAIL] Backend not reachable: {0}" -f $_.Exception.Message) -ForegroundColor Red
    exit 2
}

try {
    $modeMap = Get-Modes $BaseUrl
} catch {
    Write-Host ("[FAIL] Cannot read device modes: {0}" -f $_.Exception.Message) -ForegroundColor Red
    exit 3
}

$hasBackfill = Print-ModeSummary -ModeMap $modeMap -TargetDevices $Devices

if ($Fix -and $hasBackfill) {
    Write-Host ""
    Write-Host "Fix requested: running BACKFILL -> LIVE handoff for locked target devices..."
    Fix-BackfillLocks -ModeMap $modeMap -TargetDevices $Devices -Url $BaseUrl
    $modeMap = Get-Modes $BaseUrl
    [void](Print-ModeSummary -ModeMap $modeMap -TargetDevices $Devices)
} elseif ($hasBackfill) {
    Write-Host ""
    Write-Host "Some target devices are still BACKFILL. Re-run with -Fix to handoff them:"
    Write-Host ("powershell -NoProfile -ExecutionPolicy Bypass -File `"{0}`" -Fix" -f $PSCommandPath)
}

Write-Host ""
Write-Host "Done."
