# ICU-B CONNECT v3.7.13 FULL LEAN

Full lean release rebuilt from the current workspace on 2026-04-18.

Included fix set:

- Clinical Note log API restore for `GET/POST /api/v1/treatments/{id}/notes/log`
- Treatment Journal Notes + Audit Trail UI restore
- Print Preview anti-flicker hardening with standalone portal rendering
- Newer print layout merge from the later lean lineage
- H00 manual edit fix while treatment is still recording
- Vietnamese label fixes in Treatment Journal:
  - `COMPLETED` -> `Hoan Thanh`
  - `Edit` -> `Nhap`
  - `Operator` -> `Nguoi nhap`
- Utility script to clear treatment notes:
  - `backend/scripts/clear_treatment_notes.py`

Included content:

- backend source
- frontend source
- prismaflex_lib
- docs bundle
- PM2 ecosystem file
- full-stack update scripts
- ingest verification script
- fixed Mirth XML templates

Excluded from this package:

- runtime databases
- runtime logs
- `.env`
- frontend `node_modules/`
- frontend `.next/`
- QA screenshots and local debug artifacts

Default target:

- `D:\Block\CentralConnect`

Recommended update flow:

```bat
safe_update.bat
```

Fallback:

```bat
apply_update.bat D:\Block\CentralConnect
```

Operational notes:

1. This release updates both backend and frontend.
2. The update script does not back up PostgreSQL. Run `pg_dump` separately if required.
3. If PM2 restart fails with port conflicts, run `CHECK_STATUS.bat`, clear stale listeners on `8000` and `3000`, then run `START_SYSTEM.bat`.
4. Backend ingest endpoint must remain `http://localhost:8000/api/v1/telemetry`.

Post-update verification:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\VERIFY_INGEST_ENDPOINT.ps1
```

Then verify:

- dashboard loads
- treatment journal loads
- Notes and Audit Trail open correctly
- Print Preview stays open during live recording
- H00 can be edited after the freeze window
- Vietnamese labels render correctly in Treatment Detail and Journal
