param(
    [string]$BaseUrl = "http://localhost:8000",
    [string]$DeviceId = "PF_999",
    [string]$PatientId = "DEMO-LIVE",
    [int]$Packets = 5,
    [int]$DelayMs = 1000,
    [switch]$Run
)

$ErrorActionPreference = "Stop"

function Normalize-DeviceId {
    param([string]$Raw)

    $text = "$Raw".Trim()
    if ([string]::IsNullOrWhiteSpace($text) -or $text.ToLowerInvariant() -eq "unknown") {
        return "unknown"
    }

    $upper = $text.ToUpperInvariant()
    if ($upper.StartsWith("PF_")) {
        $suffix = $upper.Substring(3).Trim()
        $num = 0
        if ([int]::TryParse($suffix, [ref]$num)) {
            return ("PF_{0:D3}" -f $num)
        }
        return $upper
    }

    $rawNum = 0
    if ([int]::TryParse($text, [ref]$rawNum)) {
        return ("PF_{0:D3}" -f $rawNum)
    }

    return $text
}

function Get-MachineId {
    param([string]$CanonicalDeviceId)

    if ($CanonicalDeviceId.StartsWith("PF_")) {
        $suffix = $CanonicalDeviceId.Substring(3).Trim()
        $num = 0
        if ([int]::TryParse($suffix, [ref]$num)) {
            return $num
        }
    }
    return $CanonicalDeviceId
}

function New-Param {
    param(
        [string]$Type,
        [int]$Id,
        [double]$Value,
        [int]$RecordTime
    )

    return @{
        type = $Type
        id = $Id
        id_hex = ("0x{0:X6}" -f $Id)
        value = $Value
        record_time = $RecordTime
    }
}

function New-DemoPacket {
    param(
        [string]$CanonicalDeviceId,
        [object]$MachineId,
        [string]$Patient,
        [int]$PacketNum,
        [bool]$Running
    )

    $now = Get-Date
    $ts = $now.ToString("yyyy-MM-dd HH:mm:ss") + " UTC"
    $recordTime = [int][double]::Parse((Get-Date -UFormat %s))
    $statusId = if ($Running) { 5 } else { 0 }
    $runTime = if ($Running) { 600 + $PacketNum } else { 0 }

    $params = @(
        (New-Param "Actual" 1  (-80 + ($PacketNum % 5)) $recordTime),
        (New-Param "Actual" 2  (95 + ($PacketNum % 5)) $recordTime),
        (New-Param "Actual" 3  (130 + ($PacketNum % 5)) $recordTime),
        (New-Param "Actual" 4  (75 + ($PacketNum % 5)) $recordTime),
        (New-Param "Actual" 6  (60 + ($PacketNum % 3)) $recordTime),
        (New-Param "Actual" 17 160 $recordTime),
        (New-Param "Actual" 18 0 $recordTime),
        (New-Param "Actual" 19 1000 $recordTime),
        (New-Param "Actual" 21 800 $recordTime),
        (New-Param "Actual" 22 300 $recordTime),
        (New-Param "Actual" 23 2350 $recordTime),
        (New-Param "Actual" 24 50 $recordTime),
        (New-Param "Actual" 38 0 $recordTime),
        (New-Param "Actual" 410 35 $recordTime),
        (New-Param "Actual" 461 $runTime $recordTime),
        (New-Param "Set" 17 160 $recordTime),
        (New-Param "Set" 18 0 $recordTime),
        (New-Param "Set" 19 1000 $recordTime),
        (New-Param "Set" 21 800 $recordTime),
        (New-Param "Set" 22 300 $recordTime),
        (New-Param "Set" 409 1 $recordTime)
    )

    $header = @{
        machine_id = $MachineId
        patient_id = $Patient
        sw_version = "DEMO-LIVE-CHECK"
        therapy_type_id = 3
        therapy_status_id = $statusId
        timestamp = $ts
    }
    $body = @{
        total_records = $params.Count
        parameters = $params
    }

    return @{
        packet_num = $PacketNum
        timestamp = $now.ToString("o")
        meta = @{
            device_id = $CanonicalDeviceId
            timestamp = $ts
            packet_num = $PacketNum
            mode = "LIVE"
            transform_version = "demo_live_check_v1"
            ingest_profile = "realtime"
        }
        s_header = $header
        s_body = $body
        header = $header
        body = $body
    }
}

$DeviceId = Normalize-DeviceId $DeviceId
$MachineId = Get-MachineId $DeviceId
$endpoint = "$BaseUrl/api/v1/telemetry/live"

Write-Host "ICU-B Connect LIVE demo sender"
Write-Host ("Backend : {0}" -f $BaseUrl)
Write-Host ("Device  : {0} (machine_id={1})" -f $DeviceId, $MachineId)
Write-Host ("Patient : {0}" -f $PatientId)
Write-Host ("Status  : {0}" -f $(if ($Run) { "RUNNING - may create demo treatment" } else { "STOPPED - dashboard-only check" }))

try {
    Invoke-RestMethod -Method Get -Uri "$BaseUrl/" -TimeoutSec 10 | Out-Null
    Write-Host "[OK]   Backend reachable" -ForegroundColor Green
} catch {
    Write-Host ("[FAIL] Backend not reachable: {0}" -f $_.Exception.Message) -ForegroundColor Red
    exit 2
}

for ($i = 1; $i -le $Packets; $i++) {
    $packetNum = [int][double]::Parse((Get-Date -UFormat %s)) + $i
    $packet = New-DemoPacket -CanonicalDeviceId $DeviceId -MachineId $MachineId -Patient $PatientId -PacketNum $packetNum -Running ([bool]$Run)
    $json = $packet | ConvertTo-Json -Depth 20 -Compress

    try {
        $resp = Invoke-RestMethod -Method Post -Uri $endpoint -ContentType "application/json" -Body $json -TimeoutSec 15
        Write-Host ("[OK]   Sent packet {0}/{1}: {2}" -f $i, $Packets, ($resp.status | Out-String).Trim()) -ForegroundColor Green
    } catch {
        Write-Host ("[FAIL] Sent packet {0}/{1}: {2}" -f $i, $Packets, $_.Exception.Message) -ForegroundColor Red
        exit 3
    }

    if ($i -lt $Packets) {
        Start-Sleep -Milliseconds $DelayMs
    }
}

try {
    $modes = Invoke-RestMethod -Method Get -Uri "$BaseUrl/api/v1/devices/mode" -TimeoutSec 10
    $mode = $modes.PSObject.Properties[$DeviceId].Value
    if ([string]::IsNullOrWhiteSpace($mode)) {
        $mode = "NONE"
    }
    Write-Host ("[INFO] Mode after send: {0}={1}" -f $DeviceId, $mode)
} catch {
    Write-Host ("[WARN] Cannot read mode after send: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Now open Dashboard and check for device:"
Write-Host ("  {0} / patient {1}" -f $DeviceId, $PatientId)
Write-Host ""
Write-Host "If it does not appear after 5-10 seconds:"
Write-Host "  1. Refresh browser with Ctrl+F5."
Write-Host "  2. Check websocket/backend logs."
Write-Host "  3. Re-run this script with -Packets 10."
