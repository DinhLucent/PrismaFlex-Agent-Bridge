const path = require('path');
const rootDir = __dirname;

module.exports = {
    apps: [{
        name: "icub-backend",
        script: "main.py",
        cwd: path.join(rootDir, "backend"),
        // Using pythonw.exe creates NO console window
        interpreter: "pythonw",
        instances: 1,
        autorestart: true,
        watch: false,
        max_memory_restart: '1G',
        env: {
            NODE_ENV: "production",
            PYTHONUNBUFFERED: "1"
        }
    }, {
        name: "icub-frontend",
        script: "node_modules/next/dist/bin/next",
        args: "start",
        cwd: path.join(rootDir, "frontend"),
        interpreter: "node",
        instances: 1,
        autorestart: true,
        watch: false,
        env: {
            NODE_ENV: "production",
            PORT: 3000
        }
    }]
};
