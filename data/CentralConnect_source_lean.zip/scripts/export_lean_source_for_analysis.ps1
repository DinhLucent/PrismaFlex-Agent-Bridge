param(
    [string]$OutputParent
)

$ErrorActionPreference = "Stop"

function Get-GitValue {
    param(
        [string]$Root,
        [string[]]$Args
    )

    try {
        $result = & git -C $Root @Args 2>$null
        if ($LASTEXITCODE -ne 0) {
            return $null
        }
        return ($result -join [Environment]::NewLine).Trim()
    } catch {
        return $null
    }
}

$repoRoot = Split-Path $PSScriptRoot -Parent
if (-not $OutputParent) {
    $OutputParent = Join-Path $repoRoot "exports"
}

New-Item -ItemType Directory -Force -Path $OutputParent | Out-Null

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$packageName = "SOURCE_ANALYSIS_PACK_$stamp"
$packageDir = Join-Path $OutputParent $packageName
$zipPath = Join-Path $OutputParent ($packageName + ".zip")

if (Test-Path $packageDir) { Remove-Item -Recurse -Force $packageDir }
if (Test-Path $zipPath) { Remove-Item -Force $zipPath }

New-Item -ItemType Directory -Force -Path $packageDir | Out-Null

$includeDirs = @(
    "backend",
    "frontend",
    "prismaflex_lib",
    "scripts"
)

$excludePatterns = @(
    "\.git($|\\)",
    "\\node_modules($|\\)",
    "\\\.next($|\\)",
    "\\out($|\\)",
    "\\logs($|\\)",
    "\\data($|\\)",
    "\\releases($|\\)",
    "\\exports($|\\)",
    "\\checkvar($|\\)",
    "\\QA($|\\)",
    "\\__pycache__($|\\)",
    "\\.pytest_cache($|\\)",
    "\.db$",
    "\.sqlite$",
    "\.sqlite3$",
    "\.log$",
    "\.zip$",
    "\.rar$",
    "\.gz$",
    "\.pyc$",
    "\.pyo$",
    "\.md$"
)

function Should-Exclude {
    param([string]$Path)
    foreach ($pattern in $excludePatterns) {
        if ($Path -match $pattern) {
            return $true
        }
    }
    return $false
}

function Copy-TreeLean {
    param(
        [string]$SourceRoot,
        [string]$RelativeDir,
        [string]$PackageRoot
    )

    $fullSource = Join-Path $SourceRoot $RelativeDir
    if (-not (Test-Path $fullSource)) {
        return
    }

    Get-ChildItem -Path $fullSource -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
        $relative = $_.FullName.Substring($SourceRoot.Length).TrimStart("\")
        if (Should-Exclude $relative) {
            return
        }

        $destination = Join-Path $PackageRoot $relative
        if ($_.PSIsContainer) {
            New-Item -ItemType Directory -Force -Path $destination | Out-Null
        } else {
            $destDir = Split-Path -Parent $destination
            New-Item -ItemType Directory -Force -Path $destDir | Out-Null
            Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
        }
    }
}

foreach ($dir in $includeDirs) {
    Copy-TreeLean -SourceRoot $repoRoot -RelativeDir $dir -PackageRoot $packageDir
}

$rootFiles = @(
    "package.json",
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
    "ecosystem.config.js",
    "CREATE_FULL_LEAN_RELEASE_AUTO.bat",
    "COMPARE_SOURCE_ROOTS.bat"
)

foreach ($file in $rootFiles) {
    $full = Join-Path $repoRoot $file
    if (Test-Path $full) {
        Copy-Item -LiteralPath $full -Destination (Join-Path $packageDir $file) -Force
    }
}

$branch = Get-GitValue -Root $repoRoot -Args @("branch", "--show-current")
$head = Get-GitValue -Root $repoRoot -Args @("rev-parse", "HEAD")
$status = Get-GitValue -Root $repoRoot -Args @("status", "--short")

$info = @(
    "SOURCE ANALYSIS PACK",
    "====================",
    "",
    "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')",
    "Source root: $repoRoot",
    "Branch: $branch",
    "Commit: $head",
    ""
)

if ($status) {
    $info += "Working tree status:"
    $info += $status
    $info += ""
}

$info += @(
    "Included directories:",
    "  - backend",
    "  - frontend",
    "  - prismaflex_lib",
    "  - scripts",
    "  - docs",
    "",
    "Excluded heavy/runtime paths:",
    "  - .git",
    "  - node_modules",
    "  - .next",
    "  - out",
    "  - backend\\data",
    "  - logs",
    "  - releases",
    "  - exports",
    "  - checkvar",
    "  - QA",
    "  - db/log/archive/binary artifacts"
)

$info | Set-Content -Path (Join-Path $packageDir "PACK_INFO.txt") -Encoding UTF8

Compress-Archive -Path (Join-Path $packageDir "*") -DestinationPath $zipPath -CompressionLevel Optimal

$fileCount = (Get-ChildItem -Path $packageDir -Recurse -File | Measure-Object).Count
$size = (Get-ChildItem -Path $packageDir -Recurse -File | Measure-Object -Property Length -Sum).Sum

Write-Host ""
Write-Host "Lean source package created:" -ForegroundColor Green
Write-Host "  Folder : $packageDir"
Write-Host "  Zip    : $zipPath"
Write-Host "  Files  : $fileCount"
Write-Host "  Bytes  : $size"
