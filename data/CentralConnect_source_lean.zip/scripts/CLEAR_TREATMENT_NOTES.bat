@echo off
setlocal
cd /d "%~dp0.."

echo.
echo Usage examples:
echo   CLEAR_TREATMENT_NOTES.bat --treatment-id YOUR-UUID --dry-run
echo   CLEAR_TREATMENT_NOTES.bat --treatment-id YOUR-UUID --yes
echo   CLEAR_TREATMENT_NOTES.bat --all --dry-run
echo   CLEAR_TREATMENT_NOTES.bat --all --yes
echo.

python backend\scripts\clear_treatment_notes.py %*
exit /b %errorlevel%
